
build/bootloader.elf:     file format elf32-littleriscv


Disassembly of section .init:

f9000000 <_start>:
f9000000:	00001197          	auipc	gp,0x1
f9000004:	b9018193          	addi	gp,gp,-1136 # f9000b90 <__global_pointer$>
f9000008:	8201a023          	sw	zero,-2016(gp) # f90003b0 <smp_lottery_lock>

f900000c <smp_tyranny>:
f900000c:	f1402573          	csrr	a0,mhartid
f9000010:	c515                	beqz	a0,f900003c <init>

f9000012 <smp_slave>:
f9000012:	8201a503          	lw	a0,-2016(gp) # f90003b0 <smp_lottery_lock>
f9000016:	dd75                	beqz	a0,f9000012 <smp_slave>
f9000018:	0220000f          	fence	r,r
f900001c:	0000100f          	fence.i
f9000020:	81c1a783          	lw	a5,-2020(gp) # f90003ac <__bss_start>
f9000024:	4501                	li	a0,0
f9000026:	4581                	li	a1,0
f9000028:	4601                	li	a2,0
f900002a:	8782                	jr	a5

f900002c <smp_unlock>:
f900002c:	80a1ae23          	sw	a0,-2020(gp) # f90003ac <__bss_start>
f9000030:	0110000f          	fence	w,w
f9000034:	4505                	li	a0,1
f9000036:	82a1a023          	sw	a0,-2016(gp) # f90003b0 <smp_lottery_lock>
f900003a:	8082                	ret

f900003c <init>:
f900003c:	93018113          	addi	sp,gp,-1744 # f90004c0 <_sp>
f9000040:	00000517          	auipc	a0,0x0
f9000044:	2e050513          	addi	a0,a0,736 # f9000320 <_data>
f9000048:	00000597          	auipc	a1,0x0
f900004c:	2d858593          	addi	a1,a1,728 # f9000320 <_data>
f9000050:	81c18613          	addi	a2,gp,-2020 # f90003ac <__bss_start>
f9000054:	00c5fa63          	bgeu	a1,a2,f9000068 <init+0x2c>
f9000058:	00052283          	lw	t0,0(a0)
f900005c:	0055a023          	sw	t0,0(a1)
f9000060:	0511                	addi	a0,a0,4
f9000062:	0591                	addi	a1,a1,4
f9000064:	fec5eae3          	bltu	a1,a2,f9000058 <init+0x1c>
f9000068:	81c18513          	addi	a0,gp,-2020 # f90003ac <__bss_start>
f900006c:	82818593          	addi	a1,gp,-2008 # f90003b8 <_end>
f9000070:	00b57763          	bgeu	a0,a1,f900007e <init+0x42>
f9000074:	00052023          	sw	zero,0(a0)
f9000078:	0511                	addi	a0,a0,4
f900007a:	feb56de3          	bltu	a0,a1,f9000074 <init+0x38>
f900007e:	2c25                	jal	f90002b6 <__libc_init_array>
f9000080:	2019                	jal	f9000086 <main>

f9000082 <mainDone>:
f9000082:	a001                	j	f9000082 <mainDone>

f9000084 <_init>:
f9000084:	8082                	ret

Disassembly of section .text:

f9000086 <main>:
f9000086:	1141                	addi	sp,sp,-16
f9000088:	c606                	sw	ra,12(sp)
f900008a:	20f9                	jal	f9000158 <configure_uart>
f900008c:	40b2                	lw	ra,12(sp)
f900008e:	0141                	addi	sp,sp,16
f9000090:	a8e1                	j	f9000168 <bspMain>

f9000092 <spi_write.constprop.11>:
f9000092:	6741                	lui	a4,0x10
f9000094:	e80306b7          	lui	a3,0xe8030
f9000098:	177d                	addi	a4,a4,-1
f900009a:	42dc                	lw	a5,4(a3)
f900009c:	8ff9                	and	a5,a5,a4
f900009e:	dff5                	beqz	a5,f900009a <spi_write.constprop.11+0x8>
f90000a0:	10056513          	ori	a0,a0,256
f90000a4:	c288                	sw	a0,0(a3)
f90000a6:	8082                	ret

f90000a8 <spiFlash_f2m_.constprop.1>:
f90000a8:	1101                	addi	sp,sp,-32
f90000aa:	cc22                	sw	s0,24(sp)
f90000ac:	842a                	mv	s0,a0
f90000ae:	452d                	li	a0,11
f90000b0:	c62e                	sw	a1,12(sp)
f90000b2:	c432                	sw	a2,8(sp)
f90000b4:	ce06                	sw	ra,28(sp)
f90000b6:	3ff1                	jal	f9000092 <spi_write.constprop.11>
f90000b8:	01045513          	srli	a0,s0,0x10
f90000bc:	0ff57513          	andi	a0,a0,255
f90000c0:	3fc9                	jal	f9000092 <spi_write.constprop.11>
f90000c2:	4501                	li	a0,0
f90000c4:	37f9                	jal	f9000092 <spi_write.constprop.11>
f90000c6:	4501                	li	a0,0
f90000c8:	37e9                	jal	f9000092 <spi_write.constprop.11>
f90000ca:	4501                	li	a0,0
f90000cc:	37d9                	jal	f9000092 <spi_write.constprop.11>
f90000ce:	45b2                	lw	a1,12(sp)
f90000d0:	4622                	lw	a2,8(sp)
f90000d2:	6741                	lui	a4,0x10
f90000d4:	e80307b7          	lui	a5,0xe8030
f90000d8:	962e                	add	a2,a2,a1
f90000da:	177d                	addi	a4,a4,-1
f90000dc:	20000813          	li	a6,512
f90000e0:	43d4                	lw	a3,4(a5)
f90000e2:	8ef9                	and	a3,a3,a4
f90000e4:	def5                	beqz	a3,f90000e0 <spiFlash_f2m_.constprop.1+0x38>
f90000e6:	0107a023          	sw	a6,0(a5) # e8030000 <__global_pointer$+0xef02f470>
f90000ea:	43d4                	lw	a3,4(a5)
f90000ec:	82c1                	srli	a3,a3,0x10
f90000ee:	def5                	beqz	a3,f90000ea <spiFlash_f2m_.constprop.1+0x42>
f90000f0:	4388                	lw	a0,0(a5)
f90000f2:	00158693          	addi	a3,a1,1
f90000f6:	00a58023          	sb	a0,0(a1)
f90000fa:	00d61663          	bne	a2,a3,f9000106 <spiFlash_f2m_.constprop.1+0x5e>
f90000fe:	40f2                	lw	ra,28(sp)
f9000100:	4462                	lw	s0,24(sp)
f9000102:	6105                	addi	sp,sp,32
f9000104:	8082                	ret
f9000106:	85b6                	mv	a1,a3
f9000108:	bfe1                	j	f90000e0 <spiFlash_f2m_.constprop.1+0x38>

f900010a <_putchar_s>:
f900010a:	e80106b7          	lui	a3,0xe8010
f900010e:	00054703          	lbu	a4,0(a0)
f9000112:	e311                	bnez	a4,f9000116 <_putchar_s+0xc>
f9000114:	8082                	ret
f9000116:	0505                	addi	a0,a0,1
f9000118:	42dc                	lw	a5,4(a3)
f900011a:	83c1                	srli	a5,a5,0x10
f900011c:	0ff7f793          	andi	a5,a5,255
f9000120:	dfe5                	beqz	a5,f9000118 <_putchar_s+0xe>
f9000122:	c298                	sw	a4,0(a3)
f9000124:	b7ed                	j	f900010e <_putchar_s+0x4>

f9000126 <spi_waitXferBusy.constprop.6>:
f9000126:	f8b0c7b7          	lui	a5,0xf8b0c
f900012a:	ff87a703          	lw	a4,-8(a5) # f8b0bff8 <__global_pointer$+0xffb0b468>
f900012e:	f8b0c6b7          	lui	a3,0xf8b0c
f9000132:	0c870713          	addi	a4,a4,200 # 100c8 <__stack_size+0xffc8>
f9000136:	ff86a783          	lw	a5,-8(a3) # f8b0bff8 <__global_pointer$+0xffb0b468>
f900013a:	40f707b3          	sub	a5,a4,a5
f900013e:	fe07dce3          	bgez	a5,f9000136 <spi_waitXferBusy.constprop.6+0x10>
f9000142:	6741                	lui	a4,0x10
f9000144:	e8030637          	lui	a2,0xe8030
f9000148:	177d                	addi	a4,a4,-1
f900014a:	10000693          	li	a3,256
f900014e:	425c                	lw	a5,4(a2)
f9000150:	8ff9                	and	a5,a5,a4
f9000152:	fed79ee3          	bne	a5,a3,f900014e <spi_waitXferBusy.constprop.6+0x28>
f9000156:	8082                	ret

f9000158 <configure_uart>:
f9000158:	e80107b7          	lui	a5,0xe8010
f900015c:	0d800713          	li	a4,216
f9000160:	c798                	sw	a4,8(a5)
f9000162:	471d                	li	a4,7
f9000164:	c7d8                	sw	a4,12(a5)
f9000166:	8082                	ret

f9000168 <bspMain>:
f9000168:	f9000537          	lui	a0,0xf9000
f900016c:	1141                	addi	sp,sp,-16
f900016e:	32050513          	addi	a0,a0,800 # f9000320 <__global_pointer$+0xfffff790>
f9000172:	c606                	sw	ra,12(sp)
f9000174:	3f59                	jal	f900010a <_putchar_s>
f9000176:	37cd                	jal	f9000158 <configure_uart>
f9000178:	f9000537          	lui	a0,0xf9000
f900017c:	34450513          	addi	a0,a0,836 # f9000344 <__global_pointer$+0xfffff7b4>
f9000180:	3769                	jal	f900010a <_putchar_s>
f9000182:	e80307b7          	lui	a5,0xe8030
f9000186:	0007a423          	sw	zero,8(a5) # e8030008 <__global_pointer$+0xef02f478>
f900018a:	4709                	li	a4,2
f900018c:	d398                	sw	a4,32(a5)
f900018e:	4695                	li	a3,5
f9000190:	d3d4                	sw	a3,36(a5)
f9000192:	d798                	sw	a4,40(a5)
f9000194:	471d                	li	a4,7
f9000196:	d7d8                	sw	a4,44(a5)
f9000198:	3779                	jal	f9000126 <spi_waitXferBusy.constprop.6>
f900019a:	6741                	lui	a4,0x10
f900019c:	e80306b7          	lui	a3,0xe8030
f90001a0:	177d                	addi	a4,a4,-1
f90001a2:	42dc                	lw	a5,4(a3)
f90001a4:	8ff9                	and	a5,a5,a4
f90001a6:	dff5                	beqz	a5,f90001a2 <bspMain+0x3a>
f90001a8:	6785                	lui	a5,0x1
f90001aa:	80078793          	addi	a5,a5,-2048 # 800 <__stack_size+0x700>
f90001ae:	6741                	lui	a4,0x10
f90001b0:	c29c                	sw	a5,0(a3)
f90001b2:	177d                	addi	a4,a4,-1
f90001b4:	e80306b7          	lui	a3,0xe8030
f90001b8:	42dc                	lw	a5,4(a3)
f90001ba:	8ff9                	and	a5,a5,a4
f90001bc:	dff5                	beqz	a5,f90001b8 <bspMain+0x50>
f90001be:	6785                	lui	a5,0x1
f90001c0:	88078793          	addi	a5,a5,-1920 # 880 <__stack_size+0x780>
f90001c4:	c29c                	sw	a5,0(a3)
f90001c6:	0ab00513          	li	a0,171
f90001ca:	35e1                	jal	f9000092 <spi_write.constprop.11>
f90001cc:	6741                	lui	a4,0x10
f90001ce:	e80306b7          	lui	a3,0xe8030
f90001d2:	177d                	addi	a4,a4,-1
f90001d4:	42dc                	lw	a5,4(a3)
f90001d6:	8ff9                	and	a5,a5,a4
f90001d8:	dff5                	beqz	a5,f90001d4 <bspMain+0x6c>
f90001da:	6785                	lui	a5,0x1
f90001dc:	80078793          	addi	a5,a5,-2048 # 800 <__stack_size+0x700>
f90001e0:	c29c                	sw	a5,0(a3)
f90001e2:	3791                	jal	f9000126 <spi_waitXferBusy.constprop.6>
f90001e4:	f8b0c7b7          	lui	a5,0xf8b0c
f90001e8:	ff87a703          	lw	a4,-8(a5) # f8b0bff8 <__global_pointer$+0xffb0b468>
f90001ec:	6795                	lui	a5,0x5
f90001ee:	e2078793          	addi	a5,a5,-480 # 4e20 <__stack_size+0x4d20>
f90001f2:	973e                	add	a4,a4,a5
f90001f4:	f8b0c6b7          	lui	a3,0xf8b0c
f90001f8:	ff86a783          	lw	a5,-8(a3) # f8b0bff8 <__global_pointer$+0xffb0b468>
f90001fc:	40f707b3          	sub	a5,a4,a5
f9000200:	fe07dce3          	bgez	a5,f90001f8 <bspMain+0x90>
f9000204:	f9000537          	lui	a0,0xf9000
f9000208:	35850513          	addi	a0,a0,856 # f9000358 <__global_pointer$+0xfffff7c8>
f900020c:	3dfd                	jal	f900010a <_putchar_s>
f900020e:	6741                	lui	a4,0x10
f9000210:	e80306b7          	lui	a3,0xe8030
f9000214:	177d                	addi	a4,a4,-1
f9000216:	42dc                	lw	a5,4(a3)
f9000218:	8ff9                	and	a5,a5,a4
f900021a:	dff5                	beqz	a5,f9000216 <bspMain+0xae>
f900021c:	6785                	lui	a5,0x1
f900021e:	88078793          	addi	a5,a5,-1920 # 880 <__stack_size+0x780>
f9000222:	c29c                	sw	a5,0(a3)
f9000224:	00040637          	lui	a2,0x40
f9000228:	020005b7          	lui	a1,0x2000
f900022c:	00600537          	lui	a0,0x600
f9000230:	3da5                	jal	f90000a8 <spiFlash_f2m_.constprop.1>
f9000232:	6741                	lui	a4,0x10
f9000234:	e80306b7          	lui	a3,0xe8030
f9000238:	177d                	addi	a4,a4,-1
f900023a:	42dc                	lw	a5,4(a3)
f900023c:	8ff9                	and	a5,a5,a4
f900023e:	dff5                	beqz	a5,f900023a <bspMain+0xd2>
f9000240:	6785                	lui	a5,0x1
f9000242:	80078793          	addi	a5,a5,-2048 # 800 <__stack_size+0x700>
f9000246:	f9000537          	lui	a0,0xf9000
f900024a:	c29c                	sw	a5,0(a3)
f900024c:	36850513          	addi	a0,a0,872 # f9000368 <__global_pointer$+0xfffff7d8>
f9000250:	3d6d                	jal	f900010a <_putchar_s>
f9000252:	6741                	lui	a4,0x10
f9000254:	e80306b7          	lui	a3,0xe8030
f9000258:	177d                	addi	a4,a4,-1
f900025a:	42dc                	lw	a5,4(a3)
f900025c:	8ff9                	and	a5,a5,a4
f900025e:	dff5                	beqz	a5,f900025a <bspMain+0xf2>
f9000260:	6785                	lui	a5,0x1
f9000262:	88078793          	addi	a5,a5,-1920 # 880 <__stack_size+0x780>
f9000266:	c29c                	sw	a5,0(a3)
f9000268:	000c0637          	lui	a2,0xc0
f900026c:	020405b7          	lui	a1,0x2040
f9000270:	00680537          	lui	a0,0x680
f9000274:	3d15                	jal	f90000a8 <spiFlash_f2m_.constprop.1>
f9000276:	6741                	lui	a4,0x10
f9000278:	e80306b7          	lui	a3,0xe8030
f900027c:	177d                	addi	a4,a4,-1
f900027e:	42dc                	lw	a5,4(a3)
f9000280:	8ff9                	and	a5,a5,a4
f9000282:	dff5                	beqz	a5,f900027e <bspMain+0x116>
f9000284:	6785                	lui	a5,0x1
f9000286:	80078793          	addi	a5,a5,-2048 # 800 <__stack_size+0x700>
f900028a:	f9000537          	lui	a0,0xf9000
f900028e:	c29c                	sw	a5,0(a3)
f9000290:	37850513          	addi	a0,a0,888 # f9000378 <__global_pointer$+0xfffff7e8>
f9000294:	3d9d                	jal	f900010a <_putchar_s>
f9000296:	02000537          	lui	a0,0x2000
f900029a:	3b49                	jal	f900002c <smp_unlock>
f900029c:	f9000537          	lui	a0,0xf9000
f90002a0:	38850513          	addi	a0,a0,904 # f9000388 <__global_pointer$+0xfffff7f8>
f90002a4:	359d                	jal	f900010a <_putchar_s>
f90002a6:	40b2                	lw	ra,12(sp)
f90002a8:	4601                	li	a2,0
f90002aa:	4581                	li	a1,0
f90002ac:	4501                	li	a0,0
f90002ae:	02000337          	lui	t1,0x2000
f90002b2:	0141                	addi	sp,sp,16
f90002b4:	8302                	jr	t1

f90002b6 <__libc_init_array>:
f90002b6:	1141                	addi	sp,sp,-16
f90002b8:	c422                	sw	s0,8(sp)
f90002ba:	c04a                	sw	s2,0(sp)
f90002bc:	00000417          	auipc	s0,0x0
f90002c0:	06440413          	addi	s0,s0,100 # f9000320 <_data>
f90002c4:	00000917          	auipc	s2,0x0
f90002c8:	05c90913          	addi	s2,s2,92 # f9000320 <_data>
f90002cc:	40890933          	sub	s2,s2,s0
f90002d0:	c606                	sw	ra,12(sp)
f90002d2:	c226                	sw	s1,4(sp)
f90002d4:	40295913          	srai	s2,s2,0x2
f90002d8:	00090963          	beqz	s2,f90002ea <__libc_init_array+0x34>
f90002dc:	4481                	li	s1,0
f90002de:	401c                	lw	a5,0(s0)
f90002e0:	0485                	addi	s1,s1,1
f90002e2:	0411                	addi	s0,s0,4
f90002e4:	9782                	jalr	a5
f90002e6:	fe991ce3          	bne	s2,s1,f90002de <__libc_init_array+0x28>
f90002ea:	00000417          	auipc	s0,0x0
f90002ee:	03640413          	addi	s0,s0,54 # f9000320 <_data>
f90002f2:	00000917          	auipc	s2,0x0
f90002f6:	02e90913          	addi	s2,s2,46 # f9000320 <_data>
f90002fa:	40890933          	sub	s2,s2,s0
f90002fe:	40295913          	srai	s2,s2,0x2
f9000302:	00090963          	beqz	s2,f9000314 <__libc_init_array+0x5e>
f9000306:	4481                	li	s1,0
f9000308:	401c                	lw	a5,0(s0)
f900030a:	0485                	addi	s1,s1,1
f900030c:	0411                	addi	s0,s0,4
f900030e:	9782                	jalr	a5
f9000310:	fe991ce3          	bne	s2,s1,f9000308 <__libc_init_array+0x52>
f9000314:	40b2                	lw	ra,12(sp)
f9000316:	4422                	lw	s0,8(sp)
f9000318:	4492                	lw	s1,4(sp)
f900031a:	4902                	lw	s2,0(sp)
f900031c:	0141                	addi	sp,sp,16
f900031e:	8082                	ret
