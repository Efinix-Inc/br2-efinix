#ifndef HEADER_INTC_H_
#define HEADER_INTC_H_

#include "bsp.h"

void IntcInitialize();

#endif
