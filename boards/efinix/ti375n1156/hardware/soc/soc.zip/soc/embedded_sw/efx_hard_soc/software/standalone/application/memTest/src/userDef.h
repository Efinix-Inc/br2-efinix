#define MEM_LOC             ((volatile uint32_t*)0x00010000) 
#define MAX_WORDS           (4 * 1024 * 1024)
