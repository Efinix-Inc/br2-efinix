RV_M=yes
RV_C=yes
RV_A=yes
RV_F=yes
RV_D=yes
CFLAGS+=-DSMP
DEBUG?=no
DEBUG_OG?=no
