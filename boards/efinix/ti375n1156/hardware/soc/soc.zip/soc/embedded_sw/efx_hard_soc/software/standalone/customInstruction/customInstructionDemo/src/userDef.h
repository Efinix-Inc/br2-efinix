#define tinyEncryption_lowerword(rs1, rs2) opcode_R(CUSTOM0, 0x00, 0x00, rs1, rs2)
#define tinyEncryption_upperword(rs1, rs2) opcode_R(CUSTOM0, 0x01, 0x00, rs1, rs2)
