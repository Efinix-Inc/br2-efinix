#include "soc.h"

#define STACK_PER_HART 	4096
#define HART_COUNT 		4


