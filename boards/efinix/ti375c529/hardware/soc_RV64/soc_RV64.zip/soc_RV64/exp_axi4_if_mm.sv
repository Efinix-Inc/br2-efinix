interface axi4_if_mm#(parameter ADR_WIDTH=32,parameter D_WIDTH=32,parameter ID_WIDTH=6) (input clk, input rst);
    logic   [ID_WIDTH-1:0]  awid;
    logic   [ADR_WIDTH-1:0] awaddr;
    logic   [7:0]           awlen;
    logic   [2:0]           awsize;
    logic   [1:0]           awburst;
    logic   [3:0]           awcache;
    logic   [2:0]           awprot;
    logic   [3:0]           awregion;
    logic   [3:0]           awqos;
    logic                   awallstrb;
    logic                   awlock;
    logic                   awvalid;
    logic                   awready;
    logic   [D_WIDTH-1:0]   wdata;
    logic   [D_WIDTH/8-1:0] wstrb;
    logic                   wlast;
    logic                   wvalid;
    logic                   wready;
    logic   [ID_WIDTH-1:0]  bid;
    logic                   bready;
    logic   [1:0]           bresp;
    logic                   bvalid;
    logic   [ID_WIDTH-1:0]  arid;
    logic   [ADR_WIDTH-1:0] araddr;
    logic   [7:0]           arlen;
    logic   [2:0]           arsize;
    logic   [1:0]           arburst;
    logic                   arlock;
    logic   [3:0]           arcache;
    logic   [2:0]           arprot;
    logic   [3:0]           arregion;
    logic   [3:0]           arqos;
    logic                   arvalid;
    logic                   arready;   
    logic   [ID_WIDTH-1:0]  rid;
    logic                   rvalid;
    logic   [D_WIDTH-1:0]   rdata;
    logic                   rlast;
    logic                   rready;
    logic   [1:0]           rresp;

modport master (
    output awid,awaddr,awlen,awsize,awburst,awlock,awcache,awprot,awqos,awregion,awallstrb,awvalid,wdata,wstrb,wlast,wvalid,bready,arid,araddr,arlen,arsize,arburst,arlock,arprot,arqos,arregion,arcache,arvalid,rready,
    input clk,rst,awready,wready,bid,bresp,bvalid,arready,rid,rvalid,rdata,rresp,rlast
);

modport slave (
    input clk,rst,awid,awaddr,awlen,awsize,awburst,awlock,awcache,awprot,awqos,awregion,awallstrb,awvalid,wdata,wstrb,wlast,wvalid,bready,arid,araddr,arlen,arsize,arburst,arlock,arprot,arqos,arregion,arcache,arvalid,rready,
    output awready,wready,bid,bresp,bvalid,arready,rid,rvalid,rdata,rresp,rlast
);
endinterface