/////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
//
// Description:
// Example top file for EfxSapphireSocRV64
//
// Language:  Verilog 2001
//
// ------------------------------------------------------------------------------
// REVISION:
//  $Snapshot: $
//  $Id:$
//
// History:
// 1.0 Initial Release. 
/////////////////////////////////////////////////////////////////////////////////
`timescale 1ns / 1ps

module top_soc (
input		io_peripheralClk,
input		io_memoryClk,
output		system_uart_0_io_txd,
input		system_uart_0_io_rxd,
output		system_spi_0_io_sclk_write,
output		system_spi_0_io_data_0_writeEnable,
input		system_spi_0_io_data_0_read,
output		system_spi_0_io_data_0_write,
output		system_spi_0_io_data_1_writeEnable,
input		system_spi_0_io_data_1_read,
output		system_spi_0_io_data_1_write,
output [0:0] system_spi_0_io_ss,
output		system_spi_1_io_sclk_write,
output		system_spi_1_io_data_0_writeEnable,
input		system_spi_1_io_data_0_read,
output		system_spi_1_io_data_0_write,
output		system_spi_1_io_data_1_writeEnable,
input		system_spi_1_io_data_1_read,
output		system_spi_1_io_data_1_write,
output [0:0] system_spi_1_io_ss,
input [3:0] system_gpio_0_io_read,
output [3:0] system_gpio_0_io_write,
output [3:0] system_gpio_0_io_writeEnable,
input		jtag_inst1_TCK,
input		jtag_inst1_TDI,
output		jtag_inst1_TDO,
input		jtag_inst1_SEL,
input		jtag_inst1_CAPTURE,
input		jtag_inst1_SHIFT,
input		jtag_inst1_UPDATE,
input		jtag_inst1_RESET,
output		cfg_start,
output		cfg_reset,
output		cfg_sel,
input		cfg_done,
output		cfg_ok,
output		io_memoryResetn,
output		memoryCheckerPass,
output		ddr_pll_rstn,
input		ddr_pll_locked,
output		memoryClk_rstn,
output		io_ddrA_ar_valid,
input		io_ddrA_ar_ready,
output [32:0] io_ddrA_ar_payload_addr,
output [5:0] io_ddrA_ar_payload_id,
output [7:0] io_ddrA_ar_payload_len,
output [2:0] io_ddrA_ar_payload_size,
output [1:0] io_ddrA_ar_payload_burst,
output		io_ddrA_ar_payload_lock,
output		io_ddrA_ar_apcmd,
output		io_ddrA_ar_payload_qos,
output		io_ddrA_aw_valid,
input		io_ddrA_aw_ready,
output [32:0] io_ddrA_aw_payload_addr,
output [5:0] io_ddrA_aw_payload_id,
output [7:0] io_ddrA_aw_payload_len,
output [2:0] io_ddrA_aw_payload_size,
output [1:0] io_ddrA_aw_payload_burst,
output		io_ddrA_aw_payload_lock,
output [3:0] io_ddrA_aw_payload_cache,
output		io_ddrA_aw_payload_qos,
output		io_ddrA_aw_payload_allstrb,
output		io_ddrA_aw_apcmd,
output		io_ddrA_awcobuf,
output		io_ddrA_w_valid,
input		io_ddrA_w_ready,
output [511:0] io_ddrA_w_payload_data,
output [63:0] io_ddrA_w_payload_strb,
output		io_ddrA_w_payload_last,
input		io_ddrA_b_valid,
output		io_ddrA_b_ready,
input [1:0] io_ddrA_b_payload_resp,
input [5:0] io_ddrA_b_payload_id,
input		io_ddrA_r_valid,
output		io_ddrA_r_ready,
input [511:0] io_ddrA_r_payload_data,
input [5:0] io_ddrA_r_payload_id,
input [1:0] io_ddrA_r_payload_resp,
input		io_ddrA_r_payload_last,
output		system_i2c_0_io_sda_writeEnable,
output		system_i2c_0_io_sda_write,
input		system_i2c_0_io_sda_read,
output		system_i2c_0_io_scl_writeEnable,
output		system_i2c_0_io_scl_write,
input		system_i2c_0_io_scl_read,

output		systemClk_rstn,
input		systemClk_locked,
input		io_systemClk,
input		io_asyncResetn

);
/////////////////////////////////////////////////////////////////////////////	
//Reset and PLL
wire         reset;
wire         reset_sync;
wire         w_io_asyncReset;
wire         io_systemReset;
wire         io_peripheralReset;
wire         io_ndmreset;
wire         cpu1_customInstruction_cmd_valid;
wire         cpu1_customInstruction_cmd_ready;
wire [  9:0] cpu1_customInstruction_cmd_function_id;
wire [ 63:0] cpu1_customInstruction_cmd_inputs_0;
wire [ 63:0] cpu1_customInstruction_cmd_inputs_1;
wire         cpu1_customInstruction_rsp_valid;
wire         cpu1_customInstruction_rsp_ready;
wire [ 63:0] cpu1_customInstruction_rsp_outputs_0;
wire         cpu3_customInstruction_cmd_valid;
wire         cpu3_customInstruction_cmd_ready;
wire [  9:0] cpu3_customInstruction_cmd_function_id;
wire [ 63:0] cpu3_customInstruction_cmd_inputs_0;
wire [ 63:0] cpu3_customInstruction_cmd_inputs_1;
wire         cpu3_customInstruction_rsp_valid;
wire         cpu3_customInstruction_rsp_ready;
wire [ 63:0] cpu3_customInstruction_rsp_outputs_0;
wire         axi4Interrupt;
axi4_if_mm#(.ADR_WIDTH(32),.D_WIDTH(32)) axiA_mm(io_peripheralClk,io_peripheralReset);
wire [  7:0] m_awid_0;
wire [ 36:0] m_awaddr_0;
wire [  7:0] m_awlen_0;
wire [  2:0] m_awsize_0;
wire [  1:0] m_awburst_0;
wire [  1:0] m_awlock_0;
wire         m_awvalid_0;
wire         m_awready_0;
wire [  3:0] m_awregion_0;
wire [  3:0] m_awcache_0;
wire [  3:0] m_awqos_0;
wire [  2:0] m_awprot_0;
wire [  7:0] m_wid_0;
wire [255:0] m_wdata_0;
wire [31:0] m_wstrb_0;
wire         m_wlast_0;
wire         m_wvalid_0;
wire         m_wready_0;
wire [  7:0] m_arid_0;
wire [ 36:0] m_araddr_0;
wire [  7:0] m_arlen_0;
wire [  2:0] m_arsize_0;
wire [  1:0] m_arburst_0;
wire [  1:0] m_arlock_0;
wire         m_arvalid_0;
wire         m_arready_0;
wire [  3:0] m_arregion_0;
wire [  3:0] m_arcache_0;
wire [  3:0] m_arqos_0;
wire [  2:0] m_arprot_0;
wire [  3:0] m_rid_0;
wire [255:0] m_rdata_0;
wire         m_rlast_0;
wire         m_rvalid_0;
wire         m_rready_0;
wire [  1:0] m_rresp_0;
wire [  7:0] m_bid_0;
wire [  1:0] m_bresp_0;
wire         m_bvalid_0;
wire         m_bready_0;
wire         m_pass_0;
wire         m_start_0;
wire         io_axiMasterReset_0;
wire         cpu2_customInstruction_cmd_valid;
wire         cpu2_customInstruction_cmd_ready;
wire [  9:0] cpu2_customInstruction_cmd_function_id;
wire [ 63:0] cpu2_customInstruction_cmd_inputs_0;
wire [ 63:0] cpu2_customInstruction_cmd_inputs_1;
wire         cpu2_customInstruction_rsp_valid;
wire         cpu2_customInstruction_rsp_ready;
wire [ 63:0] cpu2_customInstruction_rsp_outputs_0;
wire [  7:0] m_awid_1;
wire [ 36:0] m_awaddr_1;
wire [  7:0] m_awlen_1;
wire [  2:0] m_awsize_1;
wire [  1:0] m_awburst_1;
wire [  1:0] m_awlock_1;
wire         m_awvalid_1;
wire         m_awready_1;
wire [  3:0] m_awregion_1;
wire [  3:0] m_awcache_1;
wire [  3:0] m_awqos_1;
wire [  2:0] m_awprot_1;
wire [  7:0] m_wid_1;
wire [255:0] m_wdata_1;
wire [31:0] m_wstrb_1;
wire         m_wlast_1;
wire         m_wvalid_1;
wire         m_wready_1;
wire [  7:0] m_arid_1;
wire [ 36:0] m_araddr_1;
wire [  7:0] m_arlen_1;
wire [  2:0] m_arsize_1;
wire [  1:0] m_arburst_1;
wire [  1:0] m_arlock_1;
wire         m_arvalid_1;
wire         m_arready_1;
wire [  3:0] m_arregion_1;
wire [  3:0] m_arcache_1;
wire [  3:0] m_arqos_1;
wire [  2:0] m_arprot_1;
wire [  3:0] m_rid_1;
wire [255:0] m_rdata_1;
wire         m_rlast_1;
wire         m_rvalid_1;
wire         m_rready_1;
wire [  1:0] m_rresp_1;
wire [  7:0] m_bid_1;
wire [  1:0] m_bresp_1;
wire         m_bvalid_1;
wire         m_bready_1;
wire         m_pass_1;
wire         m_start_1;
wire         io_axiMasterReset_1;
wire         cpu0_customInstruction_cmd_valid;
wire         cpu0_customInstruction_cmd_ready;
wire [  9:0] cpu0_customInstruction_cmd_function_id;
wire [ 63:0] cpu0_customInstruction_cmd_inputs_0;
wire [ 63:0] cpu0_customInstruction_cmd_inputs_1;
wire         cpu0_customInstruction_rsp_valid;
wire         cpu0_customInstruction_rsp_ready;
wire [ 63:0] cpu0_customInstruction_rsp_outputs_0;
wire         axiB_reset;
axi4_if_mm#(.ADR_WIDTH(27),.D_WIDTH(256)) axiB_mm(io_memoryClk, axiB_reset);
wire [ 32:0] io_ddrA_ar_payload_addr_i;
wire [ 32:0] io_ddrA_aw_payload_addr_i;
wire [ 29:0] soc_io_ddrA_ar_payload_addr;
wire [ 29:0] soc_io_ddrA_aw_payload_addr;
wire [  5:0] soc_io_ddrA_ar_payload_id;
wire [  5:0] soc_io_ddrA_aw_payload_id;
wire [  5:0] soc_io_ddrA_b_payload_id;
wire [  5:0] soc_io_ddrA_r_payload_id;
wire         soc_io_ddrA_aw_valid;
wire         soc_io_ddrA_aw_ready;
wire [  7:0] soc_io_ddrA_aw_payload_len;
wire [  2:0] soc_io_ddrA_aw_payload_size;
wire [  1:0] soc_io_ddrA_aw_payload_burst;
wire         soc_io_ddrA_aw_payload_lock;
wire [  3:0] soc_io_ddrA_aw_payload_qos;
wire [  3:0] soc_io_ddrA_aw_payload_cache;
wire         soc_io_ddrA_ar_valid;
wire         soc_io_ddrA_ar_ready;
wire [  7:0] soc_io_ddrA_ar_payload_len;
wire [  2:0] soc_io_ddrA_ar_payload_size;
wire [  1:0] soc_io_ddrA_ar_payload_burst;
wire         soc_io_ddrA_ar_payload_lock;
wire [  3:0] soc_io_ddrA_ar_payload_qos;
wire         soc_io_ddrA_w_valid;
wire         soc_io_ddrA_w_ready;
wire [255:0] soc_io_ddrA_w_payload_data;
wire [31:0] soc_io_ddrA_w_payload_strb;
wire         soc_io_ddrA_w_payload_last;
wire         soc_io_ddrA_b_valid;
wire         soc_io_ddrA_b_ready;
wire [  1:0] soc_io_ddrA_b_payload_resp;
wire         soc_io_ddrA_r_valid;
wire         soc_io_ddrA_r_ready;
wire [255:0] soc_io_ddrA_r_payload_data;
wire [  1:0] soc_io_ddrA_r_payload_resp;
wire         soc_io_ddrA_r_payload_last;
wire         w_system_watchdog_hardPanic;
wire [0:0] wire_system_spi_0_io_ss;


/////////////////////////////////////////////////////////////////////////////
//Reset and PLL
assign systemClk_rstn = 1'b1;
assign system_spi_0_io_ss[0] = wire_system_spi_0_io_ss[0];
assign io_ddrA_ar_payload_addr_i = {3'h0, soc_io_ddrA_ar_payload_addr};
assign io_ddrA_aw_payload_addr_i = {3'h0, soc_io_ddrA_aw_payload_addr};
assign system_i2c_0_io_sda_writeEnable = !system_i2c_0_io_sda_write;
assign system_i2c_0_io_scl_writeEnable = !system_i2c_0_io_scl_write;
assign memoryCheckerPass=m_pass_0 & m_pass_1;
assign ddr_pll_rstn = 1'b1;
assign memoryClk_rstn=1'b1;
assign io_memoryResetn = cfg_ok;

assign io_ddrA_ar_apcmd = 1'b0;
assign io_ddrA_aw_payload_allstrb = 1'b0;
assign io_ddrA_aw_apcmd = 1'b0;
assign io_ddrA_awcobuf = 1'b0;
assign reset = ~(io_asyncResetn & systemClk_locked & ddr_pll_locked & cfg_ok);
assign w_io_asyncReset = reset_sync | w_system_watchdog_hardPanic;


/////////////////////////////////////////////////////////////////////////////
reset_synchronizer #(
	.NUM_STAGE(3),
	.ACTIVE_LOW(0)
) reset_synchronizer_inst (
	.reset_in(reset),
	.reset_out(reset_sync),
	.clk(io_systemClk)
);

axi_slave #(
	.D_WIDTH(256),
	.D_DEPTH(32)
) axi_slave_instB (
	.mm(axiB_mm)
);
custom_instruction_tea cpu2_custom_instruction_tea_inst(
	.clk(io_systemClk),
	.reset(io_systemReset),
	.cmd_valid(cpu2_customInstruction_cmd_valid),
	.cmd_ready(cpu2_customInstruction_cmd_ready),
	.cmd_function_id(cpu2_customInstruction_cmd_function_id),
	.cmd_inputs_0(cpu2_customInstruction_cmd_inputs_0),
	.cmd_inputs_1(cpu2_customInstruction_cmd_inputs_1),
	.rsp_valid(cpu2_customInstruction_rsp_valid),
	.rsp_ready(cpu2_customInstruction_rsp_ready),
	.rsp_outputs_0(cpu2_customInstruction_rsp_outputs_0));

custom_instruction_tea cpu0_custom_instruction_tea_inst(
	.clk(io_systemClk),
	.reset(io_systemReset),
	.cmd_valid(cpu0_customInstruction_cmd_valid),
	.cmd_ready(cpu0_customInstruction_cmd_ready),
	.cmd_function_id(cpu0_customInstruction_cmd_function_id),
	.cmd_inputs_0(cpu0_customInstruction_cmd_inputs_0),
	.cmd_inputs_1(cpu0_customInstruction_cmd_inputs_1),
	.rsp_valid(cpu0_customInstruction_rsp_valid),
	.rsp_ready(cpu0_customInstruction_rsp_ready),
	.rsp_outputs_0(cpu0_customInstruction_rsp_outputs_0));

A256To512UpsizerAxi4Upsizer upsizer_inst (
	.io_input_aw_valid(soc_io_ddrA_aw_valid),
	.io_input_aw_ready(soc_io_ddrA_aw_ready),
	.io_input_aw_payload_addr(io_ddrA_aw_payload_addr_i),
	.io_input_aw_payload_id(soc_io_ddrA_aw_payload_id),
	.io_input_aw_payload_region(),
	.io_input_aw_payload_len(soc_io_ddrA_aw_payload_len),
	.io_input_aw_payload_size(soc_io_ddrA_aw_payload_size),
	.io_input_aw_payload_burst(soc_io_ddrA_aw_payload_burst),
	.io_input_aw_payload_lock(soc_io_ddrA_aw_payload_lock),
	.io_input_aw_payload_cache(soc_io_ddrA_aw_payload_cache),
	.io_input_aw_payload_qos(soc_io_ddrA_aw_payload_qos),
	.io_input_aw_payload_prot(),
	.io_input_w_valid(soc_io_ddrA_w_valid),
	.io_input_w_ready(soc_io_ddrA_w_ready),
	.io_input_w_payload_data(soc_io_ddrA_w_payload_data),
	.io_input_w_payload_strb(soc_io_ddrA_w_payload_strb),
	.io_input_w_payload_last(soc_io_ddrA_w_payload_last),
	.io_input_b_valid(soc_io_ddrA_b_valid),
	.io_input_b_ready(soc_io_ddrA_b_ready),
	.io_input_b_payload_id(soc_io_ddrA_b_payload_id),
	.io_input_b_payload_resp(soc_io_ddrA_b_payload_resp),
	.io_input_ar_valid(soc_io_ddrA_ar_valid),
	.io_input_ar_ready(soc_io_ddrA_ar_ready),
	.io_input_ar_payload_addr(io_ddrA_ar_payload_addr_i),
	.io_input_ar_payload_id(soc_io_ddrA_ar_payload_id),
	.io_input_ar_payload_region(),
	.io_input_ar_payload_len(soc_io_ddrA_ar_payload_len),
	.io_input_ar_payload_size(soc_io_ddrA_ar_payload_size),
	.io_input_ar_payload_burst(soc_io_ddrA_ar_payload_burst),
	.io_input_ar_payload_lock(soc_io_ddrA_ar_payload_lock),
	.io_input_ar_payload_cache(),
	.io_input_ar_payload_qos(soc_io_ddrA_ar_payload_qos),
	.io_input_ar_payload_prot(),
	.io_input_r_valid(soc_io_ddrA_r_valid),
	.io_input_r_ready(soc_io_ddrA_r_ready),
	.io_input_r_payload_data(soc_io_ddrA_r_payload_data),
	.io_input_r_payload_id(soc_io_ddrA_r_payload_id),
	.io_input_r_payload_resp(soc_io_ddrA_r_payload_resp),
	.io_input_r_payload_last(soc_io_ddrA_r_payload_last),
	.io_output_aw_valid(io_ddrA_aw_valid),
	.io_output_aw_ready(io_ddrA_aw_ready),
	.io_output_aw_payload_addr(io_ddrA_aw_payload_addr),
	.io_output_aw_payload_id(io_ddrA_aw_payload_id),
	.io_output_aw_payload_region(),
	.io_output_aw_payload_len(io_ddrA_aw_payload_len),
	.io_output_aw_payload_size(io_ddrA_aw_payload_size),
	.io_output_aw_payload_burst(io_ddrA_aw_payload_burst),
	.io_output_aw_payload_lock(io_ddrA_aw_payload_lock),
	.io_output_aw_payload_cache(io_ddrA_aw_payload_cache),
	.io_output_aw_payload_qos(io_ddrA_aw_payload_qos),
	.io_output_aw_payload_prot(),
	.io_output_w_valid(io_ddrA_w_valid),
	.io_output_w_ready(io_ddrA_w_ready),
	.io_output_w_payload_data(io_ddrA_w_payload_data),
	.io_output_w_payload_strb(io_ddrA_w_payload_strb),
	.io_output_w_payload_last(io_ddrA_w_payload_last),
	.io_output_b_valid(io_ddrA_b_valid),
	.io_output_b_ready(io_ddrA_b_ready),
	.io_output_b_payload_id(io_ddrA_b_payload_id),
	.io_output_b_payload_resp(io_ddrA_b_payload_resp),
	.io_output_ar_valid(io_ddrA_ar_valid),
	.io_output_ar_ready(io_ddrA_ar_ready),
	.io_output_ar_payload_addr(io_ddrA_ar_payload_addr),
	.io_output_ar_payload_id(io_ddrA_ar_payload_id),
	.io_output_ar_payload_region(),
	.io_output_ar_payload_len(io_ddrA_ar_payload_len),
	.io_output_ar_payload_size(io_ddrA_ar_payload_size),
	.io_output_ar_payload_burst(io_ddrA_ar_payload_burst),
	.io_output_ar_payload_lock(io_ddrA_ar_payload_lock),
	.io_output_ar_payload_cache(),
	.io_output_ar_payload_qos(io_ddrA_ar_payload_qos),
	.io_output_ar_payload_prot(),
	.io_output_r_valid(io_ddrA_r_valid),
	.io_output_r_ready(io_ddrA_r_ready),
	.io_output_r_payload_data(io_ddrA_r_payload_data),
	.io_output_r_payload_id(io_ddrA_r_payload_id),
	.io_output_r_payload_resp(io_ddrA_r_payload_resp),
	.io_output_r_payload_last(io_ddrA_r_payload_last),
	.clk  (io_memoryClk),
	.reset(io_memoryReset)); 

axi_slave #(
	.D_WIDTH(32),
	.D_DEPTH(1024)
) axi_slave_instA (
	.mm(axiA_mm)
);
custom_instruction_tea cpu1_custom_instruction_tea_inst(
	.clk(io_systemClk),
	.reset(io_systemReset),
	.cmd_valid(cpu1_customInstruction_cmd_valid),
	.cmd_ready(cpu1_customInstruction_cmd_ready),
	.cmd_function_id(cpu1_customInstruction_cmd_function_id),
	.cmd_inputs_0(cpu1_customInstruction_cmd_inputs_0),
	.cmd_inputs_1(cpu1_customInstruction_cmd_inputs_1),
	.rsp_valid(cpu1_customInstruction_rsp_valid),
	.rsp_ready(cpu1_customInstruction_rsp_ready),
	.rsp_outputs_0(cpu1_customInstruction_rsp_outputs_0));

timer_start #(
	.MHZ(50),
	.SECOND(3)
) memcheck_s0 (
	.clk(io_peripheralClk),
	.rst_n(~io_peripheralReset),
	.start(m_start_0));

axi4_memTester #(
	.FREQ(50),
	.DW(256),
	.ID('hA),
`ifdef EFX_SIM
	.NUM_PER_BURST(8),
`else
	.NUM_PER_BURST(1024),
`endif
	.START_ADDR('h809200000)
) axi4_memTester_inst0 (
	.clk(io_memoryClk),
	.rst(io_axiMasterReset_0),
	.start(m_start_0),
	.led_status(m_pass_0),
	.aw_valid(m_awvalid_0),
	.aw_ready(m_awready_0),
	.aw_payload_addr(m_awaddr_0),
	.aw_payload_id(m_awid_0),
	.aw_payload_region(m_awregion_0),
	.aw_payload_len(m_awlen_0),
	.aw_payload_size(m_awsize_0),
	.aw_payload_burst(m_awburst_0),
	.aw_payload_lock(m_awlock_0),
	.aw_payload_cache(m_awcache_0),
	.aw_payload_qos(m_awqos_0),
	.aw_payload_prot(m_awprot_0),
	.aw_payload_allStrb(),
	.w_valid(m_wvalid_0),
	.w_ready(m_wready_0),
	.w_payload_data(m_wdata_0),
	.w_payload_strb(m_wstrb_0),
	.w_payload_last(m_wlast_0),
	.b_valid(m_bvalid_0),
	.b_ready(m_bready_0),
	.b_payload_id(m_bid_0),
	.b_payload_resp(m_bresp_0),
	.ar_valid(m_arvalid_0),
	.ar_ready(m_arready_0),
	.ar_payload_addr(m_araddr_0),
	.ar_payload_id(m_arid_0),
	.ar_payload_region(m_arregion_0),
	.ar_payload_len(m_arlen_0),
	.ar_payload_size(m_arsize_0),
	.ar_payload_burst(m_arburst_0),
	.ar_payload_lock(m_arlock_0),
	.ar_payload_cache(m_arcache_0),
	.ar_payload_qos(m_arqos_0),
	.ar_payload_prot(m_arprot_0),
	.r_valid(m_rvalid_0),
	.r_ready(m_rready_0),
	.r_payload_data(m_rdata_0),
	.r_payload_id(m_rid_0),
	.r_payload_resp(m_rresp_0),
	.r_payload_last(m_rlast_0));

timer_start #(
	.MHZ(50),
	.SECOND(3)
) memcheck_s1 (
	.clk(io_peripheralClk),
	.rst_n(~io_peripheralReset),
	.start(m_start_1));

axi4_memTester #(
	.FREQ(50),
	.DW(256),
	.ID('hE),
`ifdef EFX_SIM
	.NUM_PER_BURST(8),
`else
	.NUM_PER_BURST(1024),
`endif
	.START_ADDR('h80B200000)
) axi4_memTester_inst1 (
	.clk(io_memoryClk),
	.rst(io_axiMasterReset_1),
	.start(m_start_1),
	.led_status(m_pass_1),
	.aw_valid(m_awvalid_1),
	.aw_ready(m_awready_1),
	.aw_payload_addr(m_awaddr_1),
	.aw_payload_id(m_awid_1),
	.aw_payload_region(m_awregion_1),
	.aw_payload_len(m_awlen_1),
	.aw_payload_size(m_awsize_1),
	.aw_payload_burst(m_awburst_1),
	.aw_payload_lock(m_awlock_1),
	.aw_payload_cache(m_awcache_1),
	.aw_payload_qos(m_awqos_1),
	.aw_payload_prot(m_awprot_1),
	.aw_payload_allStrb(),
	.w_valid(m_wvalid_1),
	.w_ready(m_wready_1),
	.w_payload_data(m_wdata_1),
	.w_payload_strb(m_wstrb_1),
	.w_payload_last(m_wlast_1),
	.b_valid(m_bvalid_1),
	.b_ready(m_bready_1),
	.b_payload_id(m_bid_1),
	.b_payload_resp(m_bresp_1),
	.ar_valid(m_arvalid_1),
	.ar_ready(m_arready_1),
	.ar_payload_addr(m_araddr_1),
	.ar_payload_id(m_arid_1),
	.ar_payload_region(m_arregion_1),
	.ar_payload_len(m_arlen_1),
	.ar_payload_size(m_arsize_1),
	.ar_payload_burst(m_arburst_1),
	.ar_payload_lock(m_arlock_1),
	.ar_payload_cache(m_arcache_1),
	.ar_payload_qos(m_arqos_1),
	.ar_payload_prot(m_arprot_1),
	.r_valid(m_rvalid_1),
	.r_ready(m_rready_1),
	.r_payload_data(m_rdata_1),
	.r_payload_id(m_rid_1),
	.r_payload_resp(m_rresp_1),
	.r_payload_last(m_rlast_1));

custom_instruction_tea cpu3_custom_instruction_tea_inst(
	.clk(io_systemClk),
	.reset(io_systemReset),
	.cmd_valid(cpu3_customInstruction_cmd_valid),
	.cmd_ready(cpu3_customInstruction_cmd_ready),
	.cmd_function_id(cpu3_customInstruction_cmd_function_id),
	.cmd_inputs_0(cpu3_customInstruction_cmd_inputs_0),
	.cmd_inputs_1(cpu3_customInstruction_cmd_inputs_1),
	.rsp_valid(cpu3_customInstruction_rsp_valid),
	.rsp_ready(cpu3_customInstruction_rsp_ready),
	.rsp_outputs_0(cpu3_customInstruction_rsp_outputs_0));

ddr4_init ddr4_init_inst(
	.clk(io_systemClk),
	.rstn(io_asyncResetn),
	.cfg_start(cfg_start),
	.cfg_reset(cfg_reset),
	.cfg_sel(cfg_sel),
	.cfg_done(cfg_done),
	.cfg_ok(cfg_ok)
);

/////////////////////////////////////////////////////////////////////////////

soc_rv64_ip soc_inst
(
	.axiB_clk(io_memoryClk),
	.axiB_reset(axiB_reset),
	.axiB_aw_valid(axiB_mm.awvalid),
	.axiB_aw_ready(axiB_mm.awready),
	.axiB_aw_payload_addr(axiB_mm.awaddr),
	.axiB_aw_payload_id(axiB_mm.awid),
	.axiB_aw_payload_region(axiB_mm.awregion),
	.axiB_aw_payload_len(axiB_mm.awlen),
	.axiB_aw_payload_size(axiB_mm.awsize),
	.axiB_aw_payload_burst(axiB_mm.awburst),
	.axiB_aw_payload_lock(axiB_mm.awlock),
	.axiB_aw_payload_cache(axiB_mm.awcache),
	.axiB_aw_payload_qos(axiB_mm.awqos),
	.axiB_aw_payload_prot(axiB_mm.awprot),
	.axiB_aw_payload_allStrb(),
	.axiB_w_valid(axiB_mm.wvalid),
	.axiB_w_ready(axiB_mm.wready),
	.axiB_w_payload_data(axiB_mm.wdata),
	.axiB_w_payload_strb(axiB_mm.wstrb),
	.axiB_w_payload_last(axiB_mm.wlast),
	.axiB_b_valid(axiB_mm.bvalid),
	.axiB_b_ready(axiB_mm.bready),
	.axiB_b_payload_id(axiB_mm.bid),
	.axiB_b_payload_resp(axiB_mm.bresp),
	.axiB_ar_valid(axiB_mm.arvalid),
	.axiB_ar_ready(axiB_mm.arready),
	.axiB_ar_payload_addr(axiB_mm.araddr),
	.axiB_ar_payload_id(axiB_mm.arid),
	.axiB_ar_payload_region(axiB_mm.arregion),
	.axiB_ar_payload_len(axiB_mm.arlen),
	.axiB_ar_payload_size(axiB_mm.arsize),
	.axiB_ar_payload_burst(axiB_mm.arburst),
	.axiB_ar_payload_lock(axiB_mm.arlock),
	.axiB_ar_payload_cache(axiB_mm.arcache),
	.axiB_ar_payload_qos(axiB_mm.arqos),
	.axiB_ar_payload_prot(axiB_mm.arprot),
	.axiB_r_valid(axiB_mm.rvalid),
	.axiB_r_ready(axiB_mm.rready),
	.axiB_r_payload_data(axiB_mm.rdata),
	.axiB_r_payload_id(axiB_mm.rid),
	.axiB_r_payload_resp(axiB_mm.rresp),
	.axiB_r_payload_last(axiB_mm.rlast),
	.io_peripheralClk(io_peripheralClk),
	.io_peripheralReset(io_peripheralReset),
	.io_ddrMasters_0_clk(io_memoryClk),
	.io_ddrMasters_0_reset(io_axiMasterReset_0),
	.io_ddrMasters_0_aw_valid(m_awvalid_0),
	.io_ddrMasters_0_aw_ready(m_awready_0),
	.io_ddrMasters_0_aw_payload_addr(m_awaddr_0),
	.io_ddrMasters_0_aw_payload_id(m_awid_0[3:0]),
	.io_ddrMasters_0_aw_payload_region(m_awregion_0),
	.io_ddrMasters_0_aw_payload_len(m_awlen_0),
	.io_ddrMasters_0_aw_payload_size(m_awsize_0),
	.io_ddrMasters_0_aw_payload_burst(m_awburst_0),
	.io_ddrMasters_0_aw_payload_lock(m_awlock_0[0]),
	.io_ddrMasters_0_aw_payload_cache(m_awcache_0),
	.io_ddrMasters_0_aw_payload_qos(m_awqos_0),
	.io_ddrMasters_0_aw_payload_prot(m_awprot_0),
	.io_ddrMasters_0_aw_payload_allStrb(1'b0),
	.io_ddrMasters_0_w_valid(m_wvalid_0),
	.io_ddrMasters_0_w_ready(m_wready_0),
	.io_ddrMasters_0_w_payload_data(m_wdata_0),
	.io_ddrMasters_0_w_payload_strb(m_wstrb_0),
	.io_ddrMasters_0_w_payload_last(m_wlast_0),
	.io_ddrMasters_0_b_valid(m_bvalid_0),
	.io_ddrMasters_0_b_ready(m_bready_0),
	.io_ddrMasters_0_b_payload_id(m_bid_0[3:0]),
	.io_ddrMasters_0_b_payload_resp(m_bresp_0),
	.io_ddrMasters_0_ar_valid(m_arvalid_0),
	.io_ddrMasters_0_ar_ready(m_arready_0),
	.io_ddrMasters_0_ar_payload_addr(m_araddr_0),
	.io_ddrMasters_0_ar_payload_id(m_arid_0[3:0]),
	.io_ddrMasters_0_ar_payload_region(m_arregion_0),
	.io_ddrMasters_0_ar_payload_len(m_arlen_0),
	.io_ddrMasters_0_ar_payload_size(m_arsize_0),
	.io_ddrMasters_0_ar_payload_burst(m_arburst_0),
	.io_ddrMasters_0_ar_payload_lock(m_arlock_0[0]),
	.io_ddrMasters_0_ar_payload_cache(m_arcache_0),
	.io_ddrMasters_0_ar_payload_qos(m_arqos_0),
	.io_ddrMasters_0_ar_payload_prot(m_arprot_0),
	.io_ddrMasters_0_r_valid(m_rvalid_0),
	.io_ddrMasters_0_r_ready(m_rready_0),
	.io_ddrMasters_0_r_payload_data(m_rdata_0),
	.io_ddrMasters_0_r_payload_id(m_rid_0),
	.io_ddrMasters_0_r_payload_resp(m_rresp_0),
	.io_ddrMasters_0_r_payload_last(m_rlast_0),
	.system_i2c_0_io_sda_write(system_i2c_0_io_sda_write),
	.system_i2c_0_io_sda_read(system_i2c_0_io_sda_read),
	.system_i2c_0_io_scl_write(system_i2c_0_io_scl_write),
	.system_i2c_0_io_scl_read(system_i2c_0_io_scl_read),
	.cpu2_customInstruction_cmd_valid(cpu2_customInstruction_cmd_valid),
	.cpu2_customInstruction_cmd_ready(cpu2_customInstruction_cmd_ready),
	.cpu2_customInstruction_cmd_function_id(cpu2_customInstruction_cmd_function_id),
	.cpu2_customInstruction_cmd_inputs_0(cpu2_customInstruction_cmd_inputs_0),
	.cpu2_customInstruction_cmd_inputs_1(cpu2_customInstruction_cmd_inputs_1),
	.cpu2_customInstruction_rsp_valid(cpu2_customInstruction_rsp_valid),
	.cpu2_customInstruction_rsp_ready(cpu2_customInstruction_rsp_ready),
	.cpu2_customInstruction_rsp_outputs_0(cpu2_customInstruction_rsp_outputs_0),
	.io_memoryClk(io_memoryClk),
	.io_memoryReset(io_memoryReset),
	.io_ddrA_aw_valid(soc_io_ddrA_aw_valid),
	.io_ddrA_aw_ready(soc_io_ddrA_aw_ready),
	.io_ddrA_aw_payload_addr(soc_io_ddrA_aw_payload_addr),
	.io_ddrA_aw_payload_len(soc_io_ddrA_aw_payload_len),
	.io_ddrA_aw_payload_size(soc_io_ddrA_aw_payload_size),
	.io_ddrA_aw_payload_burst(soc_io_ddrA_aw_payload_burst),
	.io_ddrA_aw_payload_lock(soc_io_ddrA_aw_payload_lock),
	.io_ddrA_aw_payload_prot(),
	.io_ddrA_aw_payload_qos(soc_io_ddrA_aw_payload_qos),
	.io_ddrA_aw_payload_cache(soc_io_ddrA_aw_payload_cache),
	.io_ddrA_aw_payload_region(),
	.io_ddrA_aw_payload_allStrb(),
	.io_ddrA_ar_valid(soc_io_ddrA_ar_valid),
	.io_ddrA_ar_ready(soc_io_ddrA_ar_ready),
	.io_ddrA_ar_payload_addr(soc_io_ddrA_ar_payload_addr),
	.io_ddrA_ar_payload_len(soc_io_ddrA_ar_payload_len),
	.io_ddrA_ar_payload_size(soc_io_ddrA_ar_payload_size),
	.io_ddrA_ar_payload_burst(soc_io_ddrA_ar_payload_burst),
	.io_ddrA_ar_payload_lock(soc_io_ddrA_ar_payload_lock),
	.io_ddrA_ar_payload_prot(),
	.io_ddrA_ar_payload_qos(soc_io_ddrA_ar_payload_qos),
	.io_ddrA_ar_payload_cache(),
	.io_ddrA_ar_payload_region(),
	.io_ddrA_w_valid(soc_io_ddrA_w_valid),
	.io_ddrA_w_ready(soc_io_ddrA_w_ready),
	.io_ddrA_w_payload_data(soc_io_ddrA_w_payload_data),
	.io_ddrA_w_payload_strb(soc_io_ddrA_w_payload_strb),
	.io_ddrA_w_payload_last(soc_io_ddrA_w_payload_last),
	.io_ddrA_b_valid(soc_io_ddrA_b_valid),
	.io_ddrA_b_ready(soc_io_ddrA_b_ready),
	.io_ddrA_b_payload_resp(soc_io_ddrA_b_payload_resp),
	.io_ddrA_r_valid(soc_io_ddrA_r_valid),
	.io_ddrA_r_ready(soc_io_ddrA_r_ready),
	.io_ddrA_r_payload_data(soc_io_ddrA_r_payload_data),
	.io_ddrA_r_payload_resp(soc_io_ddrA_r_payload_resp),
	.io_ddrA_r_payload_last(soc_io_ddrA_r_payload_last),
	.system_spi_0_io_sclk_write(system_spi_0_io_sclk_write),
	.system_spi_0_io_data_0_writeEnable(system_spi_0_io_data_0_writeEnable),
	.system_spi_0_io_data_0_read(system_spi_0_io_data_0_read),
	.system_spi_0_io_data_0_write(system_spi_0_io_data_0_write),
	.system_spi_0_io_data_1_writeEnable(system_spi_0_io_data_1_writeEnable),
	.system_spi_0_io_data_1_read(system_spi_0_io_data_1_read),
	.system_spi_0_io_data_1_write(system_spi_0_io_data_1_write),
	.system_spi_0_io_data_2_writeEnable(),
	.system_spi_0_io_data_2_read(),
	.system_spi_0_io_data_2_write(),
	.system_spi_0_io_data_3_writeEnable(),
	.system_spi_0_io_data_3_read(),
	.system_spi_0_io_data_3_write(),
	.system_spi_0_io_ss(wire_system_spi_0_io_ss),
	.io_ndmreset(io_ndmreset),
	.jtagCtrl_tck(jtag_inst1_TCK),
	.jtagCtrl_tdi(jtag_inst1_TDI),
	.jtagCtrl_tdo(jtag_inst1_TDO),
	.jtagCtrl_enable(jtag_inst1_SEL),
	.jtagCtrl_capture(jtag_inst1_CAPTURE),
	.jtagCtrl_shift(jtag_inst1_SHIFT),
	.jtagCtrl_update(jtag_inst1_UPDATE),
	.jtagCtrl_reset(jtag_inst1_RESET),
	.io_ddrA_aw_payload_id(soc_io_ddrA_aw_payload_id),
	.io_ddrA_ar_payload_id(soc_io_ddrA_ar_payload_id),
	.io_ddrA_b_payload_id(soc_io_ddrA_b_payload_id),
	.io_ddrA_r_payload_id(soc_io_ddrA_r_payload_id),
	.system_gpio_0_io_read(system_gpio_0_io_read),
	.system_gpio_0_io_write(system_gpio_0_io_write),
	.system_gpio_0_io_writeEnable(system_gpio_0_io_writeEnable),
	.io_ddrMasters_1_clk(io_memoryClk),
	.io_ddrMasters_1_reset(io_axiMasterReset_1),
	.io_ddrMasters_1_aw_valid(m_awvalid_1),
	.io_ddrMasters_1_aw_ready(m_awready_1),
	.io_ddrMasters_1_aw_payload_addr(m_awaddr_1),
	.io_ddrMasters_1_aw_payload_id(m_awid_1[3:0]),
	.io_ddrMasters_1_aw_payload_region(m_awregion_1),
	.io_ddrMasters_1_aw_payload_len(m_awlen_1),
	.io_ddrMasters_1_aw_payload_size(m_awsize_1),
	.io_ddrMasters_1_aw_payload_burst(m_awburst_1),
	.io_ddrMasters_1_aw_payload_lock(m_awlock_1[0]),
	.io_ddrMasters_1_aw_payload_cache(m_awcache_1),
	.io_ddrMasters_1_aw_payload_qos(m_awqos_1),
	.io_ddrMasters_1_aw_payload_prot(m_awprot_1),
	.io_ddrMasters_1_aw_payload_allStrb(1'b0),
	.io_ddrMasters_1_w_valid(m_wvalid_1),
	.io_ddrMasters_1_w_ready(m_wready_1),
	.io_ddrMasters_1_w_payload_data(m_wdata_1),
	.io_ddrMasters_1_w_payload_strb(m_wstrb_1),
	.io_ddrMasters_1_w_payload_last(m_wlast_1),
	.io_ddrMasters_1_b_valid(m_bvalid_1),
	.io_ddrMasters_1_b_ready(m_bready_1),
	.io_ddrMasters_1_b_payload_id(m_bid_1[3:0]),
	.io_ddrMasters_1_b_payload_resp(m_bresp_1),
	.io_ddrMasters_1_ar_valid(m_arvalid_1),
	.io_ddrMasters_1_ar_ready(m_arready_1),
	.io_ddrMasters_1_ar_payload_addr(m_araddr_1),
	.io_ddrMasters_1_ar_payload_id(m_arid_1[3:0]),
	.io_ddrMasters_1_ar_payload_region(m_arregion_1),
	.io_ddrMasters_1_ar_payload_len(m_arlen_1),
	.io_ddrMasters_1_ar_payload_size(m_arsize_1),
	.io_ddrMasters_1_ar_payload_burst(m_arburst_1),
	.io_ddrMasters_1_ar_payload_lock(m_arlock_1[0]),
	.io_ddrMasters_1_ar_payload_cache(m_arcache_1),
	.io_ddrMasters_1_ar_payload_qos(m_arqos_1),
	.io_ddrMasters_1_ar_payload_prot(m_arprot_1),
	.io_ddrMasters_1_r_valid(m_rvalid_1),
	.io_ddrMasters_1_r_ready(m_rready_1),
	.io_ddrMasters_1_r_payload_data(m_rdata_1),
	.io_ddrMasters_1_r_payload_id(m_rid_1),
	.io_ddrMasters_1_r_payload_resp(m_rresp_1),
	.io_ddrMasters_1_r_payload_last(m_rlast_1),
	.system_uart_0_io_txd(system_uart_0_io_txd),
	.system_uart_0_io_rxd(system_uart_0_io_rxd),
	.cpu0_customInstruction_cmd_valid(cpu0_customInstruction_cmd_valid),
	.cpu0_customInstruction_cmd_ready(cpu0_customInstruction_cmd_ready),
	.cpu0_customInstruction_cmd_function_id(cpu0_customInstruction_cmd_function_id),
	.cpu0_customInstruction_cmd_inputs_0(cpu0_customInstruction_cmd_inputs_0),
	.cpu0_customInstruction_cmd_inputs_1(cpu0_customInstruction_cmd_inputs_1),
	.cpu0_customInstruction_rsp_valid(cpu0_customInstruction_rsp_valid),
	.cpu0_customInstruction_rsp_ready(cpu0_customInstruction_rsp_ready),
	.cpu0_customInstruction_rsp_outputs_0(cpu0_customInstruction_rsp_outputs_0),
	.axiA_awvalid(axiA_mm.awvalid),
	.axiA_awready(axiA_mm.awready),
	.axiA_awaddr(axiA_mm.awaddr),
	.axiA_awregion(axiA_mm.awregion),
	.axiA_awlen(axiA_mm.awlen),
	.axiA_awsize(axiA_mm.awsize),
	.axiA_awburst(axiA_mm.awburst),
	.axiA_awlock(axiA_mm.awlock),
	.axiA_awcache(axiA_mm.awcache),
	.axiA_awqos(axiA_mm.awqos),
	.axiA_awprot(axiA_mm.awprot),
	.axiA_wvalid(axiA_mm.wvalid),
	.axiA_wready(axiA_mm.wready),
	.axiA_wdata(axiA_mm.wdata),
	.axiA_wstrb(axiA_mm.wstrb),
	.axiA_wlast(axiA_mm.wlast),
	.axiA_bvalid(axiA_mm.bvalid),
	.axiA_bready(axiA_mm.bready),
	.axiA_bresp(axiA_mm.bresp),
	.axiA_arvalid(axiA_mm.arvalid),
	.axiA_arready(axiA_mm.arready),
	.axiA_araddr(axiA_mm.araddr),
	.axiA_arregion(axiA_mm.arregion),
	.axiA_arlen(axiA_mm.arlen),
	.axiA_arsize(axiA_mm.arsize),
	.axiA_arburst(axiA_mm.arburst),
	.axiA_arlock(axiA_mm.arlock),
	.axiA_arcache(axiA_mm.arcache),
	.axiA_arqos(axiA_mm.arqos),
	.axiA_arprot(axiA_mm.arprot),
	.axiA_rvalid(axiA_mm.rvalid),
	.axiA_rready(axiA_mm.rready),
	.axiA_rdata(axiA_mm.rdata),
	.axiA_rresp(axiA_mm.rresp),
	.axiA_rlast(axiA_mm.rlast),
	.axiAInterrupt(axi4Interrupt),
	.cpu3_customInstruction_cmd_valid(cpu3_customInstruction_cmd_valid),
	.cpu3_customInstruction_cmd_ready(cpu3_customInstruction_cmd_ready),
	.cpu3_customInstruction_cmd_function_id(cpu3_customInstruction_cmd_function_id),
	.cpu3_customInstruction_cmd_inputs_0(cpu3_customInstruction_cmd_inputs_0),
	.cpu3_customInstruction_cmd_inputs_1(cpu3_customInstruction_cmd_inputs_1),
	.cpu3_customInstruction_rsp_valid(cpu3_customInstruction_rsp_valid),
	.cpu3_customInstruction_rsp_ready(cpu3_customInstruction_rsp_ready),
	.cpu3_customInstruction_rsp_outputs_0(cpu3_customInstruction_rsp_outputs_0),
	.system_spi_1_io_sclk_write(system_spi_1_io_sclk_write),
	.system_spi_1_io_data_0_writeEnable(system_spi_1_io_data_0_writeEnable),
	.system_spi_1_io_data_0_read(system_spi_1_io_data_0_read),
	.system_spi_1_io_data_0_write(system_spi_1_io_data_0_write),
	.system_spi_1_io_data_1_writeEnable(system_spi_1_io_data_1_writeEnable),
	.system_spi_1_io_data_1_read(system_spi_1_io_data_1_read),
	.system_spi_1_io_data_1_write(system_spi_1_io_data_1_write),
	.system_spi_1_io_data_2_writeEnable(),
	.system_spi_1_io_data_2_read(),
	.system_spi_1_io_data_2_write(),
	.system_spi_1_io_data_3_writeEnable(),
	.system_spi_1_io_data_3_read(),
	.system_spi_1_io_data_3_write(),
	.system_spi_1_io_ss(system_spi_1_io_ss),
	.io_watchdog_hardPanic(w_system_watchdog_hardPanic),
	.cpu1_customInstruction_cmd_valid(cpu1_customInstruction_cmd_valid),
	.cpu1_customInstruction_cmd_ready(cpu1_customInstruction_cmd_ready),
	.cpu1_customInstruction_cmd_function_id(cpu1_customInstruction_cmd_function_id),
	.cpu1_customInstruction_cmd_inputs_0(cpu1_customInstruction_cmd_inputs_0),
	.cpu1_customInstruction_cmd_inputs_1(cpu1_customInstruction_cmd_inputs_1),
	.cpu1_customInstruction_rsp_valid(cpu1_customInstruction_rsp_valid),
	.cpu1_customInstruction_rsp_ready(cpu1_customInstruction_rsp_ready),
	.cpu1_customInstruction_rsp_outputs_0(cpu1_customInstruction_rsp_outputs_0),

	.io_asyncReset(w_io_asyncReset),
	.io_systemClk(io_systemClk),
	.io_systemReset(io_systemReset)
);

endmodule

//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
//
// This   document  contains  proprietary information  which   is
// protected by  copyright. All rights  are reserved.  This notice
// refers to original work by Efinix, Inc. which may be derivitive
// of other work distributed under license of the authors.  In the
// case of derivative work, nothing in this notice overrides the
// original author's license agreement.  Where applicable, the 
// original license agreement is included in it's original 
// unmodified form immediately below this header.
//
// WARRANTY DISCLAIMER.  
//     THE  DESIGN, CODE, OR INFORMATION ARE PROVIDED “AS IS” AND 
//     EFINIX MAKES NO WARRANTIES, EXPRESS OR IMPLIED WITH 
//     RESPECT THERETO, AND EXPRESSLY DISCLAIMS ANY IMPLIED WARRANTIES, 
//     INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF 
//     MERCHANTABILITY, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR 
//     PURPOSE.  SOME STATES DO NOT ALLOW EXCLUSIONS OF AN IMPLIED 
//     WARRANTY, SO THIS DISCLAIMER MAY NOT APPLY TO LICENSEE.
//
// LIMITATION OF LIABILITY.  
//     NOTWITHSTANDING ANYTHING TO THE CONTRARY, EXCEPT FOR BODILY 
//     INJURY, EFINIX SHALL NOT BE LIABLE WITH RESPECT TO ANY SUBJECT 
//     MATTER OF THIS AGREEMENT UNDER TORT, CONTRACT, STRICT LIABILITY 
//     OR ANY OTHER LEGAL OR EQUITABLE THEORY (I) FOR ANY INDIRECT, 
//     SPECIAL, INCIDENTAL, EXEMPLARY OR CONSEQUENTIAL DAMAGES OF ANY 
//     CHARACTER INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF 
//     GOODWILL, DATA OR PROFIT, WORK STOPPAGE, OR COMPUTER FAILURE OR 
//     MALFUNCTION, OR IN ANY EVENT (II) FOR ANY AMOUNT IN EXCESS, IN 
//     THE AGGREGATE, OF THE FEE PAID BY LICENSEE TO EFINIX HEREUNDER 
//     (OR, IF THE FEE HAS BEEN WAIVED, $100), EVEN IF EFINIX SHALL HAVE 
//     BEEN INFORMED OF THE POSSIBILITY OF SUCH DAMAGES.  SOME STATES DO 
//     NOT ALLOW THE EXCLUSION OR LIMITATION OF INCIDENTAL OR 
//     CONSEQUENTIAL DAMAGES, SO THIS LIMITATION AND EXCLUSION MAY NOT 
//     APPLY TO LICENSEE.
//
/////////////////////////////////////////////////////////////////////////////
