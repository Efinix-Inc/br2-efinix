////////////////////////////////////////////////////////////////////////////
//           _____       
//          / _______    Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
//         / /       \   
//        / /  ..    /   misc_modules.v
//       / / .'     /    
//    __/ /.'      /     Description:
//   __   \       /      1) pulse_synchronizer - sync a pulse signal to another clock domain
//  /_/ /\ \_____/ /     2) reset synchronizer - sync a reset signal to a clock domain
// ____/  \_______/      3) bram - a generic dual port bram
//                       timer_start - simple counter to generate tick pulse
//                       or constant level high signal.
//                       4) axi_half2fullDuplex - a converter to convert axi bus from half
//                       to full duplex
//                       5) prbs32b - 32 bits pseudorandom generator
//                       6) ddr4_init - reset controller for ddr4 harden controller
// ***********************************************************************
module pulse_synchronizer
(
	input	clk_i,
	input	pulse_i,
	input	clk_o,
	output	pulse_o
);

/////////////////////////////////////////////////////////////////////////////
reg sync_pulse = 1'b0;
reg [2:0] sync_reg = 3'd0; 

/////////////////////////////////////////////////////////////////////////////
always@ (posedge clk_i)
begin
	if(pulse_i)
	sync_pulse <= ~sync_pulse;
	else
	sync_pulse <= sync_pulse;
end

/////////////////////////////////////////////////////////////////////////////
always@ (posedge clk_o)
begin
	sync_reg[2] <= sync_pulse;
	sync_reg[1] <= sync_reg[2];
	sync_reg[0] <= sync_reg[1];
end

assign pulse_o = sync_reg[0] ^ sync_reg[1];

endmodule

///////////////////////////////////////////////////////////////////////////////
module reset_synchronizer #(
	parameter NUM_STAGE  = 10,
	parameter ACTIVE_LOW = 1
)(
	input	reset_in,
	output	reset_out,
	input	clk
);

	reg [NUM_STAGE-1 : 0] data;

	generate 
	if(ACTIVE_LOW == 1)
		always @(posedge clk or negedge reset_in) 
		begin
			if(~reset_in)
			begin
				data <= {NUM_STAGE{1'b0}};
			end
			else
			begin
				data <= {1'b1, data[NUM_STAGE-1:1]};
			end 
		end
	else
		always @(posedge clk or posedge reset_in) 
		begin
			if(reset_in)
			begin
				data <= {NUM_STAGE{1'b1}};
			end 
			else
			begin
				data <= {1'b0, data[NUM_STAGE-1:1]};
			end
		end
	endgenerate

	assign reset_out = data[0];

endmodule

///////////////////////////////////////////////////////////////////////////////
module bram #(
	parameter D_WIDTH = 8,
	parameter D_DEPTH = 9,
	parameter OUTPUT_REG = "TRUE",
	parameter INIT_FILE = ""
) (
	input 						wclk, 
	input [D_WIDTH/8-1:0]		we, 
	input [$clog2(D_DEPTH)-1:0]	waddr, 
	input [D_WIDTH-1:0]			wdata,
	input						rclk,
	input						re, 
	input [$clog2(D_DEPTH)-1:0]	raddr,
	output [D_WIDTH-1:0]		rdata
);

/////////////////////////////////////////////////////////////////////////////
reg [D_WIDTH-1:0]	ram [D_DEPTH-1:0];
wire [D_WIDTH-1:0]	r_rdata_1P;
reg [D_WIDTH-1:0]	r_rdata_2P;

/////////////////////////////////////////////////////////////////////////////
	initial
	begin
	//ram = '{default:0};
	if (INIT_FILE != "")
	begin
		$readmemh(INIT_FILE, ram);
	end
	end

	always@ (posedge rclk)
	begin
	if(re)
		r_rdata_2P <= r_rdata_1P;
	end

	assign r_rdata_1P = ram[raddr];

	genvar i;
	generate
		for(i=0;i<D_WIDTH/8;i=i+1)
		begin
			always @ (posedge wclk)
			begin
			if (we[i])
				ram[waddr][i*8 +: 8] <= wdata[i*8 +: 8];	
			end	
		end

		if (OUTPUT_REG == "TRUE")
			assign  rdata = r_rdata_2P;
		else
			assign  rdata = r_rdata_1P;
	endgenerate


endmodule

/////////////////////////////////////////////////////////////////////////////
module timer_start #(
	parameter MHZ = 50,
	parameter SECOND = 3,
	parameter PULSE = 0
) (
	input	clk,
	input	rst_n,
	output	start
); 
///////////////////////////////////////////////////////////////////////////////
reg [35:0]	delay_cnt;
wire		second_tick;
reg [4:0]	second_cnt;
reg [3:0]	pulse_reg;
wire		start_reg;

///////////////////////////////////////////////////////////////////////////////

`ifndef EFX_SIM
localparam tick_cnt = (MHZ * 1000000) >> 1;
`else
localparam tick_cnt = MHZ * 200;
`endif

	always@(posedge clk or negedge rst_n)
	begin
	if(!rst_n)
		delay_cnt <= 'd0;
	else
	begin
	if(delay_cnt == tick_cnt || start_reg == 1'b1)
		delay_cnt <= 'd0;
	else
		delay_cnt <= delay_cnt + 1'b1;
	end
	end

	assign second_tick = ((delay_cnt) == (tick_cnt - 1)); 

	always@(posedge clk or negedge rst_n)
	begin
	if(!rst_n)
		second_cnt <= 'd0;
	else
	begin
		if(second_tick)
			second_cnt <= second_cnt + 1'b1;
		else
			second_cnt <= second_cnt;
	end
	end

	assign start_reg = (second_cnt == SECOND);

	always@(posedge clk)
	begin
		pulse_reg <= {pulse_reg[2:0],start_reg};
	end

generate
if(PULSE == 1)
	assign start = ~pulse_reg[3] & start_reg;
else
	assign start = start_reg;
endgenerate

endmodule

/////////////////////////////////////////////////////////////////////////////
module axi_half2fullDuplex (
input			clk,
input			reset,
input			io_ddrA_arw_valid,
output			io_ddrA_arw_ready,
input [32:0]	io_ddrA_arw_payload_addr,
input [5:0]		io_ddrA_arw_payload_id,
input [7:0]		io_ddrA_arw_payload_len,
input [2:0]		io_ddrA_arw_payload_size,
input [1:0]		io_ddrA_arw_payload_burst,
input [1:0]		io_ddrA_arw_payload_lock,
input			io_ddrA_arw_payload_write,
output			io_ddrA_aw_valid,
input 			io_ddrA_aw_ready,
output [32:0]	io_ddrA_aw_payload_addr,
output [5:0]	io_ddrA_aw_payload_id,
output [7:0]	io_ddrA_aw_payload_len,
output [2:0]	io_ddrA_aw_payload_size,
output [1:0]	io_ddrA_aw_payload_burst,
output [1:0]	io_ddrA_aw_payload_lock,
output			io_ddrA_ar_valid,
input 			io_ddrA_ar_ready,
output [32:0]	io_ddrA_ar_payload_addr,
output [5:0]	io_ddrA_ar_payload_id,
output [7:0]	io_ddrA_ar_payload_len,
output [2:0]	io_ddrA_ar_payload_size,
output [1:0]	io_ddrA_ar_payload_burst,
output [1:0]	io_ddrA_ar_payload_lock
);
/////////////////////////////////////////////////////////////////////////////
localparam [1:0]	IDLE = 2'h0,
					WRITE = 2'h1,
					READ = 2'h2;

reg [1:0]	st_cur,st_next; 
wire		op_write,op_read;

/////////////////////////////////////////////////////////////////////////////
	always@(posedge clk or posedge reset)
	begin
		if(reset)
			st_cur <= IDLE;
		else
			st_cur <= st_next;
	end

	always@(*)
	begin
		st_next = st_cur;
		case(st_cur)
		IDLE:
		begin
			if(io_ddrA_arw_valid && io_ddrA_arw_payload_write)
				st_next = WRITE;
			 else if (io_ddrA_arw_valid && !io_ddrA_arw_payload_write)
				st_next = READ;
			else
				st_next = IDLE;
		end
		WRITE:
		begin
			if(io_ddrA_aw_ready)
				st_next = IDLE;
			else
				st_next = WRITE;
		end
		READ:
		begin
			 if(io_ddrA_ar_ready)
				st_next = IDLE;
			 else
				st_next = READ;
		end
		default: st_next = IDLE;
		endcase
	end
	
	assign op_write = (st_cur == WRITE);
	assign op_read = (st_cur == READ);
	assign io_ddrA_arw_ready = (op_write & io_ddrA_aw_ready) | (op_read & io_ddrA_ar_ready);
	assign io_ddrA_aw_valid = op_write ? io_ddrA_arw_valid : 1'b0;
	assign io_ddrA_aw_payload_addr = op_write ? io_ddrA_arw_payload_addr : 33'd0;
	assign io_ddrA_aw_payload_id = op_write ? io_ddrA_arw_payload_id : 6'd0;
	assign io_ddrA_aw_payload_len = op_write ? io_ddrA_arw_payload_len : 8'd0;
	assign io_ddrA_aw_payload_size = op_write ? io_ddrA_arw_payload_size : 3'd0;
	assign io_ddrA_aw_payload_burst = op_write ? io_ddrA_arw_payload_burst : 2'd0;
	assign io_ddrA_aw_payload_lock = op_write ? io_ddrA_arw_payload_lock : 2'd0;
	assign io_ddrA_ar_valid = op_read ? io_ddrA_arw_valid : 1'b0;
	assign io_ddrA_ar_payload_addr = op_read ? io_ddrA_arw_payload_addr : 33'd0;
	assign io_ddrA_ar_payload_id = op_read ? io_ddrA_arw_payload_id : 6'd0;
	assign io_ddrA_ar_payload_len = op_read ? io_ddrA_arw_payload_len : 8'd0;
	assign io_ddrA_ar_payload_size = op_read ? io_ddrA_arw_payload_size : 3'd0;
	assign io_ddrA_ar_payload_burst = op_read ? io_ddrA_arw_payload_burst : 2'd0;
	assign io_ddrA_ar_payload_lock = op_read ? io_ddrA_arw_payload_lock : 2'd0;


endmodule

/////////////////////////////////////////////////////////////////////////////
module prbs32b #(
	parameter DW = 32
) (
	input			clk,
	input			rst,
	input			ce,
	output [DW-1:0]	prbs,
	output			valid
);

/////////////////////////////////////////////////////////////////////////////
localparam WORD = DW/32;

reg [31:0]		prbs_reg;
reg				valid_r;

generate
if(WORD == 1)
begin
	assign prbs = prbs_reg;
end
if(WORD == 2)
begin
	wire [31:0]		prbs_reg_i;

	assign prbs_reg_i = ~prbs_reg;
	assign prbs = {prbs_reg_i, prbs_reg};
end
else if (WORD == 4)
begin
	wire [31:0]		prbs_reg_i;
	wire [31:0]		prbs_shiftleft;
	wire [31:0]		prbs_shiftleft_i;

	assign prbs_reg_i = ~prbs_reg;
	assign prbs_shiftleft = prbs_reg << 1;
	assign prbs_shiftleft_i = ~prbs_shiftleft;
	assign prbs = {prbs_shiftleft_i, prbs_shiftleft, prbs_reg_i, prbs_reg};
end
else if (WORD == 8)
begin
	wire [31:0]		prbs_reg_i;
	wire [31:0]		prbs_shiftleft;
	wire [31:0]		prbs_shiftleft_i;
	wire [127:0]	prbs_tmp;
	assign prbs_reg_i = ~prbs_reg;
	assign prbs_shiftleft = prbs_reg << 1;
	assign prbs_shiftleft_i = ~prbs_shiftleft;
	assign prbs_tmp = {prbs_shiftleft_i, prbs_shiftleft, prbs_reg_i, prbs_reg};
	assign prbs = {prbs_tmp>>1, prbs_tmp};
end
else if (WORD == 16)
begin
	wire [31:0]		prbs_reg_i;
	wire [31:0]		prbs_shiftleft;
	wire [31:0]		prbs_shiftleft_i;
	wire [127:0]	prbs_tmp;
	assign prbs_reg_i = ~prbs_reg;
	assign prbs_shiftleft = prbs_reg << 1;
	assign prbs_shiftleft_i = ~prbs_shiftleft;
	assign prbs_tmp = {prbs_shiftleft_i, prbs_shiftleft, prbs_reg_i, prbs_reg};
	assign prbs = {~prbs_tmp,prbs_tmp<<1,prbs_tmp>>1,prbs_tmp};
end
endgenerate

/////////////////////////////////////////////////////////////////////////////
//tap max length = 22,2,1 = 10, 30, 31

always@(posedge clk or posedge rst)
begin
	if(rst)
		valid_r <= 1'b0;
	else
	begin
		if(ce)
			valid_r <= 1'b1;
		else	
			valid_r <= 1'b0;
	end
end

assign valid = ce;

always@(posedge clk or posedge rst)
begin
	if(rst)
		prbs_reg <= 'd1;
	else
	begin
		if(ce)
		begin
			prbs_reg[31] <= prbs_reg[0];
			prbs_reg[30] <= prbs_reg[31] ^ prbs_reg[0];
			prbs_reg[29] <= prbs_reg[30] ^ prbs_reg[0];
			prbs_reg[28] <= prbs_reg[29];
			prbs_reg[27] <= prbs_reg[28];
			prbs_reg[26] <= prbs_reg[27];
			prbs_reg[25] <= prbs_reg[26];
			prbs_reg[24] <= prbs_reg[25];
			prbs_reg[23] <= prbs_reg[24];
			prbs_reg[22] <= prbs_reg[23];
			prbs_reg[21] <= prbs_reg[22];
			prbs_reg[20] <= prbs_reg[21];
			prbs_reg[19] <= prbs_reg[20];
			prbs_reg[18] <= prbs_reg[19];
			prbs_reg[17] <= prbs_reg[18];
			prbs_reg[16] <= prbs_reg[17];
			prbs_reg[15] <= prbs_reg[16];
			prbs_reg[14] <= prbs_reg[15];
			prbs_reg[13] <= prbs_reg[14];
			prbs_reg[12] <= prbs_reg[13];
			prbs_reg[11] <= prbs_reg[12];
			prbs_reg[10] <= prbs_reg[11];
			prbs_reg[9]  <= prbs_reg[10] ^ prbs_reg[0];
			prbs_reg[8]  <= prbs_reg[9];
			prbs_reg[7]  <= prbs_reg[8];
			prbs_reg[6]  <= prbs_reg[7];
			prbs_reg[5]  <= prbs_reg[6];
			prbs_reg[4]  <= prbs_reg[5];
			prbs_reg[3]  <= prbs_reg[4];
			prbs_reg[2]  <= prbs_reg[3];
			prbs_reg[1]  <= prbs_reg[2];
			prbs_reg[0]  <= prbs_reg[1];
		end
	end
end

endmodule

/////////////////////////////////////////////////////////////////////////////
module ddr4_init (
	input	clk,
	input	rstn,
	output	cfg_start,
	output	cfg_reset,
	output	cfg_sel,
	input	cfg_done,
	output  cfg_ok

);

/////////////////////////////////////////////////////////////////////////////
localparam [1:0] IDLE = 2'b00,
				CFG_START = 2'b01,
				CFG_DONE = 2'b11;

reg [1:0] cfg_st, cfg_next;
reg [7:0] cfg_count = 8'h00;

/////////////////////////////////////////////////////////////////////////////

	always@(posedge clk or negedge rstn)
	begin
		if(!rstn)
			cfg_st <= IDLE;
		else
			cfg_st <= cfg_next;
	end

	always@(*)
	begin
		cfg_next = cfg_st;
		case(cfg_st)
		IDLE:
		begin
			if(cfg_count == 'hff)
				cfg_next = CFG_START;
			else
				cfg_next = IDLE;
		end
		CFG_START:
		begin
			if(cfg_done)
				cfg_next = CFG_DONE;
			else
				cfg_next = CFG_START;
		end
		CFG_DONE:
			cfg_next = CFG_DONE;
		default:
			cfg_next = IDLE;
		endcase
	end

	assign cfg_start = (cfg_st != IDLE);
	assign cfg_ok = (cfg_st == CFG_DONE);
	assign cfg_reset = (cfg_st == IDLE);
	assign cfg_sel = 1'b0;

	always@(posedge clk)
	begin
		if(cfg_st == IDLE)
			cfg_count <= cfg_count + 1'b1;
		else
			cfg_count <= 'h0;
	end

endmodule
