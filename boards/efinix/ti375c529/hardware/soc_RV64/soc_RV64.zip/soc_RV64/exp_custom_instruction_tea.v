////////////////////////////////////////////////////////////////////////////
//           _____       
//          / _______    Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
//         / /       \   
//        / /  ..    /   custom_instruction_tea.v
//       / / .'     /    
//    __/ /.'      /     Description:
//   __   \       /      A simple Tiny algo encryption module to showcase
//  /_/ /\ \_____/ /     how to interact with SoC custom instruction interface.
// ____/  \_______/      
//
// ***********************************************************************
module custom_instruction_tea (
	input			clk,
	input			reset,
	input			cmd_valid,
	output			cmd_ready,
	input [9:0]		cmd_function_id,
	input [63:0]	cmd_inputs_0,
	input [63:0]	cmd_inputs_1,
	output reg		rsp_valid,
	input 			rsp_ready,
	output [63:0]	rsp_outputs_0
);

/////////////////////////////////////////////////////////////////////////////
	reg [63:0]		raw_data0;
	reg [63:0]		raw_data1;
	reg				raw_valid;
	wire [63:0]		enc_out;
	wire			enc_valid;
	reg				enc_busy;
	
/////////////////////////////////////////////////////////////////////////////

	always@(posedge clk or posedge reset) 
	begin
		if(reset) 
		begin
			raw_data0 <= 64'd0;
			raw_data1 <= 64'd0;
			raw_valid <= 1'b0;
		end 
		else begin
			if (cmd_ready & cmd_valid) begin
				case (cmd_function_id[1:0])
					2'd0:
					begin
						raw_data0 <= cmd_inputs_0;
						raw_data1 <= cmd_inputs_1;
						raw_valid <= 1'b1;
					end
					default:
					begin
						raw_data0 <= raw_data0;
						raw_data1 <= raw_data1;
						raw_valid <= 1'b0;
					end
				endcase 
			end
			else begin   
				raw_data0 <= raw_data0;
				raw_data1 <= raw_data1;
				raw_valid <= 1'b0;
			end
		end
	end

	always@(posedge clk or posedge reset)
	begin
		if(reset)
			enc_busy <= 1'b0;
		else begin
			if(rsp_valid && rsp_ready)
				enc_busy <= 1'b0;
			else if(cmd_valid && cmd_function_id[1:0] == 2'b00)
				enc_busy <= 1'b1;
			else
				enc_busy <= enc_busy;
		end
	end

	always@(posedge clk or posedge reset)
	begin
		if(reset)
			rsp_valid <= 1'b0;
		else begin
			if(enc_valid)
				rsp_valid <= 1'b1;
			else if(rsp_ready)	
				rsp_valid <= 1'b0;
			else
				rsp_valid <= rsp_valid;
		end
	end

	assign rsp_outputs_0 = enc_out;
	assign cmd_ready = !enc_busy;

	tiny_encrytion #(
		.ITER(1024)
	) tea (
		.clk(clk),
		.reset(reset),
		.raw0(raw_data0[31:0]),
		.raw1(raw_data1[31:0]),
		.rawEn(raw_valid),
		.busy(),
		.enc_out(enc_out),
		.enc_valid(enc_valid)
	);

endmodule

/////////////////////////////////////////////////////////////////////////////
module tiny_encrytion #(
	parameter ITER = 1024
) (
	input				clk,
	input				reset,
	input [31:0]		raw0,
	input [31:0]		raw1,
	input				rawEn,
	output				busy,
	output reg [63:0]	enc_out,
	output				enc_valid
);

/////////////////////////////////////////////////////////////////////////////
localparam deltaConstant = 32'h9E3779B9;
localparam enckey0 = 32'h01234567;
localparam enckey1 = 32'h89abcdef;
localparam enckey2 = 32'h13579248;
localparam enckey3 = 32'h248a0135;
localparam CW = $clog2(ITER);

reg [31:0]		raw_r0, raw_r1;
reg [CW-1:0]	iteration_cnt;
reg [2:0]		iteration_start;
wire			iteration_stop;
reg				iteration_act;
reg [1:0]		data_tick;
reg				data_tick_r1;
reg [31:0]		delta_r1;
wire [31:0]		cal0_top;
wire [31:0]		cal0_mid;
wire [31:0]		cal0_bot;
wire [31:0]		cal0;
wire [31:0]		cal1_top;
wire [31:0]		cal1_mid;
wire [31:0]		cal1_bot;
wire [31:0]		cal1;

/////////////////////////////////////////////////////////////////////////////
	always@(posedge clk)
	begin
		if(data_tick[0])
			enc_out <= {raw_r1, raw_r0};
		else
			enc_out <= enc_out;
	end

	assign busy = iteration_act;
	assign enc_valid = data_tick[1];

	always@(posedge clk)
	begin
		iteration_start <= {iteration_start[1:0], rawEn};
		data_tick <= {data_tick[0], iteration_stop};
	end

	assign iteration_stop = (iteration_cnt == {CW{1'b1}});

	always@(posedge clk or posedge reset)
	begin
		if(reset)
		iteration_act <= 'b0;
		else
		begin
		if(iteration_start[2])
			iteration_act <= 1'b1;
		else if(iteration_stop)
			iteration_act <= 1'b0;
		else
			iteration_act <= iteration_act;
		end
	end

	always@(posedge clk or posedge reset)
	begin
		if(reset)
			iteration_cnt <= 'd0;
		else
		begin
		if(iteration_act)
			iteration_cnt <= iteration_cnt + 1'b1;
		else
			iteration_cnt <= 'd0;
		end
	end

	always@(posedge clk)
	begin
		if(iteration_start[1] && !iteration_act)
		begin
			raw_r0 <= raw0;
			raw_r1 <= raw1;
			delta_r1 <= deltaConstant;
		end
		else
		if(iteration_act)
		begin
			raw_r0 <= cal1 + raw_r0;
			raw_r1 <= cal0 + raw_r1;
			delta_r1 <= delta_r1 + deltaConstant;
		end 
		else
		begin
			raw_r0 <= raw_r0;
			raw_r1 <= raw_r1;
			delta_r1 <= delta_r1;
		end
	end

	assign cal0_top = ((raw_r0 + cal1) << 4) + enckey2;
	assign cal0_mid = (raw_r0 + cal1) + delta_r1;
	assign cal0_bot = ((raw_r0 + cal1) >> 5) + enckey3;
	assign cal0 = cal0_top ^ cal0_mid ^ cal0_bot;
	assign cal1_top = (raw_r1 << 4) + enckey0;
	assign cal1_mid = raw_r1 + delta_r1;
	assign cal1_bot = (raw_r1 >> 5) + enckey1;
	assign cal1 = cal1_top ^ cal1_mid ^ cal1_bot;

endmodule
