--------------------------------------------------------------------------------
-- Copyright (C) 2013-2026 Efinix Inc. All rights reserved.              
--
-- This   document  contains  proprietary information  which   is        
-- protected by  copyright. All rights  are reserved.  This notice       
-- refers to original work by Efinix, Inc. which may be derivitive       
-- of other work distributed under license of the authors.  In the       
-- case of derivative work, nothing in this notice overrides the         
-- original author's license agreement.  Where applicable, the           
-- original license agreement is included in it's original               
-- unmodified form immediately below this header.                        
--                                                                       
-- WARRANTY DISCLAIMER.                                                  
--     THE  DESIGN, CODE, OR INFORMATION ARE PROVIDED “AS IS” AND        
--     EFINIX MAKES NO WARRANTIES, EXPRESS OR IMPLIED WITH               
--     RESPECT THERETO, AND EXPRESSLY DISCLAIMS ANY IMPLIED WARRANTIES,  
--     INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF          
--     MERCHANTABILITY, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR    
--     PURPOSE.  SOME STATES DO NOT ALLOW EXCLUSIONS OF AN IMPLIED       
--     WARRANTY, SO THIS DISCLAIMER MAY NOT APPLY TO LICENSEE.           
--                                                                       
-- LIMITATION OF LIABILITY.                                              
--     NOTWITHSTANDING ANYTHING TO THE CONTRARY, EXCEPT FOR BODILY       
--     INJURY, EFINIX SHALL NOT BE LIABLE WITH RESPECT TO ANY SUBJECT    
--     MATTER OF THIS AGREEMENT UNDER TORT, CONTRACT, STRICT LIABILITY   
--     OR ANY OTHER LEGAL OR EQUITABLE THEORY (I) FOR ANY INDIRECT,      
--     SPECIAL, INCIDENTAL, EXEMPLARY OR CONSEQUENTIAL DAMAGES OF ANY    
--     CHARACTER INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF      
--     GOODWILL, DATA OR PROFIT, WORK STOPPAGE, OR COMPUTER FAILURE OR   
--     MALFUNCTION, OR IN ANY EVENT (II) FOR ANY AMOUNT IN EXCESS, IN    
--     THE AGGREGATE, OF THE FEE PAID BY LICENSEE TO EFINIX HEREUNDER    
--     (OR, IF THE FEE HAS BEEN WAIVED, $100), EVEN IF EFINIX SHALL HAVE 
--     BEEN INFORMED OF THE POSSIBILITY OF SUCH DAMAGES.  SOME STATES DO 
--     NOT ALLOW THE EXCLUSION OR LIMITATION OF INCIDENTAL OR            
--     CONSEQUENTIAL DAMAGES, SO THIS LIMITATION AND EXCLUSION MAY NOT   
--     APPLY TO LICENSEE.                                                
--
--------------------------------------------------------------------------------
------------- Begin Cut here for COMPONENT Declaration ------
component soc_rv64_ip is
port (
    io_asyncReset : in std_logic;
    io_systemClk : in std_logic;
    io_systemReset : out std_logic;
    io_peripheralClk : in std_logic;
    io_peripheralReset : out std_logic;
    io_memoryClk : in std_logic;
    io_memoryReset : out std_logic;
    axiB_clk : in std_logic;
    axiB_reset : out std_logic;
    io_ndmreset : out std_logic;
    jtagCtrl_tck : in std_logic;
    jtagCtrl_tdi : in std_logic;
    jtagCtrl_enable : in std_logic;
    jtagCtrl_capture : in std_logic;
    jtagCtrl_shift : in std_logic;
    jtagCtrl_update : in std_logic;
    jtagCtrl_reset : in std_logic;
    jtagCtrl_tdo : out std_logic;
    io_ddrA_aw_valid : out std_logic;
    io_ddrA_aw_ready : in std_logic;
    io_ddrA_aw_payload_addr : out std_logic_vector(29 downto 0);
    io_ddrA_aw_payload_id : out std_logic_vector(5 downto 0);
    io_ddrA_aw_payload_region : out std_logic_vector(3 downto 0);
    io_ddrA_aw_payload_len : out std_logic_vector(7 downto 0);
    io_ddrA_aw_payload_size : out std_logic_vector(2 downto 0);
    io_ddrA_aw_payload_burst : out std_logic_vector(1 downto 0);
    io_ddrA_aw_payload_lock : out std_logic;
    io_ddrA_aw_payload_cache : out std_logic_vector(3 downto 0);
    io_ddrA_aw_payload_qos : out std_logic_vector(3 downto 0);
    io_ddrA_aw_payload_prot : out std_logic_vector(2 downto 0);
    io_ddrA_aw_payload_allStrb : out std_logic;
    io_ddrA_w_valid : out std_logic;
    io_ddrA_w_ready : in std_logic;
    io_ddrA_w_payload_data : out std_logic_vector(255 downto 0);
    io_ddrA_w_payload_strb : out std_logic_vector(31 downto 0);
    io_ddrA_w_payload_last : out std_logic;
    io_ddrA_b_valid : in std_logic;
    io_ddrA_b_ready : out std_logic;
    io_ddrA_b_payload_id : in std_logic_vector(5 downto 0);
    io_ddrA_b_payload_resp : in std_logic_vector(1 downto 0);
    io_ddrA_ar_valid : out std_logic;
    io_ddrA_ar_ready : in std_logic;
    io_ddrA_ar_payload_addr : out std_logic_vector(29 downto 0);
    io_ddrA_ar_payload_id : out std_logic_vector(5 downto 0);
    io_ddrA_ar_payload_region : out std_logic_vector(3 downto 0);
    io_ddrA_ar_payload_len : out std_logic_vector(7 downto 0);
    io_ddrA_ar_payload_size : out std_logic_vector(2 downto 0);
    io_ddrA_ar_payload_burst : out std_logic_vector(1 downto 0);
    io_ddrA_ar_payload_lock : out std_logic;
    io_ddrA_ar_payload_cache : out std_logic_vector(3 downto 0);
    io_ddrA_ar_payload_qos : out std_logic_vector(3 downto 0);
    io_ddrA_ar_payload_prot : out std_logic_vector(2 downto 0);
    io_ddrA_r_valid : in std_logic;
    io_ddrA_r_ready : out std_logic;
    io_ddrA_r_payload_data : in std_logic_vector(255 downto 0);
    io_ddrA_r_payload_id : in std_logic_vector(5 downto 0);
    io_ddrA_r_payload_resp : in std_logic_vector(1 downto 0);
    io_ddrA_r_payload_last : in std_logic;
    io_ddrMasters_0_clk : in std_logic;
    io_ddrMasters_0_reset : out std_logic;
    io_ddrMasters_0_aw_valid : in std_logic;
    io_ddrMasters_0_aw_ready : out std_logic;
    io_ddrMasters_0_aw_payload_addr : in std_logic_vector(36 downto 0);
    io_ddrMasters_0_aw_payload_id : in std_logic_vector(3 downto 0);
    io_ddrMasters_0_aw_payload_region : in std_logic_vector(3 downto 0);
    io_ddrMasters_0_aw_payload_len : in std_logic_vector(7 downto 0);
    io_ddrMasters_0_aw_payload_size : in std_logic_vector(2 downto 0);
    io_ddrMasters_0_aw_payload_burst : in std_logic_vector(1 downto 0);
    io_ddrMasters_0_aw_payload_lock : in std_logic_vector(0 to 0);
    io_ddrMasters_0_aw_payload_cache : in std_logic_vector(3 downto 0);
    io_ddrMasters_0_aw_payload_qos : in std_logic_vector(3 downto 0);
    io_ddrMasters_0_aw_payload_prot : in std_logic_vector(2 downto 0);
    io_ddrMasters_0_aw_payload_allStrb : in std_logic;
    io_ddrMasters_0_w_valid : in std_logic;
    io_ddrMasters_0_w_ready : out std_logic;
    io_ddrMasters_0_w_payload_data : in std_logic_vector(255 downto 0);
    io_ddrMasters_0_w_payload_strb : in std_logic_vector(31 downto 0);
    io_ddrMasters_0_w_payload_last : in std_logic;
    io_ddrMasters_0_b_valid : out std_logic;
    io_ddrMasters_0_b_ready : in std_logic;
    io_ddrMasters_0_b_payload_id : out std_logic_vector(3 downto 0);
    io_ddrMasters_0_b_payload_resp : out std_logic_vector(1 downto 0);
    io_ddrMasters_0_ar_valid : in std_logic;
    io_ddrMasters_0_ar_ready : out std_logic;
    io_ddrMasters_0_ar_payload_addr : in std_logic_vector(36 downto 0);
    io_ddrMasters_0_ar_payload_id : in std_logic_vector(3 downto 0);
    io_ddrMasters_0_ar_payload_region : in std_logic_vector(3 downto 0);
    io_ddrMasters_0_ar_payload_len : in std_logic_vector(7 downto 0);
    io_ddrMasters_0_ar_payload_size : in std_logic_vector(2 downto 0);
    io_ddrMasters_0_ar_payload_burst : in std_logic_vector(1 downto 0);
    io_ddrMasters_0_ar_payload_lock : in std_logic_vector(0 to 0);
    io_ddrMasters_0_ar_payload_cache : in std_logic_vector(3 downto 0);
    io_ddrMasters_0_ar_payload_qos : in std_logic_vector(3 downto 0);
    io_ddrMasters_0_ar_payload_prot : in std_logic_vector(2 downto 0);
    io_ddrMasters_0_r_valid : out std_logic;
    io_ddrMasters_0_r_ready : in std_logic;
    io_ddrMasters_0_r_payload_data : out std_logic_vector(255 downto 0);
    io_ddrMasters_0_r_payload_id : out std_logic_vector(3 downto 0);
    io_ddrMasters_0_r_payload_resp : out std_logic_vector(1 downto 0);
    io_ddrMasters_0_r_payload_last : out std_logic;
    io_ddrMasters_1_clk : in std_logic;
    io_ddrMasters_1_reset : out std_logic;
    io_ddrMasters_1_aw_valid : in std_logic;
    io_ddrMasters_1_aw_ready : out std_logic;
    io_ddrMasters_1_aw_payload_addr : in std_logic_vector(36 downto 0);
    io_ddrMasters_1_aw_payload_id : in std_logic_vector(3 downto 0);
    io_ddrMasters_1_aw_payload_region : in std_logic_vector(3 downto 0);
    io_ddrMasters_1_aw_payload_len : in std_logic_vector(7 downto 0);
    io_ddrMasters_1_aw_payload_size : in std_logic_vector(2 downto 0);
    io_ddrMasters_1_aw_payload_burst : in std_logic_vector(1 downto 0);
    io_ddrMasters_1_aw_payload_lock : in std_logic_vector(0 to 0);
    io_ddrMasters_1_aw_payload_cache : in std_logic_vector(3 downto 0);
    io_ddrMasters_1_aw_payload_qos : in std_logic_vector(3 downto 0);
    io_ddrMasters_1_aw_payload_prot : in std_logic_vector(2 downto 0);
    io_ddrMasters_1_aw_payload_allStrb : in std_logic;
    io_ddrMasters_1_w_valid : in std_logic;
    io_ddrMasters_1_w_ready : out std_logic;
    io_ddrMasters_1_w_payload_data : in std_logic_vector(255 downto 0);
    io_ddrMasters_1_w_payload_strb : in std_logic_vector(31 downto 0);
    io_ddrMasters_1_w_payload_last : in std_logic;
    io_ddrMasters_1_b_valid : out std_logic;
    io_ddrMasters_1_b_ready : in std_logic;
    io_ddrMasters_1_b_payload_id : out std_logic_vector(3 downto 0);
    io_ddrMasters_1_b_payload_resp : out std_logic_vector(1 downto 0);
    io_ddrMasters_1_ar_valid : in std_logic;
    io_ddrMasters_1_ar_ready : out std_logic;
    io_ddrMasters_1_ar_payload_addr : in std_logic_vector(36 downto 0);
    io_ddrMasters_1_ar_payload_id : in std_logic_vector(3 downto 0);
    io_ddrMasters_1_ar_payload_region : in std_logic_vector(3 downto 0);
    io_ddrMasters_1_ar_payload_len : in std_logic_vector(7 downto 0);
    io_ddrMasters_1_ar_payload_size : in std_logic_vector(2 downto 0);
    io_ddrMasters_1_ar_payload_burst : in std_logic_vector(1 downto 0);
    io_ddrMasters_1_ar_payload_lock : in std_logic_vector(0 to 0);
    io_ddrMasters_1_ar_payload_cache : in std_logic_vector(3 downto 0);
    io_ddrMasters_1_ar_payload_qos : in std_logic_vector(3 downto 0);
    io_ddrMasters_1_ar_payload_prot : in std_logic_vector(2 downto 0);
    io_ddrMasters_1_r_valid : out std_logic;
    io_ddrMasters_1_r_ready : in std_logic;
    io_ddrMasters_1_r_payload_data : out std_logic_vector(255 downto 0);
    io_ddrMasters_1_r_payload_id : out std_logic_vector(3 downto 0);
    io_ddrMasters_1_r_payload_resp : out std_logic_vector(1 downto 0);
    io_ddrMasters_1_r_payload_last : out std_logic;
    axiA_awvalid : out std_logic;
    axiA_awready : in std_logic;
    axiA_awaddr : out std_logic_vector(31 downto 0);
    axiA_awregion : out std_logic_vector(3 downto 0);
    axiA_awlen : out std_logic_vector(7 downto 0);
    axiA_awsize : out std_logic_vector(2 downto 0);
    axiA_awburst : out std_logic_vector(1 downto 0);
    axiA_awlock : out std_logic_vector(0 to 0);
    axiA_awcache : out std_logic_vector(3 downto 0);
    axiA_awqos : out std_logic_vector(3 downto 0);
    axiA_awprot : out std_logic_vector(2 downto 0);
    axiA_wvalid : out std_logic;
    axiA_wready : in std_logic;
    axiA_wdata : out std_logic_vector(31 downto 0);
    axiA_wstrb : out std_logic_vector(3 downto 0);
    axiA_wlast : out std_logic;
    axiA_bvalid : in std_logic;
    axiA_bready : out std_logic;
    axiA_bresp : in std_logic_vector(1 downto 0);
    axiA_arvalid : out std_logic;
    axiA_arready : in std_logic;
    axiA_araddr : out std_logic_vector(31 downto 0);
    axiA_arregion : out std_logic_vector(3 downto 0);
    axiA_arlen : out std_logic_vector(7 downto 0);
    axiA_arsize : out std_logic_vector(2 downto 0);
    axiA_arburst : out std_logic_vector(1 downto 0);
    axiA_arlock : out std_logic_vector(0 to 0);
    axiA_arcache : out std_logic_vector(3 downto 0);
    axiA_arqos : out std_logic_vector(3 downto 0);
    axiA_arprot : out std_logic_vector(2 downto 0);
    axiA_rvalid : in std_logic;
    axiA_rready : out std_logic;
    axiA_rdata : in std_logic_vector(31 downto 0);
    axiA_rresp : in std_logic_vector(1 downto 0);
    axiA_rlast : in std_logic;
    axiAInterrupt : in std_logic;
    axiB_aw_valid : out std_logic;
    axiB_aw_ready : in std_logic;
    axiB_aw_payload_addr : out std_logic_vector(27 downto 0);
    axiB_aw_payload_id : out std_logic_vector(5 downto 0);
    axiB_aw_payload_region : out std_logic_vector(3 downto 0);
    axiB_aw_payload_len : out std_logic_vector(7 downto 0);
    axiB_aw_payload_size : out std_logic_vector(2 downto 0);
    axiB_aw_payload_burst : out std_logic_vector(1 downto 0);
    axiB_aw_payload_lock : out std_logic_vector(0 to 0);
    axiB_aw_payload_cache : out std_logic_vector(3 downto 0);
    axiB_aw_payload_qos : out std_logic_vector(3 downto 0);
    axiB_aw_payload_prot : out std_logic_vector(2 downto 0);
    axiB_aw_payload_allStrb : out std_logic;
    axiB_w_valid : out std_logic;
    axiB_w_ready : in std_logic;
    axiB_w_payload_data : out std_logic_vector(255 downto 0);
    axiB_w_payload_strb : out std_logic_vector(31 downto 0);
    axiB_w_payload_last : out std_logic;
    axiB_b_valid : in std_logic;
    axiB_b_ready : out std_logic;
    axiB_b_payload_id : in std_logic_vector(5 downto 0);
    axiB_b_payload_resp : in std_logic_vector(1 downto 0);
    axiB_ar_valid : out std_logic;
    axiB_ar_ready : in std_logic;
    axiB_ar_payload_addr : out std_logic_vector(27 downto 0);
    axiB_ar_payload_id : out std_logic_vector(5 downto 0);
    axiB_ar_payload_region : out std_logic_vector(3 downto 0);
    axiB_ar_payload_len : out std_logic_vector(7 downto 0);
    axiB_ar_payload_size : out std_logic_vector(2 downto 0);
    axiB_ar_payload_burst : out std_logic_vector(1 downto 0);
    axiB_ar_payload_lock : out std_logic_vector(0 to 0);
    axiB_ar_payload_cache : out std_logic_vector(3 downto 0);
    axiB_ar_payload_qos : out std_logic_vector(3 downto 0);
    axiB_ar_payload_prot : out std_logic_vector(2 downto 0);
    axiB_r_valid : in std_logic;
    axiB_r_ready : out std_logic;
    axiB_r_payload_data : in std_logic_vector(255 downto 0);
    axiB_r_payload_id : in std_logic_vector(5 downto 0);
    axiB_r_payload_resp : in std_logic_vector(1 downto 0);
    axiB_r_payload_last : in std_logic;
    cpu0_customInstruction_cmd_valid : out std_logic;
    cpu0_customInstruction_cmd_ready : in std_logic;
    cpu0_customInstruction_cmd_function_id : out std_logic_vector(9 downto 0);
    cpu0_customInstruction_cmd_inputs_0 : out std_logic_vector(63 downto 0);
    cpu0_customInstruction_cmd_inputs_1 : out std_logic_vector(63 downto 0);
    cpu0_customInstruction_rsp_valid : in std_logic;
    cpu0_customInstruction_rsp_ready : out std_logic;
    cpu0_customInstruction_rsp_outputs_0 : in std_logic_vector(63 downto 0);
    cpu1_customInstruction_cmd_valid : out std_logic;
    cpu1_customInstruction_cmd_ready : in std_logic;
    cpu1_customInstruction_cmd_function_id : out std_logic_vector(9 downto 0);
    cpu1_customInstruction_cmd_inputs_0 : out std_logic_vector(63 downto 0);
    cpu1_customInstruction_cmd_inputs_1 : out std_logic_vector(63 downto 0);
    cpu1_customInstruction_rsp_valid : in std_logic;
    cpu1_customInstruction_rsp_ready : out std_logic;
    cpu1_customInstruction_rsp_outputs_0 : in std_logic_vector(63 downto 0);
    cpu2_customInstruction_cmd_valid : out std_logic;
    cpu2_customInstruction_cmd_ready : in std_logic;
    cpu2_customInstruction_cmd_function_id : out std_logic_vector(9 downto 0);
    cpu2_customInstruction_cmd_inputs_0 : out std_logic_vector(63 downto 0);
    cpu2_customInstruction_cmd_inputs_1 : out std_logic_vector(63 downto 0);
    cpu2_customInstruction_rsp_valid : in std_logic;
    cpu2_customInstruction_rsp_ready : out std_logic;
    cpu2_customInstruction_rsp_outputs_0 : in std_logic_vector(63 downto 0);
    cpu3_customInstruction_cmd_valid : out std_logic;
    cpu3_customInstruction_cmd_ready : in std_logic;
    cpu3_customInstruction_cmd_function_id : out std_logic_vector(9 downto 0);
    cpu3_customInstruction_cmd_inputs_0 : out std_logic_vector(63 downto 0);
    cpu3_customInstruction_cmd_inputs_1 : out std_logic_vector(63 downto 0);
    cpu3_customInstruction_rsp_valid : in std_logic;
    cpu3_customInstruction_rsp_ready : out std_logic;
    cpu3_customInstruction_rsp_outputs_0 : in std_logic_vector(63 downto 0);
    system_uart_0_io_txd : out std_logic;
    system_uart_0_io_rxd : in std_logic;
    system_spi_0_io_sclk_write : out std_logic;
    system_spi_0_io_data_0_writeEnable : out std_logic;
    system_spi_0_io_data_0_read : in std_logic;
    system_spi_0_io_data_0_write : out std_logic;
    system_spi_0_io_data_1_writeEnable : out std_logic;
    system_spi_0_io_data_1_read : in std_logic;
    system_spi_0_io_data_1_write : out std_logic;
    system_spi_0_io_data_2_writeEnable : out std_logic;
    system_spi_0_io_data_2_read : in std_logic;
    system_spi_0_io_data_2_write : out std_logic;
    system_spi_0_io_data_3_writeEnable : out std_logic;
    system_spi_0_io_data_3_read : in std_logic;
    system_spi_0_io_data_3_write : out std_logic;
    system_spi_0_io_ss : out std_logic_vector(0 to 0);
    system_spi_1_io_sclk_write : out std_logic;
    system_spi_1_io_data_0_writeEnable : out std_logic;
    system_spi_1_io_data_0_read : in std_logic;
    system_spi_1_io_data_0_write : out std_logic;
    system_spi_1_io_data_1_writeEnable : out std_logic;
    system_spi_1_io_data_1_read : in std_logic;
    system_spi_1_io_data_1_write : out std_logic;
    system_spi_1_io_data_2_writeEnable : out std_logic;
    system_spi_1_io_data_2_read : in std_logic;
    system_spi_1_io_data_2_write : out std_logic;
    system_spi_1_io_data_3_writeEnable : out std_logic;
    system_spi_1_io_data_3_read : in std_logic;
    system_spi_1_io_data_3_write : out std_logic;
    system_spi_1_io_ss : out std_logic_vector(0 to 0);
    system_i2c_0_io_sda_write : out std_logic;
    system_i2c_0_io_sda_read : in std_logic;
    system_i2c_0_io_scl_write : out std_logic;
    system_i2c_0_io_scl_read : in std_logic;
    system_gpio_0_io_read : in std_logic_vector(3 downto 0);
    system_gpio_0_io_write : out std_logic_vector(3 downto 0);
    system_gpio_0_io_writeEnable : out std_logic_vector(3 downto 0);
    io_watchdog_hardPanic : out std_logic
);
end component soc_rv64_ip;

---------------------- End COMPONENT Declaration ------------
------------- Begin Cut here for INSTANTIATION Template -----
u_soc_rv64_ip : soc_rv64_ip
port map (
    io_asyncReset => io_asyncReset,
    io_systemClk => io_systemClk,
    io_systemReset => io_systemReset,
    io_peripheralClk => io_peripheralClk,
    io_peripheralReset => io_peripheralReset,
    io_memoryClk => io_memoryClk,
    io_memoryReset => io_memoryReset,
    axiB_clk => axiB_clk,
    axiB_reset => axiB_reset,
    io_ndmreset => io_ndmreset,
    jtagCtrl_tck => jtagCtrl_tck,
    jtagCtrl_tdi => jtagCtrl_tdi,
    jtagCtrl_enable => jtagCtrl_enable,
    jtagCtrl_capture => jtagCtrl_capture,
    jtagCtrl_shift => jtagCtrl_shift,
    jtagCtrl_update => jtagCtrl_update,
    jtagCtrl_reset => jtagCtrl_reset,
    jtagCtrl_tdo => jtagCtrl_tdo,
    io_ddrA_aw_valid => io_ddrA_aw_valid,
    io_ddrA_aw_ready => io_ddrA_aw_ready,
    io_ddrA_aw_payload_addr => io_ddrA_aw_payload_addr,
    io_ddrA_aw_payload_id => io_ddrA_aw_payload_id,
    io_ddrA_aw_payload_region => io_ddrA_aw_payload_region,
    io_ddrA_aw_payload_len => io_ddrA_aw_payload_len,
    io_ddrA_aw_payload_size => io_ddrA_aw_payload_size,
    io_ddrA_aw_payload_burst => io_ddrA_aw_payload_burst,
    io_ddrA_aw_payload_lock => io_ddrA_aw_payload_lock,
    io_ddrA_aw_payload_cache => io_ddrA_aw_payload_cache,
    io_ddrA_aw_payload_qos => io_ddrA_aw_payload_qos,
    io_ddrA_aw_payload_prot => io_ddrA_aw_payload_prot,
    io_ddrA_aw_payload_allStrb => io_ddrA_aw_payload_allStrb,
    io_ddrA_w_valid => io_ddrA_w_valid,
    io_ddrA_w_ready => io_ddrA_w_ready,
    io_ddrA_w_payload_data => io_ddrA_w_payload_data,
    io_ddrA_w_payload_strb => io_ddrA_w_payload_strb,
    io_ddrA_w_payload_last => io_ddrA_w_payload_last,
    io_ddrA_b_valid => io_ddrA_b_valid,
    io_ddrA_b_ready => io_ddrA_b_ready,
    io_ddrA_b_payload_id => io_ddrA_b_payload_id,
    io_ddrA_b_payload_resp => io_ddrA_b_payload_resp,
    io_ddrA_ar_valid => io_ddrA_ar_valid,
    io_ddrA_ar_ready => io_ddrA_ar_ready,
    io_ddrA_ar_payload_addr => io_ddrA_ar_payload_addr,
    io_ddrA_ar_payload_id => io_ddrA_ar_payload_id,
    io_ddrA_ar_payload_region => io_ddrA_ar_payload_region,
    io_ddrA_ar_payload_len => io_ddrA_ar_payload_len,
    io_ddrA_ar_payload_size => io_ddrA_ar_payload_size,
    io_ddrA_ar_payload_burst => io_ddrA_ar_payload_burst,
    io_ddrA_ar_payload_lock => io_ddrA_ar_payload_lock,
    io_ddrA_ar_payload_cache => io_ddrA_ar_payload_cache,
    io_ddrA_ar_payload_qos => io_ddrA_ar_payload_qos,
    io_ddrA_ar_payload_prot => io_ddrA_ar_payload_prot,
    io_ddrA_r_valid => io_ddrA_r_valid,
    io_ddrA_r_ready => io_ddrA_r_ready,
    io_ddrA_r_payload_data => io_ddrA_r_payload_data,
    io_ddrA_r_payload_id => io_ddrA_r_payload_id,
    io_ddrA_r_payload_resp => io_ddrA_r_payload_resp,
    io_ddrA_r_payload_last => io_ddrA_r_payload_last,
    io_ddrMasters_0_clk => io_ddrMasters_0_clk,
    io_ddrMasters_0_reset => io_ddrMasters_0_reset,
    io_ddrMasters_0_aw_valid => io_ddrMasters_0_aw_valid,
    io_ddrMasters_0_aw_ready => io_ddrMasters_0_aw_ready,
    io_ddrMasters_0_aw_payload_addr => io_ddrMasters_0_aw_payload_addr,
    io_ddrMasters_0_aw_payload_id => io_ddrMasters_0_aw_payload_id,
    io_ddrMasters_0_aw_payload_region => io_ddrMasters_0_aw_payload_region,
    io_ddrMasters_0_aw_payload_len => io_ddrMasters_0_aw_payload_len,
    io_ddrMasters_0_aw_payload_size => io_ddrMasters_0_aw_payload_size,
    io_ddrMasters_0_aw_payload_burst => io_ddrMasters_0_aw_payload_burst,
    io_ddrMasters_0_aw_payload_lock => io_ddrMasters_0_aw_payload_lock,
    io_ddrMasters_0_aw_payload_cache => io_ddrMasters_0_aw_payload_cache,
    io_ddrMasters_0_aw_payload_qos => io_ddrMasters_0_aw_payload_qos,
    io_ddrMasters_0_aw_payload_prot => io_ddrMasters_0_aw_payload_prot,
    io_ddrMasters_0_aw_payload_allStrb => io_ddrMasters_0_aw_payload_allStrb,
    io_ddrMasters_0_w_valid => io_ddrMasters_0_w_valid,
    io_ddrMasters_0_w_ready => io_ddrMasters_0_w_ready,
    io_ddrMasters_0_w_payload_data => io_ddrMasters_0_w_payload_data,
    io_ddrMasters_0_w_payload_strb => io_ddrMasters_0_w_payload_strb,
    io_ddrMasters_0_w_payload_last => io_ddrMasters_0_w_payload_last,
    io_ddrMasters_0_b_valid => io_ddrMasters_0_b_valid,
    io_ddrMasters_0_b_ready => io_ddrMasters_0_b_ready,
    io_ddrMasters_0_b_payload_id => io_ddrMasters_0_b_payload_id,
    io_ddrMasters_0_b_payload_resp => io_ddrMasters_0_b_payload_resp,
    io_ddrMasters_0_ar_valid => io_ddrMasters_0_ar_valid,
    io_ddrMasters_0_ar_ready => io_ddrMasters_0_ar_ready,
    io_ddrMasters_0_ar_payload_addr => io_ddrMasters_0_ar_payload_addr,
    io_ddrMasters_0_ar_payload_id => io_ddrMasters_0_ar_payload_id,
    io_ddrMasters_0_ar_payload_region => io_ddrMasters_0_ar_payload_region,
    io_ddrMasters_0_ar_payload_len => io_ddrMasters_0_ar_payload_len,
    io_ddrMasters_0_ar_payload_size => io_ddrMasters_0_ar_payload_size,
    io_ddrMasters_0_ar_payload_burst => io_ddrMasters_0_ar_payload_burst,
    io_ddrMasters_0_ar_payload_lock => io_ddrMasters_0_ar_payload_lock,
    io_ddrMasters_0_ar_payload_cache => io_ddrMasters_0_ar_payload_cache,
    io_ddrMasters_0_ar_payload_qos => io_ddrMasters_0_ar_payload_qos,
    io_ddrMasters_0_ar_payload_prot => io_ddrMasters_0_ar_payload_prot,
    io_ddrMasters_0_r_valid => io_ddrMasters_0_r_valid,
    io_ddrMasters_0_r_ready => io_ddrMasters_0_r_ready,
    io_ddrMasters_0_r_payload_data => io_ddrMasters_0_r_payload_data,
    io_ddrMasters_0_r_payload_id => io_ddrMasters_0_r_payload_id,
    io_ddrMasters_0_r_payload_resp => io_ddrMasters_0_r_payload_resp,
    io_ddrMasters_0_r_payload_last => io_ddrMasters_0_r_payload_last,
    io_ddrMasters_1_clk => io_ddrMasters_1_clk,
    io_ddrMasters_1_reset => io_ddrMasters_1_reset,
    io_ddrMasters_1_aw_valid => io_ddrMasters_1_aw_valid,
    io_ddrMasters_1_aw_ready => io_ddrMasters_1_aw_ready,
    io_ddrMasters_1_aw_payload_addr => io_ddrMasters_1_aw_payload_addr,
    io_ddrMasters_1_aw_payload_id => io_ddrMasters_1_aw_payload_id,
    io_ddrMasters_1_aw_payload_region => io_ddrMasters_1_aw_payload_region,
    io_ddrMasters_1_aw_payload_len => io_ddrMasters_1_aw_payload_len,
    io_ddrMasters_1_aw_payload_size => io_ddrMasters_1_aw_payload_size,
    io_ddrMasters_1_aw_payload_burst => io_ddrMasters_1_aw_payload_burst,
    io_ddrMasters_1_aw_payload_lock => io_ddrMasters_1_aw_payload_lock,
    io_ddrMasters_1_aw_payload_cache => io_ddrMasters_1_aw_payload_cache,
    io_ddrMasters_1_aw_payload_qos => io_ddrMasters_1_aw_payload_qos,
    io_ddrMasters_1_aw_payload_prot => io_ddrMasters_1_aw_payload_prot,
    io_ddrMasters_1_aw_payload_allStrb => io_ddrMasters_1_aw_payload_allStrb,
    io_ddrMasters_1_w_valid => io_ddrMasters_1_w_valid,
    io_ddrMasters_1_w_ready => io_ddrMasters_1_w_ready,
    io_ddrMasters_1_w_payload_data => io_ddrMasters_1_w_payload_data,
    io_ddrMasters_1_w_payload_strb => io_ddrMasters_1_w_payload_strb,
    io_ddrMasters_1_w_payload_last => io_ddrMasters_1_w_payload_last,
    io_ddrMasters_1_b_valid => io_ddrMasters_1_b_valid,
    io_ddrMasters_1_b_ready => io_ddrMasters_1_b_ready,
    io_ddrMasters_1_b_payload_id => io_ddrMasters_1_b_payload_id,
    io_ddrMasters_1_b_payload_resp => io_ddrMasters_1_b_payload_resp,
    io_ddrMasters_1_ar_valid => io_ddrMasters_1_ar_valid,
    io_ddrMasters_1_ar_ready => io_ddrMasters_1_ar_ready,
    io_ddrMasters_1_ar_payload_addr => io_ddrMasters_1_ar_payload_addr,
    io_ddrMasters_1_ar_payload_id => io_ddrMasters_1_ar_payload_id,
    io_ddrMasters_1_ar_payload_region => io_ddrMasters_1_ar_payload_region,
    io_ddrMasters_1_ar_payload_len => io_ddrMasters_1_ar_payload_len,
    io_ddrMasters_1_ar_payload_size => io_ddrMasters_1_ar_payload_size,
    io_ddrMasters_1_ar_payload_burst => io_ddrMasters_1_ar_payload_burst,
    io_ddrMasters_1_ar_payload_lock => io_ddrMasters_1_ar_payload_lock,
    io_ddrMasters_1_ar_payload_cache => io_ddrMasters_1_ar_payload_cache,
    io_ddrMasters_1_ar_payload_qos => io_ddrMasters_1_ar_payload_qos,
    io_ddrMasters_1_ar_payload_prot => io_ddrMasters_1_ar_payload_prot,
    io_ddrMasters_1_r_valid => io_ddrMasters_1_r_valid,
    io_ddrMasters_1_r_ready => io_ddrMasters_1_r_ready,
    io_ddrMasters_1_r_payload_data => io_ddrMasters_1_r_payload_data,
    io_ddrMasters_1_r_payload_id => io_ddrMasters_1_r_payload_id,
    io_ddrMasters_1_r_payload_resp => io_ddrMasters_1_r_payload_resp,
    io_ddrMasters_1_r_payload_last => io_ddrMasters_1_r_payload_last,
    axiA_awvalid => axiA_awvalid,
    axiA_awready => axiA_awready,
    axiA_awaddr => axiA_awaddr,
    axiA_awregion => axiA_awregion,
    axiA_awlen => axiA_awlen,
    axiA_awsize => axiA_awsize,
    axiA_awburst => axiA_awburst,
    axiA_awlock => axiA_awlock,
    axiA_awcache => axiA_awcache,
    axiA_awqos => axiA_awqos,
    axiA_awprot => axiA_awprot,
    axiA_wvalid => axiA_wvalid,
    axiA_wready => axiA_wready,
    axiA_wdata => axiA_wdata,
    axiA_wstrb => axiA_wstrb,
    axiA_wlast => axiA_wlast,
    axiA_bvalid => axiA_bvalid,
    axiA_bready => axiA_bready,
    axiA_bresp => axiA_bresp,
    axiA_arvalid => axiA_arvalid,
    axiA_arready => axiA_arready,
    axiA_araddr => axiA_araddr,
    axiA_arregion => axiA_arregion,
    axiA_arlen => axiA_arlen,
    axiA_arsize => axiA_arsize,
    axiA_arburst => axiA_arburst,
    axiA_arlock => axiA_arlock,
    axiA_arcache => axiA_arcache,
    axiA_arqos => axiA_arqos,
    axiA_arprot => axiA_arprot,
    axiA_rvalid => axiA_rvalid,
    axiA_rready => axiA_rready,
    axiA_rdata => axiA_rdata,
    axiA_rresp => axiA_rresp,
    axiA_rlast => axiA_rlast,
    axiAInterrupt => axiAInterrupt,
    axiB_aw_valid => axiB_aw_valid,
    axiB_aw_ready => axiB_aw_ready,
    axiB_aw_payload_addr => axiB_aw_payload_addr,
    axiB_aw_payload_id => axiB_aw_payload_id,
    axiB_aw_payload_region => axiB_aw_payload_region,
    axiB_aw_payload_len => axiB_aw_payload_len,
    axiB_aw_payload_size => axiB_aw_payload_size,
    axiB_aw_payload_burst => axiB_aw_payload_burst,
    axiB_aw_payload_lock => axiB_aw_payload_lock,
    axiB_aw_payload_cache => axiB_aw_payload_cache,
    axiB_aw_payload_qos => axiB_aw_payload_qos,
    axiB_aw_payload_prot => axiB_aw_payload_prot,
    axiB_aw_payload_allStrb => axiB_aw_payload_allStrb,
    axiB_w_valid => axiB_w_valid,
    axiB_w_ready => axiB_w_ready,
    axiB_w_payload_data => axiB_w_payload_data,
    axiB_w_payload_strb => axiB_w_payload_strb,
    axiB_w_payload_last => axiB_w_payload_last,
    axiB_b_valid => axiB_b_valid,
    axiB_b_ready => axiB_b_ready,
    axiB_b_payload_id => axiB_b_payload_id,
    axiB_b_payload_resp => axiB_b_payload_resp,
    axiB_ar_valid => axiB_ar_valid,
    axiB_ar_ready => axiB_ar_ready,
    axiB_ar_payload_addr => axiB_ar_payload_addr,
    axiB_ar_payload_id => axiB_ar_payload_id,
    axiB_ar_payload_region => axiB_ar_payload_region,
    axiB_ar_payload_len => axiB_ar_payload_len,
    axiB_ar_payload_size => axiB_ar_payload_size,
    axiB_ar_payload_burst => axiB_ar_payload_burst,
    axiB_ar_payload_lock => axiB_ar_payload_lock,
    axiB_ar_payload_cache => axiB_ar_payload_cache,
    axiB_ar_payload_qos => axiB_ar_payload_qos,
    axiB_ar_payload_prot => axiB_ar_payload_prot,
    axiB_r_valid => axiB_r_valid,
    axiB_r_ready => axiB_r_ready,
    axiB_r_payload_data => axiB_r_payload_data,
    axiB_r_payload_id => axiB_r_payload_id,
    axiB_r_payload_resp => axiB_r_payload_resp,
    axiB_r_payload_last => axiB_r_payload_last,
    cpu0_customInstruction_cmd_valid => cpu0_customInstruction_cmd_valid,
    cpu0_customInstruction_cmd_ready => cpu0_customInstruction_cmd_ready,
    cpu0_customInstruction_cmd_function_id => cpu0_customInstruction_cmd_function_id,
    cpu0_customInstruction_cmd_inputs_0 => cpu0_customInstruction_cmd_inputs_0,
    cpu0_customInstruction_cmd_inputs_1 => cpu0_customInstruction_cmd_inputs_1,
    cpu0_customInstruction_rsp_valid => cpu0_customInstruction_rsp_valid,
    cpu0_customInstruction_rsp_ready => cpu0_customInstruction_rsp_ready,
    cpu0_customInstruction_rsp_outputs_0 => cpu0_customInstruction_rsp_outputs_0,
    cpu1_customInstruction_cmd_valid => cpu1_customInstruction_cmd_valid,
    cpu1_customInstruction_cmd_ready => cpu1_customInstruction_cmd_ready,
    cpu1_customInstruction_cmd_function_id => cpu1_customInstruction_cmd_function_id,
    cpu1_customInstruction_cmd_inputs_0 => cpu1_customInstruction_cmd_inputs_0,
    cpu1_customInstruction_cmd_inputs_1 => cpu1_customInstruction_cmd_inputs_1,
    cpu1_customInstruction_rsp_valid => cpu1_customInstruction_rsp_valid,
    cpu1_customInstruction_rsp_ready => cpu1_customInstruction_rsp_ready,
    cpu1_customInstruction_rsp_outputs_0 => cpu1_customInstruction_rsp_outputs_0,
    cpu2_customInstruction_cmd_valid => cpu2_customInstruction_cmd_valid,
    cpu2_customInstruction_cmd_ready => cpu2_customInstruction_cmd_ready,
    cpu2_customInstruction_cmd_function_id => cpu2_customInstruction_cmd_function_id,
    cpu2_customInstruction_cmd_inputs_0 => cpu2_customInstruction_cmd_inputs_0,
    cpu2_customInstruction_cmd_inputs_1 => cpu2_customInstruction_cmd_inputs_1,
    cpu2_customInstruction_rsp_valid => cpu2_customInstruction_rsp_valid,
    cpu2_customInstruction_rsp_ready => cpu2_customInstruction_rsp_ready,
    cpu2_customInstruction_rsp_outputs_0 => cpu2_customInstruction_rsp_outputs_0,
    cpu3_customInstruction_cmd_valid => cpu3_customInstruction_cmd_valid,
    cpu3_customInstruction_cmd_ready => cpu3_customInstruction_cmd_ready,
    cpu3_customInstruction_cmd_function_id => cpu3_customInstruction_cmd_function_id,
    cpu3_customInstruction_cmd_inputs_0 => cpu3_customInstruction_cmd_inputs_0,
    cpu3_customInstruction_cmd_inputs_1 => cpu3_customInstruction_cmd_inputs_1,
    cpu3_customInstruction_rsp_valid => cpu3_customInstruction_rsp_valid,
    cpu3_customInstruction_rsp_ready => cpu3_customInstruction_rsp_ready,
    cpu3_customInstruction_rsp_outputs_0 => cpu3_customInstruction_rsp_outputs_0,
    system_uart_0_io_txd => system_uart_0_io_txd,
    system_uart_0_io_rxd => system_uart_0_io_rxd,
    system_spi_0_io_sclk_write => system_spi_0_io_sclk_write,
    system_spi_0_io_data_0_writeEnable => system_spi_0_io_data_0_writeEnable,
    system_spi_0_io_data_0_read => system_spi_0_io_data_0_read,
    system_spi_0_io_data_0_write => system_spi_0_io_data_0_write,
    system_spi_0_io_data_1_writeEnable => system_spi_0_io_data_1_writeEnable,
    system_spi_0_io_data_1_read => system_spi_0_io_data_1_read,
    system_spi_0_io_data_1_write => system_spi_0_io_data_1_write,
    system_spi_0_io_data_2_writeEnable => system_spi_0_io_data_2_writeEnable,
    system_spi_0_io_data_2_read => system_spi_0_io_data_2_read,
    system_spi_0_io_data_2_write => system_spi_0_io_data_2_write,
    system_spi_0_io_data_3_writeEnable => system_spi_0_io_data_3_writeEnable,
    system_spi_0_io_data_3_read => system_spi_0_io_data_3_read,
    system_spi_0_io_data_3_write => system_spi_0_io_data_3_write,
    system_spi_0_io_ss => system_spi_0_io_ss,
    system_spi_1_io_sclk_write => system_spi_1_io_sclk_write,
    system_spi_1_io_data_0_writeEnable => system_spi_1_io_data_0_writeEnable,
    system_spi_1_io_data_0_read => system_spi_1_io_data_0_read,
    system_spi_1_io_data_0_write => system_spi_1_io_data_0_write,
    system_spi_1_io_data_1_writeEnable => system_spi_1_io_data_1_writeEnable,
    system_spi_1_io_data_1_read => system_spi_1_io_data_1_read,
    system_spi_1_io_data_1_write => system_spi_1_io_data_1_write,
    system_spi_1_io_data_2_writeEnable => system_spi_1_io_data_2_writeEnable,
    system_spi_1_io_data_2_read => system_spi_1_io_data_2_read,
    system_spi_1_io_data_2_write => system_spi_1_io_data_2_write,
    system_spi_1_io_data_3_writeEnable => system_spi_1_io_data_3_writeEnable,
    system_spi_1_io_data_3_read => system_spi_1_io_data_3_read,
    system_spi_1_io_data_3_write => system_spi_1_io_data_3_write,
    system_spi_1_io_ss => system_spi_1_io_ss,
    system_i2c_0_io_sda_write => system_i2c_0_io_sda_write,
    system_i2c_0_io_sda_read => system_i2c_0_io_sda_read,
    system_i2c_0_io_scl_write => system_i2c_0_io_scl_write,
    system_i2c_0_io_scl_read => system_i2c_0_io_scl_read,
    system_gpio_0_io_read => system_gpio_0_io_read,
    system_gpio_0_io_write => system_gpio_0_io_write,
    system_gpio_0_io_writeEnable => system_gpio_0_io_writeEnable,
    io_watchdog_hardPanic => io_watchdog_hardPanic
);

------------------------ End INSTANTIATION Template ---------
