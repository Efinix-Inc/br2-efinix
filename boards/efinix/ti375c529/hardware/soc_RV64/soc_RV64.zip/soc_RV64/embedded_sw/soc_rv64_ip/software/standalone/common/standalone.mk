# --------------------------------------------------
# Paths
# --------------------------------------------------
BSP_PATH ?= ${STANDALONE}/../../bsp/${BSP}
# LWIP_PATH ?= ${BSP_PATH}/app/lwip
# FATFS_PATH ?= ${BSP_PATH}/app/fatfs

# --------------------------------------------------
# Toolchain
# --------------------------------------------------
RISCV_BIN ?= riscv-none-elf-
RISCV_CC=${RISCV_BIN}gcc
RISCV_OBJCOPY=${RISCV_BIN}objcopy
RISCV_OBJDUMP=${RISCV_BIN}objdump

# --------------------------------------------------
# SoC configuration
# --------------------------------------------------
include ${BSP_PATH}/include/soc.mk

# --------------------------------------------------
# RISC-V ISA / ABI
# --------------------------------------------------
MARCH := rv64i
MABI := lp64

ifeq ($(RV_M),yes)
	MARCH := $(MARCH)m
endif

ifeq ($(RV_A),yes)
	MARCH := $(MARCH)a
else
	ifeq ($(RV_C),yes)
		MARCH := $(MARCH)a
	endif
endif

ifeq ($(RV_F),yes)
	MARCH := $(MARCH)f

	ifneq ($(RV_D),yes)
		MABI := $(MABI)f
	endif
endif

ifeq ($(RV_D),yes)
	MARCH := $(MARCH)d
	MABI := $(MABI)d
endif

ifeq ($(RV_C),yes)
	MARCH := $(MARCH)c
endif

# --- Bit-manipulation Extensions ---

ifeq ($(RV_ZB),yes)
	MARCH := $(MARCH)_zba_zbb_zbs
endif

# --- Cache Management Operation Extensions ---

ifeq ($(RV_ZICBOM),yes)
	MARCH := $(MARCH)_zicbom
endif

# --------------------------------------------------
# Libraries / Newlib
# --------------------------------------------------
ifeq ($(NEWLIB), NOSTD)
	USELIB=0 # For NOSTD, set USELIB to 0.
	CFLAGS+= -DNO_LIBC_INIT_ARRAY
else
	USELIB=1 # For NANO, set USELIB to 1.
endif

ifeq ($(NEWLIB),NANO)
	LDFLAGS += --specs=nano.specs --specs=nosys.specs
else ifeq ($(NEWLIB),NOSTD)
	LDFLAGS += -nostdlib 
endif

ifeq ($(LIBGCC),yes)
	LIB += -lgcc
endif

ifeq ($(LIBC),yes)
	LIB += -lc
endif

ifeq ($(LIBMATH),yes)
	LIB += -lm
endif

MARCH := $(MARCH)_zicsr_zifencei

# --------------------------------------------------
# Include paths
# --------------------------------------------------
BSP_INCLUDES = \
	-I$(BSP_PATH)/include \
	-I$(BSP_PATH)/include/boards

MW_INCLUDES = \
	-I$(LWIP_PATH) \
	-I$(FATFS_PATH)

DRV_INCLUDES = \
	-I$(STANDALONE)/driver

COMMON_INCLUDES = \
	-I$(STANDALONE)/common

CFLAGS += $(BSP_INCLUDES) $(MW_INCLUDES) $(DRV_INCLUDES) $(COMMON_INCLUDES)

# --------------------------------------------------
# Compiler flags
# --------------------------------------------------
CFLAGS += -mcmodel=medany
CFLAGS += -march=$(MARCH) -mabi=$(MABI)
CFLAGS += $(DEBUG_LVL) $(OPT_LVL)
CFLAGS += -DUSE_GP
CFLAGS += $(U_CFLAGS)
CFLAGS += -DUSELIB=$(USELIB)
CFLAGS += -ffunction-sections -fdata-sections

# --------------------------------------------------
# Linker flags
# --------------------------------------------------
LDFLAGS += -march=$(MARCH) -mabi=$(MABI)
LDFLAGS += -nostartfiles -ffreestanding
LDFLAGS += -Wl,-Bstatic
LDFLAGS += $(LIB)
LDFLAGS += $(U_LDFLAGS)
LDFLAGS += -T $(LDSCRIPT)
LDFLAGS += -Wl,--no-warn-rwx-segment
LDFLAGS += -Wl,-Map,$(OBJDIR)/$(PROJ_NAME).map,--print-memory-usage,--gc-sections

# --------------------------------------------------
# Objects
# -------------------------------------------------

DOT:= .
COLON:=:
DELIM:=@@DELIM@@
# Scans current directory ($1) & Recursively calls itself on subdirectories
rwildcard=$(foreach d,$(wildcard $(1:=/*)),$(call rwildcard,$d,$2) $(filter $(subst *,%,$2),$d))

# Usage:
SRCS += $(call rwildcard, ${STANDALONE}/common, *.c)
SRCS += $(call rwildcard, ${STANDALONE}/common, *.S)
SRCS += $(call rwildcard, ${STANDALONE}/driver, *.c)

OBJDIR ?= build
OBJS := $(SRCS)
OBJS := $(notdir $(OBJS))
OBJS := $(OBJS:.c=.o)
OBJS := $(OBJS:.cpp=.o)
OBJS := $(OBJS:.S=.o)
OBJS := $(OBJS:.s=.o)
OBJS := $(addprefix $(OBJDIR)/obj_files/,$(OBJS))

all: $(OBJDIR)/$(PROJ_NAME).elf $(OBJDIR)/$(PROJ_NAME).asm $(OBJDIR)/$(PROJ_NAME).bin

$(OBJDIR)/%.elf: $(OBJS) | $(OBJDIR)
	@echo "LD $(PROJ_NAME)"
	@echo "$(LDFLAGS)"
	@$(RISCV_CC) $(CFLAGS) -o $@ $^ $(LDFLAGS)

%.bin: %.elf
	@$(RISCV_OBJCOPY) -O binary $^ $@

%.v: %.elf
	@$(RISCV_OBJCOPY) -O verilog $^ $@

%.asm: %.elf
	@$(RISCV_OBJDUMP) -S -d $^ > $@

define LIST_RULE
$(word 1,$(subst $(DELIM), ,$(1))): $(word 2,$(subst $(DELIM), ,$(1)))
	@mkdir -p $(dir $(word 1, $(subst $(DELIM), ,$(1))))
	@echo "CC $(word 2,$(subst $(DELIM), ,$(1)))"
	@echo " $(CFLAGS)"
	@$(RISCV_CC) -c $(CFLAGS)  $(INC) -o $(word 1,$(subst $(DELIM), ,$(1))) $(word 2,$(subst $(DELIM), ,$(1)))
endef

CAT:= $(addsuffix  $(DELIM), $(OBJS))
CAT:= $(join  $(CAT), $(SRCS))
$(foreach i,$(CAT),$(eval $(call LIST_RULE,$(i))))

$(OBJDIR):
	@mkdir -p $@

clean:
	@rm -rf $(OBJDIR)

.SECONDARY: $(OBJS)
