////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/*******************************************************************************
*
* @file main.c: rtcDemo 
*
* @brief This demo uses the I2C peripheral to communicate with on-board PCF8523 RTC module
* 		 on Ti375C529. It allows user to change various configuration such as real-time data 
*		 with convertible 12/24hr time system, battery setting of the PCF8523 module.
*
* @note To run this example design, please make sure the following requirements are fulfilled:
* 		1. Ti375C529 Dev Board
* 		2. Enable UART0 and I2C0
*
*		User are allowed to configure certain parameters in peri.h (User defined Section)
*		1. I2C_FREQ 		=> Frequency of I2C, default set to 100kHz
*
******************************************************************************/
#include <stdio.h>
#include "bsp.h"
#include "irq.h"
#include "userDef.h"

// Include application layer for RTC configuration and control
#include "app/rtcApp.h"

/* =========================================================================
 * NEWLIB Guard — scanf requires NEWLIB = NANO
 * ========================================================================= */
#if (USELIB == 0)

void main() {
    bsp_init();
    printf(ANSI_RED  "[ERR] Please use NEWLIB = NANO in makefile for this demo.\n\r");
    printf(           "User needs to implement scanf if switching to NEWLIB=NOSTD.\r\n" ANSI_RESET);
}

#else
#ifdef SYSTEM_I2C_0_IO_CTRL

extern void trap_entry();


/******************************************************************************
*
* The OPENING_STRING is used to display the message at the beginning of the program
*
******************************************************************************/
#define OPENING_STRING "The default RTC driver is set to PCF8523 \
                        (Built-in Ti375C529_devkit),User may change the \
                        supported driver via userDef.h\n"


/******************************************************************************
*
* @brief This struct configure I2C setting, driver used.
*
******************************************************************************/
rtc_instance_t RTC = {
    .drv  = &RTC_DRIVER,
    .inst = &(i2c_instance_t){
        .hwreg      			= I2C_CTRL,
        .slaveAddress			= RTC_CTRL,
        .samplingClockDivider	= 3,
        .timeout				= I2C_CTRL_HZ/1000,
        .tsuDat					= I2C_CTRL_HZ/(I2C_FREQ*5),
        .tLow					= I2C_CTRL_HZ/(I2C_FREQ*2),
        .tHigh					= I2C_CTRL_HZ/(I2C_FREQ*2),
        .tBuf					= I2C_CTRL_HZ/(I2C_FREQ),
},
};


/******************************************************************************
*
* @brief This struct configure PLIC setting for I2C interrupt
*
******************************************************************************/
void rtc_init(){
    plic_instance_t rtc_plic = {
        .target 	= BSP_PLIC_CPU_0,
        .gateway 	= SYSTEM_I2C_0_IO_INTERRUPT,
        .priority 	= 0x1U,
        .enable 	= 0X1U,
        .threshold 	= 0x0U,
    };
    
    plic_applyConfig(&rtc_plic);
}



/******************************************************************************
*
* @brief This is a custom IRQ Handler for I2C ID.
*
******************************************************************************/
int irq_m_i2c0_handler()
{
    printf(ANSI_RED "WARN: I2C Timeout/Dropped!\n" ANSI_RESET);
    i2c_clearInterruptFlag(RTC.inst,I2C_INTERRUPT_DROP);
    while(1);
    return 0;
}


/******************************************************************************
*
* @brief This main function intialize UART configuration and allow user to configure
* 		 RTC in runtime.
*
******************************************************************************/
void main(void) {
    bsp_init();
    printf(ANSI_RESET "Welcome to RTC Demo!\n\n");
    LOG_INFO(DBG_MOD_MAIN,OPENING_STRING);
    u32 choice = 0;
    
    // Initialize RTC Interrupt and Enable Error Interrupt
    rtc_applyConfig(&RTC);
    rtc_enableErrorInterrupt(&RTC);
    rtc_init();

    // Turn on global interrupt after configuring PLIC and enabling RTC interrupt
    irq_setTrapVector(trap_entry);
    irq_setType(IRQ_EXTERNAL);
    irq_enable();
    while (1) {
        printf(RTC_MENU);
        if (scanf("%d", &choice) == 1) {
            switch (choice) {
                case READ_DATA:
                    rtcApp_printTime(&RTC);
                    break;
                case WRITE_DATA:
                    rtcApp_setTime(&RTC);
                    break;
                case CONFIG_TIMESYSTEM:
                    rtcApp_setTimeSystem(&RTC);
                    break;
                default:
                    printf(ANSI_RED "\n[ERR] Invalid Option. Try 1-3.\n" ANSI_RESET);
            }
        }
        else {
            // This loop reads and discards characters from buffer until newline.
            while(getchar() != '\n');
            printf(ANSI_RED "\n[ERR] Invalid Input. Numbers only.\n" ANSI_RESET);
        }
    }
}


#else   /* SYSTEM_I2C_0_IO_CTRL not defined */
void main() {
   bsp_init();
   printf(ANSI_RED "\n[ERR] I2C is disabled, please enable it to run this app. \n"ANSI_RESET);
}
#endif  /* SYSTEM_I2C_0_IO_CTRL */
#endif  /* USELIB */


