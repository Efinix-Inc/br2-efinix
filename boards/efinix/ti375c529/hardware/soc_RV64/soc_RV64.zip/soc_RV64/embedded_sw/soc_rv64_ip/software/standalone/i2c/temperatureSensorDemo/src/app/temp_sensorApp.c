////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/*******************************************************************************
*
* @file TEMP_SENSOR_APP
*
* @brief Implementation file contain high level API for Temperature Sensor.
*
******************************************************************************/

#include "temp_sensorApp.h"
#include <stdio.h>
#include "bsp.h"
/******************************************************************************
*
* @brief This function print time in a formatted way. 
* @return none.
*
******************************************************************************/
void tempSensorApp_configure(temp_sensor_instance_t *temp){

    temp->drv->applyConfig(temp);
    //temp->drv->enableErrorInterrupt(temp);
    temp_sensor_data_t *data = &temp->temp_value;

    //Configure range of the temperature measurement
    if (temp->drv->setTempRange)
        temp->drv->setTempRange(temp,EXTENDED_RANGE_ENABLED);

    printf("********************START OF CONFIGURATION***********************\r\n\n");
    temp->temp_value.channels[0].high_limit = HIGH_TEMPERATURE_LIMIT_VALUE_INT; // Internal
    temp->temp_value.channels[0].low_limit  = LOW_TEMPERATURE_LIMIT_VALUE_INT;
    temp->temp_value.channels[1].high_limit = HIGH_TEMPERATURE_LIMIT_VALUE_EXT1; // External 1
    temp->temp_value.channels[1].low_limit  = LOW_TEMPERATURE_LIMIT_VALUE_EXT1;
    temp->temp_value.channels[2].high_limit = HIGH_TEMPERATURE_LIMIT_VALUE_EXT2; // External 1
    temp->temp_value.channels[2].low_limit  = LOW_TEMPERATURE_LIMIT_VALUE_EXT2;
    temp->drv->setTempLimit(temp);

    temp->drv->getTempLimit(temp);
    printf("Set High Temperature limit in internal EMC1413 sensor: %f°C \r\n",data->channels[0].high_limit);
    printf("Set High Temperature limit on temperature sensor 1   : %f°C \r\n",data->channels[1].high_limit);
    printf("Set High Temperature limit on temperature sensor 2   : %f°C \r\n",data->channels[2].high_limit);
    printf("Set Low Temperature limit in internal EMC1413 sensor : %f°C \r\n",data->channels[0].low_limit);
    printf("Set Low Temperature limit on temperature sensor 1    : %f°C \r\n",data->channels[1].low_limit);
    printf("Set Low Temperature limit on temperature sensor 2    : %f°C \r\n",data->channels[2].low_limit);
    if (temp->drv->checkTempRange(temp))
        printf("Range of the temperature measurement: Extended Range (-64°C to +191°C)\n");
    else printf("Range of the temperature measurement: Default Range (0°C to +127°C)\n");
    printf("\n********************END OF CONFIGURATION***********************\r\n");
    printf(ANSI_GREEN "OK: Done Configure!!!\n\n"ANSI_RESET);

}