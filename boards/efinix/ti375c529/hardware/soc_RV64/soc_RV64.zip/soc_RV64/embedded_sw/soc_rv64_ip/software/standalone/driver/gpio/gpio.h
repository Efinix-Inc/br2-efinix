////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header: bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef GPIO_H
#define GPIO_H

/**
 * @file gpio.h
 * @author Efinix Inc
 * @brief GPIO driver API definitions.
 *
 * This file provides data structures and APIs for controlling
 * the GPIO peripheral on the EfxSapphireSoC platform.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "type.h"
#include "soc.h"
#include "riscv.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup GPIO GPIO Driver
 * @brief General Purpose I/O (GPIO) driver.
 * @ingroup io_group
 *
 * This module provides functions to configure and control
 * GPIO input/output and interrupt behavior.
 * @section Example_GPIO Usage & Initialization.
 * This is an example show how to instantiate @ref GPIO with @ref gpio_instance_t.
 *
 * @code
 * #include "gpio/gpio.h"
 * 
 * #define GPIO_0  (gpio_hwreg_t*)SYSTEM_GPIO_0_IO_CTRL
 * 
 * void gpio_init(){
 * 	gpio_instance_t gpio_0 = {
 * 		.hwreg		    = GPIO_0,
 * 		.output         = 0x00, // Set GPIO Output pin Value
 * 		.outputEnable   = 0x0E, // Set to Enable GPIO pin as OUTPUT.
 * 	};
 * 	gpio_applyConfig(&gpio_0);
 * 
 * }
 * @endcode 
 * @see @ref gpioDemo "Example GPIO Demo" - Learn how to use the driver for basic operations 
 * @{
 */

/* ========================================================================== */
/* SUB-GROUP : DATA STRUCTS                                          			*/
/* ========================================================================== */
/**
 * @defgroup GPIO_Types Data Structures
 * @ingroup GPIO
 * @brief Structs and Enums used by the driver.
 * @note
 * <b> This is an example show how to instantiate GPIO with @ref gpio_instance_t 
 * and @ref gpio_hwreg_t.
 * 
 * @code 
 * #define GPIO_0  (gpio_hwreg_t*)SYSTEM_GPIO_0_IO_CTRL
 * 
 * gpio_instance_t gpio_0 = {
 * 		.hwreg		    = GPIO_0,
 * 		.output         = 0x00, // Set GPIO Output pin Value
 * 		.outputEnable   = 0x0E, // Set to Enable GPIO pin as OUTPUT.
 * };
 * gpio_applyConfig(&gpio_0);
 * 
 * @endcode
 * @{
 */

    /**
     * @brief GPIO hardware register map.
     *
     * This is the main structure that maps directly onto the GPIO peripheral
     * memory-mapped register layout.
     */
    typedef volatile struct {
        u32 INPUT;                  ///< Address Offset: 0x00 - Input Value */
        u32 OUTPUT;                 ///< Address Offset: 0x04 - Output Value */
        u32 OUTPUT_ENABLE;          ///< Address Offset: 0x08 - Output Enable (Direction) */
        u32 RESERVED0[5];           ///< Reserved Space (0x0C to 0x1F) */
        u32 INTERRUPT_RISE_ENABLE;  ///< Address Offset: 0x20 - Rising Edge IRQ */
        u32 INTERRUPT_FALL_ENABLE;  ///< Address Offset: 0x24 - Falling Edge IRQ */
        u32 INTERRUPT_HIGH_ENABLE;  ///< Address Offset: 0x28 - High Level IRQ */
        u32 INTERRUPT_LOW_ENABLE;   ///< Address Offset: 0x2C - Low Level IRQ */
    } gpio_hwreg_t;
    /**
     * @brief GPIO instance.
     *
     * Holds the software  registers and a pointer
     * to the hardware register block.
     */
    typedef struct {
        gpio_hwreg_t    *hwreg;               ///< Pointer to Hardware Register Map */
        u32             output;               ///< Stored Output Value */
        u32             outputEnable;         ///< Stored Output Enable Mask */
        u32             interruptRiseEnable;  ///< Stored Rise IRQ Mask */
        u32             interruptFallEnable;  ///< Stored Fall IRQ Mask */
        u32             interruptHighEnable;  ///< Stored High IRQ Mask */
        u32             interruptLowEnable;   ///< Stored Low IRQ Mask */
    } gpio_instance_t;

/** @} */ // End of GPIO_Types group

/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup GPIO_Funcs API Functions
 * @ingroup GPIO
 * @brief Function definitions for GPIO driver.
 * @{
 */

    /**
     * @brief Apply stored GPIO configuration to hardware.
     *
     * Writes all configuration values to the
     * corresponding hardware registers.
     *
     * @param inst Pointer to GPIO instance.
     */
    void gpio_applyConfig(gpio_instance_t *inst);

    /** @name GPIO (Get Functions)
     * Read values from the GPIO hardware registers.
     * @{
     */
        /**
         * @brief Read GPIO Input Register.
         * @param inst Pointer to GPIO instance.
         * @return Current state of the input pins.
         */
        u32 gpio_getInput(gpio_instance_t *inst);

        /**
         * @brief Get stored GPIO Output Value.
         * @param inst Pointer to GPIO instance.
         * @return The value currently set in the output register.
         */
        u32 gpio_getOutput(gpio_instance_t *inst);

        /**
         * @brief Get stored GPIO Output Enable Mask.
         * @param inst Pointer to GPIO instance.
         * @return The current output enable (direction) mask.
         */
        u32 gpio_getOutputEnable(gpio_instance_t *inst);

        /**
         * @brief Get Rising Edge Interrupt Mask.
         * @param inst Pointer to GPIO instance.
         * @return The current rising edge interrupt enable mask.
         */
        u32 gpio_getInterruptRiseEnable(gpio_instance_t *inst);

        /**
         * @brief Get Falling Edge Interrupt Mask.
         * @param inst Pointer to GPIO instance.
         * @return The current falling edge interrupt enable mask.
         */
        u32 gpio_getInterruptFallEnable(gpio_instance_t *inst);

        /**
         * @brief Get High Level Interrupt Mask.
         * @param inst Pointer to GPIO instance.
         * @return The current high level interrupt enable mask.
         */
        u32 gpio_getInterruptHighEnable(gpio_instance_t *inst);

        /**
         * @brief Get Low Level Interrupt Mask.
         * @param inst Pointer to GPIO instance.
         * @return The current low level interrupt enable mask.
         */
        u32 gpio_getInterruptLowEnable(gpio_instance_t *inst);
    /** @} */

    /** @name GPIO (Set Functions)
     * Write values to the GPIO  registers.
     * @note Call gpio_applyConfig() to make these changes effective.
     * @{
     */

        /**
         * @brief Set GPIO Output Value.
         * @param inst  Pointer to GPIO instance.
         * @param value Bitmask of pins to set high/low.
         */
        void gpio_setOutput(gpio_instance_t *inst, u32 value);

        /**
         * @brief Set GPIO Output Enable (Direction).
         * @param inst  Pointer to GPIO instance.
         * @param value Bitmask where 1 = Output, 0 = Input.
         */
        void gpio_setOutputEnable(gpio_instance_t *inst, u32 value);

        /**
         * @brief Set Rising Edge Interrupt Enable.
         * @param inst  Pointer to GPIO instance.
         * @param value Bitmask where 1 = Enable Interrupt.
         */
        void gpio_setInterruptRiseEnable(gpio_instance_t *inst, u32 value);

        /**
         * @brief Set Falling Edge Interrupt Enable.
         * @param inst  Pointer to GPIO instance.
         * @param value Bitmask where 1 = Enable Interrupt.
         */
        void gpio_setInterruptFallEnable(gpio_instance_t *inst, u32 value);

        /**
         * @brief Set High Level Interrupt Enable.
         * @param inst  Pointer to GPIO instance.
         * @param value Bitmask where 1 = Enable Interrupt.
         */
        void gpio_setInterruptHighEnable(gpio_instance_t *inst, u32 value);

        /**
         * @brief Set Low Level Interrupt Enable.
         * @param inst  Pointer to GPIO instance.
         * @param value Bitmask where 1 = Enable Interrupt.
         */
        void gpio_setInterruptLowEnable(gpio_instance_t *inst, u32 value);
    /** @} */

/** @} */ // End of GPIO_Funcs group
#ifdef __cplusplus
}
#endif

/** @} */ // End of MAIN GPIO Group

#endif // GPIO_H
