////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/**
* @file pcf8523.c
* @brief pcf8523 RTC driver implementation.
*
* Implements the functions defined in pcf8523.h for controlling
* pcf8523 RTC input/output and interrupts on the EfxSapphireSoC platform.
* @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
* See the full @ref license_page for Efinix and SaxonSoc MIT terms.
*/
#include <stdio.h>
#include "bsp.h"
#include "rtc/device/PCF8523.h"

/* -----------------------------------------------------------------------------*/
/*  RTC - Hardware Register Map for PCF8523	              						
/* -----------------------------------------------------------------------------*/

/* --- Address: Control Status Register --- */
#define RTC_CONTROL_1		0X00
#define	RTC_CONTROL_2		0X01
#define RTC_CONTROL_3		0X02

/* --- Address: Timekeeping Register --- */
#define RTC_SECONDS			0X03
#define	RTC_MINUTES			0X04
#define RTC_HOURS			0X05
#define RTC_DAYS			0X06
#define RTC_WEEKDAYS		0X07
#define RTC_MONTH			0X08
#define RTC_YEAR			0X09

/* --- Address: Timer Register --- */
#define TIMER_A_FREQ_CTRL   0x10
#define TIMER_A_REG         0x11
#define TIMER_B_FREQ_CTRL   0x12
#define TIMER_B_REG         0x13

/* --- Address: Timekeeping/ALARM in Each Register --- */
#define SECONDS_DATA 		0X7F 
#define MINUTES_DATA 		0X7F 
#define HOURS_DATA 			0X3F 
#define DAYS_DATA 			0X3F
#define WEEKDAYS_DATA 		0X07
#define MONTHS_DATA 		0X1F
#define YEARS_DATA 			0XFF

/* -----------------------------------------------------------------------------*/
/* RTC: Plug & Play Driver                            	        	
/* -----------------------------------------------------------------------------*/
const rtc_api_t PCF8523_DRIVER =
{
    .applyConfig			= PCF8523_applyConfig,
    .enableErrorInterrupt 	= PCF8523_enableErrorInterrupt,
    .getTime        		= PCF8523_getTime,
    .setTime        		= PCF8523_setTime,
    .setTimeSystem  		= PCF8523_setTimeSystem,

};

rtc_status_t PCF8523_applyConfig(rtc_instance_t *rtc) {

    i2c_applyConfig(rtc->inst);
    return RTC_OK;
}

rtc_status_t PCF8523_enableErrorInterrupt(rtc_instance_t *rtc) {

     // Will drop I2C Transcation if Timeout.
    i2c_enableInterrupt(rtc->inst, I2C_INTERRUPT_DROP);
    return RTC_OK;
}

rtc_status_t PCF8523_getTime(rtc_instance_t *rtc) {
    
    LOG_INFO(DBG_MOD_RTC,"This is PCF8523_getTime func!\n");
    rtc_data_t *time = &rtc->current_time;
    u8 get_data[9] = {0}; 

    // Hardware Read
    i2c_setMux(rtc->inst, 0x1);
    i2c_readData_b(rtc->inst, RTC_CONTROL_1, get_data, 14);

    // Parsing
    time->timesystem = (get_data[RTC_CONTROL_1] & 0x08) >> 3;
    time->seconds  	= bcd2bin(get_data[RTC_SECONDS] & SECONDS_DATA);
    time->minutes  	= bcd2bin(get_data[RTC_MINUTES] & MINUTES_DATA);
    time->years    	= bcd2bin(get_data[RTC_YEAR]);
    time->months   	= bcd2bin(get_data[RTC_MONTH] & MONTHS_DATA); 
    time->days     	= bcd2bin(get_data[RTC_DAYS]  & DAYS_DATA);
    time->weekdays 	= get_data[RTC_WEEKDAYS] & WEEKDAYS_DATA;
    u8 raw_hours 	= get_data[RTC_HOURS];

    if (time->timesystem == 1) { 
        // --- 12 Hour Mode ---
        time->PM = (raw_hours & 0x20) >> 5; 
        time->hours = bcd2bin(raw_hours & 0x1F); 
    } 
    else {
        // --- 24 Hour Mode ---
        time->PM = 0; // Not applicable
        time->hours = bcd2bin(raw_hours & 0x3F); 
    }

    return RTC_OK;
}

rtc_status_t PCF8523_setTime(rtc_instance_t *rtc) {
    rtc_data_t *t = &rtc->current_time;
    u8 buffer[1];
    
    i2c_setMux(rtc->inst, 0x1);
    i2c_readData_b(rtc->inst, RTC_CONTROL_1, buffer, 1);
    
    // Make sure it is in 24hr timesystem!
    // Check Bit 3 (0 = 24h, 1 = 12h). If it is 1, we must clear it.
    if (buffer[0] & 0x08) { 
        buffer[0] &= ~0x08; // Clear Bit 3 to force 24h mode
        
        i2c_setMux(rtc->inst, 0xF);
        i2c_writeData_b(rtc->inst, RTC_CONTROL_1, buffer, 1);
    }

    u8 set_data[7] = {
        bin2bcd(t->seconds),
        bin2bcd(t->minutes),
        bin2bcd(t->hours),    // 0-23 is now perfectly valid
        bin2bcd(t->days),
        bin2bcd(t->weekdays),
        bin2bcd(t->months),
        bin2bcd(t->years)
    };
    i2c_setMux(rtc->inst, 0xF);
    i2c_writeData_b(rtc->inst, RTC_SECONDS, set_data, 7);

    return RTC_OK;
}

rtc_status_t PCF8523_setTimeSystem(rtc_instance_t *rtc, u8 use_12hour_mode) {
    u8 buffer[1];
    u8 current_mode_12h;
    
    // Check Current Status
    i2c_setMux(rtc->inst,0x1);
    i2c_readData_b(rtc->inst, RTC_CONTROL_1, buffer, 1);
    
    // Extract Bit 3 (0 = 24h, 1 = 12h)
    current_mode_12h = (buffer[0] & 0x08) >> 3;

    // If already in the correct mode, exit
    if (current_mode_12h == use_12hour_mode) {
        return RTC_SKIP;
    }

    // Update the Control Register (Switch the Mode bit)
    if (use_12hour_mode) {
        buffer[0] |= 0x08;  // Set Bit 3 (12h)
    } else {
        buffer[0] &= ~0x08; // Clear Bit 3 (24h)
    }
    
    i2c_setMux(rtc->inst,0xF); // Assuming this is needed for writes on your board
    i2c_writeData_b(rtc->inst, RTC_CONTROL_1, buffer, 1);


    // Update Current Time Hour Register
    i2c_setMux(rtc->inst, 0x1);
    i2c_readData_b(rtc->inst, RTC_HOURS, buffer, 1);
    
    buffer[0] = convert_hour_register(buffer[0], use_12hour_mode);
    
    i2c_setMux(rtc->inst,0xF);
    i2c_writeData_b(rtc->inst, RTC_HOURS, buffer, 1);

    // User Feedback
    return RTC_OK;
}

rtc_status_t PCF8523_softreset(rtc_instance_t *rtc)
{
    u8 status[1] = {0x58};
    i2c_setMux(rtc->inst,0xF);
    i2c_writeData_b(rtc->inst,RTC_CONTROL_1,status,1);
    return RTC_OK;
}

rtc_status_t PCF8523_getCSR(rtc_instance_t *rtc)
{
    u8 status[3] = { };
    i2c_setMux(rtc->inst,0x1);
    i2c_readData_b(rtc->inst, RTC_CONTROL_1, status, 3);
    for (int i = 1; i < 4; i++) {
        LOG_INFO(DBG_MOD_RTC,"RTC CSR%d readback: %x", RTC_CONTROL_1 + i, status[i - 1]);
    }
    return RTC_OK;
}
