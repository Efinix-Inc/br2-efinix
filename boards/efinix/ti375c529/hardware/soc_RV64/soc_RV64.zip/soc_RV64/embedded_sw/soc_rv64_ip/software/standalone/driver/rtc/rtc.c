////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/**
* @file rtc.c
* @brief RTC driver implementation.
*
* Implements the functions defined in rtc.h for controlling
* RTC input/output and interrupts on the EfxSapphireSoC platform.
* @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
* See the full @ref license_page for Efinix and SaxonSoc MIT terms.
*/

#include "rtc/rtc.h"
#include <stddef.h>

/*----------------------------------------------------------------------------*/
/* Function implementations                                                    */
/*----------------------------------------------------------------------------*/


const char* Day_ordinal [] = {
        "st",
        "nd",
        "rd",
        "th"
};


const char* const DayStrings[]  = {
        "Unknown",
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday"
};


const char* const MonthStrings[]  = {
        "Unknown",
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July" ,
        "August" ,
        "September" ,
        "October",
        "November" ,
        "December"
};



const char* const  meridiem[] = {
        "am",
        "pm"
};



const char* get_ordinal(u8 day) {
    if (day >= 11 && day <= 13) return "th"; // Special case for 11th, 12th, 13th
    
    switch (day % 10) {
        case 1:  return "st";
        case 2:  return "nd";
        case 3:  return "rd";
        default: return "th";
    }
}

rtc_status_t rtc_applyConfig(rtc_instance_t *rtc) {
    // Safety check! Ensure the pointer actually exists before calling it
    if (rtc != NULL && rtc->drv != NULL && rtc->drv->applyConfig != NULL) {
        
        return rtc->drv->applyConfig(rtc);
    }
    
    return RTC_ERR; 
}
rtc_status_t rtc_enableErrorInterrupt(rtc_instance_t *rtc) {

    if (rtc != NULL && rtc->drv != NULL && rtc->drv->enableErrorInterrupt != NULL) {
        return rtc->drv->enableErrorInterrupt(rtc);
    }
    return RTC_ERR;
}
u8 convert_hour_register(u8 old_reg_val, u8 to_12h)
{
        u8 h, pm_flag;
        u8 new_reg_val;

        if (to_12h) { 
            // --- Convert 24h to 12h ---
            // Input is raw BCD (00 to 23)
            h = bcd2bin(old_reg_val & 0x3F); // Mask 0x3F removes unused bits
            
            if (h >= 12) {
                pm_flag = 1;
                if (h > 12) h -= 12;
            } else {
                pm_flag = 0;
                if (h == 0) h = 12; // 00:00 becomes 12:00 AM
            }
            
            // Re-encode: [Bit 5 = PM] [Bits 4-0 = Hour BCD]
            new_reg_val = bin2bcd(h) | (pm_flag << 5);
        } 
        else {
            // --- Convert 12h to 24h ---
            // Input is [Bit 5 = PM] [Bits 4-0 = Hour BCD]
            pm_flag = (old_reg_val & 0x20) >> 5;
            h = bcd2bin(old_reg_val & 0x1F); // Mask 0x1F gets the number
            
            if (pm_flag) {
                // PM Case: 12 PM -> 12, 1 PM -> 13
                if (h < 12) h += 12; 
            } else {
                // AM Case: 12 AM -> 00, 1 AM -> 1
                if (h == 12) h = 0;
            }
            
            new_reg_val = bin2bcd(h);
        }
        return new_reg_val;
}

