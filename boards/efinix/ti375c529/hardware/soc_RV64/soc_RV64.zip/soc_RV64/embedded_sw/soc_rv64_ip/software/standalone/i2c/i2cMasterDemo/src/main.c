////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/******************************************************************************
*
* @file main.c: i2cMasterInterruptDemo
*
* @brief This demo is functionally similar to i2cMasterDemo but includes interrupt support
*        to prevent the program from getting stuck if the slave device fails to respond.
*        It demonstrates the use of a timeout interrupt to handle stalled I2C communication.
*        The program operates as an I2C master, performing both single- and multi-byte reads
*        from a slave device, which can be emulated using I2CSlaveDemo.
*        It assumes it is the sole master on the bus and performs data transfers in a blocking manner.
*
******************************************************************************/

#include <stdio.h>
#include "bsp.h"
#include "userDef.h"
#include "irq.h"

// Include driver
#include "i2c/i2c.h"

extern void trap_entry();

#ifdef SYSTEM_I2C_0_IO_CTRL


/******************************************************************************
*
* @brief This function configure PLIC setting and init i2c setting.
*
******************************************************************************/
i2c_instance_t I2C = {
    .hwreg      			= I2C_CTRL,
    .slaveAddress			= I2C_MASTER_ADDR,
    .samplingClockDivider	= 3,
    .timeout				= I2C_CTRL_HZ/1000,
    .tsuDat					= I2C_CTRL_HZ/(I2C_FREQ*5),
    .tLow					= I2C_CTRL_HZ/(I2C_FREQ*2),
    .tHigh					= I2C_CTRL_HZ/(I2C_FREQ*2),
    .tBuf					= I2C_CTRL_HZ/(I2C_FREQ),
};

plic_instance_t i2c_plic = {
    .target 	= BSP_PLIC_CPU_0,
    .gateway 	= SYSTEM_I2C_0_IO_INTERRUPT,
    .priority 	= 0x1U,
    .enable 	= 0X1U,
    .threshold 	= 0x0U,
};

void i2c_init(){
    i2c_applyConfig(&I2C);
    i2c_enableInterrupt(&I2C, I2C_INTERRUPT_DROP);
    plic_applyConfig(&i2c_plic);
    irq_setTrapVector(trap_entry);
    irq_setType(IRQ_EXTERNAL);
    irq_enable();

}

/******************************************************************************
*
* @brief This is a custom IRQ Handler for I2C ID.
*
******************************************************************************/
int irq_m_i2c0_handler()
{
    printf(ANSI_RED "WARN: I2C Timeout/Dropped!\n" ANSI_RESET);
    i2c_clearInterruptFlag(&I2C,I2C_INTERRUPT_DROP);
    while(1);
    return 0;
}


/******************************************************************************
*
* @brief This main function demonstrates the functionality of I2C Master. It performs
*        single byte and multi-byte write-read operations with error checks.
*        The I2C Master communicates with an I2C Slave (or another compatible I2C
*        device) to perform the tests.
*
******************************************************************************/
void main() {
    bsp_init();
    i2c_init(); // Initiatize
    printf(ANSI_RESET"I2C Master Interrupt Demo! \n");
    printf("Please ensure you've either connect to a compatible I2C Slave/running the i2cSlaveDemo with I2C ports connected.\n");
    printf("TEST STARTED ! \n");
    u8 dacValue[ARRAY_DATA_SIZE];
    u8 readData[ARRAY_DATA_SIZE];
    // Set default value for dacValue variable.
    for (int i = 0; i < ARRAY_DATA_SIZE; i++){
        dacValue[i] = i;
    }
    while(1){ // Forever loop
        u32 ready;

#if ( WORD_REG_ADDR == 1) // 2-Byte Register Address
        //single byte write and read
        i2c_writeData_w(&I2C, 0x00, dacValue, 0x01); // Write a byte of dacValue array to address 0x00 with 2-byte of register address
        i2c_readData_w(&I2C, 0x00, readData , 0x01); // Read a byte of data from address 0x00 with 2-byte of register address
        // Make sure the data write and read are tally.
        if (dacValue[0] != readData[0]){
            printf(ANSI_RED "I2C single data write and read test failed. \n"ANSI_RESET);
            while(1){};
        }

        //Multiple bytes write and read
        i2c_writeData_w(&I2C, 0x00, dacValue, ARRAY_DATA_SIZE); // Write ARRAY_DATA_SIZE bytes of dacValue array to address 0x00 with 2-byte of register address
        i2c_readData_w(&I2C, 0x00, readData , ARRAY_DATA_SIZE); // Read ARRAY_DATA_SIZE bytes of data from address 0x00 with 2-byte of register address
        // Make sure the data write and read are tally.
        for (int i = 0; i < ARRAY_DATA_SIZE; i++){
            if (dacValue[i] != readData[i]){
                printf(ANSI_RED "I2C multi data write and read test failed at data #%i \n" ANSI_RESET, i);
                while(1){};
            }
        }
#else // 1-Byte Register Address
        //single byte write and read
        i2c_writeData_b(&I2C, 0x00, dacValue, 0x01); // Write a byte of dacValue array to address 0x00 with 1-byte of register address
        i2c_readData_b(&I2C, 0x00, readData , 0x01); // Read a byte of data from address 0x00 with 1-byte of register address
        // Make sure the data write and read are tally.
        if (dacValue[0] != readData[0]){
            printf(ANSI_RED "I2C single data write and read test failed. \n" ANSI_RESET);
            while(1){};
        }

        //Multiple bytes write and read
        i2c_writeData_b(&I2C, 0x00, dacValue, ARRAY_DATA_SIZE); // Write ARRAY_DATA_SIZE bytes of dacValue array to address 0x00 with 1-byte of register address
        i2c_readData_b(&I2C, 0x00, readData , ARRAY_DATA_SIZE); // Read ARRAY_DATA_SIZE bytes of data from address 0x00 with 1-byte of register address
        // Make sure the data write and read are tally.
        for (int i = 0; i < ARRAY_DATA_SIZE; i++){
            if (dacValue[i] != readData[i]){
                printf(ANSI_RED "I2C multi data write and read test failed at data #%i \n" ANSI_RESET, i);
                while(1){};
            }
        }
#endif
        printf("I2C Master Interrupt Demo completed. \n");
        printf(ANSI_GREEN "TEST PASSED! \n" ANSI_RESET);
        while(1){};
    }
}
#else
void main() {
   bsp_init();
   printf(ANSI_RED "\n[ERR] I2C is disabled, please enable it to run this app. \n"ANSI_RESET);
}
#endif





