////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSoc/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef SRC_USERDEF_H_
#define SRC_USERDEF_H_

#ifdef __cplusplus
extern "C" {
#endif

/* -----------------------------------------------------------------------------*/
/*  HARDWARE CONFIGURATION
/* -----------------------------------------------------------------------------*/
/* -----------------------------------------------------------------------------*/
/*  USER CONFIGURATION
/* -----------------------------------------------------------------------------*/
/* -----------------------------------------------------------------------------*/
/*  USER DEBUG CONFIGURATION
/* -----------------------------------------------------------------------------*/
// --- DEBUG_MODE --- 
    // 0 = Asserts OFF, Logs removed
    // 1 = Asserts ON, Logs filtered
#define DEBUG_MODE 0
// --- ACTIVE_DEBUG_MOD --- This is the list of available module to debug
    // DBG_MOD_SYS        
    // DBG_MOD_TRAP        
    // DBG_MOD_UART       
    // DBG_MOD_I2C        
    // DBG_MOD_SPI       
    // DBG_MOD_SPI_FLASH  
    // DBG_MOD_RTC        
    // DBG_MOD_SENSOR     
    // DBG_MOD_ALL
#define ACTIVE_DEBUG_MOD   DBG_MOD_ALL

// --- ACTIVE_MIN_LVL ---
    // DBG_LVL_ALL     0   // Info, Warn, Error
    // DBG_LVL_WARN    1   // Warn, Error
    // DBG_LVL_ERR     2   // Error only
    // DBG_LVL_NONE    3   // Silence
#define ACTIVE_MIN_LVL   DBG_LVL_ERR

#ifdef __cplusplus
}
#endif // C_plusplus

#endif /* SRC_USERDEF_H_ */
