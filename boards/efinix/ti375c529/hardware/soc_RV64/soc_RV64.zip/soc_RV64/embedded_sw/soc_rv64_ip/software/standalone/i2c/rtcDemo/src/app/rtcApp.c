////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/*******************************************************************************
*
* @file RTC_APP
*
* @brief Implementation file contain high level API for RTC.
*
******************************************************************************/
#include <stdio.h>
#include "bsp.h"
#include "rtcApp.h"

/******************************************************************************
*
* @brief This function print time in a formatted way. 
* @return none.
*
******************************************************************************/
void rtcApp_printTime(rtc_instance_t *rtc) {
    rtc_data_t *t = &rtc->current_time;
    rtc->drv->getTime(rtc);
    // Safety Checks (Prevent Crash)
    const char *day_str =
            (t->weekdays > 0 && t->weekdays <= 7) ?
                    DayStrings[t->weekdays] : "Unknown";
    const char *month_str =
            (t->months > 0 && t->months <= 12) ?
                    MonthStrings[t->months] : "Unknown";

    // Print Date
    printf("%s, %d%s %s 20%02d\n", day_str, t->days, get_ordinal(t->days),
            month_str, t->years);

    // Print Time
    if (t->timesystem == 1) {
        // 12-Hour Format
        printf("Current Time: %02d:%02d:%02d %s\n\n", t->hours, t->minutes,
                t->seconds, (t->PM) ? "PM" : "AM");
    } else {
        // 24-Hour Format
        printf("Current Time: %02d:%02d:%02d\n\n", t->hours, t->minutes,
                t->seconds);
    }
}

/******************************************************************************
*
* @brief This function check min and max provided by user when prompting msg.
* @return  true value.
*
******************************************************************************/
u32 rtcApp_getValidInt(const char* prompt, u32 min, u32 max) {
    u32 value;
    u32 status;

    while (1) {
        printf("%s (%d-%d): ", prompt, min, max);
        status = scanf("%d", &value);

        // Check if it's a number
        if (status != 1) {
            while(getchar() != '\n');
            printf(ANSI_RED "[ERR] Not a number. Try again.\n" ANSI_RESET);
            continue;
        }

        // Check Range
        if (value < min || value > max) {
            printf(ANSI_RED "[ERR] Out of range! Must be %d to %d.\n" ANSI_RESET, min, max);
            continue;
        }

        // Success!
        return value;
    }
}


/******************************************************************************
*
* @brief This function allow user to set time interactively. 
* @return  RTC Status.
*
******************************************************************************/
u8 rtcApp_setTime(rtc_instance_t *rtc) {
    printf("[Info] Set New Time -> 24hr TimeSystem Only!---\n");
    rtc_data_t *t = &rtc->current_time;
    t->years = rtcApp_getValidInt("Enter Year", 0, 99);
    t->months = rtcApp_getValidInt("Enter Month", 1, 12);

    //  Lookup Table Strategy - Index 0 is dummy so Month 1 maps to index 1.
    static const u8 days_in_month[] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30,
            31, 30, 31 };

    u8 max_days = days_in_month[t->months];

    // Leap Year Adjustment
    // Rule: If Month is Feb (2) AND Year is divisible by 4
    if (t->months == 2 && (t->years % 4 == 0)) {
        max_days = 29;
    }

    t->days = rtcApp_getValidInt("Enter Day", 1, max_days);
    t->weekdays = rtcApp_getValidInt("Enter Weekday (1=Sun...7=Sat)", 1, 7);
    t->hours = rtcApp_getValidInt("Enter Hour", 0, 23);
    t->minutes = rtcApp_getValidInt("Enter Minute", 0, 59);
    t->seconds = rtcApp_getValidInt("Enter Second", 0, 59);

    // Apply Hardware
    rtc->drv->setTime(rtc);
    printf(ANSI_GREEN "\nOK: Time updated!\n"ANSI_RESET);
    rtcApp_printTime(rtc);
    return RTC_OK;
}

/******************************************************************************
*
* @brief This function allow user to set TimeSystem interactively. 
* @return  RTC Status.
*
******************************************************************************/
u8 rtcApp_setTimeSystem(rtc_instance_t *rtc)
{
    printf("\n[INFO] TimeSystem...\n");
    u32 timesystem =rtcApp_getValidInt("Enter 0 for 24hr TimeSystem, 1 for 12hr TimeSystem",0,1);
    if (rtc->drv->setTimeSystem(rtc,timesystem)==0)
    printf(ANSI_GREEN"OK: TimeSystem changed to %s mode!\n" ANSI_RESET, timesystem ? "12hr" : "24hr");
    return RTC_OK;

}


