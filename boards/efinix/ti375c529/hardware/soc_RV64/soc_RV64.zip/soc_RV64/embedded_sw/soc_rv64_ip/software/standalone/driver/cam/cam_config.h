////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef CAM_CONFIG_H
#define CAM_CONFIG_H

/**
 * @file cam_config.h
 * @author Efinix Inc
 * @brief Camera Configuration and Driver Selection.
 *
 * This file automatically selects the correct I2C address and 
 * driver structure based on the user-defined ACTIVE_CAM_TYPE.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "userDef.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup CAM_Config Driver Configuration
 * @ingroup CAM_DRV
 * @brief Automatic hardware selection logic.
 * @{
 */

/* ========================================================================== */
/* SUB-GROUP: DRIVER SELECTION LOGIC                                          */
/* ========================================================================== */

/** @name Automatic Driver Selection
 * Resolves the low-level driver implementation based on @ref ACTIVE_CAM_TYPE.
 * This allows the user to switch camera devices by changing a single configuration value in userDef.h.
 * @note 
 * 		- User can switch between supported camera devices by changing
 * 		  the ACTIVE_CAM_TYPE macro.
 * 			- Add ``#define ACTIVE_CAM_TYPE CAM_TYPE_IMX708`` in userDef.h to use IMX708 Camera.
 * 			- Add ``#define ACTIVE_CAM_TYPE CAM_TYPE_IMX219`` in userDef.h to use IMX219 Camera.
 * 		- For custom cam devices, include the custom driver header and define
 * 		  CAM_CTRL and CAM_DRIVER macros accordingly.
 * 			- Refer to userDef.h in cameraStreaming_HDMI of including a custom camera driver.
 * @{
 */

#if (ACTIVE_CAM_TYPE == CAM_TYPE_IMX708)
    #include "cam/device/IMX708.h"
    
    /** @brief I2C Address for the currently selected cam (IMX708). 
	 * @note User can switch to different cam device by changing ACTIVE_CAM_TYPE macro in userDef.h.
	*/
    #define CAM_CTRL    CAM_IMX708_ADDR 	///< cam_CTRL used for Address of cam controller 
    
    /** @brief Driver Interface Table for the currently selected cam (IMX708). 
	 * @note User can switch to different cam device by changing ACTIVE_CAM_TYPE macro in userDef.h.
	 */
    #define CAM_DRIVER   IMX708_DRIVER		///< cam_DRIVER used for Driver API Table of Camera controller 

#elif (ACTIVE_CAM_TYPE == CAM_TYPE_IMX219)
    #include "cam/device/IMX219.h"

    /** @brief I2C Address for the currently selected cam (IMX219).
	 * @note User can switch to different cam device by changing ACTIVE_CAM_TYPE macro in userDef.h.
	 */
    #define CAM_CTRL    CAM_IMX219_ADDR		///< cam_CTRL used for Address of cam controller 

    /** @brief Driver Interface Table for the currently selected cam (IMX219).
	 * @note User can switch to different cam device by changing ACTIVE_CAM_TYPE macro in userDef.h.
	 */
    #define CAM_DRIVER  IMX219_DRIVER		///< cam_DRIVER used for Driver API Table of Camera controller 
#else
    #warning "Unsupported ACTIVE_CAM_TYPE"
    #warning "Make sure to include the custom driver !!"
#endif

/** @} */ // End of Automatic Driver Selection

/** @} */ // End of cam_Config Group

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // cam_CONFIG_H