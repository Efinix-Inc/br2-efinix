////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/*******************************************************************************
*
* @file main.c: i2cEepromDemo (Read/Write On-Board EEPROM AT24C01)
*
* @brief This demo uses the I2C peripheral to communicate with the T120F324 Dev Kit 
* 		 On-Board EEPROM AT24C01. It allows the user to read and write to a specific
*  		 address based on input throughthe UART interface. This example design is 
*		 using UART Interrupt method.
*
* @note To run this example design, please make sure the following requirements are fulfilled:
* 		1. T120F324/ T120F576 Dev Board
* 		2. Enable UART0 and I2C0
*
******************************************************************************/
#include <stdio.h>
#include "bsp.h"
#include "userDef.h"
#include "irq.h"

// Include driver
#include "i2c/i2c.h"

/* =========================================================================
 * NEWLIB Guard — scanf requires NEWLIB = NANO
 * ========================================================================= */
#if (USELIB == 0)

void main() {
    bsp_init();
    printf(ANSI_RED  "[ERR] Please use NEWLIB = NANO in makefile for this demo.\n\r");
    printf(           "User needs to implement scanf if switching to NEWLIB=NOSTD.\r\n" ANSI_RESET);
}

#else
#ifdef SYSTEM_I2C_0_IO_CTRL

/******************************************************************************
*
* @brief User Prompts
*
******************************************************************************/
#define OPENING_STRING \
    "T120F324/T120F576 Dev Kit on-board EEPROM, AT24C01 I2C Demo!\n" \
    "Please make sure you are using the T120F324/T120F576 Dev Kit.\n"

#define FEATURE_SELECT_STRING \
    "\nPlease choose a feature (key in selection and press Enter):\n"   \
    "  1: Write a byte to EEPROM\n"                                     \
    "  2: Read a byte from EEPROM\n"                                    \
    "  3: Current address read (last accessed address + 1)\n"           \
    "  4: Read multiple bytes from EEPROM\n"                            \
    "  5: Write multiple bytes to EEPROM\n"

#define INVALID_ADDR_STRING \
    "Invalid address. Please enter a correct hex address (e.g., 00A0).\n"

/******************************************************************************
*
* @brief This struct configure I2C setting, driver used.
*
******************************************************************************/
extern void trap_entry();

i2c_instance_t I2C = {
    .hwreg                = I2C_CTRL,
    .slaveAddress         = EEPROM_CTRL,
    .samplingClockDivider = 3,
    .timeout              = I2C_CTRL_HZ / 1000,
    .tsuDat               = I2C_CTRL_HZ / (I2C_FREQ * 5),
    .tLow                 = I2C_CTRL_HZ / (I2C_FREQ * 2),
    .tHigh                = I2C_CTRL_HZ / (I2C_FREQ * 2),
    .tBuf                 = I2C_CTRL_HZ / (I2C_FREQ),
};

plic_instance_t i2c_plic = {
    .target    = BSP_PLIC_CPU_0,
    .gateway   = SYSTEM_I2C_0_IO_INTERRUPT,
    .priority  = 0x1U,
    .enable    = 0x1U,
    .threshold = 0x0U,
};

/******************************************************************************
*
* @brief This function initialize i2c, plic setting.
*
******************************************************************************/
static void i2c_init() {
    i2c_applyConfig(&I2C);
    i2c_enableInterrupt(&I2C, I2C_INTERRUPT_DROP);
    plic_applyConfig(&i2c_plic);
    irq_setTrapVector(trap_entry);
    irq_setType(IRQ_EXTERNAL);
    irq_enable();
}

/******************************************************************************
*
* @brief Helper — flush stdin after bad input
*
******************************************************************************/
static inline void flush_stdin() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

/******************************************************************************
*
* @brief This main function serves as the main control loop for the EEPROM operation.
* 		 It handles user input to perform various EEPROM operations such as read and write.
*
******************************************************************************/
void main() {
    int choice;
    u32 address    = 0;
    u32 length     = 0;
    u32 temp_input = 0;
    u8  data_buffer[256];   /* Buffer for multi-byte operations */

    bsp_init();
    i2c_init();

    printf(OPENING_STRING);

    while (1) {

        /* --- Get operation choice --- */
        printf(FEATURE_SELECT_STRING);
        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
            flush_stdin();
            continue;
        }

        /* --- Get address (required for ops 1, 2, 4, 5) --- */
        if (choice == 1 || choice == 2 || choice == 4 || choice == 5) {
            printf("Enter 16-bit address in hex (e.g., 00A0): ");
            if (scanf("%x", &address) != 1) {
                printf(INVALID_ADDR_STRING);
                continue;
            }
        }

        /* --- Get length (required for ops 4, 5) --- */
        if (choice == 4 || choice == 5) {
            printf("Enter length in hex (max FF): ");
            if (scanf("%x", &length) != 1 || length == 0 || length > 255) {
                printf("Invalid length. Must be 1–255.\n");
                continue;
            }
        } else {
            length = 1;     /* Default to 1 for single-byte ops */
        }

        /* --- Get write data --- */
        if (choice == 1) {
            printf("Enter data byte in hex (e.g., FF): ");
            if (scanf("%x", &temp_input) == 1)
                data_buffer[0] = (u8)temp_input;

        } else if (choice == 5) {
            printf("Enter %d data bytes in hex (space-separated): ", (int)length);
            for (int i = 0; i < (int)length; i++) {
                if (scanf("%x", &temp_input) == 1) {
                    data_buffer[i] = (u8)temp_input;
                } else {
                    printf("Error reading byte %d.\n", i + 1);
                    break;
                }
            }
        }

        /* --- Execute operation --- */
        printf("Processing...\n");

        switch (choice) {
            case 1:     /* Write single byte */
                i2c_writeData_w(&I2C, address, data_buffer, 1);
                printf("Written 0x%02X to address 0x%04X.\n", data_buffer[0], address);
                break;

            case 2:     /* Read single byte */
                i2c_readData_w(&I2C, address, data_buffer, 1);
                printf("Read 0x%02X from address 0x%04X.\n", data_buffer[0], address);
                break;

            case 3:     /* Current address read */
                i2c_readData_b(&I2C, address, data_buffer, 1);
                printf("Current address data: 0x%02X.\n", data_buffer[0]);
                break;

            case 4:     /* Read multi-byte */
                i2c_readData_w(&I2C, address, data_buffer, length);
                printf("Read data:\n");
                for (int i = 0; i < (int)length; i++)
                    printf("  [%03d] 0x%02X\n", i, data_buffer[i]);
                break;

            case 5:     /* Write multi-byte */
                i2c_writeData_w(&I2C, address, data_buffer, length);
                printf("Multi-write complete.\n");
                break;

            default:
                printf("Unknown command.\n");
                break;
        }
    }
}

#else   /* SYSTEM_I2C_0_IO_CTRL not defined */

void main() {
    bsp_init();
    printf(ANSI_RED "\n[ERR] I2C is disabled. Please enable it to run this demo.\n" ANSI_RESET);
}

#endif  /* SYSTEM_I2C_0_IO_CTRL */
#endif  /* USELIB */
