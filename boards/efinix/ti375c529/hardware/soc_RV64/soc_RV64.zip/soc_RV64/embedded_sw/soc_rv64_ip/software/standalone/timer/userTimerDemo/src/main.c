////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/******************************************************************************
*
* @file main.c: userTimerDemo
*
* @brief This demo shows how to use and configure user Timer for external interrupt.
*
******************************************************************************/
#include <stdio.h>
#include "bsp.h"
#include "irq.h"
#include "userDef.h"

// Include driver
#include "timer/timer.h"

#ifdef SYSTEM_USER_TIMER_0_CTRL

extern void trap_entry();

u32 tick_counter_limit = 0;
volatile u32 tick_counter = 0;
volatile u32 count = 0;


/******************************************************************************
*
* @brief This function check the prescaler value & timer limit value to ensure
* 		 timer generate one pulse per second.
*
******************************************************************************/
void sanityCheck()
{

    /*
     * HW_Divisor = (prescaler_value + 1)*(TIMER_LIMIT_VALUE +1);
     * HW_Divisor = (127 + 1) * (4095 + 1);
     * Ticks Per Second (f,Hz) = SYSTEM_CLINT_HZ / HW_Divisor
     * Period (1/f)= (prescaler_value + 1)x(TIMER_LIMIT_VALUE +1)/SYSTEM_CLINT_HZ
     */
    u32 hw_divisor = (PRESCALER_VALUE + 1) * (TIMER_LIMIT_VALUE + 1);
    tick_counter_limit = SYSTEM_CLINT_HZ / hw_divisor; //Tick per second

    // Safety check: If the system clock is extremely slow, ensure we don't get 0
    if (tick_counter_limit == 0) {
        tick_counter_limit = 1;
    }
}


/******************************************************************************
*
* @brief This IRQ function will keep on counting once enter interrupt routine.
* 		 It always generate one pulse per second based on tick_counter_limit.
*
******************************************************************************/
int irq_m_userTimer0_handler(void) {
    tick_counter++;

    if (tick_counter >= tick_counter_limit) {
        tick_counter = 0;
        printf("Entering timer 0 interrupt routine .. \n");
        printf("Count:%d .. Done \n",count++);
    }
    return 0;
}
/******************************************************************************
*
* @brief This instance is used to configure user timer setting.
*
******************************************************************************/
timer_instance_t timer0 = {
    // Configure the interrupt source
    .hwreg 				= TIMER_0,
    .prescaler_value 	= PRESCALER_VALUE, // Config based on 8bit-width of prescaler
    .prescaler_enable 	= 0x1U,
    .self_restart 		= 0x1U,
    .timer_limit 		= TIMER_LIMIT_VALUE, // Config based on 12bit-width of timerLimit
};

/******************************************************************************
*
* @brief This instance is used to configure PLIC for user timer.
*
******************************************************************************/
plic_instance_t timer0_plic = {
    // Configure the interrupt source
    .target    = BSP_PLIC_CPU_0,
    .gateway   = SYSTEM_USER_TIMER_0_INTERRUPTS_0,
    .priority  = 0x1U,
    .enable    = 0x1U,
    .threshold = 0x0U, // Allow all priorities > 0
};

/******************************************************************************
*
* @brief This function initializes user timer interrupts and enables external interrupts
*        by setting up the machine trap vector. 
*
******************************************************************************/
void isrInit(){
    sanityCheck();
    timer_applyConfig(&timer0);
    plic_applyConfig(&timer0_plic);
    irq_setTrapVector(trap_entry);
    irq_setType(IRQ_EXTERNAL);
    irq_enable();
}

/******************************************************************************
*
* @brief This main function intialize the system and then prints a message 
*        indicating that the user timer 0 demo is starting.
*
******************************************************************************/
void main() {
    // Initialize UART
    bsp_init();
    // Initialize Interrupt related Timer
    isrInit();
    printf(ANSI_RESET "***Starting User Timer Interrupt Demo*** \n");
    while(1);
}
#else
void trap(){
}

void main() {
bsp_init();
printf(ANSI_RED "\n[ERR] User Timer is disabled, please enable it to run this app. \n"ANSI_RESET);
}
#endif

