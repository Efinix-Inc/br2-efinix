////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/*******************************************************************************
*
* @file main.c: temperatureSensorDemo 
*
* @brief This demo uses the I2C peripheral to communicate with on-board EMC1413 Temperature
* 		 module on Ti375C529. It print out the temperature of the device on terminal every 
*		 few seconds and alerts user if the temperature of the device exceed above the high
*		 temperature limit. 
*
* @note To run this example design, please make sure the following requirements are fulfilled:
* 		1. Ti375C529 Dev Board
* 		2. Enable UART0 and I2C0
*
*		User are allowed to change driver configuration in userDef.h (User defined Section)
*		User are allowed to configure certain parameters in peri.h (User defined Section)
*		1. I2C_FREQ 		=> Frequency of I2C, default set to 100kHz
*		2. I2C_CTRL			=> Change I2C Controller.
*		3. EXTENDED_RANGE_ENABLED  	=>If set to 0, means range of temp measurement from 0°C to +127°C (Default)
*								 	=>If set to 1, means range of temp measurement from -64°C to +191°C (Extended Range enabled)
*
* 		4. HIGH_TEMPERATURE_LIMIT_VALUE_INT  	=> High limit temp for internal temperature sensor in EMC1413 itself.
* 		5. LOW_TEMPERATURE_LIMIT_VALUE_INT   	=> Low  limit temp for temperature sensor 1 on Ti375C529.
*		6. HIGH_TEMPERATURE_LIMIT_VALUE_EXT1 	=> High limit temp for internal temperature sensor in EMC1413 itself.
*		7. LOW_TEMPERATURE_LIMIT_VALUE_EXT1   	=> Low  limit temp for temperature sensor 1 on Ti375C529.
*		8. HIGH_TEMPERATURE_LIMIT_VALUE_EXT2  	=> High limit temp for internal temperature sensor in EMC1413 itself.
*		9. LOW_TEMPERATURE_LIMIT_VALUE_EXT2   	=> Low  limit temp for temperature sensor 1 on Ti375C529.
*
*
******************************************************************************/

#include <stdio.h>
#include "bsp.h"
#include "userDef.h"
#include "app/temp_sensorApp.h"

extern void trap_entry();

#ifdef SYSTEM_I2C_0_IO_CTRL

#define OPENING_STRING "The default Temperature Sensor driver is set to EMC1413 \
						(Built-in Ti375C529_devkit),User may change the \
						supported driver via userDef.h\n"

/******************************************************************************
*
* @brief This struct configure I2C setting, driver used.
*
******************************************************************************/
temp_sensor_instance_t TEMP_SENSOR = {
	.drv  = &TEMP_SENSOR_DRIVER,
	.inst = &(i2c_instance_t){
		.hwreg      			= I2C_CTRL,
		.slaveAddress			= TEMP_SENSOR_CTRL,
		.samplingClockDivider	= 3,
		.timeout				= I2C_CTRL_HZ/1000,
		.tsuDat					= I2C_CTRL_HZ/(I2C_FREQ*5),
		.tLow					= I2C_CTRL_HZ/(I2C_FREQ*2),
		.tHigh					= I2C_CTRL_HZ/(I2C_FREQ*2),
		.tBuf					= I2C_CTRL_HZ/(I2C_FREQ),
},
};

/******************************************************************************
*
* @brief This main function intialize UART configuration and read temperature
* 		 value every second.
*
******************************************************************************/
void main()
{
    //System Initialization
	bsp_init();
	printf(ANSI_RESET "Welcome to Temperature Demo!\n\n");
	LOG_INFO(DBG_MOD_MAIN,OPENING_STRING);

	// Initialize Temperature Sensor and Enable Error Interrupt
	tempSensorApp_configure(&TEMP_SENSOR);

    while(1){
        float internal = TEMP_SENSOR.temp_value.channels[0].current_temp;
        float external1 = TEMP_SENSOR.temp_value.channels[1].current_temp;
        float external2 = TEMP_SENSOR.temp_value.channels[2].current_temp;
        TEMP_SENSOR.drv->getTemp(&TEMP_SENSOR);
        printf("Internal: %.3f°C	External D1: %.3f°C 	External D2: %.3f°C\n", internal,external1,external2);

        // Check Alerts
        u8 alert = TEMP_SENSOR.drv->checkTempAlert(&TEMP_SENSOR);
        if (alert == TEMP_SENSOR_HIGH_ALERT) {
            printf(ANSI_RED "WARN: HIGH Temperature Alert!\n"ANSI_RESET);
        } else if (alert == TEMP_SENSOR_LOW_ALERT) {
            printf(ANSI_RED "WARN: LOW Temperature Alert!\n"ANSI_RESET);
        }

        bsp_uDelay(1000000);
    };

}
#else
void main() {
   bsp_init();
   printf(ANSI_RED "\n[ERR] I2C is disabled, please enable it to run this app. \n"ANSI_RESET);
}
#endif

