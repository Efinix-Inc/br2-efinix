////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef UART_H
#define UART_H

/**
 * @file uart.h
 * @author Efinix Inc
 * @brief UART driver API definitions.
 *
 * This file provides data structures and APIs for controlling
 * the UART peripheral on the EfxSapphireSoC platform.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "type.h"
#include "io.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup UART UART Driver
 * @brief Universal Asynchronous Receiver/Transmitter (UART) driver.
 * @ingroup comm_group
 *
 * This module provides functions to configure and control
 * UART input/output and interrupt behavior.
 * 
 * @section Example_UART Usage & Initialization.
 * This is an example show how to instantiate @ref UART with @ref uart_instance_t.
 * 
 * @code 
 * #include "uart/uart.h"
 * 
 * #define BSP_UART_DATA_LEN   8
 * #define BSP_UART_BAUDRATE   115200
 * #define BSP_UART_TERMINAL   SYSTEM_UART_0_IO_CTRL
 * #define UART_BASE  (uart_hwreg_t*)SYSTEM_UART_0_IO_CTRL
 * 
 * uart_instance_t uart0;
 * 
 * void bsp_init() {
 * 	// Init uart 0
 * 	uart0.hwreg = UART0_BASE;
 * 	uart0.dataLength = BITS_8;
 * 	uart0.parity = NONE;
 * 	uart0.stop = ONE;
 * 	uart0.clockDivider = BSP_CLINT_HZ/(BSP_UART_BAUDRATE*BSP_UART_DATA_LEN)-1;
 * 	uart_applyConfig(&uart0);
 * }
 * @endcode
 * @see @ref uartEchoDemo "Example UART Echo Demo" - Learn how to use the driver in Echo mode
 * @see @ref uartInterruptDemo "Example UART Interrupt Demo" - Learn how to use the driver in Interrupt mode
 * @{
 */


/* ========================================================================== */
/* SUB-GROUP : Data Types			                                         */
/* ========================================================================== */

    /**
     * @defgroup UART_ENUM Data Types
     * @ingroup UART
     * @brief Enums used by the driver.
     * @{
     */
        /** @brief  UART data Length*/ 	
        typedef enum  {	
            BITS_6 = 6,	///< 6-bit data length */
            BITS_7 = 7,	///< 7-bit data length */
            BITS_8 = 8	///< 8-bit data length */
        } cfg_dataLength_t;

        /** @brief  UART data Parity*/ 	
        typedef enum  {	
            NONE = 0,	///< No Parity */
            EVEN = 1,	///< Even Parity */
            ODD = 2		///< Odd Parity */
        } cfg_dataParity_t;

        /** @brief  UART Stop Bits*/
        typedef  enum {	
            ONE = 0,	///< One Stop Bit */
            TWO = 1		///< Two Stop Bits */
        } cfg_stopBits_t;
    /** @} */

/* ========================================================================== */
/* SUB-GROUP : DATA STRUCTS                                          			*/
/* ========================================================================== */
/**
 * @defgroup UART_Types Data Structures
 * @ingroup UART
 * @brief Structs and Enums used by the driver.
 * @note
 * <b> This is an example show how to instantiate UART with @ref  uart_instance_t 
 * and @ref uart_hwreg_t.
 * 
 * @code 
 * #define UART_BASE  (uart_hwreg_t*)SYSTEM_UART_0_IO_CTRL
 * 
 * void bsp_init() {
 * 		uart_instance_t uart0;
 * 		// Init uart 0
 * 		uart0.hwreg = UART0_BASE;
 * 		uart0.dataLength = BITS_8;
 * 		uart0.parity = NONE;
 * 		uart0.stop = ONE;
 * 		uart0.clockDivider = BSP_CLINT_HZ/(BSP_UART_BAUDRATE*BSP_UART_DATA_LEN)-1;
 * 		uart_applyConfig(&uart0);
 * }
 *
 * @endcode
 * @{
 */

    /**
     * @brief UART hardware register map.
     */
    typedef volatile struct
    {
        u32 DATA;				///< Address Offset: 0x00 - Data Register */
        u32 STATUS;				///< Address Offset: 0x04 - Status Register */
        u32 CLOCK_DIVIDER;		///< Address Offset: 0x08 - Clock Divider Register */
        u32 FRAME_CONFIG;		///< Address Offset: 0x0C - Frame Configuration Register */
    } uart_hwreg_t;
    /**
     * @brief UART instance.
     * Holds the software registers and hardware pointer.
     * @note To apply the changes, please call uart_applyConfig() after modifying the configuration fields.
     */
    typedef struct  
    {
        uart_hwreg_t			*hwreg;			///< Pointer to Hardware Register Map */
        cfg_dataLength_t		dataLength;		///< Data Length Configuration */
        cfg_dataParity_t		parity;			///< Parity Configuration */
        cfg_stopBits_t			stop;			///< Stop Bits Configuration */
        u32						clockDivider;	///< Clock Divider Value */
        u8						irqn;			///< UART IRQ Number */
    }uart_instance_t;

/** @} */ // End of UART_Types group


/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup UART_Funcs API Functions
 * @ingroup UART
 * @brief Function definitions for UART driver.
 * @{
 */

    /**
     * @brief Read 32-bit UART data.
     * @param inst Pointer to UART instance.
     * @return 32-bit data value.
     */
    u32 uart_read(uart_instance_t *inst);

    /**
     * @brief Write 32-bit UART data.
     * @param inst Pointer to UART instance.
     * @param data 32-bit data value to be written.
     */
    u32 uart_readStatus(uart_instance_t *inst);

    /**
     * @brief Get the occupancy of the UART buffer for reading data.
     * @param inst Pointer to UART instance.
     * @return  The number of occupied spaces in the UART buffer for reading data
     *          as a 32-bit unsigned integer.
     * @note    The function reads the UART status register and extracts the number
     *          of occupied spaces for reading data from bits 31 to 24.
     */
    u32 uart_getReadOccupancy(uart_instance_t *inst);

    /**
     * @brief Get the availability of the UART buffer for writing data.
     * @param inst Pointer to UART instance.
     * @return  The number of available spaces in the UART buffer for writing data
     *          as a 32-bit unsigned integer.
     * @note    The function reads the UART status register and extracts the number
     *          of available spaces for writing data from bits 23 to 16.
     */
    u32 uart_getWriteAvailability(uart_instance_t *inst);

    /**
     * @brief Apply stored UART configuration to hardware.
     * @param inst Pointer to UART instance.
     */
    void uart_applyConfig (uart_instance_t *inst);


    /**
     * @brief Writes a single character to the UART data register.
     * @param inst Pointer to UART instance.
     * @param data The character data to be written.
     * @note    The function waits until there is available space in the UART buffer
     *          for writing data. Once space is available, it writes the character
     *          data to the UART data register.
     */
    void uart_write(uart_instance_t *inst, char data);

    /**
     * @brief Write string to UART.
     * @param inst Pointer to UART instance.
     * @param str Null-terminated string to be written.
     * @note    The function iterates through each character in the string
     *          and writes it to the UART using the uart_write function.
     */
    void uart_writeStr(uart_instance_t *inst, const char* str);

    /**
     * @brief Write integer as decimal to UART.
     * @param inst Pointer to UART instance.
     * @param value Integer value to be written in hexadecimal format.
     * @note    The function converts the integer value to its hexadecimal representation
     *          and writes each hexadecimal digit to the UART using the uart_write function.
     */
    void uart_writeHex(uart_instance_t *inst, int value);
    /**
     * @brief Writes a value to the UART status register.
     * @param inst Pointer to UART instance.
     * @param data The 32-bit value to be written to the status register.
     */
    void uart_writeStatus(uart_instance_t *inst, u32 data);

    /**
     * @brief Enable or Disable UART TX Empty Interrupt.
     * @param inst Pointer to UART instance.
     * @param Ena The flag indicating whether to enable (1) or disable (0) the TX empty interrupt.
     * @note    The function enables or disables the TX empty interrupt in the UART status register.
     */
    void uart_setTxInterruptEnable(uart_instance_t *inst, char Ena);

    /**
     * @brief Enable or Disable UART RX Not Empty Interrupt.
     * @param inst Pointer to UART instance.
     * @param Ena The flag indicating whether to enable (1) or disable (0) the RX not empty interrupt.
     * @note    The function enables or disables the RX not empty interrupt in the UART status register.
     */
    void uart_setRxInterruptEnable(uart_instance_t *inst, char Ena);

/** @} */ // End of UART_Funcs group
#ifdef __cplusplus
}
#endif

/** @} */ // End of MAIN UART Group

#endif // UART_H



