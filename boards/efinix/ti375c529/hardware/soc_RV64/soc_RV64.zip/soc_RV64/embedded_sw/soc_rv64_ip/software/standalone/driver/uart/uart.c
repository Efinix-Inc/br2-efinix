////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/**
* @file uart.c
* @brief UART driver implementation.
*
* Implements the functions defined in uart.h for controlling
* UART input/output and interrupts on the EfxSapphireSoC platform.
* @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
* See the full @ref license_page for Efinix and SaxonSoc MIT terms.
*/

#include "uart/uart.h"

/*----------------------------------------------------------------------------*/
/* Function implementations                                                    */
/*----------------------------------------------------------------------------*/

u32 uart_getWriteAvailability(uart_instance_t *inst) {
    return ( (inst->hwreg->STATUS >>16) & 0xff );
}

u32 uart_getReadOccupancy(uart_instance_t *inst) {
    return ( inst->hwreg->STATUS >> 24 );
}


u32 uart_readStatus(uart_instance_t *inst)
{
    return inst->hwreg->STATUS;
}


void uart_writeStatus(uart_instance_t *inst, u32 data)
{
    inst->hwreg->STATUS = data;
}


u32 uart_read(uart_instance_t *inst) {
    while(uart_getReadOccupancy(inst) == 0);
    return ( inst->hwreg->DATA );
}


void uart_write(uart_instance_t *inst, char data) {
    while (uart_getWriteAvailability(inst) == 0);
    inst->hwreg->DATA = data;
}


void uart_writeStr(uart_instance_t *inst, const char* str){
    while(*str) uart_write(inst, *str++);
}


void uart_writeHex(uart_instance_t *inst, int value){
    for(int i = 7; i >= 0; i--){
        int hex = (value >> i*4) & 0xF;
        uart_write(inst, hex > 9 ? 'A' + hex - 10 : '0' + hex);
    }
}


void uart_applyConfig (uart_instance_t *inst) {
    inst->hwreg->CLOCK_DIVIDER = inst->clockDivider;
    inst->hwreg->FRAME_CONFIG = ((inst->dataLength-1) << 0 | (inst->parity << 8) | (inst->stop << 16));

}


void uart_setTxInterruptEnable(uart_instance_t *inst, char Ena)
{
    uart_writeStatus(inst,(uart_readStatus(inst) & 0xFFFFFFFE) | (Ena & 0x01));
}


void uart_setRxInterruptEnable(uart_instance_t *inst, char Ena)
{
    uart_writeStatus(inst,(uart_readStatus(inst) & 0xFFFFFFFD) | (Ena << 1));
}
