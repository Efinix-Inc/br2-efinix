////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef SPI_FLASH_DEVICE_H
#define SPI_FLASH_DEVICE_H

/**
 * @file spiFlash_list.h
 * @author Efinix Inc
 * @brief SPI Flash Device Database and Capability Flags.
 *
 * This file defines the supported Flash devices, their JEDEC IDs,
 * and capability flags (Profiles) used by the driver to handle 
 * vendor-specific quirks (Winbond vs Macronix vs ISSI).
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include <stdint.h>
#include <stddef.h>
#include "type.h"
#include "soc.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup SPI_FLASH_LIST Flash Device Database
 * @brief Database for supported flash device.
 * @ingroup SPI_FLASH
 * @{
 */

/* ========================================================================== */
/* SUB-GROUP : FLASH CAPABILITY FLAGS                                         */
/* ========================================================================== */
/**
 * @defgroup SPI_FLASH_DRV_F Flash Capability Flags
 * @ingroup SPI_FLASH_LIST
 * @brief Flash Capability and Handling Method
 * @details
 * These flags represent the <b>static hardware capabilities</b> of a specific Flash 
 * part number. They are combined using a bitwise OR operation to form the 
 * `flags` field in the @ref spiFlash_info_t structure.
 * 
 * @note The driver uses these flags at runtime to abstract away flash capability difference.
 * Instead of checking for specific Manufacturers (e.g., `if (id == WINBOND)`), 
 * the driver checks for Capabilities.
 * - <b>Standard Flags:</b> (e.g., `FLAG_4BYTE_SUPPORT`) denote adherence to JEDEC standards.
 * - <b>Quirk Flags:</b> (e.g., `FLAG_4BYTE_EXIT_ISSI`) denote non-compliant or unique behavior 
 * that requires special handling in the driver state machine.
 * 
 * Referring to <b> @ref spiFlash_applyQuirks </b>,  This function show how Flash Capability Flags are used to conditionally apply Quirks. 
 * This should handled automatically when @ref spiFlash_probe is called.
 * @code
 * // Example: Handling 4-Byte Addressing Exit
    if (flash->info->flags & FLAG_4BYTE_EXIT_ISSI) {
        flash->info->flags->cmd_exit_4byte = CMD_EXIT_4B_ISSI; // ISSI ONLY
    } else {
        flash->info->flags->cmd_exit_4byte = CMD_EXIT_4B; // Default
    }
 * @endcode
 * @{
 */

    /** @name Addressing & Boot Flags
     * @brief Capabilities related to memory size and startup state.
     * @{
     */
        /** @brief Supports 4-Byte Addressing Mode.
         * @details Indicates the device capacity is larger than 16MB (128Mb) and requires 
         * 32-bit address commands (e.g., 0x13, 0x12, 0x21) to access the full memory array.
         */
        #define FLAG_4BYTE_SUPPORT      (1 << 0) 

        /** @brief Quirk: ISSI-Specific 4-Byte Exit.
         * @details The ISSI IS25WP series does not respond to the standard Exit 4-Byte 
         * command (0xE9). It requires command <b>0x29</b> instead.
         */
        #define FLAG_4BYTE_EXIT_ISSI    (1 << 1) 

        /** @brief Quirk: Auto-Lock on Power Up.
         * @details Macronix devices often power up with Block Protection (BP) bits set 
         * in the Status Register, preventing writes. Setting this flag forces the 
         * driver to issue a `Global Unlock` command during initialization.
         */
        #define FLAG_UNLOCK_ON_PROBE    (1 << 2) 
    /** @} */

    /** @name Quad Enable (QE) Method Flags
     * @brief Defines how to enable QSPI mode (Quad I/O).
     * @details There is no standard JEDEC command to enable Quad mode. Each vendor 
     * implements this differently.
     * @{
     */
        /** @brief Method A: Winbond Style (Status Register 2).
         * @details QE is Bit 1 of Status Register 2. Requires `Write SR2` command (0x31).
         */
        #define FLAG_QE_SR2_BIT1        (1 << 3) 

        /** @brief Method B: Macronix/ISSI Style (Status Register 1).
         * @details QE is Bit 6 of Status Register 1. Requires `Write SR1` command (0x01).
         */
        #define FLAG_QE_SR1_BIT6        (1 << 4) 

    /** @} */

    /** @name Read Mode Capabilities
     * @brief Supported high-speed read commands.
     * @{
     */
        /** @brief Supports Dual Output Read (1-1-2).
         * @details Device responds to the DREAD (0x3B) command.
         */
        #define FLAG_DREAD_SUPPORT      (1 << 6) 

        /** @brief Supports Quad Output Read (1-1-4).
         * @details Device responds to the QREAD (0x6B) command.
         */
        #define FLAG_QREAD_SUPPORT      (1 << 7) 
    /** @} */

    /** @name Helper Masks
     * @brief Macros for internal logic simplification.
     * @{
     */
        /** @brief Check if QE requires a Status Register Write.
         * @details Used by `spiFlash_enable_quad_access` to determine if the 
         * Write Enable (WREN 0x06) latch must be set before modifying the QE bit.
         */
        #define FLAG_QE_ENABLE_VIA_SR   (FLAG_QE_SR2_BIT1 | FLAG_QE_SR1_BIT6)
    /** @} */

/** @} */ // End of SPI_FLASH_DRV_F

/* ========================================================================== */
/* SUB-GROUP : VENDOR PROFILES                                                */
/* ========================================================================== */
/**
 * @defgroup SPI_FLASH_VENDOR Vendor Profiles
 * @ingroup SPI_FLASH_LIST
 * @brief Pre-defined capability sets for supported Flash families.
 *
 * @details 
 * A "Vendor Profile" is a helper macro that combines multiple @ref SPI_FLASH_DRV_F 
 * flags into a single definition. 
 *
 * Instead of manually listing every capability for every chip, user can assign 
 * a profile (e.g., @ref PROFILE_WINBOND_64) to a device by creating a descriptor
 * @ref spiFlash_info_t (under .flag).
 * * @code
 * // Example: Creating user's custom Flash with supported vendor profile
 * const spiFlash_info_t user_flash[] = {
 * {
 * .part_no = "CUSTOM_X",
 * .jedec_id = 0x9D701A00,
 * .flags = PROFILE_WINBOND_64, 
 * .post_init_hook = NULL,
 * },
 * };
 * @endcode
 *
 * @note 
 * - These profiles are static configurations used during the device definition.
 * - Once a device is matched via JEDEC ID, the driver applies the flags found 
 * in the profile to handle runtime operations (like 4-byte exit or Quad Enable).
 *
 * @{
 */
    /** @name Vendor Profiles
     * @{
     */
        #define PROFILE_WINBOND_64      (FLAG_DREAD_SUPPORT | FLAG_QREAD_SUPPORT | FLAG_QE_SR2_BIT1) ///< Profile for Winbond <= 64Mb. @note Supports Dual/Quad Read, QE in SR2. 
    
        #define PROFILE_WINBOND_128     (FLAG_DREAD_SUPPORT | FLAG_QE_SR2_BIT1) ///< Profile for Winbond 128Mb. @note Supports Dual Read, QE in SR2. 

        #define PROFILE_MACRONIX_LARGE  (FLAG_DREAD_SUPPORT | FLAG_QREAD_SUPPORT| FLAG_4BYTE_SUPPORT | \
                                        FLAG_QE_SR1_BIT6 | FLAG_UNLOCK_ON_PROBE) ///< Profile for Macronix > 16MB. @note 4-Byte Addressing, QE in SR1, Auto-unlocks BP bits.

        #define PROFILE_ISSI_LARGE      (FLAG_DREAD_SUPPORT | FLAG_QREAD_SUPPORT | FLAG_4BYTE_SUPPORT | \
                                        FLAG_QE_SR1_BIT6 | FLAG_4BYTE_EXIT_ISSI) ///< Profile for ISSI > 16MB. @note 4-Byte Addressing, QE in SR1, requires special 0x29 exit command.

        #define PROFILE_GIGA_LARGE      (FLAG_QREAD_SUPPORT | FLAG_4BYTE_SUPPORT ) ///< Profile for GigaDevice > 16MB. @note 4-Byte Addressing, QPI mode.
    /** @} */
/** @} */

/* ========================================================================== */
/* SUB-GROUP : JEDEC IDENTIFIERS                                              */
/* ========================================================================== */

/**
 * @defgroup SPI_FLASH_JEDECS JEDEC Identifiers
 * @ingroup SPI_FLASH_LIST
 * @brief Manufacturer ID + Memory Type + Capacity + Padding (0x00).
 *
 * @details 
 * @note This JEDEC Identifiers is used for verifying the Supported flash when using @ref spiFlash_probe.
 * 
 * @code
 * // Example: Identify Flash Using JEDEC Identifier
 * if (spiFlash_verify(flash) != 0)
 * return SPI_FLASH_ERR;
 * @endcode
 * @{
 */
    /** @name GigaDevice IDs
     * @{
     */
        /** @brief GigaDevice 512Mb (Ti375N1156).
         * @note 
         * - **Part No:** GD25LB512MEYIGR
         * - **Used In:** Efinix Ti375N1156 Development Board
         */
        #define JEDEC_ID_GD25LB512MEYIGR    0xC8671A00 
    /** @} */

    /** @name Winbond IDs
     * @{
     */
        /** @brief Winbond 128Mb (T120F576/T120F324).
         * @note 
         * - **Part No:** W25Q128JVSIQ
         * - **Used In:** Efinix T120F576 / T120F324 Development Boards
         */
        #define JEDEC_ID_W25Q128JVSIQ       0xEF401800 

        /** @brief Winbond 64Mb (Ti60F225).
         * @note 
         * - **Part No:** W25Q64JWSSIQ
         * - **Used In:** Efinix Ti60F225 Development Board
         */
        #define JEDEC_ID_W25Q64JWSSIQ       0xEF601700 
    /** @} */

    /** @name Macronix IDs
     * @{
     */
        /** @brief Macronix 256Mb (Ti180J484).
         * @note 
         * - **Part No:** MX25U25645GZ4I00
         * - **Used In:** Efinix Ti180J484 Development Board
         */
        #define JEDEC_ID_MX25U25645GZ4I00   0xC2253900 
    /** @} */

    /** @name ISSI IDs
     * @{
     */
        /** @brief ISSI 512Mb (Ti375C529).
         * @note 
         * - **Part No:** IS25WP512M
         * - **Used In:** Efinix Ti375C529 Development Board
         */
        #define JEDEC_ID_IS25WP512M         0x9D701A00 
    /** @} */

    /** @name Generic / Error Codes
     * @{
     */
        /** @note Detection Failed / No Chip Present */
        #define JEDEC_ID_UNSupported            0xFFFFFFFF 
    /** @} */

/** @} */ // End of SPI_FLASH_JEDECS
/** @} */

/* ========================================================================== */
/* SUB-GROUP : DATA STRUCTURES                                                */
/* ========================================================================== */
/**
 * @addtogroup SPI_FLASH_Types Data Structures
 * @brief Main Structs used by the SPI Flash driver.
 * @{
 */
    /**
     * @brief Post-Initialization Hook Function Pointer.
     * @note This callback is executed after the driver has probed and configured 
     * the flash, allowing for board-specific tweaks.
     * @param flash_instance Void pointer to spiFlash_instance_t. 
     * (Casted to void* to prevent circular dependency with spiFlash.h)
     * @return 0 on Success, Non-zero on failure.
     */
    typedef int (*flash_hook)(void *flash_instance);

    /**
     * @brief SPI Flash Device Descriptor.
     * @note This structure defines the properties of a specific Flash such as
     * - **Part Number**
     * - **JEDEC ID**
     * - **Capability Flash Flag**
     * - **Custom Function**
     * * The driver uses this to look up capabilities based on the detected JEDEC ID.
     * 
     * @section Example_Custom_Flash Example of Creating Custom Flash Descriptor
     * If user's specific Flash chip is not supported by the factory library, 
     * user can define a custom descriptor. This allows the driver to recognize 
     * the chip and apply specific vendor profiles or initialization logic.
     * 
     * <b> Steps to Implement: </b>
     * 1. Create an array of `spiFlash_info_t` containing user's chip's JEDEC ID.
     * 		* Make sure the JEDEC_ID is correctly formatted (Manuf + Type + Cap + 0x00 padding).
     * 		* User can set the `flags` field to match the capabilities of the chip, or assign a predefined profile (e.g., @ref PROFILE_WINBOND_64) if it matches an existing profile.
     * 		  Else set to '0' if no matching profile is available.
     * 2. Define a `post_init_hook` function Only if user plan to execute custom setup function after the initialization.
     * 3. Call @ref spiFlash_register before @ref spiFlash_probe.
     * 
     * <b> Below are the example of how to create a custom flash descriptor and register it to the driver. </b>
     * 
     * @code
     * #include "spiFlash/spiFlash.h"
     * 
     * int custom_chip_setup(void *instance);
     * 
     * // Example: Creating user's custom Flash with supported vendor profile
     * const spiFlash_info_t user_flash[] = {
     * {
     * 		.part_no = "CUSTOM_X", // The name of the flash
     * 		.jedec_id = 0x9D701A00, // Expected ID, make sure it is aligned
     * 		.flags = PROFILE_WINBOND_64, // Vendor profile
     * 		.post_init_hook = custom_chip_setup, // Custom function
     * },
     * };
     * 
     * // Custom Flash - Example of how to configure a user-defined flash chip.
     * // Users are allowed to define the part_no, id, flags, and post-init function.
     * int custom_chip_setup(void *instance){
     * 	Flash.cmd_wr_status =0x77;
     * 	Flash.mask_qe= 0x40; //Just an example !
     * 	printf("This is a user spiFlash function\n" );
     * 	return 0;
     * }
     * 
     * void main (){
     * 	// Register the user flash table.
     * 	spiFlash_register(user_flash); 
     * 	spiFlash_probe(&Flash); 
     * }
     * @endcode
     */
    typedef struct {
        const char  *part_no;         ///< String representation of Part Number (e.g., "W25Q128") 
        u32         jedec_id;         ///< Expected JEDEC ID (Manuf + Type + Cap) 
        u32         flags;            ///< Capability Flags (@ref SPI_FLASH_DRV_F) 
        flash_hook  post_init_hook;   ///< Optional callback (NULL if unused) 
    } spiFlash_info_t;

/** @} */ // End of SPI_FLASH_Types


/* ========================================================================== */
/* SUB-GROUP : Supported Flash Device Info                                    */
/* ========================================================================== */

/**
 * @defgroup FLASH_INFO Supported Flash  Device Info
 * @ingroup SPI_FLASH_LIST
 * @brief Global List of Supported Flash Devices.
 * @note If a match is found, the corresponding @ref SPI_FLASH_VENDOR flags are applied.
 * 
 * @note 
 * Please refer to @ref Example_Custom_Flash.
 * 
 * @{
 */
    /**
     * @brief Supported Flash Info.
     * @note Check the source code of [spiFlash_list.c](spi_flash__list_8c_source.html#L20) to see the detailed support flash list.
     * @see spiFlash_info_t
     * @see spiFlash_instance_t
     */
    extern const spiFlash_info_t known_flash[];

/** @} */ // End of FLASH_INFO group

#ifdef __cplusplus
}
#endif

/** @} */ // End of SPI_FLASH_LIST group

#endif // SPI_FLASH_DEVICE_H