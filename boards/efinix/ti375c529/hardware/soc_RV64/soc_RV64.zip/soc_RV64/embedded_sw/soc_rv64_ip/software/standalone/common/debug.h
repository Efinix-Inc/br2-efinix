////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header: bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef DEBUG_H
#define DEBUG_H

/**
 * @file debug.h
 * @author Efinix Inc
 * @brief Debug, logging, and assertion API.
 *
 * This file provides data structures and APIs for debug, 
 * logging and assertion.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include <stdio.h> /* Required for printf */

#ifdef __cplusplus
extern "C" {
#endif

/* Forward declaration for the character output function used in Assertion */
extern void bsp_putChar(char c);

/**
 * @defgroup DEBUG Debug Driver
 * @ingroup System_Service
 * 
 * @section Example_DEBUG Usage & Initialization
 * This module provides functions to configure and control
 * debug level, logging and assertion.
 *
 * @note <b>
 * Efinity IDE Will create userDef.h automatically when user create a new project
 * or import a project that doesn't have userDef.h unless user's project already 
 * its own userDef.h </b>
 * 
 * This is the template of Debug User Configuration in userDef.h:
 * @code
 * 
 * // --- DEBUG_MODE --- 
 * 	// 0 = Asserts OFF, Logs removed
 * 	// 1 = Asserts ON, Logs filtered
 * #define DEBUG_MODE 0
 * // --- ACTIVE_DEBUG_MOD --- This is the list of available module to debug
 * 	// DBG_MOD_SYS          // Enable Log for RISCV Extension
 * 	// DBG_MOD_IRQ          // Enable Log for IRQ, mtrap
 * 	// DBG_MOD_FAULT        // Enable Log for System Fault  
 * 	// DBG_MOD_UART         // Enable Log for UART Driver
 * 	// DBG_MOD_I2C          // Enable Log for I2C Driver   
 * 	// DBG_MOD_SPI          // Enable Log for SPI Driver
 * 	// DBG_MOD_SPI_FLASH    // Enable Log for SPI FLASH Driver
 * 	// DBG_MOD_RTC          // Enable Log for RTC Driver
 * 	// DBG_MOD_CAM          // Enable Log for CAM Driver
 * 	// DBG_MOD_SENSOR       // Enable Log for Sensor (temp sensor)
 * 	// DBG_MOD_MAIN         // Enable Log for main.c
 * 	// DBG_MOD_ALL          // Enable all Logs
 * #define ACTIVE_DEBUG_MOD   DBG_MOD_ALL
 * 
 * // --- ACTIVE_MIN_LVL ---
 * 	// DBG_LVL_ALL     0   // Show Info, Warn, Error
 * 	// DBG_LVL_WARN    1   // Show Warn, Error
 * 	// DBG_LVL_ERR     2   // Show Error only
 * 	// DBG_LVL_NONE    3   // Silence
 * #define ACTIVE_MIN_LVL   DBG_LVL_ALL
 * @endcode
 * 
 * To use the logging function in the code, refer to @ref DBG_FUNC.
 * 
 * @section Example_Debug Example: Logging
 *
 * The following shows how to enable and use the logging macros.
 * For the full API reference, see @ref DBG_FUNC.
 *
 * <b><i>Step 1 — Configure debug settings in userDef.h</i></b>
 * @code{.c}
 * #define DEBUG_MODE        1
 * #define ACTIVE_DEBUG_MOD  DBG_MOD_ALL
 * #define ACTIVE_MIN_LVL    DBG_LVL_ALL
 * @endcode
 *
 * <b><i>Step 2 — Use logging macros in main.c</i></b>
 *
 * With the configuration above, all log levels will print to the console.
 * @code{.c}
 * #include "debug.h"
 *
 * LOG_INFO(DBG_MOD_MAIN, "This is an info log.");
 * LOG_WARN(DBG_MOD_MAIN, "This is a warning log.");
 * LOG_ERR(DBG_MOD_MAIN, "This is an error log.");
 * @endcode
 *
 * @{
 */

/* =========================================================================
 * ANSI Colors
 * ========================================================================= */

/**
 * @defgroup ANSI_COLOUR ANSI Colors
 * @ingroup DEBUG
 * @brief ANSI escape codes for colored terminal output.
 * @{
 */
    #define ANSI_RESET    "\033[0m"   ///< Reset to default color
    #define ANSI_RED      "\033[31m"  ///< Red text
    #define ANSI_GREEN    "\033[32m"  ///< Green text
    #define ANSI_YELLOW   "\033[33m"  ///< Yellow text
    #define ANSI_BLUE     "\033[34m"  ///< Blue text
    #define ANSI_MAGENTA  "\033[35m"  ///< Magenta text
    #define ANSI_CYAN     "\033[36m"  ///< Cyan text
    #define ANSI_BOLD     "\033[1m"   ///< Bold text
    #define ANSI_UNDER    "\033[4m"   ///< Underlined text
/** @} */

/* =========================================================================
 * Debug Modules
 * ========================================================================= */

/**
 * @defgroup DBG_MOD Debug Modules
 * @ingroup DEBUG
 * @brief Bitmasks to enable logging per peripheral or subsystem.
 * @note Combine with `|` and assign to @ref ACTIVE_DEBUG_MOD in `userDef.h`.
 * 
 * *For example:*
 * @code{.c}
 * #define ACTIVE_DEBUG_MOD DBG_MOD_MAIN
 * @endcode
 * @{
 */
    #define DBG_MOD_SYS        (1 << 0)  ///< System / RISC-V core
    #define DBG_MOD_IRQ        (1 << 1)  ///< Interrupt controller
    #define DBG_MOD_FAULT      (1 << 2)  ///< Hard faults and errors
    #define DBG_MOD_UART       (1 << 3)  ///< UART driver
    #define DBG_MOD_I2C        (1 << 4)  ///< I2C driver
    #define DBG_MOD_SPI        (1 << 5)  ///< SPI driver
    #define DBG_MOD_SPI_FLASH  (1 << 6)  ///< SPI Flash driver
    #define DBG_MOD_RTC        (1 << 7)  ///< Real-Time Clock driver
    #define DBG_MOD_CAM        (1 << 8)  ///< Camera driver
    #define DBG_MOD_SENSOR     (1 << 9)  ///< External sensors
    #define DBG_MOD_MAIN       (1 << 10) ///< Main application

    /** @brief Enable all debug modules */
    #define DBG_MOD_ALL  \
        ( DBG_MOD_SYS | DBG_MOD_IRQ | DBG_MOD_FAULT | DBG_MOD_UART  | \
          DBG_MOD_I2C | DBG_MOD_SPI | DBG_MOD_SPI_FLASH | DBG_MOD_RTC | \
          DBG_MOD_CAM | DBG_MOD_SENSOR | DBG_MOD_MAIN )
/** @} */

/* =========================================================================
 * Debug Levels
 * ========================================================================= */

/**
 * @defgroup DBG_LVL Debug Levels
 * @ingroup DEBUG
 * @brief Minimum log severity filter.
 * @note Assign one of these to @ref ACTIVE_MIN_LVL in `userDef.h`.
 * 
 * *For example:*
 * @code{.c}
 * #define ACTIVE_MIN_LVL DBG_LVL_WARN
 * @endcode
 * @{
 */
    #define DBG_LVL_ALL   0  ///< Show Info, Warn, and Error
    #define DBG_LVL_WARN  1  ///< Show Warn and Error only
    #define DBG_LVL_ERR   2  ///< Show Error only
    #define DBG_LVL_NONE  3  ///< Silence — no output
/** @} */

/* =========================================================================
 * Debug API Function
 * ========================================================================= */

#include "userDef.h"

#if (DEBUG_MODE == 1) || defined(__DOXYGEN__)

    /* --- Fallback defaults if userDef.h is incomplete --- */
    #if !defined(ACTIVE_DEBUG_MOD) || !defined(ACTIVE_MIN_LVL)
    /**
     * @ingroup DBG_MOD
     */
        #define ACTIVE_DEBUG_MOD  0 ///< Default set to No modules enabled
    /**
     * @ingroup DBG_LVL
     */
        #define ACTIVE_MIN_LVL    DBG_LVL_NONE ///< Default set to no logs shown
        #ifndef __DOXYGEN__
            #warning "Missing ACTIVE_DEBUG_MOD or ACTIVE_MIN_LVL in userDef.h — debug disabled."
        #endif
    #endif

    /**
     * @defgroup DBG_FUNC Debug API Functions
     * @ingroup DEBUG
     * @brief Logging macros and runtime assertion.
     * @{
     */

    /** @cond */
    #define SHOULD_LOG(mod, lvl) \
        ( ((ACTIVE_DEBUG_MOD) & (mod)) && ((lvl) >= (ACTIVE_MIN_LVL)) )
    /** @endcond */

    /**
     * @brief Assert a condition. Prints message and halts on failure.
     * @param cond Condition to evaluate.
     * @param msg  Null-terminated string to print on failure.
     */
    #define BSP_ASSERT(cond, msg)               \
        do {                                    \
            if (!(cond)) {                      \
                const char *_p = (msg);         \
                while (*_p) bsp_putChar(*_p++); \
                while (1);                      \
            }                                   \
        } while (0)

    /**
     * @brief Log an informational message (green).
     * @param mod Module flag — see @ref DBG_MOD.
     * @param fmt Printf-style format string.
     * @param ... Format arguments.
     */
    #define LOG_INFO(mod, fmt, ...)                                         \
        do {                                                                \
            if (SHOULD_LOG(mod, DBG_LVL_ALL))                              \
                printf(ANSI_GREEN "INFO: " fmt ANSI_RESET "\n", ##__VA_ARGS__); \
        } while (0)

    /**
     * @brief Log a warning message (yellow).
     * @param mod Module flag — see @ref DBG_MOD.
     * @param fmt Printf-style format string.
     * @param ... Format arguments.
     */
    #define LOG_WARN(mod, fmt, ...)                                            \
        do {                                                                   \
            if (SHOULD_LOG(mod, DBG_LVL_WARN))                                \
                printf(ANSI_YELLOW "WRN: " fmt ANSI_RESET "\n", ##__VA_ARGS__); \
        } while (0)

    /**
     * @brief Log an error message (red).
     * @param mod Module flag — see @ref DBG_MOD.
     * @param fmt Printf-style format string.
     * @param ... Format arguments.
     */
    #define LOG_ERR(mod, fmt, ...)                                          \
        do {                                                                \
            if (SHOULD_LOG(mod, DBG_LVL_ERR))                              \
                printf(ANSI_RED "ERR: " fmt ANSI_RESET "\n", ##__VA_ARGS__); \
        } while (0)

    /** @} */ /* DBG_FUNC */

#else /* DEBUG_MODE == 0 — optimize everything out */

    /** @cond */
    #define BSP_ASSERT(cond, msg)      ((void)0)
    #define LOG_INFO(mod, fmt, ...)    ((void)0)
    #define LOG_WARN(mod, fmt, ...)    ((void)0)
    #define LOG_ERR(mod, fmt, ...)     ((void)0)
    /** @endcond */

#endif /* DEBUG_MODE */

/** @} */ /* DEBUG */

#ifdef __cplusplus
}
#endif

#endif /* DEBUG_H */