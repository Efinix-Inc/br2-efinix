////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef DS3231_H_
#define DS3231_H_

/**
 * @file ds3231.h
 * @author Efinix Inc
 * @brief DS3231 Driver API definitions.
 * This file provides data structures and APIs for controlling
 * the DS3231 RTC device on the EfxSapphireSoC platform.
 * @note This is a device-specific driver implementation for the DS3231 RTC.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "rtc/rtc.h"
/**
 * @defgroup Supported_RTC Supported Devices
 * @ingroup RTC
 * @brief Supported Real Time Clock (RTC) devices.
 * 
 * @note This module provides device-specific drivers for various RTC hardware that currently supported by Efinix.
 * @note User may add their custom RTC device drivers based on this framework.
 * @{
 */

/**
 * @defgroup DS3231_Config DS3231 RTC Driver
 * @ingroup Supported_RTC
 * @brief DS3231 Real Time Clock driver definitions.
 * 
 * @note This is a device-specific driver implementation for the DS3231 RTC.
 * @{
 */

#ifdef __cplusplus
extern "C" {
#endif

/* ========================================================================== */
/* SUB-GROUP : REGISTER DEFINITIONS                                          */
/* ========================================================================== */

/**
 * @defgroup DS3231_Macros Register Definitions
 * @ingroup Supported_RTC
 * @brief Register bitmasks and offsets.
 * @{
 */
    /**
     * @brief I2C Address for DS3231 RTC device.
     */
    #define RTC_DS3231_ADDR 	0x68<<1     ///< DS3231 I2C Address */

/** @} */ // End of DS3231_Macros group


/* ========================================================================== */
/* SUB-GROUP : Driver Definition                                        */
/* ========================================================================== */

/**
 * @defgroup DS3231_DRV Driver Structure
 * @ingroup Supported_RTC
 * @brief This is the DS3231 driver structure.
 * @{
 */
    /**
     * @brief DS3231 Driver Instance.
     * Point your generic RTC pointer to this structure to use the DS3231 hardware.
     * @note Implements the following hooks from @ref rtc_api_t:
     *      - **getTime:** Reads current time registers.
     *      - **setTime:** Writes current time registers.
     *      - **setTimeSystem:** Configures the 12/24H mode bit.
     * @see rtc_api_t
     * @code
     * // Example Usage:
     * rtc_api_t *my_rtc = &DS3231_DRIVER;
     * * // The application code doesn't know this is a DS3231
     * my_rtc->getTime(&t); 
     * @endcode
     */
    extern const rtc_api_t DS3231_DRIVER;

/** @} */ // End of DS3231_DRV group

/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup DS3231_Funcs API Functions
 * @ingroup Supported_RTC
 * @brief Function definitions for DS3231 driver.
 * @note This is the public API for the DS3231 RTC device.
 * @{
 */
     /**
     * @brief Apply I2C + RTC configuration.
     * @param rtc Pointer to RTC instance.
     * @return Status code of the operation.
     */
    rtc_status_t DS3231_applyConfig(rtc_instance_t *rtc);
     /**
     * @brief Enable error interrupt for DS3231 RTC.
     * @param rtc Pointer to RTC instance.
     * @return Status code of the operation.
     */
    rtc_status_t DS3231_enableErrorInterrupt(rtc_instance_t *rtc);
    /**
     * @brief Get time from DS3231 RTC.
     * @param rtc Pointer to RTC instance.
     * @return Status code of the operation.
     */
    rtc_status_t DS3231_getTime(rtc_instance_t *rtc);
    /**
     * @brief Set time on DS3231 RTC.
     * @param rtc Pointer to RTC instance.
     * @return Status code of the operation.
     */
    rtc_status_t DS3231_setTime(rtc_instance_t *rtc);
    /**
     * @brief Set time system (12-hour or 24-hour) on DS3231 RTC.
     * @param rtc Pointer to RTC instance.
     * @param use_12hour_mode Flag indicating whether to use 12-hour mode (1) or 24-hour mode (0).
     * @return Status code of the operation.
     */
    rtc_status_t DS3231_setTimeSystem(rtc_instance_t *rtc, u8 use_12hour_mode) ;
/** @} */ // End of DS3231_Funcs group

#ifdef __cplusplus
}
#endif // C_plusplus

/** @} */ // End of MAIN DS3231 Group

/** @} */ // End of MAIN Supported_RTC Group
#endif // DS3231_H_