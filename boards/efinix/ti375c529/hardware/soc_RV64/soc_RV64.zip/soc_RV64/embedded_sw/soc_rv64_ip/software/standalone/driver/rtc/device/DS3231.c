////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/**
* @file DS3231.c
* @brief DS3231 RTC driver implementation.
*
* Implements the functions defined in DS3231.h for controlling
* DS3231 RTC input/output and interrupts on the EfxSapphireSoC platform.
* @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
* See the full @ref license_page for Efinix and SaxonSoc MIT terms.
*/

#include <stdio.h>
#include "bsp.h"
#include "rtc/device/DS3231.h"

/*----------------------------------------------------------------------------*/
/* Register Definition                                                    */
/*----------------------------------------------------------------------------*/

/* --- Address: Timekeeping Register --- */
#define RTC_SECONDS			0X00
#define	RTC_MINUTES			0X01
#define RTC_HOURS			0X02
#define RTC_WEEKDAYS		0X03
#define RTC_DAYS			0X04
#define RTC_MONTH			0X05
#define RTC_YEAR			0X06

/* --- Address: Control Status Register, Temp Reg --- */
#define CONTROL_ADDR		0X0E
#define STATUS_ADDR			0X0F
#define AGING_ADDR			0X10
#define MSB_TEMP			0X11
#define LSB_TEMP			0X12

/* --- Address: Timekeeping/ALARM in Each Register --- */
#define SECONDS_DATA 		0X7F
#define MINUTES_DATA 		0X7F
#define _12HOURS_DATA 		0X1F
#define _24HOURS_DATA 		0X3F  
#define DAYS_DATA 			0XFF
#define DATE_DATA 			0X37
#define MONTH_DATA 			0X1F
#define YEAR_DATA 			0XFF


/* -----------------------------------------------------------------------------*/
/* RTC: Plug & Play Driver                            	        	
/* -----------------------------------------------------------------------------*/
const rtc_api_t DS3231_driver =
{
    .applyConfig			= DS3231_applyConfig,
    .enableErrorInterrupt 	= DS3231_enableErrorInterrupt,
    .getTime        		= DS3231_getTime,
    .setTime        		= DS3231_setTime,
    .setTimeSystem  		= DS3231_setTimeSystem,

};

rtc_status_t DS3231_applyConfig(rtc_instance_t *rtc) {

    i2c_applyConfig(rtc->inst);
    return RTC_OK;
}

rtc_status_t DS3231_enableErrorInterrupt(rtc_instance_t *rtc) {

     // Will drop I2C Transcation if Timeout.
    i2c_enableInterrupt(rtc->inst, I2C_INTERRUPT_DROP);
    return RTC_OK;
}

rtc_status_t DS3231_getTime(rtc_instance_t *rtc) {
    
    LOG_INFO(DBG_MOD_RTC,"This is DS3231_getTime func!\n");
    rtc_data_t *time = &rtc->current_time;
    u8 get_data[9] = {0}; 

    // Hardware Read
    i2c_readData_b(rtc->inst, RTC_SECONDS, get_data, 7);
    // Parsing
    time->seconds  = bcd2bin(get_data[RTC_SECONDS] & SECONDS_DATA);
    time->minutes  = bcd2bin(get_data[RTC_MINUTES] & MINUTES_DATA);
    time->weekdays = bcd2bin(get_data[RTC_WEEKDAYS] & 0x07);
    time->days     = bcd2bin(get_data[RTC_DAYS] & 0x3F);
    time->months   = bcd2bin(get_data[RTC_MONTH] & 0x1F); 
    time->years    = bcd2bin(get_data[RTC_YEAR]);

    // Handle 12/24 Hour Logic (DS3231 Specific)
    time->timesystem = (get_data[RTC_HOURS] & 0x40) >> 6; 

    if (time->timesystem == 1) { 
        // --- 12 Hour Mode ---
        time->PM    = (get_data[RTC_HOURS] & 0x20) >> 5; 
        time->hours = bcd2bin(get_data[RTC_HOURS] & 0x1F); 
    } 
    else {
        // --- 24 Hour Mode ---
        time->PM    = 0; // Not applicable
        time->hours = bcd2bin(get_data[RTC_HOURS] & 0x3F);
    }
    return RTC_OK;
}

rtc_status_t DS3231_setTimeSystem(rtc_instance_t *rtc, u8 use_12hour_mode) {
    u8 buffer[1];
    u8 current_mode_12h;
    
    // DS3231 stores the mode flag in Bit 6 of this register
    i2c_readData_b(rtc->inst, RTC_HOURS, buffer, 1);
    
    // Extract Bit 6 (1 = 12h mode, 0 = 24h mode)
    current_mode_12h = (buffer[0] & 0x40) >> 6;

    // If already in the correct mode, do nothing
    if (current_mode_12h == use_12hour_mode) {
        return RTC_SKIP;
    }

    // 2. Perform the Conversion
    u8 h_val;
    u8 pm_flag = 0;
    u8 new_reg_val;

    if (use_12hour_mode) {
        // In 24h mode, bits 0-5 are the value (0-23). Bit 6 is 0.
        h_val = bcd2bin(buffer[0] & 0x3F); 

        if (h_val >= 12) {
            pm_flag = 1;
            if (h_val > 12) h_val -= 12; // 13:00 -> 1:00
        } else {
            pm_flag = 0;
            if (h_val == 0) h_val = 12; // 00:00 -> 12:00 AM
        }
        
        new_reg_val = 0x40 | (pm_flag << 5) | bin2bcd(h_val);
        
    } 
    else {
        // In 12h mode: Bit 5 is PM, Bits 0-4 are Hour (1-12)
        pm_flag = (buffer[0] & 0x20) >> 5;
        h_val   = bcd2bin(buffer[0] & 0x1F);

        if (pm_flag) {
            // PM Case: 12 PM -> 12, 1 PM -> 13
            if (h_val < 12) h_val += 12;
        } else {
            // AM Case: 12 AM -> 00, 1 AM -> 1
            if (h_val == 12) h_val = 0;
        }
        new_reg_val = bin2bcd(h_val);
    }

    // 3. Write Back
    i2c_writeData_b(rtc->inst, RTC_HOURS, &new_reg_val, 1);
    return RTC_OK;
}

rtc_status_t DS3231_setTime(rtc_instance_t *rtc) {
    rtc_data_t *t = &rtc->current_time;
    u8 buffer[1];
    
    i2c_readData_b(rtc->inst, RTC_HOURS, buffer, 1);
    
    // Make sure it is in 24hr timesystem!
    // Check Bit 6 (0 = 24h, 1 = 12h). If it is 1, we must clear it.
    if (buffer[0] & 0x40) { 
        buffer[0] &= ~0x40; // Clear Bit 6 to force 24h mode
        
        i2c_setMux(rtc->inst, 0xF);
        i2c_writeData_b(rtc->inst, RTC_HOURS, buffer, 1);
    }

    u8 set_data[7] = {
        bin2bcd(t->seconds),
        bin2bcd(t->minutes),
        bin2bcd(t->hours),    // 0-23 is now perfectly valid
        bin2bcd(t->weekdays),
        bin2bcd(t->days),
        bin2bcd(t->months),
        bin2bcd(t->years)
    };
    i2c_writeData_b(rtc->inst, RTC_SECONDS, set_data, 7);

    return RTC_OK;
}

/************************************************************************************************************************/
