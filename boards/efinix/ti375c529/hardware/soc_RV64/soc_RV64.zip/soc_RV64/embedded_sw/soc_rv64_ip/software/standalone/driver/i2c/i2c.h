////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef I2C_H
#define I2C_H

/**
 * @file i2c.h
 * @author Efinix Inc
 * @brief I2C driver API definitions.
 *
 * This file provides data structures and APIs for controlling
 * the I2C peripheral on the EfxSapphireSoC platform.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */


#include <stdint.h>
#include "type.h"
#include "soc.h"

#ifdef __cplusplus
extern  "C" {
#endif
/**
 * @defgroup I2C I2C Driver
 * @brief Inter-Integrated Circuit (I2C) driver.
 * @ingroup comm_group
 *
 * This module provides functions to configure and control
 * I2C input/output and interrupt behavior.
 * 
 * @section Example_I2C Usage & Initialization
 * This is an example show how to instantiate @ref I2C with @ref i2c_instance_t.
 * 
 * @code  
 * #include "i2c/i2c.h"
 * 
 * #define I2C_SLAVE_ADDR   	0x50>>1
 * #define I2C_FREQ    		100000
 * #define I2C_CTRL_HZ 		SYSTEM_CLINT_HZ
 * #define I2C_CTRL    		(i2c_hwreg_t *)SYSTEM_I2C_0_IO_CTRL
 * 
 * i2c_instance_t I2C = {
 * 	.hwreg      			= I2C_CTRL,
 * 	.slaveAddress			= I2C_SLAVE_ADDR,
 * 	.samplingClockDivider	= 3,
 * 	.timeout				= I2C_CTRL_HZ/1000,
 * 	.tsuDat					= I2C_CTRL_HZ/(I2C_FREQ*5),
 * 	.tLow					= I2C_CTRL_HZ/(I2C_FREQ*2),
 * 	.tHigh					= I2C_CTRL_HZ/(I2C_FREQ*2),
 * 	.tBuf					= I2C_CTRL_HZ/(I2C_FREQ),
 * },
 * };
 * 
 * i2c_applyConfig(&I2C);
 * 
 * @endcode
 * 
 * @see @ref i2cMasterDemo "Example I2C Master Demo" - Learn how to use the driver in Master mode
 * @see @ref i2cSlaveDemo "Example I2C Slave Demo" - Learn how to use the driver in Slave mode
 * @see @ref i2cEepromDemo "Example I2C EEPROM Demo" - Learn how to use the driver with an EEPROM
 * @{
 */

/* ========================================================================== */
/* SUB-GROUP : REGISTER DEFINITIONS                                          */
/* ========================================================================== */ 

/**
 * @defgroup I2C_Macros Register Definitions
 * @ingroup I2C
 * @brief Register bitmasks and offsets.
 * @{
 */
    /** @name I2C Mode Control Register Bitmasks
     * @{
     */
    #define I2C_MODE_CPOL                   (1 << 0)	///< I2C Clock Polarity Mask
    #define I2C_MODE_CPHA                   (1 << 1)	///< I2C Clock Phase Mask
    /** @} */

    /** @name I2C TX/RX and Status Register Bitmasks 
     * @{
    */
    #define I2C_TX_VALUE                    (0xFF)		///< Mask for TX value 
    #define I2C_TX_VALID                    (1 << 8)	///< Mask for TX valid bit 
    #define I2C_TX_ENABLE                   (1 << 9)	///< Mask for Enable TX 
    #define I2C_TX_REPEAT                   (1 << 10)	///< Mask for Repeat TX 
    #define I2C_TX_DISABLE_ON_DATA_CONFLICT (1 << 11)	///< Mask for Disable TX on data conflict 
    #define I2C_RX_VALUE                    (0xFF)		///< Mask for RX value 
    #define I2C_RX_VALID                    (1 << 8)  	///< Mask for RX valid bit 
    #define I2C_RX_LISTEN                   (1 << 9)	///< Mask for RX listen mode 
    /** @} */

    /** @name I2C Master/Slave Status Register Bitmasks
     * 	@{
     */
    #define I2C_MASTER_BUSY                 (1 << 0)	///< Mask for Master Busy 
    #define I2C_MASTER_START                (1 << 4)	///< Mask for Master Start 
    #define I2C_MASTER_STOP                 (1 << 5)	///< Mask for Master Stop 
    #define I2C_MASTER_DROP                 (1 << 6)	///< Mask for Master Drop 
    #define I2C_MASTER_RECOVER              (1 << 7)	///< Mask for Master Recover 
    #define I2C_MASTER_START_DROPPED        (1 << 9)	///< Mask for Master Start Dropped 
    #define I2C_MASTER_STOP_DROPPED         (1 << 10)	///< Mask for Master Stop Dropped 
    #define I2C_MASTER_RECOVER_DROPPED      (1 << 11)	///< Mask for Master Recover Dropped 
    #define I2C_SLAVE_STATUS_IN_FRAME       (1 << 0)	///< Mask for the transaction is in progress 
    #define I2C_SLAVE_STATUS_SDA            (1 << 1)	///< Mask for Slave's current state of SDA Line
    #define I2C_SLAVE_STATUS_SCL            (1 << 2)	///< Mask for Slave's current state of SCL Line
    #define I2C_SLAVE_OVERRIDE_SDA          (1 << 1)	///< Mask for Force Slave SDA line 
    #define I2C_SLAVE_OVERRIDE_SCL          (1 << 2)	///< Mask for Force Slave SCL line
    /** @} */

    /** @name I2C Filter Configuration Bitmasks 
     * @{
    */
    #define I2C_FILTER_7_BITS               (0)			///< Filter setting for 7 bits 
    #define I2C_FILTER_10_BITS              (1 << 14)	///< Filter setting for 10 bits 
    #define I2C_FILTER_ENABLE               (1 << 15)	///< Filter Enable 
    /** @} */

    /** @name I2C Read/Write Definitions 
     * @{
    */
    #define I2C_READ                        0x01	///< Indicate Read Transcation 
    #define I2C_WRITE                       0x00	///< Indicate Write Transcation 
    /** @} */


    /** @name I2C TX and Check Macro
     * @{
    */	
    /**
     * @brief Transmits a single byte over the I2C bus and waits for an ACK response.
     * @param inst Pointer to I2C instance.
     * @param byte The byte to be transmitted.
     * Holds the software  registers and hardware pointer.
     * @note This macro performs a single byte transmission as part of an I2C write transaction.
     *       - First, it sends the specified byte using the `i2c_sendTxByte()` function. 
     *       - Followed by`i2c_sendNackBlocking()` to complete the 9-bit transfer cycle (8 data bits + 1 ACK/NACK).
     *       - It then calls `i2c_waitRxAck()` to wait until the ACK status is returned by the slave.
     *       - This ensures that the slave has successfully received and acknowledged the byte.
     *       - The macro is wrapped in a `do { ... } while(0)` construct to allow safe usage
     *          within conditional blocks or inline statements.
     */
    #ifndef TX_AND_CHECK
    #define TX_AND_CHECK(inst, byte)             \
        do {                                     \
            i2c_sendTxByte(inst, (byte));            \
            i2c_sendNackBlocking(inst);            \
            i2c_waitRxAck(inst);                 \
        } while(0)
    #endif
    /** @} */

/** @} */ // End of I2C_Macros group

/* ========================================================================== */
/* SUB-GROUP : Data Types			                                         */
/* ========================================================================== */

/**
 * @defgroup I2C_ENUM Data Types
 * @ingroup I2C
 * @brief Enums used by the driver.
 * @{
 */

    /** @name Interrupt Enums
     * @brief Enums used for driver interrupt handling.
     * @{
     */
    
         /** @brief I2C Enable Interrupt List. */
        typedef enum {
            I2C_INTERRUPT_RX_DATA			= (1 << 0), ///< Trigger Interrupt when receive data
            I2C_INTERRUPT_RX_ACK			= (1 << 1), ///< Trigger Interrupt when receive ACK
            I2C_INTERRUPT_TX_DATA        	= (1 << 2),	///< Trigger Interrupt when transmit data
            I2C_INTERRUPT_TX_ACK        	= (1 << 3), ///< Trigger Interrupt when transmit ACK      
            I2C_INTERRUPT_START				= (1 << 4),	///< Trigger Interrupt when START condition is sent
            I2C_INTERRUPT_RESTART			= (1 << 5), ///< Trigger Interrupt when RESTART condition is sent
            I2C_INTERRUPT_END 	          	= (1 << 6), ///< Trigger Interrupt when STOP condition is sent
            I2C_INTERRUPT_DROP           	= (1 << 7),  ///< Trigger Interrupt when DROP condition is sent        
            I2C_INTERRUPT_CLOCK_GEN_EXIT 	= (1 << 15), ///< Trigger Interrupt when Clock Generation is stop
            I2C_INTERRUPT_CLOCK_GEN_ENTER	= (1 << 16), ///< Trigger Interrupt when Clock Generation is start
            I2C_INTERRUPT_FILTER         	= (1 << 17)  ///< Trigger Interrupt when controller act as slave and its addres filter is triggered      
        } i2c_interrupt_t;
        /** @} */

/** @} */ // End of I2C_ENUM group


/* ========================================================================== */
/* SUB-GROUP : DATA STRUCTS                                          			*/
/* ========================================================================== */
/**
 * @defgroup I2C_Types Data Structures
 * @ingroup I2C
 * @brief Structs used by the driver.
 * @note
 * <b> This is an example show how to instantiate I2C with @ref i2c_instance_t 
 * and @ref i2c_hwreg_t.
 * 
 * @code 
 * 
 * #define I2C_FREQ				100000
 * #define I2C_ADDR				0x67<<1   // Slave device address
 * #define I2C_CTRL_HZ			SYSTEM_CLINT_HZ
 * #define I2C_CTRL				(i2c_hwreg_t *)SYSTEM_I2C_0_IO_CTRL
 * 
 * i2c_instance_t I2C_inst = {
 *		.hwreg      			= I2C_CTRL,
 *		.slaveAddress			= I2C_ADDR,
 *		.samplingClockDivider	= 3,
 *		.timeout				= I2C_CTRL_HZ/1000,
 *		.tsuDat					= I2C_CTRL_HZ/(I2C_FREQ*5),
 *		.tLow					= I2C_CTRL_HZ/(I2C_FREQ*2),
 *		.tHigh					= I2C_CTRL_HZ/(I2C_FREQ*2),
 *		.tBuf					= I2C_CTRL_HZ/(I2C_FREQ),
 *},
 *
 * @endcode
 *
 * @{
 */

     /**
     * @brief I2C hardware filter configuration map.
     * @note Filter structure ONLY maps directly onto the I2C peripheral
     *       memory-mapped register layout.
     */
    typedef volatile struct 
    {
        u32 FILTER_CONFIG_0; ///< Offset +0x00: Primary Filter Config (Addr/Enable)
        u32 FILTER_CONFIG_1; ///< Offset +0x04: Secondary Filter Config (Addr/Enable)

    } i2c_filter_hwreg_t;

    /**
     * @brief I2C hardware register map.
     * @note This is the main structure that maps directly onto the I2C peripheral
     *       memory-mapped register layout.
     */
    typedef volatile struct{
        u32 TX_DATA;             	///<  Address Offset: 0x00 
        u32 TX_ACK;             	///<  Address Offset: 0x04 
        u32 RX_DATA;          		///<  Address Offset: 0x08 
        u32 RX_ACK;       		    ///<  Address Offset: 0x0C 
        u32 RESERVED0[4];			///< Reserved Space (0x0C to 0x16) 
        u32 INTERRUPT;    			///<  Address Offset: 0x20 
        u32 INTERRUPT_CLEAR;    	///< Address Offset: 0x24 
        u32 SAMPLING_CLOCK_DIVIDER; ///< Address Offset: 0x28 
        u32 TIMEOUT;          		///< Address Offset: 0x2C 
        u32 TSU_DATA;       		///< Address Offset: 0x30 
        u32 RESERVED1[3];			///< Reserved Space (0x34 to 0x3C) 
        u32 MASTER_STATUS;    		///< Address Offset: 0x40 
        u32 SLAVE_STATUS;         	///< Address Offset: 0x44 
        u32 SLAVE_OVERRIDE;     	///< Address Offset: 0x48 
        u32 RESERVED2;          	///< Address Offset: 0x4C  
        u32 tLOW;          			///< Address Offset: 0x50 
        u32 tHIGH;          		///< Address Offset: 0x54 
        u32 tBUF;          			///< Address Offset: 0x58 
        u32 RESERVED3[9];			///< Reserved Space (0x5C to 0x7C) 
        u32 HIT_CONTEXT;          	///< Address Offset: 0x80 
        u32 FILTER_STATUS;          ///< Address Offset: 0x84 
        i2c_filter_hwreg_t FILTER[3];   ///< Address Offset: 0x8C 
    } i2c_hwreg_t;

    /**
     * @brief I2C instance.
     * Holds the software registers and hardware pointer.
     * @note This structure holds configuration values to be applied to the hardware.
     *		- slaveAddress: 7-bit slave address.
      *		- samplingClockDivider 
     *			- Sampling rate = (FCLK/(samplingClockDivider + 1)).
     *			- Controls the rate at which the I2C controller samples SCL and SDA.
     *		- timeout: Timeout value in number of SCL clock cycles.
     *			- Inactive timeout clock cycle. The controller will drop the transfer when the value of the timeout is reached or exceeded.
     *			- Setting the timeout value to zero will disable the timeout feature.
     *			- Defines the maximum duration the controller will wait for SCL to
      *		- tsuDat => Data setup time. The number of clock cycles should SDA hold its state before the rising edge of SCL.
     *		- tLow   => The number of clock cycles of SCL in LOW state.
     *		- tHigh  => The number of clock cycles of SCL in HIGH state.
     *		- tBuf => The number of clock cycles delay before master can initiate a START bit after a STOP bit is issued.
      * @note To apply the changes, please call i2c_applyConfig() after modifying the configuration fields.
     */
    typedef struct{
        i2c_hwreg_t		*hwreg;       			///< Pointer to Hardware Register Map 
        u32 			slaveAddress;			///< 7-bit Slave Address 
        u32 			samplingClockDivider; 	///< Sampling Clock Divider 
        u32 			timeout;              	///< Timeout Value 
        u32 			tsuDat;               	///< Data Setup Time 
        u32 			tLow;  				 	///< SCL Low Time 
        u32 			tHigh; 					///< SCL High Time 
        u32 			tBuf;  					///< Bus Free Time between STOP and START 
    }i2c_instance_t;



/** @} */ // End of I2C_Types group

/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup I2C_Funcs API Functions
 * @ingroup I2C
 * @brief Function definitions for I2C driver.
 * @{
 */

    /** 
     * @brief Apply the software configuration to the hardware.
     *
     * Writes all  values stored in the i2c_instance to the corresponding
     * I2C hardware registers.
     *
     * @param inst Pointer to I2C instance.
     */
    void i2c_applyConfig(i2c_instance_t *inst);

    /** 
     * @brief Write values to I2C hardware registers.
     * @param inst Pointer to I2C instance.
     * @param value Value to write to Slave Override register.
     */
    void i2c_setSlaveOverride(i2c_instance_t *inst, u32 value);
    
    /** @name I2C (Get Functions)
     * Read value from I2C hardware registers.
     * @{
        */
        /** 
         * @brief Get Slave Status 
         * @details Retrieve value from @ref i2c_hwreg_t::SLAVE_STATUS Register.
         * @param inst Pointer to I2C instance.
         * @return Slave Status Register Value.
         */
        u32 i2c_getSlaveStatus(i2c_instance_t *inst);
        /** 
         * @brief Get Master Status
         * @details Retrieve value from @ref i2c_hwreg_t::MASTER_STATUS Register.
         * @param inst Pointer to I2C instance.
         * @return Master Status Register Value.
         */
        u32 i2c_getMasterStatus(i2c_instance_t *inst);
        /** 
         * @brief Get Filtering Hit 
         * @details Retrieve value from @ref i2c_hwreg_t::HIT_CONTEXT.
         * @param inst Pointer to I2C instance.
         * @return Filtering Hit Register Value.
         */
        u32 i2c_getFilteringHit(i2c_instance_t *inst);
        /** 
         * @brief Get Interrupt Flag 
         * @details Retrieve value from @ref i2c_hwreg_t::INTERRUPT_CLEAR.
         * @param inst Pointer to I2C instance.
         * @return Interrupt Flag Register Value.
         */
        u32 i2c_getInterruptFlag (i2c_instance_t *inst);
        /** 
         * @brief Get Interrupt Enable 
         * @details Retrieve value from @ref i2c_hwreg_t::INTERRUPT.
         * @param inst Pointer to I2C instance.
         * @return Interrupt Enable Register Value.
         */
        u32 i2c_getInterruptEnable (i2c_instance_t *inst);
        /** 
         * @brief Get Filtering Status 
         * @details Retrieve value from @ref i2c_hwreg_t::FILTER_STATUS.
         * @param inst Pointer to I2C instance.
         * @return Filtering Status Register Value.
         */
        u32 i2c_getFilteringStatus(i2c_instance_t *inst);
        /**
         * @brief Get Slave Override 
         * @details Retrieve value from @ref i2c_hwreg_t::SLAVE_OVERRIDE.
         * @param inst Pointer to I2C instance.
         * @return Slave Override Register Value.
         */
        u32 i2c_getSlaveOverride(i2c_instance_t *inst);

    /** @} */

    /** @name I2C (Master Functions)
     * Functions for controlling the I2C master.
     * @{
    */
    
        /**
         * @brief Initiate start condition for I2C master mode and sets the dropped status if necessary.
         * @param inst Pointer to I2C instance.
         */
        void i2c_startMaster(i2c_instance_t *inst);
        /**
         * @brief Initiate restart condition for I2C master mode and sets the dropped status if necessary.
         * @param inst Pointer to I2C instance.
         */
        void i2c_restartMaster(i2c_instance_t *inst);
        /**
         * @brief Initiate recover condition for I2C master mode and sets the dropped status if necessary.
         * @param inst Pointer to I2C instance.
         */
        void i2c_recoverMaster(i2c_instance_t *inst);
        /**
         * @brief Initiate start condition for I2C master mode and waits until the operation is complete.
         * @param inst Pointer to I2C instance.
         */
        void i2c_startMasterBlocking(i2c_instance_t *inst);
        /**
         * @brief Initiate restart condition for I2C master mode and waits until the operation is complete.
         * @param inst Pointer to I2C instance.
         */
        void i2c_restartMasterBlocking(i2c_instance_t *inst);
        /**
         * @brief Initiate stop condition for I2C master mode and sets the dropped status if necessary.
         * @param inst Pointer to I2C instance.
         */
        void i2c_stopMaster(i2c_instance_t *inst);
        /**
         * @brief Initiate stop condition for I2C master mode and waits until the operation is complete.
         * @param inst Pointer to I2C instance.
         */
        void i2c_stopMasterBlocking(i2c_instance_t *inst);
        /**
         * @brief Initiate recover condition for I2C master mode and waits until the operation is complete.
         * @param inst Pointer to I2C instance.
         */
        void i2c_recoverMasterBlocking(i2c_instance_t *inst);
        /**
         * @brief Drops the current I2C master operation.
         * @param inst Pointer to I2C instance.
         */
        void i2c_dropMaster(i2c_instance_t *inst);
        /**
         * @brief Checks if the I2C master is busy.
         * @param inst Pointer to I2C instance.
         * @return Non-zero if the master is busy, zero otherwise.
         */
        u32 i2c_checkMasterBusy(i2c_instance_t *inst);
    /** @} */ //End of I2C Master Functions group


    /** @name I2C (Transmit/Receive Functions)
     * Transmit data over I2C or receive data over I2C.
     * @{
    */
        /**
         * @brief Configures the I2C controller to listen for ACK signals on the receiver (RX) line.
         * @param inst Pointer to I2C instance.
         */
        void i2c_listenAck(i2c_instance_t *inst);
        /**
         * @brief Transmits a byte of data over I2C.
         * @param inst Pointer to I2C instance.
         * @param byte The byte of data to transmit.
         */
        void i2c_sendTxByte(i2c_instance_t *inst,u8 byte);
        /**
         * @brief Transmits an ACK signal over I2C.
         * @param inst Pointer to I2C instance.
         */
        void i2c_sendTxAck(i2c_instance_t *inst);
        /**
         * @brief Transmits an NACK signal over I2C.
         * @param inst Pointer to I2C instance.
         */
        void i2c_sendTxNack(i2c_instance_t *inst);
        /**
         * @brief Waits until the transmission of an ACK signal is complete over the I2C bus.
         * @param inst Pointer to I2C instance.
         */
        void i2c_waitTxAck(i2c_instance_t *inst);
        /**
         * @brief Waits until the reception of an ACK signal is complete over the I2C bus.
         * @param inst Pointer to I2C instance.
         */
        void i2c_waitRxAck(i2c_instance_t *inst);
        /**
         * @brief Sends an ACK signal over the I2C bus and waits until the transmission is complete.
         * @param inst Pointer to I2C instance.
         */
        void i2c_sendAckBlocking(i2c_instance_t *inst);
        /**
         * @brief Sends an NACK signal over the I2C bus and waits until the transmission is complete.
         * @param inst Pointer to I2C instance.
         */
        void i2c_sendNackBlocking(i2c_instance_t *inst);
        /**
         * @brief Reads data from I2C receive data register.
         * @param inst Pointer to I2C instance.
         */
        u32 i2c_getRxData(i2c_instance_t *inst);
        /**
         * @brief Reads Acknowledge signal from I2C receive data register.
         * @param inst Pointer to I2C instance.
         */
        u32 i2c_getRxAck(i2c_instance_t *inst);
        /**
         * @brief Checks if the received ACK signal is detected.
         * @param inst Pointer to I2C instance.
         */
        u32 i2c_getRxNack(i2c_instance_t *inst);
        /**
         * @brief Sends a byte over I2C bus with repeat mode enabled.
         * @param inst Pointer to I2C instance.
         * @param byte The byte of data to transmit.
         */
        void i2c_sendTxByteRepeat(i2c_instance_t *inst,u8 byte);
        /**
         * @brief Sends a NACK signal over I2C bus with repeat mode enabled.
         * @param inst Pointer to I2C instance.
         */
        void i2c_sendTxNackRepeat(i2c_instance_t *inst);

    /** @} */	//End of I2C Transmit/Receive Functions group

    /** @name I2C (Control Functions)
     * Configure I2C filters and interrupts.
     * @{
    */
        /**
         * @brief Enables and configures an I2C hardware filter.
         * @param inst Pointer to I2C instance.
         * @param filterId The ID of the filter to enable.
         * @param config The configuration value for the filter.
         */
        void i2c_enableFilter(i2c_instance_t *inst, u32 filterId, u32 config);
        /**
         * @brief Sets the configuration for an I2C hardware filter.
         * @param inst Pointer to I2C instance.
         * @param filterId The ID of the filter to configure.
         * @param value The configuration value to set for the filter.
         */
        void i2c_setFilterConfig(i2c_instance_t *inst, u32 filterId, u32 value);
        /**
         * @brief Enables specific I2C interrupts.
         * @param inst Pointer to I2C instance.
         * @param value The interrupt(s) to enable.
         */
        void i2c_enableInterrupt(i2c_instance_t *inst, i2c_interrupt_t value);
        /**
         * @brief Disables specific I2C interrupts.
         * @param inst Pointer to I2C instance.
         * @param value The interrupt(s) to disable.
         */
        void i2c_disableInterrupt(i2c_instance_t *inst, i2c_interrupt_t value);
        /**
         * @brief Clears specific I2C interrupt flags.
         * @param inst Pointer to I2C instance.
         * @param value The interrupt flag(s) to clear.
         */
        void i2c_clearInterruptFlag(i2c_instance_t *inst, i2c_interrupt_t value);

    /** @} */	//End of I2C Control Functions group

    /** @name I2C (Read/Write Functions)
     * Read and write data over I2C bus.
     * @{
    */
        /**
         * @brief Write data with an 8-bit register address over I2C and check rx ack for each transaction.
         * @param inst Pointer to I2C instance.
         * @param regAddr 8-bit register address to write to.
         * @param data Pointer to data buffer to write.
         * @param length Number of bytes to write.
         * @note This function performs a write operation over the I2C bus using a 16-bit register address. 
         *		- It begins by sending the start condition, followed by the slave address with the write bit. 
         *		- Next, it transmits the target register address within the slave.
         *		- Then, it iterates through the provided data buffer, transmitting each byte individually.
         *		- After sending each byte, the function waits for an acknowledgment (ACK) from the slave ,
         *		  device to confirm reception using the `TX_AND_CHECK()` macro.
         *		- If at any point the slave does not acknowledge (ACK), the macro ensures that
         *			the function will block until an ACK is received. Finally, a stop condition
         *			is sent to complete the transaction.
         */
        void i2c_writeData_b(i2c_instance_t *inst, u8 regAddr, u8 *data, u32 length);
        /**
         * @brief Write data with a 16-bit register address over I2C and check rx ack for each transaction.
         * @param inst Pointer to I2C instance.
         * @param regAddr 16-bit register address to write to.
         * @param data Pointer to data buffer to write.
         * @param length Number of bytes to write.
         * @note This function performs a write operation over the I2C bus using a 16-bit register address. 
         *		- It begins by sending the start condition, followed by the slave address with the write bit. 
         *		- Next, it transmits the target register address within the slave.
         *		- Then, it iterates through the provided data buffer, transmitting each byte individually.
         *		- After sending each byte, the function waits for an acknowledgment (ACK) from the slave ,
         *		  device to confirm reception using the `TX_AND_CHECK()` macro.
         *		- If at any point the slave does not acknowledge (ACK), the macro ensures that
         *			the function will block until an ACK is received. Finally, a stop condition
         *			is sent to complete the transaction.
         */
        void i2c_writeData_w(i2c_instance_t *inst, u16 regAddr, u8 *data, u32 length);
        /**
         * @brief Read data with an 8-bit register address over I2C.
         * @param inst Pointer to I2C instance.
         * @param regAddr 8-bit register address to read from.
         * @param data Pointer to data buffer to store read data.
         * @param length Number of bytes to read.
         * @note This function performs a read operation over the I2C bus using an 8-bit
         * 		register address. 
         * 		- It begins by sending the start condition, followed by
         * 		the slave address with the write bit. 
         * 		- Next, it transmits the target register address within the slave. 
         * 		- Then, it sends a repeated start condition followed by the slave address with the read bit. 
         * 		- Finally, it reads the specified number of bytes from the slave into the provided data buffer.
         */
        void i2c_readData_b(i2c_instance_t *inst, u8 regAddr, u8 *data , u32 length);
        /**
         * @brief Read data with a 16-bit register address over I2C.
         * @param inst Pointer to I2C instance.
         * @param regAddr 16-bit register address to read from.
         * @param data Pointer to data buffer to store read data.
         * @param length Number of bytes to read.
         * @note This function performs a read operation over the I2C bus using a 16-bit register address. 
         *			- It begins by sending the start condition, followed by the slave address with the write bit. 
         *			- Next, it transmits the target register address within the slave. 
         *			- Then, it sends a repeated start condition followed by the slave address with the read bit. 
         *			- Finally, it reads the specified number of bytes from the slave into the provided data buffer.
         */
        void i2c_readData_w(i2c_instance_t *inst, u16 regAddr, u8 *data , u32 length);
        /**
         * @brief Set I2C MUX control register.
         * @param inst Pointer to I2C instance.
         * @param cr MUX control register value.
         * @note  This function hardcdeds the I2C address of the multiplexer to 0x71.
         */
        void i2c_setMux(i2c_instance_t *inst, const uint8_t cr);

    /** @} */	//End of I2C Read/Write Functions group

/** @} */	//End of I2C Funcs group
#ifdef __cplusplus
}
#endif // C_plusplus

/** @} */ // End of MAIN I2C Group

#endif // I2C_H
