////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef IRQ_H
#define IRQ_H

/**
 * @file irq.h
 * @author Efinix Inc
 * @brief RISC-V Core Interrupt Handling and Vector Table.
 *
 * This file provides APIs to control the CPU's global interrupt state
 * (MIE bit in mstatus) and individual interrupt sources (mie register).
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "type.h"
#include "riscv.h"
#include "mtrap.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup Core_IRQ IRQ Controller Driver
 * @brief RISC-V CSR Interrupt Management (MIE/MSTATUS).
 * @ingroup intc_group
 * 
 * @section Usage_Core_IRQ Usage & Initialization.
 * @note
 * This module controls the processor's willingness to accept interrupts.
 * It does not configure the external PLIC, but rather the CPU's internal
 * gates for Software, Timer, and External (PLIC) interrupts.
 * 
 * To enable IRQ for <b> external interrupt:</b>
 * - Please refer to @ref uartInterruptDemo.
 * @code
 *	irq_setTrapVector(trap_entry);
 *	irq_setType(IRQ_EXTERNAL);
 *	irq_enable();
 * @endcode
 * 
 * To enable IRQ for <b> Timer interrupt:</b>
 * 
 * - Please refer to @ref userTimerDemo.
 * @code
 *	irq_setTrapVector(trap_entry);
 *	irq_setType(IRQ_TIMER);
 *	irq_enable();
 * @endcode
 * 
 * To enable IRQ for <b> Software interrupt:</b>
 * 
 * - Please refer to @ref clintTimerInterruptDemo.
 * @code
 *	irq_setTrapVector(trap_entry);
 *	irq_setType(IRQ_SOFTWARE);
 *	irq_enable();
 * @endcode
 * 
 * To register a <b> custom IRQ Handler: </b>
 * 
 * - Use @ref irq_registerExt to register a custom handler for a specific PLIC interrupt source.
 * @code
 * int custom_IRQ_handler()
 * {
 *  if (uart_readStatus(&uart0) & 0x00000200){
 * 		//Entering uart rx fifo not empty interrupt routine
 * 		uart_writeStatus(&uart0,uart_readStatus(&uart0) & 0xFFFFFFFD);
 * 		uart_write(&uart0, uart_read(&uart0));
 * 		uart_writeStatus(&uart0,uart_readStatus(&uart0) | 0x02);
 * 		return 1;
 * 	}
 * 	return 0;
 * }
 * 
 * void main() {
 *     irq_registerExt(SYSTEM_UART_0_IO_INTERRUPT, custom_IRQ_handler);
 *     irq_setTrapVector(trap_entry);
 *     irq_setType(IRQ_EXTERNAL);
 *     irq_enable();
 *     uart_setRxInterruptEnable(&uart0, 0x1U);
 * }
 * @endcode
 * 
 * @{
 */

/* ========================================================================== */
/* DATA TYPES                                                                 */
/* ========================================================================== */
/**
 * @defgroup IRQ_Types Data Structures
 * @ingroup Core_IRQ
 * @brief Structs and Enums used by the driver.
 * @{
 */
    /**
     * @brief Standard Interrupt Handler Function Pointer.
     * @return 0 on success, non-zero on error.
     */
    typedef int (*irq_handler_t)(void);

    /**
     * @brief Global Interrupt Vector Table.
     * @note This table resides in RAM (if remapped) to allow dynamic registration 
     * of ISRs. It is typically indexed by the PLIC Interrupt ID.
     */
    extern int (*interrupt_vector_table[64])(void);

    /**
     * @brief CPU Interrupt Type (Standard RISC-V MIE bits).
     * @note These values correspond directly to the bits in the `mie` CSR.
     */
    typedef enum {
        IRQ_SOFTWARE    = MIE_MSIE,  //< Machine Software Interrupt (Bit 3) 
        IRQ_TIMER       = MIE_MTIE,  //< Machine Timer Interrupt (Bit 7) 
        IRQ_EXTERNAL    = MIE_MEIE   //< Machine External Interrupt (PLIC) (Bit 11) 
    } cpu_irq_t;
/** @} */ // End of IRQ_Types

/* ========================================================================== */
/* FUNCTION PROTOTYPES                                                        */
/* ========================================================================== */

/**
 * @defgroup IRQ_Funcs API Functions
 * @ingroup IRQ
 * @brief Function definitions for IRQ driver.
 * @{
 */
    /**
     * @brief Enable Global Interrupts.
     * @details Sets the Machine Interrupt Enable (MIE) bit in the `mstatus` CSR.
     * This acts as the master switch for all interrupts.
     */
    void irq_enable(void);

    /**
     * @brief Disable Global Interrupts.
     * @details Clears the Machine Interrupt Enable (MIE) bit in the `mstatus` CSR.
     * @note This is often used to create critical sections.
     */
    void irq_disable(void);

    /**
     * @brief Enable specific CPU interrupt sources.
     * @details Sets the corresponding bit in the `mie` (Machine Interrupt Enable) CSR.
     * @param enable Bitmask of interrupts to enable (e.g., `IRQ_TIMER | IRQ_EXTERNAL`).
     */
    void irq_setType(cpu_irq_t enable);

    /**
     * @brief Disable specific CPU interrupt sources.
     * @details Clears the corresponding bit in the `mie` CSR.
     * @param disable Bitmask of interrupts to disable.
     */
    void irq_clearType(cpu_irq_t disable);

    /**
     * @brief Register a handler for an External Interrupt (PLIC).
     * @details Writes the function pointer to the software vector table.
     * @param gateway The PLIC Interrupt ID (Source ID) to register.
     * @param handler Pointer to the ISR function.
     */
    void irq_registerExt(u32 gateway, irq_handler_t handler);

    /**
     * @brief Set the Machine Trap Vector (mtvec).
     * @details Configures the address the CPU jumps to when an exception or interrupt occurs.
     * @param trap_vector Function pointer to the assembly trap entry point.
     * @note usually set to `trap_entry` defined in `trap.S`.
     */
    void irq_setTrapVector(void (*trap_vector)(void));
/** @} */ // End of Core_Funcs


#ifdef __cplusplus
}
#endif // C_plusplus

/** @} */ // End of IRQ_Funcs

#endif // IRQ_H