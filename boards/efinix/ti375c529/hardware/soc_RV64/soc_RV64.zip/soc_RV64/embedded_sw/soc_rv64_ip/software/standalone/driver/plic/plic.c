////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/**
* @file plic.c
* @brief PLIC driver implementation.
*
* Implements the functions defined in plic.h for controlling
* PLIC input/output and interrupts on the EfxSapphireSoC platform.
* @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
* See the full @ref license_page for Efinix and SaxonSoc MIT terms.
*/

#include <stdio.h>
#include <stdint.h>
#include "plic/plic.h"


#define PLIC ((plic_hwreg_t *)SYSTEM_PLIC_CTRL)
/**
 * @brief Initialize the PLIC instance with a base address.
 * Calculates the internal pointers for the register blocks.
 * This can called once during system initialization -> BSP_init something like that !!
 */

u32 plic_claimExtIRQ_m()
{
    volatile uintptr_t mhartid = csr_read(mhartid);
    return PLIC->regs_context[mhartid*2].CLAIM;
}

void plic_releaseExtIRQ_m(u32 gateway)
{
    volatile uintptr_t mhartid = csr_read(mhartid);
    PLIC->regs_context[mhartid*2].CLAIM = gateway;
}

void plic_setPriority(plic_instance_t *inst)
{
    PLIC->regs_priority.PRIORITY[inst->gateway] = inst->priority;
}

u32 plic_getPriority(plic_instance_t *inst)
{
    return PLIC->regs_priority.PRIORITY[inst->gateway];
}

void plic_setEnable(plic_instance_t *inst)
{
    u32 group = inst->gateway / 32;
    u32 intr_en = 1 << (inst->gateway % 32);
    u32 current = PLIC->regs_enable[inst->target].ENABLE[group];

    if (inst->enable) {
        PLIC->regs_enable[inst->target].ENABLE[group] = current | intr_en;
    } else {
        PLIC->regs_enable[inst->target].ENABLE[group] = current & ~intr_en;
    }
}

void plic_setThreshold(plic_instance_t *inst)
{
    PLIC->regs_context[inst->target].THRESHOLD = inst->threshold;
}

u32 plic_getThreshold(plic_instance_t *inst)
{
    return PLIC->regs_context[inst->target].THRESHOLD;
}

u32 plic_claim(plic_instance_t *inst)
{
    return PLIC->regs_context[inst->target].CLAIM;
}

void plic_release(plic_instance_t *inst)
{
    PLIC->regs_context[inst->target].CLAIM = inst->gateway;
}

void plic_applyConfig(plic_instance_t *inst)
{
    // 1. Set the threshold for the target context
    plic_setThreshold(inst);
    // 2. Set priority for the specific gateway (Source)
    plic_setPriority(inst);
    // 3. Enable this gateway for the specific target
    plic_setEnable(inst);
}


