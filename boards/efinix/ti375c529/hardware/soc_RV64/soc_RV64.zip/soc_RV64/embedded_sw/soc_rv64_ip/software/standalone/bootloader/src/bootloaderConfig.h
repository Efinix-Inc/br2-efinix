//*------------------------------------------------------------------------------------------
//  MIT License
//  
//  Copyright (c) 2023 SaxonSoc contributors
//  
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//  
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//  
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.
//*-----------------------------------------------------------------------------------------
#pragma once
#include <stdio.h>
#include "bsp.h"
#include "start.h"

// Include driver
#include "spiFlash/spiFlash.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SPI                     (spi_hwreg_t* )SYSTEM_SPI_0_IO_CTRL
#define USER_SOFTWARE_MEMORY    0x0800000000
#define USER_SOFTWARE_FLASH     0x00600000
#define USER_SOFTWARE_SIZE	    0x01F000 //124KB

#define SINGLE_SPI 1 //define DUAL_SPI for dual data SPI or QUAD_SPI for quad data SPI

spiFlash_instance_t Flash = {
  .cs = 0,
  .inst = &(spi_instance_t){
    .hwreg      = SPI,
    .cpol       = LOW,
    .cpha       = DATA_SAMPLED_RISE_EDGE,
    .mode       = FULL_DUPLEX_SINGLE_LINE
},

};

void bspMain() {

#ifndef SIM
    spiFlash_probe(&Flash); // Initialize the flash and read JEDEC ID to verify communication with flash and apply flash specific configuration
#ifdef SINGLE_SPI
    spiFlash_f2m_single(&Flash, USER_SOFTWARE_FLASH, USER_SOFTWARE_MEMORY, USER_SOFTWARE_SIZE); // single data line full duplex
#elif DUAL_SPI 
    spiFlash_f2m_dual(&Flash, USER_SOFTWARE_FLASH, USER_SOFTWARE_MEMORY, USER_SOFTWARE_SIZE); // dual data line half duplex
#elif QUAD_SPI
    spiFlash_f2m_quad(&Flash, USER_SOFTWARE_FLASH, USER_SOFTWARE_MEMORY, USER_SOFTWARE_SIZE); // quad data line half duplex
#else 
    #error "You must either define SINGLE_SPI to use single data line SPI, DUAL_SPI to use dual data line SPI or QUAD_SPI to use quad data line SPI."
#endif
#endif
    void (*userMain)() = (void (*)())USER_SOFTWARE_MEMORY;
    #ifdef SMP
       smp_unlock(userMain);
    #endif
    userMain();
}

#ifdef __cplusplus
}
#endif // C_plusplus
