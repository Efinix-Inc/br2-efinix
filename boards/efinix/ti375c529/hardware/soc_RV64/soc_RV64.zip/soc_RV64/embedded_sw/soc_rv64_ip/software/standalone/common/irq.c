////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/**
 * @file irq.c
 * @author Efinix Inc
 * @brief C implementation for default IRQ handling and vector table management.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include <stdint.h>
#include <stddef.h>
#include "irq.h"


/* ========================================================================== */
/* EXTERNAL INTERRUPT FUNCTIONS (PLIC)                                        */
/* ========================================================================== */

/**
 * @brief Override the default external IRQ handler for a specific gateway.
 * @param gateway The PLIC ID (Gateway ID) to register (0-63).
 * @param handler Function pointer to the ISR.
 * @note This function is used for PLIC (External) interrupts only.
 */
void irq_registerExt(u32 gateway, irq_handler_t handler) 
{
    if (gateway < 64) {
        interrupt_vector_table[gateway] = handler;
    }
}


/* ========================================================================== */
/* CORE INTERRUPT CONTROL (CSR Operations)                                    */
/* ========================================================================== */

/**
 * @brief Set the Machine Trap Vector (mtvec).
 * @param trap_vector Function pointer to the trap entry assembly code.
 * @note Writes to the `mtvec` CSR. Ensure the address is aligned (usually 4-byte).
 */
void irq_setTrapVector(void (*trap_vector)(void))
{
    /* Write direct address to mtvec (MODE bits assumed 0 or handled by caller) */
    csr_write(mtvec, (unsigned long)trap_vector);
}

/**
 * @brief Enable Global Interrupts (MIE bit).
 * @details Sets the MIE bit in the mstatus CSR.
 */
void irq_enable(void)
{
    /* Atomic Set Bit: csrs mstatus, MSTATUS_MIE */
    csr_set(mstatus, MSTATUS_MIE);
}

/**
 * @brief Disable Global Interrupts (MIE bit).
 * @details Clears the MIE bit in the mstatus CSR.
 */
void irq_disable(void)
{
    /* Atomic Clear Bit: csrc mstatus, MSTATUS_MIE */
    csr_clear(mstatus, MSTATUS_MIE);
}

/**
 * @brief Enable specific CPU interrupt sources.
 * @param enable Bitmask of interrupts to enable (e.g., IRQ_TIMER | IRQ_EXTERNAL).
 */
void irq_setType(cpu_irq_t enable)
{
    csr_set(mie, enable);
}

/**
 * @brief Disable specific CPU interrupt sources.
 * @param disable Bitmask of interrupts to disable.
 */
void irq_clearType(cpu_irq_t disable)
{
    csr_clear(mie, disable);
}