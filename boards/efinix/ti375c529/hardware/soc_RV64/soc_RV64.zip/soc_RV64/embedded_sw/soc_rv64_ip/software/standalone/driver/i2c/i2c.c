////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////


/**
* @file i2c.c
* @brief I2C driver implementation.
*
* Implements the functions defined in i2c.h for controlling
* I2C input/output and interrupts on the EfxSapphireSoC platform.
* @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
* See the full @ref license_page for Efinix and SaxonSoc MIT terms.
*/

#include "i2c/i2c.h"

/*----------------------------------------------------------------------------*/
/* Function implementations                                                    */
/*----------------------------------------------------------------------------*/

u32 i2c_getInterruptFlag (i2c_instance_t *inst)
{
	return inst->hwreg->INTERRUPT_CLEAR;
}

u32 i2c_getInterruptEnable (i2c_instance_t *inst)
{
	return inst->hwreg->INTERRUPT;
}

u32 i2c_getMasterStatus(i2c_instance_t *inst)
{
	return inst->hwreg->MASTER_STATUS;
}

u32 i2c_getFilteringHit(i2c_instance_t *inst)
{
	return inst->hwreg->HIT_CONTEXT;
}

u32 i2c_getFilteringStatus(i2c_instance_t *inst)
{
	return inst->hwreg->FILTER_STATUS;
}

u32 i2c_getSlaveStatus(i2c_instance_t *inst)
{
	return inst->hwreg->SLAVE_STATUS;
}

u32 i2c_getSlaveOverride(i2c_instance_t *inst)
{
    return inst->hwreg->SLAVE_OVERRIDE;
}

u32 i2c_getRxData(i2c_instance_t *inst)
{
	return inst->hwreg->RX_DATA & I2C_RX_VALUE;
}

u32 i2c_getRxNack(i2c_instance_t *inst)
{
	return (inst->hwreg->RX_ACK & I2C_RX_VALUE) != 0;
}

u32 i2c_getRxAck(i2c_instance_t *inst)
{
	return (inst->hwreg->RX_ACK & I2C_RX_VALUE) == 0;
}

void i2c_setSlaveOverride(i2c_instance_t *inst, u32 value)
{
	inst->hwreg->SLAVE_OVERRIDE = value;
}

void i2c_setFilterConfig(i2c_instance_t *inst, u32 filterId, u32 value)
{
	inst->hwreg->FILTER[filterId].FILTER_CONFIG_0 = value;
}

void i2c_applyConfig(i2c_instance_t *inst)
{
	inst->hwreg->SAMPLING_CLOCK_DIVIDER = inst->samplingClockDivider;
	inst->hwreg->TIMEOUT = inst->timeout;
	inst->hwreg->TSU_DATA = inst->tsuDat;
	inst->hwreg->tLOW = inst->tLow;
	inst->hwreg->tHIGH = inst->tHigh;
	inst->hwreg->tBUF = inst->tBuf;
}

void i2c_startMaster(i2c_instance_t *inst)
{
	inst->hwreg->MASTER_STATUS = I2C_MASTER_START | I2C_MASTER_START_DROPPED;
}

void i2c_restartMaster(i2c_instance_t *inst)
{
	i2c_startMaster(inst);
}

void i2c_recoverMaster(i2c_instance_t *inst)
{
	inst->hwreg->MASTER_STATUS = I2C_MASTER_RECOVER | I2C_MASTER_RECOVER_DROPPED;
}

u32 i2c_checkMasterBusy(i2c_instance_t *inst)
{
	return (inst->hwreg->MASTER_STATUS & I2C_MASTER_BUSY) !=0 ;
}

void i2c_startMasterBlocking(i2c_instance_t *inst)
{
	i2c_startMaster(inst);
	while(i2c_getMasterStatus(inst) & I2C_MASTER_START);
}

void i2c_restartMasterBlocking(i2c_instance_t *inst)
{
	i2c_startMasterBlocking(inst);
}

void i2c_stopMaster(i2c_instance_t *inst)
{
	inst->hwreg->MASTER_STATUS = I2C_MASTER_STOP | I2C_MASTER_STOP_DROPPED;
}

void i2c_stopMasterBlocking(i2c_instance_t *inst)
{
	i2c_stopMaster(inst);
    while(i2c_checkMasterBusy(inst));
}

void i2c_dropMaster(i2c_instance_t *inst)
{
	inst->hwreg->MASTER_STATUS = I2C_MASTER_DROP;
}

void i2c_recoverMasterBlocking(i2c_instance_t *inst)
{
	for(int i = 0;i < 3;i++){
		i2c_recoverMaster(inst);
		while(i2c_getMasterStatus(inst) & I2C_MASTER_RECOVER);
		if((i2c_getMasterStatus(inst) & I2C_MASTER_RECOVER_DROPPED) == 0){
			break;
		}
	}
}

void i2c_listenAck(i2c_instance_t *inst)
{
	inst->hwreg->RX_ACK = I2C_RX_LISTEN ;
}

void i2c_sendNackBlocking(i2c_instance_t *inst)
{
	i2c_sendTxNack(inst);
	i2c_waitTxAck(inst);
}

void i2c_sendAckBlocking(i2c_instance_t *inst)
{
	i2c_sendTxAck(inst);
	i2c_waitTxAck(inst);
}

void i2c_sendTxByteRepeat(i2c_instance_t *inst,u8 byte)
{
	inst->hwreg->TX_DATA = byte | I2C_TX_VALID | I2C_TX_ENABLE | I2C_TX_DISABLE_ON_DATA_CONFLICT | I2C_TX_REPEAT; 
}      

void i2c_sendTxNackRepeat(i2c_instance_t *inst)
{
	inst->hwreg->TX_ACK = 1 | I2C_TX_VALID | I2C_TX_ENABLE | I2C_TX_REPEAT;
}

void i2c_sendTxByte(i2c_instance_t *inst,u8 byte)
{
	inst->hwreg->TX_DATA = byte | I2C_TX_VALID | I2C_TX_ENABLE | I2C_TX_DISABLE_ON_DATA_CONFLICT;
}

void i2c_sendTxAck(i2c_instance_t *inst)
{
	inst->hwreg->TX_ACK = I2C_TX_VALID | I2C_TX_ENABLE;
}

void i2c_sendTxNack(i2c_instance_t *inst)
{
	inst->hwreg->TX_ACK = 1 | I2C_TX_VALID | I2C_TX_ENABLE;
}

void i2c_waitTxAck(i2c_instance_t *inst)
{
	while(inst->hwreg->TX_ACK & I2C_TX_VALID);
}

void i2c_waitRxAck(i2c_instance_t *inst)
{
	while((inst->hwreg->RX_ACK & I2C_RX_VALUE) != 0);
}


void i2c_enableFilter(i2c_instance_t *inst, u32 filterId, u32 config)
{
	inst->hwreg->FILTER[filterId].FILTER_CONFIG_0 = config;
}

void i2c_disableInterrupt(i2c_instance_t *inst, i2c_interrupt_t value)
{
	inst->hwreg->INTERRUPT &= ~value ;
}

void i2c_enableInterrupt(i2c_instance_t *inst, i2c_interrupt_t value)
{
	inst->hwreg->INTERRUPT |= value;
}

void i2c_clearInterruptFlag(i2c_instance_t *inst, i2c_interrupt_t value)
{
	inst->hwreg->INTERRUPT_CLEAR = value;
}

void i2c_writeData_b(i2c_instance_t *inst, u8 regAddr, u8 *data, u32 length) {
    
    // Send Start Sequence
    i2c_startMasterBlocking(inst);
    // Send Slave Address (Write Mode)
    TX_AND_CHECK(inst, inst->slaveAddress | I2C_WRITE);
    // Send Register Address (8-bit)
    TX_AND_CHECK(inst, (regAddr & 0xFF));
    // Send Data Bytes
    // Note: In Write mode, we treat all bytes the same (Slave ACKs all of them)
    for (u32 i = 0; i < length; i++) {
        TX_AND_CHECK(inst, data[i]);
    }
    // Send Stop Sequence
    i2c_stopMasterBlocking(inst);
}

void i2c_writeData_w(i2c_instance_t *inst, u16 regAddr, u8 *data, u32 length) {
    // Send Start Sequence
    i2c_startMasterBlocking(inst);
    // Send Slave Address (Write Mode)
    TX_AND_CHECK(inst, inst->slaveAddress | I2C_WRITE);
    // Send Register Address High Byte (MSB)
    TX_AND_CHECK(inst, (regAddr >> 8) & 0xFF);
    // Send Register Address Low Byte (LSB)
    TX_AND_CHECK(inst, (regAddr >> 0) & 0xFF);
    // Send Data Bytes
    for (u32 i = 0; i < length; i++) {
        TX_AND_CHECK(inst, data[i]);
    }
    // Send Stop Sequence
    i2c_stopMasterBlocking(inst);
}

void i2c_readData_b(i2c_instance_t *inst, u8 regAddr, u8 *data, u32 length) {
    // Send Start Sequence
    i2c_startMasterBlocking(inst);
    // Send Slave Address (Write Mode)
    TX_AND_CHECK(inst, inst->slaveAddress | I2C_WRITE);
    // Send Register Address
    TX_AND_CHECK(inst, (regAddr & 0xFF));
    // Send Restart Sequence
    i2c_restartMasterBlocking(inst);
    // Send Slave Address (Read Mode)
    TX_AND_CHECK(inst, inst->slaveAddress | I2C_READ);
    // Read Loop (Length > 1)
    if (length > 1) {
        for (int i = 0; i < length - 1; i++) {
            i2c_sendTxByte(inst, 0xFF);       // Release SDA
            i2c_sendAckBlocking(inst);      // Send ACK to request next byte
            data[i] = i2c_getRxData(inst);   // Read Data
        }
    }
    // Read Last Byte
    i2c_sendTxByte(inst, 0xFF);               // Release SDA
    i2c_sendNackBlocking(inst);             // Send NACK to stop slave transmission
    data[length - 1] = i2c_getRxData(inst);  // Read Last Data
    // Send Stop Sequence
    i2c_stopMasterBlocking(inst);
}

void i2c_readData_w(i2c_instance_t *inst, u16 regAddr, u8 *data, u32 length) {
    // Send Start Sequence
    i2c_startMasterBlocking(inst);
    // Send Slave Address (Write Mode)
    TX_AND_CHECK(inst, inst->slaveAddress | I2C_WRITE);
    // Send Register Address (High Byte)
    TX_AND_CHECK(inst, ((regAddr >> 8) & 0xFF));
    // Send Register Address (Low Byte)
    TX_AND_CHECK(inst, ((regAddr >> 0) & 0xFF));
    // Send Restart Sequence
    i2c_restartMasterBlocking(inst);
    // Send Slave Address (Read Mode)
    TX_AND_CHECK(inst, inst->slaveAddress | I2C_READ);
    // Read Loop (Length > 1)
    if (length > 1) {
        for (int i = 0; i < length - 1; i++) {
            i2c_sendTxByte(inst, 0xFF);       // Release SDA
            i2c_sendAckBlocking(inst);      // Send ACK to request next byte
            data[i] = i2c_getRxData(inst);   // Read Data
        }
    }
    // Read Last Byte
    i2c_sendTxByte(inst, 0xFF);               // Release SDA
    i2c_sendNackBlocking(inst);             // Send NACK to stop slave transmission
    data[length - 1] = i2c_getRxData(inst);  // Read Last Data
    // Send Stop Sequence
    i2c_stopMasterBlocking(inst);
}

void i2c_setMux(i2c_instance_t *inst, const uint8_t cr)
{
	// u8 outdata;

	i2c_startMasterBlocking(inst);
	i2c_sendTxByte(inst, (0x71<<1)); //Hardcoded to 0x71 Mux for now!
	i2c_sendNackBlocking(inst);
	// assert(i2c_getRxAck(inst)); // Optional check

	i2c_sendTxByte(inst, cr);
	i2c_sendNackBlocking(inst);
	// assert(i2c_getRxAck(inst)); // Optional check

	i2c_stopMasterBlocking(inst);
}