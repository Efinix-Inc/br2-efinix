////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/**
 * @file spiFlash_list.c
 * @author Efinix Inc
 * @brief SPI Flash Device Database Implementation.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "spiFlash/spiFlash_list.h"

/** 
 * @brief Internal table of factory-supported SPI Flash devices.
 * @details This list contains JEDEC IDs and quirk flags for common chips.
 */
const spiFlash_info_t known_flash[] = {

    /* ======================================================================
     * 16MB or Smaller (Standard 3-Byte Addressing)
     * ====================================================================== */
    {
        // T120F576, T120F324
        .part_no        = "W25Q128JVSIQ",
        .jedec_id       = JEDEC_ID_W25Q128JVSIQ,
        .flags          = PROFILE_WINBOND_128,
        .post_init_hook = NULL, 
    },
    {
        // Ti60F225
        .part_no        = "W25Q64JWSSIQ",
        .jedec_id       = JEDEC_ID_W25Q64JWSSIQ,
        .flags          = PROFILE_WINBOND_64,
        .post_init_hook = NULL,
    },

    /* ======================================================================
     * Larger than 16MB (Requires 4-Byte Addressing)
     * ====================================================================== */
    {
        // Ti180J484
        .part_no        = "MX25U25645GZ4I00",
        .jedec_id       = JEDEC_ID_MX25U25645GZ4I00,
        .flags          = PROFILE_MACRONIX_LARGE,
        .post_init_hook = NULL, 
    },
    {
        // Ti375C529
        .part_no        = "IS25WP512M-JLLA3",
        .jedec_id       = JEDEC_ID_IS25WP512M,
        .flags          = PROFILE_ISSI_LARGE,
        .post_init_hook = NULL,
    },
    {
        // Ti375N1156
        .part_no        = "GD25LB512MEYIGR",
        .jedec_id       = JEDEC_ID_GD25LB512MEYIGR,
        .flags          = PROFILE_GIGA_LARGE,
        .post_init_hook = NULL,
    }
};