////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/******************************************************************************
*
* @file main.c: watchdogDemo
*
* @brief This demo shows how to use watchdogTimer.
*
******************************************************************************/
#include <stdio.h>
#include "bsp.h"
#include "irq.h"
#include "userDef.h"

// Include driver
#include "watchdog/watchdog.h"

#ifdef SYSTEM_WATCHDOG_CTRL

extern void trap_entry();
void patWatchdog();
void wdg_isr_init();

u32 softPanicCounter = 0;
u32 software_gone_wrong = 0;
u32 random_x = 3;
u32 random_y = 3;

/******************************************************************************
*
* @brief This struct configure WATCHDOG
*
******************************************************************************/
watchdog_instance_t wdg_0 = {
    // Hardware Register Map
    .hwreg 			= WDG_0,
    // Enable counter 0 to trigger first (interrupt)
    // Enable counter 1 to trigger the hardware reset of the SoC (Handled outside the SoC)
    .enable 		= {0x1U, 0x1U},
    .prescaler 		= WATCHDOG_PRESCALER_CYCLE_PER_MS-1,
    .counterLimit 	= {WATCHDOG_TIMEOUT_MS, 2*WATCHDOG_TIMEOUT_MS},
    // Heartbeat Config: WDG_TIMER_CLEAR, WDG_TIMER_UNLOCK , WDG_TIMER_LOCK
    .heartbeat 		= 0x0U,
};

/******************************************************************************
*
* @brief This WATCHDOG IRQ handle interupt subroutine task.
*
******************************************************************************/
int irq_m_watchDog0_handler(){

    softPanicCounter += 1;
    if(softPanicCounter > random_y){
        printf("Soft panic count=%d \nstop pat the watchdog this time and watchdog will reset system after %ds ..\n\n", softPanicCounter, WATCHDOG_TIMEOUT_MS/1000);
        while(1);
    }
    // Here your software can recover.
    patWatchdog();
    software_gone_wrong = 0;

    printf("Soft panic count=%d \n", softPanicCounter);
    return 0;
}

/******************************************************************************
*
* @brief This struct configure WATCHDOG related interrupt,trap,init
*
******************************************************************************/
void wdg_isr_init(){

    plic_instance_t wdg_plic = {
        // Set Target to handler external interrupt
        .target 	= BSP_PLIC_CPU_0,
        // Interrupt source ID
        .gateway 	= SYSTEM_WATCHDOG_INTERRUPTS_0,
        // Priority Level: 0=Disable, 1=Low, 3=Highest
        .priority   = 0x1U, 
        // Interrupt Enable Bit (1=Enable)
        .enable     = 0x1U, 
        // Threshold: CPU accepts any priority > 0
        .threshold  = 0x0U,
    };

    // Apply Config for PLIC & WDG setting
    plic_applyConfig(&wdg_plic);
    watchdog_applyConfig(&wdg_0);

    // Initialize IRQ Sequence
    irq_setTrapVector(trap_entry);
    irq_setType(IRQ_EXTERNAL);
    irq_enable();
}

/******************************************************************************
*
* @brief This function is used to reset WATCHDOG timer.
*
******************************************************************************/
void patWatchdog(){
    printf("Pat the watchdog .. \n");
    watchdog_clear(&wdg_0); // This will clear all the timeout counters and the soft panic
}

/******************************************************************************
*
* @brief Main event for watchdogTimerDemo.
*
******************************************************************************/
void main() {
    bsp_init();
    printf(ANSI_RESET "***Starting WatchDog Timer Demo***\n");
    bsp_uDelay(1000);
    wdg_isr_init();
    printf("Watchdog timer timeout = %ds .. \n", WATCHDOG_TIMEOUT_MS/1000);
    printf("Pat the watchdog every %dms for %d times then wait for soft panic trigger .. \n", WAIT_TIME_MS, random_x);
    printf("Watchdog patting will stop after %d soft panic trigger.. \n\n", random_y);

    while(1){
        for(u32 i=0; i<random_x; i++){
            bsp_uDelay(WAIT_TIME_MS*1000);
            patWatchdog();
        }

        software_gone_wrong = 1;
        while(software_gone_wrong == 1){
            bsp_uDelay(1000*1000);
            printf("Assume software gone wrong here .. \n");
        };
        printf("\n");
    }; //Idle
}
#else
void main() {
   bsp_init();
   printf(ANSI_RED "\n[ERR] Watchdog is disabled, please enable it to run this app. \n"ANSI_RESET);
}
#endif
