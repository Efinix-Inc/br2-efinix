////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef PLIC_H
#define PLIC_H

/**
 * @file plic.h
 * @author Efinix Inc
 * @brief PLIC driver API definitions.
 *
 * This file provides data structures and APIs for controlling
 * the plic peripheral on the EfxSapphireSoC platform.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "type.h"
#include "soc.h"
#include "riscv.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup PLIC PLIC Controller Driver
 * @brief Platform-Level Interrupt Controller (PLIC) driver.
 * @ingroup intc_group
 *
 * This module provides functions to configure and control
 * PLIC input/output and interrupt behavior.
 * @section Example_PLIC Usage & Initialization.
 * 
 * This is an example show how to instantiate @ref PLIC for interrupt configuration.
 * 
 * To set interrupt type and enable global interrupt, refer to @ref Core_IRQ.
 * 
 * @code
 * #include "timer/timer.h"
 * #include "irq.h"
 * 
 * plic_instance_t timer0_plic = {
 * 	// Configure the interrupt source
 * 	.target    = BSP_PLIC_CPU_0,
 * 	.gateway   = SYSTEM_USER_TIMER_0_INTERRUPTS_0,
 * 	.priority  = 0x1U,
 * 	.enable    = 0x1U,
 * 	.threshold = 0x0U,
 * };
 * 
 * void isrInit(){
 *	plic_applyConfig(&timer0_plic);
 *	irq_setType(IRQ_EXTERNAL);
 *	irq_enable();
 *}
 * @endcode
 * @{
 */

/* ========================================================================== */
/* SUB-GROUP : DATA STRUCTS                                          			*/
/* ========================================================================== */

/**
 * @defgroup PLIC_Types Data Structures
 * @ingroup PLIC
 * @brief Structs used by the driver.
 * @note
 * <b> This is an example show how to instantiate PLIC with @ref plic_instance_t 
 * and @ref plic_hwreg_t.
 * 
 * @code 
 *	plic_instance_t wdg_plic = {
 *		.target 	= BSP_PLIC_CPU_0,
 *		.gateway 	= WATCHDOG_SOFT_PANIC_INTERRUPT,
 *		.priority   = 0x1U, 
 *		.enable     = 0x1U, 
 *		.threshold  = 0x0U,
 *	};
 *
 *	// Apply Config for PLIC & WDG setting
 *	plic_applyConfig(&wdg_plic);
 *
 * @endcode
 * @{
 */

        /** @brief Priority Block: 1024 sources max (Offset 0x000000) */
        typedef struct {
            volatile u32 PRIORITY[1024];  ///< The interrupt priority for each interrupt source.
        } plic_priority_block_t;

        /** @brief Pending Block: 1024 sources / 32 bits = 32 words (Offset 0x001000) */
        typedef struct {
            volatile u32 PENDING[32]; ///<  The interrupt pending status of each interrupt source.
        } plic_pending_block_t;

        /** @brief Enable Block: Per Target (Hart). Stride is 0x80 bytes (Offset 0x002000) */
        typedef struct {
            volatile u32 ENABLE[32];  ///< Enables the interrupt source of each context.
        } plic_enable_block_t;

        /** @brief Context Block: Per Target (Hart). Stride is 0x1000 (4096) bytes (Offset 0x200000) */
        typedef struct {
            volatile u32 THRESHOLD;		/// < Addressing offset: 0x00
            volatile u32 CLAIM;			/// < Addressing offset: 0x04
            u32			RESERVED[1022];	/// < Padding to reach 0x1000 stride
        } plic_context_block_t;

    /**
     * @brief PLIC hardware register map.
     * @note This is the main structure that maps directly onto the PLIC peripheral
     *       memory-mapped register layout.
     */
        typedef struct {
            plic_priority_block_t	regs_priority;					///< Address Offset: 0x00				
            plic_pending_block_t	regs_pending;					///< Address Offset: 0x1000
            u32 					reserved0[0x1000U/4U-0x20U];	///< Address Offset: 0x1080
            plic_enable_block_t		regs_enable[8U];				///< Address Offset: 0x2000
            u32						reserved1[(0x00200000 - 0x00002400)/4U]; ///< Address Offset: 0x2020
            plic_context_block_t	regs_context[8U]; ///< Address Offset: 0x200000 
        } plic_hwreg_t;

    /**
     * @brief PLIC instance.
     * Holds the software registers and hardware pointer.
     * @note This structure holds configuration values to be applied to the hardware.
     *  	 - **target:** Set Target to handler external interrupt.
      * 		 - **gateaway:** Interrupt source ID.
      * 		 - **priorty:** Priority Level: 0=Disable, 1=Low, 3=Highest
      * 		 - **enable:** Interrupt Enable Bit (1=Enable)
      * 		 - **threshold:** CPU accepts any priority > 0
     */
        typedef struct {
            u32 target;			///< Set Target to handler external interrupt.
            u32 gateway;		///< Interrupt source ID.
            u32 priority;		///< Priority Level: 0=Disable, 1=Low, 3=Highest
            u32 enable;			///< Interrupt Enable Bit (1=Enable)
            u32 threshold;		///< CPU accepts any priority > 0
        }plic_instance_t;

/** @} */ // End of PLIC_Types group

/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup PLIC_Funcs API Functions
 * @ingroup PLIC
 * @brief Function definitions for PLIC driver.
 * @{
 */
    /**
     * @brief Apply stored PLIC configuration to hardware.
     * @param inst Pointer to PLIC instance.
     * @note Call this function after making any changes to the @ref plic_instance_t
     *       structure to apply those changes to the hardware.
     */
    void plic_applyConfig(plic_instance_t *inst);
    /**
     * @brief Claim ID source from external IRQ
     * @param inst Pointer to PLIC instance.
     * @return ID source that triggered external IRQ.
     */
    u32 plic_claimExtIRQ_m();
    /**
     * @brief Release ID source from external IRQ
     * @param inst Pointer to PLIC instance.
     */
    void plic_releaseExtIRQ_m(u32 gateway);

    /** @name PLIC (Get Functions)
     * Read values from the PLIC hardware registers.
     * @{
     */
        /**
         * @brief Read value from PLIC register.
         * @param inst Pointer to PLIC instance.
         * @return Value of the threshold.
         */
        u32 plic_getThreshold(plic_instance_t *inst);
        /**
         * @brief Read value from PLIC register.
         * @param inst Pointer to PLIC instance.
         * @return Value of the priority.
         */
        u32 plic_getPriority(plic_instance_t *inst);	

    /** @} */

    /** @name PLIC (Set Functions)
     * Set values to the PLIC hardware registers.
     * @{
     */
        /**
         * @brief Set priority value to PLIC register.
         * @param inst Pointer to PLIC instance.
         */
        void plic_setPriority(plic_instance_t *inst);
        /**
         * @brief Set enable value to PLIC register.
         * @param inst Pointer to PLIC instance.
         */
        void plic_setEnable(plic_instance_t *inst);
        /**
         * @brief Set threshold value to PLIC register.
         * @param inst Pointer to PLIC instance.
         */
        void plic_setThreshold(plic_instance_t *inst);

    /** @} */

/** @} */ // End of PLIC_Funcs group

#ifdef __cplusplus
}
#endif

/** @} */ // End of MAIN PLIC Group

#endif // PLIC_H

