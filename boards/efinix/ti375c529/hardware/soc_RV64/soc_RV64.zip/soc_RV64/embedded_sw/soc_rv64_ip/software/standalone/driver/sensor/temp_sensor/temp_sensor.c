////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/**
* @file temp_sensor.c
* @brief Temperature Sensor driver implementation.
*
* Implements the functions defined in temp_sensor.h for controlling
* Temperature Sensor input/output and interrupts on the EfxSapphireSoC platform.
* @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
* See the full @ref license_page for Efinix and SaxonSoc MIT terms.
*/

#include "sensor/temp_sensor/temp_sensor.h"
#include <stddef.h>
/* -----------------------------------------------------------------------------*/
/*  Common API: Helper                                   	 	
/* -----------------------------------------------------------------------------*/
temp_sensor_status_t tempSensor_applyConfig(temp_sensor_instance_t *temp) {
    
    if (temp != NULL && temp->drv != NULL && temp->drv->applyConfig != NULL) {
        
        return temp->drv->applyConfig(temp);
    }
    
    return TEMP_SENSOR_ERR; 
}

temp_sensor_status_t tempSensor_enableErrorInterrupt(temp_sensor_instance_t *temp) {

    if (temp != NULL && temp->drv != NULL && temp->drv->enableErrorInterrupt != NULL) {
        return temp->drv->enableErrorInterrupt(temp);
    }
    return TEMP_SENSOR_ERR;
}

u8 tempSensor_readTempReg(temp_sensor_instance_t *temp, const u8 reg)
{
    u8 data = 0;
    if (temp && temp->inst) {
        i2c_setMux(temp->inst, 0x0F);
        i2c_readData_b(temp->inst, reg, &data, 1);
    }
    return data;
}

u8 tempSensor_writeTempReg(temp_sensor_instance_t *temp, const u8 reg, const u8 data)
{
    if (temp && temp->inst) {
        i2c_setMux(temp->inst, 0x0F); 
        i2c_writeData_b(temp->inst, reg, (u8*)&data, 1);
        return TEMP_SENSOR_OK;
    }
    return TEMP_SENSOR_SKIP;
}

float tempSensor_calTempCelsius(u8 hb, u8 lb, u8 is_extended) {
    int16_t integer_part = hb;

    // Apply Offset (Extended: -64 to 191)
    if (is_extended) {
        integer_part -= 64;
    }

    // Calculate Fractional Part (0.125 steps)
    float fractional = (lb >> 5) * 0.125f;
    return (float)integer_part + fractional;
}

u8 tempSensor_encodeTempLimit(float val, u8 is_extended, u8 *out_hb, u8 *out_lb) {
    // Handle Offset
    if (is_extended) {
        val += 64.0f;
    }

    // Extract Integer Part
    int integer_part = (int)val;
    if (integer_part < 0) integer_part = 0;     // Clamp min
    if (integer_part > 255) integer_part = 255; // Clamp max
    *out_hb = (u8)integer_part;

    // Extract Fractional Part
    float fraction = val - integer_part;
    if (fraction < 0) fraction = 0;
    u8 frac_bits = (u8)(fraction * 8.0f);
    *out_lb = (frac_bits << 5); 
    return TEMP_SENSOR_OK;
}
