////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef CLINT_H
#define CLINT_H


/**
 * @file clint.h
 * @author Efinix Inc
 * @brief CLINT driver API definitions.
 *
 * This file provides data structures and APIs for controlling
 * the CLINT peripheral on the EfxSapphireSoC platform.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "type.h"
#include "soc.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup CLINT Clint Timer Driver
 * @brief Core Local Interruptor (CLINT) driver.
 * @ingroup System
 *
 * This module provides functions to configure and control
 * CLINT input/output and interrupt behavior.
 * @section Example_CLINT Usage & Initialization.
 * This is an example show how to utilize @ref CLINT_Funcs and enable <b> software interrupt </b> using @ref Core_IRQ.
 * 
 * @code 
 * #include "irq.h"
 * 
 * int irq_handleTimer(){
 * 	static uint32_t counter = 0;
 * 	timerCmp += TIMER_TICK_DELAY;
 * 	clint_setCmp(timerCmp, 0);
 * 	printf(ANSI_YELLOW "Timer Interrupt Triggered!\n" ANSI_RESET);
 * 	return 1;
 * }
 * 
 * void isrInit(){
 * 	// Configure timer
 * 	initTimer();
 * 	clint_setSoftInterrupt(MSIP_ENABLE,0);
 * 	irq_setTrapVector(trap_entry);
 * 	irq_setType(IRQ_TIMER);
 * 	irq_enable();
 * 
 * }
 * @endcode
 * This is an example show how to utilize @ref CLINT_Funcs and enable <b> timer interrupt </b> using @ref Core_IRQ.
 * 
 * @code 
 * #include "irq.h"
 * 
 * int irq_handleTimer(){
 * 	static uint32_t counter = 0;
 * 	timerCmp += TIMER_TICK_DELAY;
 * 	clint_setCmp(timerCmp, 0);
 * 	printf(ANSI_YELLOW "Timer Interrupt Triggered!\n" ANSI_RESET);
 * 	return 1;
 * }
 * 
 * 
 * void isrInit(){
 * 	// Configure timer
 * 	initTimer();
 * 	clint_setSoftInterrupt(MSIP_ENABLE,0);
 * 	irq_setTrapVector(trap_entry);
 * 	irq_setType(IRQ_TIMER);
 * 	irq_enable();
 * 
 * }
 * @endcode
 * @see @ref clintTimerInterruptDemo "Example CLINT Timer Interrupt Demo" - Learn how to use the driver for timer interrupt operations
 * @{
 */

/* ========================================================================== */
/* SUB-GROUP : Data Types			                                         */
/* ========================================================================== */

    /**
     * @defgroup CLINT_ENUM Data Types
     * @ingroup CLINT
     * @brief Enums used by the driver.
     * @{
     */

    typedef enum {
        MSIP_DISABLE    = 0, 	///< Disable Software Interrupt */
        MSIP_ENABLE     = 1		///< Enable Software Interrupt */
    } clint_msip_t;

    /** @} */

/* ========================================================================== */
/* SUB-GROUP : DATA STRUCTS                                          			*/
/* ========================================================================== */
/**
 * @defgroup CLINT_Types Data Structures
 * @ingroup CLINT
 * @brief Structs and Enums used by the driver.
 * @note User are allowed to use CLINT API directly without instantiate CLINT by 
 * pointing it to @ref clint_hwreg_t.
 * @see clint.c
 * @{
 */

    /**
     * @brief CLINT MTIMECMP hardware register map.
     */
    typedef volatile struct 
    {
        u32 MTIMECMP_LOW; 	///< Offset: 0x00, MTIMECMP Low */
        u32 MTIMECMP_HIGH;	///< Offset: 0x04, MTIMECMP High */

    } clint_mtimecmp_hwreg_t;

    /**
     * @brief CLINT hardware register map.
     */
    typedef volatile struct 
    {
        u32          			MSIP[SYSTEM_NUMBER_OF_HARTS]; 						///< Offset: 0x0000, Software Interrupt Pending for each hart 	
        u32             		reserved0[(0x4000 - 4*SYSTEM_NUMBER_OF_HARTS)/4U];	///< Reserved Space (0x0C to 0x3FFF) 
        clint_mtimecmp_hwreg_t 	MTIMECMP[SYSTEM_NUMBER_OF_HARTS];  					///< Offset: 0x4000, MTIMECMP for each hart 
        u32             		reserved1[(0xBFF8U - 0x4000 - 8*SYSTEM_NUMBER_OF_HARTS)/4U];	///< Reserved Space (0x4000 to 0xBFF7) 
        u32            			MTIME_LOW;								///< Offset: 0xBFF8, MTIME Low 
        u32            			MTIME_HIGH;								///< Offset: 0xBFFC, MTIME High 

    } clint_hwreg_t;

/** @} */ // End of CLINT_Types group


/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup CLINT_Funcs API Functions
 * @ingroup CLINT
 * @brief Function definitions for CLINT driver.
 * @{
 */

    /**
    * @brief   This function introduces a microsecond delay using the CLINT TIME register.
    *
    * @param   usec is the delay time in microseconds.
    * @param   hz is the frequency of the timer in Hz.
    *
    * @note    The function calculates the number of machine cycles per microsecond
    *          based on the given timer frequency 'hz'. It then calculates the time
    *          limit by adding the delay 'usec' in microseconds to the current time
    *          obtained from the CLINT TIME register. The function enters a loop,
    *          continuously checking if the difference between the current time
    *          and the time limit is non-negative, indicating that the delay has
    *          not yet elapsed.
    */
    void clint_uDelay(u32 usec, u32 hz);

    /** @name CLINT (Get Functions)
     * Retrieve value from CLINT register.
     * @{
    */
        /**
         * @brief Get the time difference between t0 and t1.
         * @param t0 Time 1
         * @param t1 Time 2
         * @return Time Difference between t0 and t1.
         */
        double clint_getTimeDiff(u64 t0, u64 t1);
        /**
         * @brief Reads the current time value from the CLINT TIME register.
         * @return The current time as a 64-bit unsigned integer.
         *
         * The function reads the high and low 32-bit parts of the CLINT TIME register
         * in a loop to ensure a consistent snapshot of the time value. It first reads
         * the high part, then the low part, and finally checks if the high part has
         * changed during the read. If it has changed, it repeats the process until
         * a consistent value is obtained. The final 64-bit time value is constructed
         * by combining the high and low parts.
         */
        u64 clint_getTime();

        /**
        * @brief Reads the low part of the current time.
        * @note Reads a 32-bit unsigned integer value from the CLINT TIME register.
        */
        u32 clint_getTimeLow();

        /**
        * @brief Reads the high part of the current time.
        * @note Reads a 32-bit unsigned integer value from the CLINT TIME register 
        * offset by 4 bytes (representing the high part).
        */
        u32 clint_getTimeHigh();
        /**
         * @brief Obtain the current state of the software interrupt for a specific hart.
         * @param hart_id The ID of the hart for which to read the software interrupt state
         */
        u32 clint_getSoftInterrupt(u32 hart_id);
    /** @} */ //End of CLINT Get Functions group

    /** @name CLINT (Set Functions)
     * Set value to CLINT register.
     * @{
    */

        /** 
        * @brief  This function sets the compare value for the CLINT CMP register for a specific hardware thread.
        * @param   cmp is the 64-bit compare value to be set in the CMP register.
        * @param   hart_id is the ID of the hardware thread for which the compare value
        *          is being set.
        * @note    The function calculates the address offset for the CMP register
        *          associated with the specified hardware thread and writes the lower
        *          32 bits of the compare value to the lower 32 bits of the CMP register,
        *          the upper 32 bits of the compare value to the upper 32 bits of the CMP
        *          register, and sets the lower 32 bits to all 1s (0xFFFFFFFF) to ensure the compare
        *          value is treated as an absolute value.
        */
        void clint_setCmp(u64 cmp, u32 hart_id);
        /**
         * @brief Sets the software interrupt state for a specific hart.
         * @param enable The desired state of the software interrupt (enable or disable).
         * @param hart_id The ID of the hart for which to set the software interrupt state.
         */
        void clint_setSoftInterrupt(clint_msip_t enable, u32 hart_id);
    /** @} */ //End of CLINT Set Functions group

/** @} */ // End of CLINT_Funcs group

#ifdef __cplusplus
}
#endif

/** @} */ // End of MAIN CLINT Group

#endif // CLINT_H



