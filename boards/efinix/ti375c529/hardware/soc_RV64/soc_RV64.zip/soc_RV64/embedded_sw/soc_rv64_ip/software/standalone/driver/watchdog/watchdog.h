////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef WATCHDOG_H
#define WATCHDOG_H

/**
 * @file watchdog.h
 * @author Efinix Inc
 * @brief Watchdog driver API definitions.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.*
 */

#include "type.h"
#include "soc.h"
#include "riscv.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup WatchDog WatchDog Timer Driver
 * @brief Watchdog driver API definitions.
 * @ingroup timer_group
 * 
 * @details The watchdog hardware is designed as following :
 * 		- There is a shared prescaler provide a periodic tick.
 * 		- There is one/multiple counters which increment when the prescaler overflow.
 * 		- Each of those counters will have its own "limit" register which will specify 
 *		  when it will generate its own interrupt.
 * 		- All counters and the "softPanic" can be cleared together by the software 
 *		  executing a heartbeat.
 * 		- Typicaly, the watchdog can be configured to have two counters:
 *   		- Counter 0 would provide an interrupt to let's the CPU handle the 
 *			  issue or shutdown the system cleanly.
 *   		- Counter 1, configured to trigger after counter 0, would be connected 
 *			  in hardware to reset the whole system in a hard way.
 * @section Example_WATCHDOG Usage & Initialization.
 * This is an example show how to instantiate @ref WATCHDOG with @ref watchdog_instance_t.
 * 
 * This implementation depends on @ref PLIC for interrupt configuration.
 * 
 * @code
 * 
 * #include "watchdog/watchdog.h"
 * #include "irq.h"
 * 
 * #define WDG_0 ((watchdog_hwreg_t *)SYSTEM_WATCHDOG_CTRL)
 * #define WATCHDOG_PRESCALER_CYCLE_PER_MS SYSTEM_CLINT_HZ/1000
 * #define WATCHDOG_TIMEOUT_MS 3000
 * 
 *   // Handle the WDG interrupt
 * int irq_m_watchDog0_handler(){}
 * 
 * watchdog_instance_t wdg_0 = {
 * 	.hwreg 			= WDG_0,
 * 	.enable 		= {0x1U, 0x1U},
 * 	.prescaler 		= WATCHDOG_PRESCALER_CYCLE_PER_MS-1,
 * 	.counterLimit 	= {WATCHDOG_TIMEOUT_MS, 2*WATCHDOG_TIMEOUT_MS},
 * 	.heartbeat 		= 0x0U,
 * };
 * 
 * plic_instance_t wdg_plic = {
 *  .target 	= BSP_PLIC_CPU_0, 
 *  .gateway 	= SYSTEM_WATCHDOG_INTERRUPTS_0, 
 *  .priority   = 0x1U, 
 *  .enable     = 0x1U, 
 *  .threshold  = 0x0U, 
 * };
 * 
 * void wdg_isr_init(){
 * 	plic_applyConfig(&wdg_plic);
 * 	watchdog_applyConfig(&wdg_0);
 * 	irq_setTrapVector(trap_entry);
 * 	irq_setType(IRQ_EXTERNAL);
 * 	irq_enable();
 * }
 * @endcode
 * @see @ref watchdogDemo "Example Watchdog Timer Demo" - Learn how to use the driver for watchdog operations
 * @{
 */

/* ========================================================================== */
/* SUB-GROUP : Data Types			                                         */
/* ========================================================================== */
/**
 * @defgroup WDG_ENUM Data Types
 * @ingroup WatchDog
 * @brief Enums used by the driver.
 * @{
 */

    /** @name Configuration Enums
     * @brief Enums used for driver initialization.
     * @{
     */
        /** @brief Value for the timer to generate a detection pulse */
        typedef enum {
            WDG_TIMER_CLEAR	    = 0xAD68E70D, 	///< Reset WDG Timer
            WDG_TIMER_UNLOCK	= 0x3C21B925,	///< Unlock WDG Timer
            WDG_TIMER_LOCK	    = 0x3C21B924	///< Lock WDG Timer
        } watchdog_heartbeat_t;

    /** @} */

/** @} */ // End of WDG_ENUM group

/* ========================================================================== */
/* SUB-GROUP : DATA STRUCTS                                          			*/
/* ========================================================================== */
/**
 * @defgroup WDG_Types Data Structures
 * @ingroup WatchDog
 * @brief Structs used by the driver.
 * @note
 * <b> This is an example show how to instantiate WatchDog with @ref watchdog_instance_t,  
 * @ref watchdog_heartbeat_t, and @ref watchdog_hwreg_t.
 * 
 * @code 
 * #define WDG_0 ((watchdog_hwreg_t *)SYSTEM_WATCHDOG_CTRL)
 * 
 *watchdog_instance_t wdg_0 = {
 *	// Hardware Register Map
 *	.hwreg 			= WDG_0,
 *	// Enable counter 0 to trigger first (interrupt)
 *	// Enable counter 1 to trigger the hardware reset of the SoC (Handled outside the SoC)
 *	.enable 		= {0x1U, 0x1U},
 *	.prescaler 		= WATCHDOG_PRESCALER_CYCLE_PER_MS-1,
 *	// The counter Limit 0 -> Set Limit Value for counter 0
 *	// The counter Limit 1 -> Set Limit Value for counter 1
 *	.counterLimit 	= {WATCHDOG_TIMEOUT_MS, 2*WATCHDOG_TIMEOUT_MS},
 *	// Heartbeat Config: WDG_TIMER_CLEAR, WDG_TIMER_UNLOCK , WDG_TIMER_LOCK
 *	.heartbeat 		= 0x0U,
 *};
 *
 * watchdog_applyConfig(&wdg_0);
 *
 * @endcode
 * @{
 */
    /**
     * @brief Watchdog hardware register map.
     * @note This is the main structure that maps directly onto the Watchdog peripheral
     *       memory-mapped register layout.
     */
    typedef volatile struct 
    {
        u32 WDG_HEARTBEAT;						///< Address Offset: 0x00 - Heartbeat Register
        u32 WDG_ENABLE;							///< Address Offset: 0x04 - Enable Register	
        u32 WDG_DISABLE;						///< Address Offset: 0x08 - Disable Register
        u32 reserved0 [(0x0040 - 0xC)/4U];		///< Reserved Space (0x0C to 0x3F)
        u32 WDG_PRESCALER;						///< Address Offset: 0x40 - Prescaler Register
        u32 reserved1 [(0x0080 - 0x44)/4U];		///< Reserved Space (0x44 to 0x7F)
        u32 WDG_COUNTER_LIMIT_0;				///< Address Offset: 0x80 - Counter 0 Limit Register
        u32 WDG_COUNTER_LIMIT_1;				///< Address Offset: 0x84 - Counter 1 Limit Register
        u32 reserved2 [(0x00C0 - 0x88)/4U];		///< Reserved Space (0x88 to 0xBF)
        u32 WDG_COUNTER_VALUE_0;				///< Address Offset: 0xC0 - Counter 0 Value Register
        u32 WDG_COUNTER_VALUE_1;				///< Address Offset: 0xC4 - Counter 1 Value Register

    } watchdog_hwreg_t;

    /**
     * @brief Watchdog instance.
     * Holds the software  registers and hardware pointer.
     * @note This structure holds configuration values to be applied to the hardware.
     *			- enable: Enable flags for each counter.
     *			- prescaler: Clock divider value.
     *			- counterLimit: Counter limit values for each counter.
     *			- heartbeat: Heartbeat action value.
     */
    typedef struct {
        watchdog_hwreg_t    *hwreg;				///< Pointer to Hardware Register Map 
                                                ///< @note
                                                ///< Struct that maps directly onto the Watchdog peripheral
                                                 ///< memory-mapped register layout.

        u32                 enable[2];    		///< Enable flags for each counter 
                                                ///< @note 
                                                ///< - enable[0] to enable Counter 0
                                                ///< - enable[1] to enable Counter 1

        u32                 prescaler;			///< Prescaler value 

        u32                 counterLimit[2]; 	///< Counter limit values for each counter 
                                                ///< @note 
                                                ///< - CounterLimit[0] for Limit Counter 0
                                                ///< - CounterLimit[1] for Limit Counter 1

        u32                 heartbeat;			///< Heartbeat action value 
                                                ///< @note Heartbeat Config: WDG_TIMER_CLEAR,
                                                ///< WDG_TIMER_UNLOCK , WDG_TIMER_LOCK
        
    }watchdog_instance_t;

/** @} */ // End of WDG_Types group


/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup WDG_Funcs API Functions
 * @ingroup WatchDog
 * @brief Function definitions for Watchdog driver.
 * @{
 */
    /** 
     * @brief Apply the software configuration to the hardware.
     *
     * Writes all  values stored in the watchdog_instance to the corresponding
     * Watchdog hardware registers.
     *
     * @param inst Pointer to Watchdog instance.
     * @note Call this function after making any changes to the watchdog_instance
     *       structure to apply those changes to the hardware.
     */
    void watchdog_applyConfig(watchdog_instance_t *inst);

    /** @name Watchdog (Control Functions)
     * Control functions for the Watchdog.
     * @{
     */
        /** 
         * @brief Send Lock Heartbeat to Watchdog.
         * @param inst Pointer to Watchdog instance.
         * @note After locking, the watchdog must be unlocked before it can be cleared again.
         */
        void watchdog_lock(watchdog_instance_t *inst);
        /** 
         * @brief Send Unlock Heartbeat to Watchdog.
         * @param inst Pointer to Watchdog instance.
         */
        void watchdog_unlock(watchdog_instance_t *inst);
        /** 
         * @brief Send Clear Heartbeat to Watchdog.
         * @param inst Pointer to Watchdog instance.
         * @note This resets all enabled watchdog counters.
         */
        void watchdog_clear(watchdog_instance_t *inst);
        /** 
         * @brief Enable Watchdog Counters.
         * @param inst Pointer to Watchdog instance.
         * @param mask Bitmask of counters to enable.
         * @note To enable counter 0, pass bit 0 (0x1). To enable counter 1, pass bit 1 (0x2).
         */
        void watchdog_enable(watchdog_instance_t *inst, u32 mask);
        /** 
         * @brief Disable Watchdog Counters.
         * @param inst Pointer to Watchdog instance.
         * @param mask Bitmask of counters to disable.
         * @note To disable counter 0, pass bit 0 (0x1). To disable counter 1, pass bit 1 (0x2).
         */
        void watchdog_disable(watchdog_instance_t *inst, u32 mask);
    /** @} */

    /** @name Watchdog (Get Functions)
     * Read values from the Watchdog hardware registers.
     * @{
     */
        /** 
         * @brief Get current Counter Value.
         * @param inst Pointer to Watchdog instance.
         * @param counterId Counter index (0 or 1).
         * @return The current counter value.
         */
        u32 watchdog_getCounterValue(watchdog_instance_t *inst, u32 counterId);
        /**
         * @brief Get Watchdog Enable Register.
         * @param inst Pointer to Watchdog instance.
         * @return The current enable register value.
         */
        u32 watchdog_getEnable(watchdog_instance_t *inst);
    /** @} */

    /** @name Watchdog (Set Functions)
     * Write values to the Watchdog  registers.
     * @note Call watchdog_applyConfig() to make these changes effective.
     * @{
     */
        /** 
         * @brief Set Watchdog Prescaler Value.
         * @param inst  Pointer to Watchdog instance.
         * @param value Clock divider value.
         */
        void watchdog_setPrescaler(watchdog_instance_t * inst, u32 value);
        /** 
         * @brief Set Watchdog Heartbeat Action.
         * @param inst  Pointer to Watchdog instance.
         * @param value Heartbeat action value.
         */
        void watchdog_setHeartBeat(watchdog_instance_t *inst, watchdog_heartbeat_t value);
        /** 
         * @brief Set Watchdog Counter Limit.
         * @param inst  Pointer to Watchdog instance.
         * @param counterId Counter index (0 or 1).
         * @param value Counter limit value.
         */
        void watchdog_setCounterLimit(watchdog_instance_t *inst, u32 counterId, u32 value);
    /** @} */

/** @} */ // End of WDG_Funcs group



#ifdef __cplusplus
}
#endif
/** @} */ // End of MAIN WDG Group

#endif // WATCHDOG_H