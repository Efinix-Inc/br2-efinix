////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef MTRAP_H
#define MTRAP_H

/**
 * @file mtrap.h
 * @author Efinix Inc
 * @brief Trap (Interrupt) and Exception Handling Definitions.
 *
 * This file defines the entry point for all processor traps (`trap_entry`),
 * as well as the C-level dispatchers for Interrupts (`trap()`) and 
 * Exceptions (`crash()`).
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include <stdio.h>
#include "debug.h"
#include "plic/plic.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup exception_group Trap Handlers
 * @ingroup System
 * @brief Exception and interrupt dispatching for the Sapphire SoC.
 * @details
 * This module handles low-level context saving and dispatching when the
 * CPU encounters an interrupt or exception.
 *
 * @section Usage_Exception Usage & Initialization
 *
 * Generally, users do not need to interact with this module directly.
 * The following describes how the trap system works:
 *
 * | Component | Behavior |
 * |:--|:--|
 * | @ref trap_entry | Configured as the trap vector in the `mtvec` register. Automatically manages all traps — no manual handling required. |
 * | @ref irq_handleSoft / @ref irq_handleTimer | Weakly aliased to @ref irq_handleDefault by default. Override by defining a function with the same name. |
 * | @ref irq_handleExt | Reads the PLIC claim register to identify the interrupt source, then invokes the corresponding handler. All PLIC handlers are weak aliases to @ref irq_handleDefault. |
 *
 * @see <a href="mtrap_8c_source.html#L37"><b>mtrap.c</b></a> — Full list
 * of interrupt handlers and their corresponding PLIC IDs.
 *
 * @{
 */

/* ========================================================================== */
/* SUB-GROUP 1: ASSEMBLY HELPERS (Context Saving)                               */
/* ========================================================================== */

/**
 * @defgroup Exception_Types Assembly Context Helpers
 * @ingroup Exception
 * @brief Macros to abstract XLEN (32 vs 64-bit) for inline assembly.
 * @note These are used inside `trap_entry` to save/restore registers 
 * width-agnostically.
 * @{
 */
    #if __riscv_xlen == 64
        #define STORE   	"sd"  ///< Store Double-word (64-bit) 
        #define LOAD    	"ld"  ///< Load Double-word (64-bit) 
        #define GPR_SIZE 	"8"
        #define STACK_SIZE 	"128"
    #else
        #define STORE   	"sw"  ///< Store Word (32-bit) 
        #define LOAD    	"lw"  ///< Load Word (32-bit) 
        #define GPR_SIZE 	"4"
        #define STACK_SIZE 	"64"  
    #endif

    #ifdef __riscv_flen // FPU is present
        #undef STACK_SIZE
        #if __riscv_flen == 64 // RV_DF extension
            #define FPR_SIZE "8"
            #define FSTORE  "fsd"
            #define FLOAD   "fld"
            #if __riscv_xlen == 64
            // RV64DF: 128(GPR) + 160(FPR) + 8(FCSR)
                #define STACK_SIZE "304" 
            #else
             // RV32DF: 64(GPR) + 160(FPR) + 4(FCSR)
                #define STACK_SIZE "240"
            #endif
        #else // Single Precision FPU
            #define FPR_SIZE "4"
            #define FSTORE  "fsw"
            #define FLOAD   "flw"
            #if __riscv_xlen == 64
             // RV64F: 128(GPR) + 80(FPR) + 8(FCSR)
                #define STACK_SIZE "224"
            #else
            // RV32F: 64(GPR) + 80(FPR) + 4(FCSR)
                #define STACK_SIZE "160" 
            #endif
        #endif
    #endif
/** @} */


/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup Exception_Funcs API Functions
 * @ingroup Exception
 * @brief Function definitions for interrupt handler, exception.
 * @{
 */

     /** @name Main Trap Entry Point (Naked).
     *  Hardware vector target (written to `mtvec`).
     * @{
     */
        /**
         * @brief The Main Trap Entry Point (Naked).
         * @details This function is the hardware vector target (written to `mtvec`).
         * 
         * @note **It performs the following:**
         * - Allocates stack space.
         * - Saves all CPU registers (Context Save).
         * - Calls `trap()` (The C dispatcher).
         * - Restores all CPU registers (Context Restore).
         * - Executes `mret` (Return from Machine Mode).
         *
         * @note Declared `naked` because it contains pure assembly and must not 
         * have a compiler-generated prologue/epilogue.
         */
            void  trap_entry(void) __attribute__((naked, aligned(4)));
    /** @} */

     /** @name CPU Interrupt Handler.
     *  Handle interrupt from external, timer, software interrupts.
     * @note
     * These are weak aliases pointing to `irq_handleDefault`.
     * The user can override them by defining a function with the same name.
     * @{
     */
        /**
         * @brief Default Fallback Interrupt Handler.
         * @note Invoked if an interrupt fires but no specific handler is defined.
         * @return 0
         */
            int irq_handleDefault(void);
        /**
         * @brief Handlers for CPU interrupts (Software).
         * @note
         * This function points to @ref irq_handleDefault which is also
         * a weak alias.
         * User can override it by defining a function with the same name.
         */
            int irq_handleSoft(void) __attribute__((weak));
        /**
         * @brief Handlers for CPU interrupts (Timer).
         * @note
         * This function points to @ref irq_handleDefault which is also
         * a weak alias.
         * User can override it by assigning a function with same name.
         */
            int irq_handleTimer(void) __attribute__((weak));
        /**
         * @brief External Interrupt Handler (PLIC).
         * @details Called by the trap dispatcher when `mcause` indicates an 
         * External Interrupt. It queries the PLIC for the specific source ID.
         */
            void irq_handleExt(void) __attribute__((weak));
        /** @} */

     /** @name List of Interrupt Handler.
     *  List of weak aliases for all PLIC interrupt sources.
     *  The user can override any of these by defining a function with the same name.
     * @note
     * These are weak aliases pointing to `irq_handleDefault`.
     * Refer to @ref mtrap.c for the full list of handlers and their corresponding PLIC IDs.
     * The user can override them by defining a function with the same name.
     * @{
     */

        /**
         * @brief ID: 0, Handler for invalid/unassigned interrupts
         */
            int irq_m_invalid_handler(void);
        /**
         * @brief ID: 1, Handler for UART0 interrupts
         */	
           int irq_m_uart0_handler(void);
        /**
         * @brief ID: 2, Handler for UART1 interrupts
         */		
           int irq_m_uart1_handler(void); 		
        /**
         * @brief ID: 3, Handler for UART2 interrupts
         */	
            int irq_m_uart2_handler(void); 
        /**
         * @brief ID: 6, Handler for SPI0 interrupts
         */	
            int irq_m_spi0_handler(void);
        /**
         * @brief ID: 7, Handler for SPI1 interrupts
         */	
            int irq_m_spi1_handler(void);
        /**
         * @brief ID: 8, Handler for SPI2 interrupts
         */	
            int irq_m_spi2_handler(void);
        /**
         * @brief ID: 11, Handler for I2C0 interrupts
         */	
            int irq_m_i2c0_handler(void);
        /**
         * @brief ID: 12, Handler for I2C1 interrupts
         */	
            int irq_m_i2c1_handler(void);
        /**
         * @brief ID: 13, Handler for I2C2 interrupts
         */	
            int irq_m_i2c2_handler(void);
        /**
         * @brief ID: 14, Handler for I2C3 interrupts
         */	
            int irq_m_i2c3_handler(void);
        /**
         * @brief ID: 15, Handler for I2C4 interrupts
         */	
            int irq_m_i2c4_handler(void);
        /**
         * @brief ID: 16, Handler for GPIO0_0 interrupts
         */	
            int irq_m_gpio0_0_handler(void);
        /**
         * @brief ID: 17, Handler for GPIO0_1 interrupts
         */	
            int irq_m_gpio0_1_handler(void);
        /**
         * @brief ID: 18, Handler for GPIO1_0 interrupts
         */	
            int irq_m_gpio1_0_handler(void);
        /**
         * @brief ID: 19, Handler for GPIO1_1 interrupts
         */	
            int irq_m_gpio1_1_handler(void);
        /**
         * @brief ID: 21, Handler for User Timer 0 interrupts
         */	
            int irq_m_userTimer0_handler(void);
        /**
         * @brief ID: 22, Handler for User Timer 1 interrupts
         */	
            int irq_m_userTimer1_handler(void);
        /**
         * @brief ID: 23, Handler for User Timer 2 interrupts
         */	
            int irq_m_userTimer2_handler(void);	
        /**
         * @brief ID: 26, Handler for WatchDog Timer interrupts
         */	
            int irq_m_watchDog0_handler(void);	
        /**
         * @brief ID: 30, Handler for AXI A interrupts
         */	
            int irq_m_axiA_handler(void);
        /**
         * @brief ID: 31, Handler for L2 Cache Control interrupts
         */	
            int irq_m_l2Cache_handler(void);
        /**
         * @brief ID: 32, Handler for User-defined Interrupt A
         */	
            int irq_m_user_a_handler(void);		
        /**
         * @brief ID: 33, Handler for User-defined Interrupt B
         */	
            int irq_m_user_b_handler(void);
        /**
         * @brief ID: 34, Handler for User-defined Interrupt C
         */	
            int irq_m_user_c_handler(void);
        /**
         * @brief ID: 35, Handler for User-defined Interrupt D
         */	
            int irq_m_user_d_handler(void);
        /**
         * @brief ID: 36, Handler for User-defined Interrupt E
         */	
            int irq_m_user_e_handler(void);
        /**
         * @brief ID: 37, Handler for User-defined Interrupt F
         */	
            int irq_m_user_f_handler(void);
        /**
         * @brief ID: 38, Handler for User-defined Interrupt G
         */	
            int irq_m_user_g_handler(void);
        /**
         * @brief ID: 39, Handler for User-defined Interrupt H
         */	
            int irq_m_user_h_handler(void);
           /** @} */

    /** @name Dispatcher/Exception Handlers (Function)
     * @brief Trap Dispatcher mainly for external interrupt and exception handler.
     * @details 
     * @note
     * These are weak aliases pointing to `irq_handleDefault`.
     * The user can override them by defining a function with the same name.
     * @{
     */
        /**
         * @brief Main C Trap Dispatcher.
         * @details Called by `trap_entry` after context save. It reads `mcause` 
         * to determine if the event was an Interrupt (Async) or Exception (Sync).
         * - **Interrupt:** Calls `irq_handle*` functions.
         * - **Exception:** Calls `crash()`.
         */
        void trap(void) __attribute__((weak));

        /**
         * @brief Fatal Exception Handler.
         * @details 
         * @warning 
         * Called when the CPU encounters a synchronous fault (e.g., 
         * Illegal Instruction, Load/Store Misaligned).
         * Default implementation prints the registers (`mepc`, `mcause`) and hangs.
         */
        void crash(void) __attribute__((weak));

    /** @} */

/** @} */ // End of MTRAP_Funcs group
#ifdef __cplusplus
}
#endif

/** @} */ // End of MAIN MTRAP Group

#endif // MTRAP_H