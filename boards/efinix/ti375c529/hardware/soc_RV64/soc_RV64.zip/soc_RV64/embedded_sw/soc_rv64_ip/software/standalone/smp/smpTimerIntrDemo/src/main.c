////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/******************************************************************************
*
* @file main.c: smpTimerIntrDemo
*
* @brief This demo shows how to configure multiple timer and handle it with different hart.
*
******************************************************************************/
#include <stdio.h>
#include "bsp.h"
#include "userDef.h"
#include "irq.h"

// Include SMP (Multi-core)
#include "smp.h"
#include "start.h"

// Include Driver
#include "timer/timer.h"

#if defined(SYSTEM_USER_TIMER_0_CTRL) && defined(SYSTEM_USER_TIMER_1_CTRL)

extern void smpInit();
extern void trap_entry();
volatile ulen hartCounter = 0;

// 0 = Unlocked, 1 = Locked
volatile u32 uart_lock = 0;
u8 hartStack[STACK_PER_HART*SYSTEM_NUMBER_OF_HARTS] __attribute__((aligned(16)));

volatile u32 tick_counter_limit_t0 = 0;
volatile u32 tick_counter_t0 = 0;

volatile u32 tick_counter_limit_t1 = 0;
volatile u32 tick_counter_t1 = 0;


/******************************************************************************
*
* @brief This function check the prescaler value & timer limit value to ensure
* 		 timer generate one pulse per second.
*
******************************************************************************/
volatile u32 sanityCheck(u32 p, u32 t)
{
    /*
     * HW_Divisor = (prescaler_value + 1)*(timer_limit +1);
     * HW_Divisor = (127 + 1) * (4095 + 1);
     * Ticks Per Second (f,Hz) = SYSTEM_CLINT_HZ / HW_Divisor
     * Period (1/f)= (prescaler_value + 1)x(timer_limit +1)/SYSTEM_CLINT_HZ
     */
    u32 hw_divisor = (p + 1) * (t + 1);
    u32 tick_counter_limit = SYSTEM_CLINT_HZ / hw_divisor; //Tick per second
    return (tick_counter_limit == 0)?1:tick_counter_limit;

}

/******************************************************************************
*
* @brief This function allow hart to lock certain task/variable to protect shared
* 		 resource.
*
******************************************************************************/
__inline__ __attribute__((always_inline)) void spin_lock(volatile u32 *lock) {
    u32 temp = 1;
    u32 result;
    while (1) {
        // Attempt to grab the lock
        __asm__ volatile(
            "amoswap.w %[result], %[temp], (%[address])"
            : [result] "=r"(result)
            : [temp] "r"(temp), [address] "r"(lock)
            : "memory"
        );
        // If we got it (result == 0), we are done!
        if (result == 0) {
            return;
        }
        // If we failed, wait a bit to let others finish.
        // This prevents "Bus Starvation"
        for (volatile int i = 0; i < 1000; i++) {
            __asm__ volatile ("nop");
        }
    }
}

/******************************************************************************
*
* @brief This function release the lock by writing 0, it uses memory barrier
* 		 (fence) to ensure all print operations finish before we release the
* 		 lock.
*
******************************************************************************/
__inline__ __attribute__((always_inline)) void spin_unlock(volatile u32 *lock) {
    __asm__ volatile("fence rw,rw" ::: "memory");
    *lock = 0;
}

/******************************************************************************
*
* @brief This instance is used to configure user timer 0 setting.
*
******************************************************************************/
timer_instance_t timer0 = {
    // Configure the interrupt source
    .hwreg 				= TIMER_0,
    .prescaler_value 	= PRESCALER_VALUE,
    .prescaler_enable 	= 0x1U,
    .self_restart 		= 0x1U,
    .timer_limit 		= TIMER_LIMIT_VALUE,
};

/******************************************************************************
*
* @brief This instance is used to configure PLIC for timer_0.
*
******************************************************************************/
plic_instance_t timer0_plic = {
    // Configure the interrupt source
    .target    = BSP_PLIC_CPU_0,
    .gateway   = SYSTEM_USER_TIMER_0_INTERRUPTS_0,
    .priority  = 1,
    .enable    = 1,
    .threshold = 0, // Allow all priorities > 0
};

/******************************************************************************
*
* @brief This instance is used to configure user timer 1 setting.
*
******************************************************************************/
timer_instance_t timer1 = {
    // Configure the interrupt source
    .hwreg 				= TIMER_1,
    .prescaler_value 	= PRESCALER_VALUE,
    .prescaler_enable 	= 0x1U,
    .self_restart 		= 0x1U,
    .timer_limit 		= TIMER_LIMIT_VALUE,
};

/******************************************************************************
*
* @brief This instance is used to configure PLIC for timer_1.
*
******************************************************************************/
plic_instance_t timer1_plic = {
    // Configure the interrupt source
    .target    = BSP_PLIC_CPU_1,
    .gateway   = SYSTEM_USER_TIMER_1_INTERRUPTS_0,
    .priority  = 1,
    .enable    = 1,
    .threshold = 0, // Allow all priorities > 0
};

/******************************************************************************
*
* @brief This timer_0 IRQ function will keep on counting once enter interrupt routine.
*
******************************************************************************/
int irq_m_userTimer0_handler(){
    ulen hartId = csr_read(mhartid);
    tick_counter_t0++;

    if (tick_counter_t0 >= tick_counter_limit_t0) {
        tick_counter_t0=0;
        spin_lock(&uart_lock);
        printf(ANSI_BLUE "Timer 0 ISR .. from hart %d\n" ANSI_RESET,hartId);
        spin_unlock(&uart_lock);
    }
    return 0;

}

/******************************************************************************
*
* @brief This timer_1 IRQ function will keep on counting once enter interrupt routine.
*
******************************************************************************/
int irq_m_userTimer1_handler(){
    ulen hartId = csr_read(mhartid);
    tick_counter_t1++;

    if (tick_counter_t1 >= tick_counter_limit_t1*2) {
        tick_counter_t1=0;
        spin_lock(&uart_lock);
        printf(ANSI_GREEN "Timer 1 ISR .. from hart %d\n" ANSI_RESET,hartId);
        spin_unlock(&uart_lock);
    }
    return 0;

}

void mainSmp(){
    //this routine run by all cores
    ulen hartId = csr_read(mhartid);

    // Register interrupt/trap for each core
    irq_setTrapVector(trap_entry);
    irq_setType(IRQ_EXTERNAL);
    irq_enable();

    // Fetch and Add for atomic
    __sync_fetch_and_add(&hartCounter, 1);

    while(hartCounter != SYSTEM_NUMBER_OF_HARTS);
    if(hartId == 0) while(1);
    else if(hartId == 1) while(1);

}


/******************************************************************************
*
* @brief This is the main event for smpTimerIntrDemo.
*
******************************************************************************/
void main(){
    // Init UART
    bsp_init();

    tick_counter_limit_t0 = sanityCheck(PRESCALER_VALUE,TIMER_LIMIT_VALUE);
    tick_counter_limit_t1 = sanityCheck(PRESCALER_VALUE,TIMER_LIMIT_VALUE);
    // Apply PLIC config for all timers.
    plic_applyConfig(&timer0_plic);
    plic_applyConfig(&timer1_plic);

    // Apply userTimer config.
    timer_applyConfig(&timer0);
    timer_applyConfig(&timer1);

    // User can call ISR function via irq_registerExt instead.
//	irq_registerExt(SYSTEM_USER_TIMER_0_INTERRUPTS_0,ISR);
//	irq_registerExt(SYSTEM_USER_TIMER_1_INTERRUPTS_0,ISR);
    printf(ANSI_RESET"***Starting SMP User Timer Interrupt Demo*** \n");
    smp_unlock(smpInit);
    mainSmp();
}

#else

void main() {
bsp_init();
printf(ANSI_RED "\n[ERR] Both User Timer 1 & 2 are disabled, please enable them to run this app. \n"ANSI_RESET);
}
#endif

