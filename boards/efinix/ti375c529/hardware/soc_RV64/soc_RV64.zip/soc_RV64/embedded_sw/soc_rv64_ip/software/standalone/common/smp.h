////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#pragma once
#include "soc.h"

#ifdef __cplusplus
extern "C" {
#endif

#define STACK_PER_HART 8192
#define SMP_INUSE       (SYSTEM_NUMBER_OF_HARTS > 1)

#if (SYSTEM_NUMBER_OF_HARTS==4)
    #define BSP_PLIC_CPU_3 SYSTEM_PLIC_CPU_3_MEI
    #define BSP_PLIC_CPU_2 SYSTEM_PLIC_CPU_2_MEI
    #define BSP_PLIC_CPU_1 SYSTEM_PLIC_CPU_1_MEI
#elif (SYSTEM_NUMBER_OF_HARTS==3)
    #define BSP_PLIC_CPU_2 SYSTEM_PLIC_CPU_2_MEI
    #define BSP_PLIC_CPU_1 SYSTEM_PLIC_CPU_1_MEI
#elif (SYSTEM_NUMBER_OF_HARTS==2)
    #define BSP_PLIC_CPU_1 SYSTEM_PLIC_CPU_1_MEI
#endif

#ifdef __cplusplus
}
#endif // C_plusplus