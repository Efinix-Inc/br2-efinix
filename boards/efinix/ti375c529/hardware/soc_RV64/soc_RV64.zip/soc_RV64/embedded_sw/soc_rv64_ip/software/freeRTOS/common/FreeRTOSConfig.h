/*
 * FreeRTOS V202212.01
 * Copyright (C) 2022 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * https://www.FreeRTOS.org
 * https://github.com/FreeRTOS
 */

/**
 * @file FreeRTOSConfig.h
 * @brief Unified FreeRTOS kernel configuration for the Efinix RV64 SoC.
 *
 * See https://www.freertos.org/a00110.html for the full parameter reference.
 */

#ifndef FREERTOS_CONFIG_H
#define FREERTOS_CONFIG_H

#include "bsp.h"

/*===========================================================================
 * Scheduler & core behaviour
 *===========================================================================*/

/** @brief Use the pre-emptive scheduler. */
#define configUSE_PREEMPTION                        1

/**
 * @brief Use the port-optimised (CLZ-based) task selection.
 *
 * The RV64 GCC port supports this via the __builtin_clz() intrinsic, giving
 * O(1) highest-priority task selection instead of O(n).
 */
#define configUSE_PORT_OPTIMISED_TASK_SELECTION     1

/**
 * @brief Tick rate in Hz.
 *
 * 1000 Hz (1 ms tick) gives good timer resolution for networking timeouts
 * while keeping ISR overhead low on a 200 MHz core.
 */
#define configTICK_RATE_HZ                          ( ( TickType_t ) 1000 )

/** @brief Number of priority levels. 10 levels suit a multi-subsystem design
 *         (idle / app / FAT / TCP / ISR-deferred tasks all need room). */
#define configMAX_PRIORITIES                        ( 10 )

/**
 * @brief Minimal task stack size (in words, not bytes).
 *
 * On RV64 each word is 8 bytes.  384 words = 3 KB — enough for a simple task
 * with a modest call depth and local variables.  Increase per task as needed
 * via the task-creation call.
 */
#define configMINIMAL_STACK_SIZE                    ( ( StackType_t ) 384 )

/**
 * @brief Total FreeRTOS heap available in bytes.
 *
 * When DDR is present (SYSTEM_DDR_A_CTRL_SIZE defined in soc.h), 8 MB is allocated
 *
 * When running from OCR only, the heap is capped at half of
 * SYSTEM_RAM_A_CTRL_SIZE to leave room for code, data, and per-hart stacks.
 * A 4 KB floor prevents misconfiguration on very small OCR builds.
 */
#ifdef SYSTEM_DDR_A_CTRL_SIZE
    #define configTOTAL_HEAP_SIZE               ( ( size_t ) ( 8U * 1024U * 1024U ) )
#else
    #define configTOTAL_HEAP_SIZE               ( ( size_t ) (                          \
        ( ( SYSTEM_RAM_A_CTRL_SIZE / 2U ) > ( 4U * 1024U ) )                                \
            ? ( SYSTEM_RAM_A_CTRL_SIZE / 2U )                                                \
            : ( 4U * 1024U ) ) )
#endif /* SYSTEM_DDR_A_CTRL_SIZE */

/** @brief Maximum length of a task name string (including NUL). */
#define configMAX_TASK_NAME_LEN                     ( 16 )

/** @brief Use 32-bit tick counter (sufficient for >49-day uptime at 1 kHz). */
#define configUSE_16_BIT_TICKS                      0

/** @brief Yield to equal-priority tasks from the Idle task. */
#define configIDLE_SHOULD_YIELD                     1

/** @brief Enable backward compatibility macros (required by some middleware). */
#define configENABLE_BACKWARD_COMPATIBILITY         1

/** @brief Number of thread-local storage pointers per task.
 *         FreeRTOS+FAT requires 2 when CWD support is enabled; reserve 3. */
#define configNUM_THREAD_LOCAL_STORAGE_POINTERS     3

/** @brief Record the highest stack address for debugging. */
#define configRECORD_STACK_HIGH_ADDRESS             1

/*===========================================================================
 * Clock & RISC-V timer (CLINT)
 *===========================================================================*/

/**
 * @brief Base address of the CLINT MTIME register.
 *
 * Standard CLINT layout: MTIME is at offset 0xBFF8 from the CLINT base.
 * SYSTEM_CLINT_CTRL = 0x2000000, so MTIME = 0x200BFF8.
 */
#define configMTIME_BASE_ADDRESS                    ( BSP_CLINT + 0xBFF8UL )

/**
 * @brief Base address of the CLINT MTIMECMP register (hart 0).
 *
 * Standard CLINT layout: MTIMECMP[0] is at offset 0x4000 from the CLINT base.
 * = 0x2004000.
 */
#define configMTIMECMP_BASE_ADDRESS                 ( BSP_CLINT + 0x4000UL )

/**
 * @brief CLINT reference clock frequency used by the FreeRTOS tick driver.
 *
 * This must be the CLINT input frequency, NOT the
 * CPU frequency.  The CLINT counter increments at this rate.
 */
#define configCPU_CLOCK_HZ                          ( ( uint64_t ) ( BSP_CLINT_HZ ) )

/*===========================================================================
 * Hook functions
 *===========================================================================*/

/** @brief Call vApplicationTickHook() on every tick interrupt. */
#define configUSE_TICK_HOOK                         0

/** @brief Call vApplicationIdleHook() from the idle task. */
#define configUSE_IDLE_HOOK                         1

/** @brief Call vApplicationMallocFailedHook() if pvPortMalloc() returns NULL. */
#define configUSE_MALLOC_FAILED_HOOK                1

/**
 * @brief Stack overflow detection method.
 *
 * Method 2 provides the most thorough checking (pattern + watermark).
 * Disable (set to 0) only in a final production build if the overhead is
 * unacceptable.
 */
#define configCHECK_FOR_STACK_OVERFLOW              2

/*===========================================================================
 * Software timers
 *===========================================================================*/

/** @brief Include the software timer feature. */
#define configUSE_TIMERS                            1

/**
 * @brief Priority of the timer service task.
 *
 * One below the maximum so ISR-deferred tasks and the TCP/IP task can
 * pre-empt it.
 */
#define configTIMER_TASK_PRIORITY                   ( configMAX_PRIORITIES - 1 )

/** @brief Length of the timer command queue. */
#define configTIMER_QUEUE_LENGTH                    10

/** @brief Stack depth for the timer task. */
#define configTIMER_TASK_STACK_DEPTH                ( configMINIMAL_STACK_SIZE * 2 )

/*===========================================================================
 * Synchronisation primitives
 *===========================================================================*/

/** @brief Include mutex support. */
#define configUSE_MUTEXES                           1

/** @brief Include recursive mutex support. */
#define configUSE_RECURSIVE_MUTEXES                 1

/** @brief Include counting semaphore support. */
#define configUSE_COUNTING_SEMAPHORES               1

/** @brief Include event group support (required by FreeRTOS+TCP). */
#define configUSE_EVENT_GROUPS                      1

/**
 * @brief Queue registry size.
 *
 * Set > 0 to enable named queues in a RTOS-aware debugger.  0 saves RAM in
 * production.
 */
#define configQUEUE_REGISTRY_SIZE                   0

/** @brief Include task-tag / application-tag support. */
#define configUSE_APPLICATION_TASK_TAG              0

/*===========================================================================
 * Memory allocation
 *===========================================================================*/

/**
 * @brief Enable dynamic allocation (heap_4 or heap_5 recommended).
 *
 * FreeRTOS+TCP uses dynamic allocation for network buffers.
 */
#define configSUPPORT_DYNAMIC_ALLOCATION            1

/**
 * @brief Enable static allocation.
 *
 * Some TCP/MQTT internal objects may use static allocation.
 */
#define configSUPPORT_STATIC_ALLOCATION             1

/*===========================================================================
 * Run-time stats & trace
 *===========================================================================*/

/** @brief Enable vTaskList() / vTaskGetRunTimeStats() formatting helpers. */
#define configUSE_TRACE_FACILITY                    1

/** @brief Include human-readable stats formatting functions. */
#define configUSE_STATS_FORMATTING_FUNCTIONS        1

/*===========================================================================
 * Printf / logging
 *===========================================================================*/

/** @brief Map configPRINTF() to the BSP printf implementation. */
#define configPRINTF( X )                           printf X

/** @brief Non-format thread-safe print. */
#define configPRINT( X )                            printf X

/** @brief String-only thread-safe print. */
#define configPRINT_STRING( X )                     printf X

/*===========================================================================
 * Platform identification
 *===========================================================================*/

/** @brief Human-readable platform name (used by some demo utilities). */
#define configPLATFORM_NAME                         "Efinix_RV64_FPGA"

/*===========================================================================
 * Demo / application-specific settings
 *===========================================================================*/

/** @brief Gather basic IP-stack debug stats via the CLI interface. */
#define configINCLUDE_DEMO_DEBUG_STATS              1

/**
 * @brief Global CLI output buffer size.
 *
 * Set to 1 (minimum) when each CLI instance has its own local output buffer,
 * saving RAM.
 */
#define configCOMMAND_INT_MAX_OUTPUT_SIZE           1

/** @brief ISR priority for MAC simulation tasks (not used on bare-metal). */
#define configMAC_ISR_SIMULATOR_PRIORITY            ( configMAX_PRIORITIES - 1 )

/** @brief Pseudo-random number generator used by FreeRTOS+TCP. */
extern uint32_t ulRand( void );
#define configRAND32()                              ulRand()

/*===========================================================================
 * Default networking parameters (FreeRTOS+TCP)
 *
 * These are used by demos as fallback when DHCP is disabled or fails.
 * Adjust to match your lab network.
 *===========================================================================*/

/** @brief Board MAC address (must be unique on the network segment). */
#define configMAC_ADDR0                             0x00
#define configMAC_ADDR1                             0x11
#define configMAC_ADDR2                             0x22
#define configMAC_ADDR3                             0x33
#define configMAC_ADDR4                             0x44
#define configMAC_ADDR5                             0x32

/** @brief Static IP address (fallback). */
#define configIP_ADDR0                              192
#define configIP_ADDR1                              168
#define configIP_ADDR2                              31
#define configIP_ADDR3                              55

/** @brief Default gateway. */
#define configGATEWAY_ADDR0                         192
#define configGATEWAY_ADDR1                         168
#define configGATEWAY_ADDR2                         31
#define configGATEWAY_ADDR3                         1

/** @brief DNS server (Google public DNS). */
#define configDNS_SERVER_ADDR0                      8
#define configDNS_SERVER_ADDR1                      8
#define configDNS_SERVER_ADDR2                      8
#define configDNS_SERVER_ADDR3                      8

/** @brief Subnet mask. */
#define configNET_MASK0                             255
#define configNET_MASK1                             255
#define configNET_MASK2                             255
#define configNET_MASK3                             0

/** @brief Echo server address used by TCP/UDP echo client demos. */
#define configECHO_SERVER_ADDR0                     192
#define configECHO_SERVER_ADDR1                     168
#define configECHO_SERVER_ADDR2                     31
#define configECHO_SERVER_ADDR3                     6
#define configTCP_ECHO_CLIENT_PORT                  7

/** @brief UDP port for log/print messages. */
#define configPRINT_PORT                            ( 15000 )

/** @brief Profiling disabled by default. */
#define configPROFILING                             ( 0 )

/*===========================================================================
 * Optional API inclusions
 *===========================================================================*/

#define INCLUDE_vTaskPrioritySet                    1
#define INCLUDE_uxTaskPriorityGet                   1
#define INCLUDE_vTaskDelete                         1
#define INCLUDE_vTaskCleanUpResources               0
#define INCLUDE_vTaskSuspend                        1
#define INCLUDE_vTaskDelayUntil                     1
#define INCLUDE_vTaskDelay                          1
#define INCLUDE_uxTaskGetStackHighWaterMark         1
#define INCLUDE_xTaskGetSchedulerState              1
#define INCLUDE_xTimerGetTimerTaskHandle            0
#define INCLUDE_xTaskGetIdleTaskHandle              0
#define INCLUDE_xQueueGetMutexHolder                1
#define INCLUDE_eTaskGetState                       1
#define INCLUDE_xEventGroupSetBitsFromISR           1
#define INCLUDE_xTimerPendFunctionCall              1
#define INCLUDE_xTaskGetCurrentTaskHandle           1
#define INCLUDE_xTaskAbortDelay                     1

#endif /* FREERTOS_CONFIG_H */
