////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header: bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef SPI_H
#define SPI_H

/**
 * @file spi.h
 * @author Efinix Inc
 * @brief SPI driver API definitions.
 *
 * This file provides data structures and APIs for controlling
 * the SPI peripheral on the EfxSapphireSoC platform.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include <stdint.h>
#include "type.h"
#include "soc.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup SPI SPI Driver
 * @brief Serial Peripheral Interface (SPI) driver.
 * @ingroup comm_group
 *
 * This module provides functions to configure and control
 * SPI input/output and interrupt behavior.
 * @section Example_SPI Usage & Initialization.
 * This is an example show how to instantiate @ref SPI with @ref spi_instance_t.
 * 
 * @code 
 * #include "spi/spi.h"
 * 
 * #define SPI (spi_hwreg_t*)SYSTEM_SPI_0_IO_CTRL
 * 
 * spi_instance_t SPI = {
 * 	   	   .hwreg      = SPI,
 * 		   .cpol       = LOW,
 * 		   .cpha       = DATA_SAMPLED_RISE_EDGE,
 * 		   .mode       = FULL_DUPLEX_SINGLE_LINE,
 * 		   .clkDivider = 15,
 * 		   .ssSetup    = 5,
* 		   .ssHold     = 2,
 * 		   .ssDisable  = 7
 * },
 * 
 * spi_applyConfig(&SPI);
 * 
 * @endcode
 * 
 * @see @ref spiFlashDemo "Example SPI Flash Demo" - Learn how to use the driver for interacting with Flash devices
 * @{
 */

/* ========================================================================== */
/* SUB-GROUP : REGISTER DEFINITIONS                                          */
/* ========================================================================== */

/**
 * @defgroup SPI_Macros Register Definitions
 * @ingroup SPI
 * @brief Register bitmasks and offsets.
 * @{
 */

    /** @name SPI_CMD Register Bits
     * Offset: 0x00
     * @{
     */
    #define SPI_CMD_DATA_MASK           0xFF	  ///< Mask for Data to be transmitted 
    #define SPI_CMD_WR                  (1 << 8)  ///< Write Trigger
    #define SPI_CMD_RD                  (1 << 9)  ///< Read Trigger
    #define SPI_CMD_SS                  (1 << 11) ///< Slave Select Trigger
    #define SPI_CMD_READ_INVALID        (1 << 31) ///< Read Data Invalid Flag
    /** @} */

    /** @name SPI_RSP Register Bits
     * Offset: 0x04
     * @{
     */
    #define SPI_RSP_CMD_FIFO_AVAILABILITY (0xFFFF)       ///< Mask for CMD FIFO count
    #define SPI_RSP_FIFO_OCCUPANCY        (0xFFFF << 16) ///< Mask for RSP FIFO count
    /** @} */

    /** @name SPI_CONFIG Register Bits
     * Offset: 0x08
     * @{
     */
    #define SPI_CONFIG_CPOL             (1 << 0)  ///< Clock Pola
    #define SPI_CONFIG_MODE             (1 << 4)  ///< Line Mode (Dual/Q
    #define SPI_CONFIG_CPHA             (1 << 16) ///< Clock P
    /** @} */

    /** @name SPI_INTERRUPT Register Bits
     * Offset: 0x0C
     * @{
     */
    #define SPI_INTC_CMD_INT_ENABLE     (1 << 0)  ///< Command FIFO Empty Interrupt En
    #define SPI_INTC_RSP_INT_ENABLE     (1 << 1)  ///< Response FIFO Valid Interrupt En
    #define SPI_CMD_INT                 (1 << 8)  ///< Command Interrupt St
    #define SPI_RSP_INT                 (1 << 9)  ///< Response Interrupt St
    #define SPI_CMD_VALID               (1 << 16) ///< Command Valid S
    /** @} */

/** @} */ // End of SPI_Macros group


/** @cond INTERNAL_HIDDEN */
//-----------------------------------------------------------------------------
// SPI Hardware Sanity Check (Hidden from User)
//-----------------------------------------------------------------------------
#define IS_VALID_CPOL(x) ((x) == LOW || (x) == HIGH)
#define IS_VALID_CPHA(x) ((x) == DATA_SAMPLED_RISE_EDGE || (x) == DATA_SAMPLED_FALL_EDGE)
#define IS_VALID_MODE(x) ((x) == FULL_DUPLEX_SINGLE_LINE || (x) == HALF_DUPLEX_DUAL_LINE || (x) == HALF_DUPLEX_QUAD_LINE)
/** @endcond */


/* ========================================================================== */
/* SUB-GROUP : Data Types			                                         */
/* ========================================================================== */

/**
 * @defgroup SPI_ENUM Data Types
 * @ingroup SPI
 * @brief Enums used by the driver.
 * @{
 */

    /** @name Configuration Enums
     * @brief Enums used for driver initialization.
     * @{
     */
        /** @brief SPI transfer mode configuration. */
        enum cfg_mode {
            FULL_DUPLEX_SINGLE_LINE = 0, ///< Full-duplex mode using single data lin
            HALF_DUPLEX_DUAL_LINE = 1, ///< Half-duplex mode using dual data lin
            HALF_DUPLEX_QUAD_LINE = 2  ///< Half-duplex mode using quad data lin
        };

        /** @brief SPI clock polarity configuration. */
        enum cfg_cpol {
            LOW  = 0, ///< Clock is low when id
            HIGH = 1  ///< Clock is high when id
        };

        /** @brief SPI clock phase configuration. */
        enum cfg_cpha {
            DATA_SAMPLED_RISE_EDGE = 0, ///< Data sampled on rising clock ed
            DATA_SAMPLED_FALL_EDGE = 1  ///< Data sampled on falling clock ed
        };
        /** @} */

/** @} */ // End of SPI_ENUM group

/* ========================================================================== */
/* SUB-GROUP : DATA STRUCTS                                          			*/
/* ========================================================================== */
/**
 * @defgroup SPI_Types Data Structures
 * @ingroup SPI
 * @brief Structs used by the driver.
 * @note
 * <b> This is an example show how to instantiate SPI with @ref spi_instance_t 
 * and @ref spi_hwreg_t.
 * 
 * @code 
 * #define SPI  (spi_hwreg_t*)SYSTEM_SPI_0_IO_CTRL
 * 
 * spi_instance_t SPI_inst = {
 *	   	   .hwreg      = SPI,
 *		   .cpol       = LOW,
 *		   .cpha       = DATA_SAMPLED_RISE_EDGE,
 *		   .mode       = FULL_DUPLEX_SINGLE_LINE,
 *		   .clkDivider = 2,
 *		   .ssSetup    = 5,
 *		   .ssHold     = 2,
 *		   .ssDisable  = 7
 *},
 * spi_applyConfig(&SPI_inst);
 *
 * @endcode
 * @{
 */

    /**
     * @brief SPI hardware register map.
     * @note This is the main structure that maps directly onto the SPI peripheral
     *       memory-mapped register layout.
     */
    typedef volatile struct {
        u32 CMD;                ///< Address Offset: 0x00 - Command Register
        u32 RSP;                ///< Address Offset: 0x04 - Response Register
        u32 CONFIG;             ///< Address Offset: 0x08 - Configuration Register
        u32 INTERRUPT;          ///< Address Offset: 0x0C - Interrupt Control
        u32 RESERVED0[4];       ///< Reserved
        u32 CLOCKDIVIDER;       ///< Address Offset: 0x20 - Clock Divider
        u32 SSSETUP;            ///< Address Offset: 0x24 - SS Setup Cycles
        u32 SSHOLD;             ///< Address Offset: 0x28 - SS Hold Cycles
        u32 SSDISABLE;          ///< Address Offset: 0x2C - SS Disable Cycles
        u32 SSACTIVEHIGH;       ///< Address Offset: 0x30 - SS Polarity
        u32 RESERVED1[7];       ///< Reserved
        u32 CMD_WRITELARGE;     ///< Address Offset: 0x50 - 32-bit Write
        u32 CMD_READWRITELARGE; ///< Address Offset: 0x54 - 32-bit Read/Write
        u32 CMD_READLARGE;      ///< Address Offset: 0x58 - 32-bit Read
    } spi_hwreg_t;


/**
     * @brief SPI instance.
     * Holds the software registers and hardware pointer.
     * @note This structure holds configuration values to be applied to the hardware.
     * - **cpol:** Clock polarity (0 or 1).
     * - **cpha:** Clock phase (0 or 1).
     * - **mode:** SPI mode
     * 		- 0: Full-duplex single line
     * 		- 1: Half-duplex dual line (Available only when data width is 8 or 16)
     * 		- 2: Half-duplex quad line (Available only when data width is 8 or 16)
     * - **clkDivider:** Clock divider value.
     * 		- Formula: `SPI frequency = FCLK / ((clockDivider+1)*2)`
     * 		- Note: FCLK is the system clock (`io_systemClk`). If peripheral clock is enabled, 
     * 			FCLK is driven by `io_peripheralClk` instead.
     * - **ssSetup:** Slave select setup time.
     * 		- Clock cycles between activated chip-select and first rising-edge of SCLK.
     * - **ssHold:** Slave select hold time.
     * 		- Clock cycles between last falling-edge and deactivated chip-select.
     * - **ssDisable:** Slave select disable time.
     * 		- Clock cycles between consecutive chip-select activations.
     */
    typedef struct {
        spi_hwreg_t     *hwreg;       ///< Pointer to Hardware Register Map
        enum cfg_cpol   cpol;         ///< Stored Clock Polarity
        enum cfg_cpha   cpha;         ///< Stored Clock Phase
        enum cfg_mode   mode;         ///< Stored Transfer Mode
        u32             clkDivider;   ///< Clock Divider Value
        u32             ssSetup;      ///< Slave Select Setup Cycles
        u32             ssHold;       ///< Slave Select Hold Cycles
        u32             ssDisable;    ///< Slave Select Disable Cycles
    } spi_instance_t;

/** @} */ // End of SPI_Types group


/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup SPI_Funcs API Functions
 * @ingroup SPI
 * @brief Function definitions for SPI driver.
 * @{
 */

    /**
     * @brief Read 8-bit SPI data.
     * @param inst Pointer to SPI instance.
     * @return 8-bit data value.
     */
    u8 spi_read(spi_instance_t *inst);

    /**
     * @brief Write and Read 8-bit SPI data.
     * @param inst Pointer to SPI instance.
     * @param data 8-bit Data to be written.
     * @return 8-bit Data received.
     */
    u8 spi_writeRead(spi_instance_t *inst, u8 data);

    /**
     * @brief Read 32-bit SPI data.
     * @param inst Pointer to SPI instance.
     * @return 32-bit data value.
     */
    u32 spi_read32(spi_instance_t *inst);

    /**
     * @brief Check SPI response FIFO occupancy.
     * @param inst Pointer to SPI instance.
     * @return Number of entries in Response FIFO.
     */
    u32 spi_getRspOccupancy(spi_instance_t *inst);

    /**
     * @brief Check SPI command FIFO availability.
     * @param inst Pointer to SPI instance.
     * @return Number of free slots in Command FIFO.
     */
    u32 spi_getCmdAvailability(spi_instance_t *inst);

    /**
     * @brief Check SPI if it has any command waiting to be executed in queue.
     * @param inst Pointer to SPI instance.
     * @return Return 1 if busy, 0 otherwise.
     */
    u32 spi_isBusy(spi_instance_t *inst);

    /**
     * @brief Write and Read 32-bit SPI data.
     * @param inst Pointer to SPI instance.
     * @param data 32-bit Data to be written.
     * @return 32-bit Data received.
     */
    u32 spi_writeRead32(spi_instance_t *inst, u32 data);

    /**
     * @brief Apply stored SPI configuration to hardware.
     * @param inst Pointer to SPI instance.
     * @note Call this function after making any changes to the @ref 
     * spi_instance_t structure to apply those changes to the hardware.
     */
    void spi_applyConfig(spi_instance_t *inst);

    /**
     * @brief Wait for SPI if any command waiting to be executed.
     * @param inst Pointer to SPI instance.
     */
    void spi_waitUntilIdle(spi_instance_t *inst);

    /**
     * @brief Write 8-bit SPI data.
     * @param inst Pointer to SPI instance.
     * @param data 8-bit data to be written.
     */
    void spi_write(spi_instance_t *inst, u8 data);

    /**
     * @brief Write 32-bit SPI data.
     * @param inst Pointer to SPI instance.
     * @param data 32-bit data to be written.
     */
    void spi_write32(spi_instance_t *inst, u32 data);

    /**
     * @brief Assert SPI Chip Select.
     * @param inst Pointer to SPI instance.
     * @param cs Chip select index.
     */
    void spi_select(spi_instance_t *inst, u32 cs);

    /**
     * @brief De-assert SPI Chip Select.
     * @param inst Pointer to SPI instance.
     * @param cs Chip select index.
     */
    void spi_deselect(spi_instance_t *inst, u32 cs);

    /**
     * @brief Set SPI data transfer mode.
     * @param inst Pointer to SPI instance.
     * @param mode Data mode (Full Duplex, Half Duplex, etc.).
     */
    void spi_setDataMode(spi_instance_t *inst, enum cfg_mode mode);

/** @} */ // End of SPI_Funcs group

#ifdef __cplusplus
}
#endif // C_plusplus

/** @} */ // End of MAIN SPI Group

#endif // SPI_H