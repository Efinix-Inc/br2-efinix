////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/******************************************************************************
*
* @file main.c: clintTimerInterruptDemo
*
* @brief This demo show how to use software interrupt and timer interrupt using CLINT driver
*		 where both interrupt triggered at different period. 
*		 
*
******************************************************************************/
#include <stdio.h>
#include "bsp.h"
#include "irq.h"
#include "userDef.h"

void initTimer();
void scheduleTimer();
void isrInit();
extern void trap_entry();

// Store the next interrupt time
uint64_t timerCmp; 
u32 sw_counter=0;

/******************************************************************************
*
* @brief This function handles the timer interrupt event. 
*
******************************************************************************/
int irq_handleTimer(){
    static uint32_t counter = 0;
    scheduleTimer();
    printf(ANSI_YELLOW "Timer Interrupt Triggered!\n" ANSI_RESET);
    printf("Entering ISR routine\n") ;
    printf("Count:%d .. Done \n\n" ANSI_RESET,counter);
    if(++counter == 59) counter = 0;
    return 1;
}

/******************************************************************************
*
* @brief This function handles the software interrupt event.
*
******************************************************************************/
int irq_handleSoft(){;
    printf(ANSI_GREEN "Software Interrupt Triggered!\n" ANSI_RESET);
    printf("Entering ISR routine\n") ;
    clint_setSoftInterrupt(MSIP_DISABLE,0);
    printf("Count:%d .. Done \n\n",sw_counter);
    if(++sw_counter == 59) sw_counter = 0;
    return 1;
}

/******************************************************************************
*
* @brief This function make the timer tick in 1 second.
*
* @note For simulation, the timer tick faster as to avoid having to wait too long. 
*
******************************************************************************/
void scheduleTimer(){
    timerCmp += TIMER_TICK_DELAY;
    clint_setCmp(timerCmp, 0);
}

/******************************************************************************
*
* @brief This function initialize timer.  
*
******************************************************************************/
void initTimer(){
    timerCmp = clint_getTime();
    scheduleTimer();
}

/******************************************************************************
*
* @brief This function initialize timer and enable machine timer interrupts. 
*
******************************************************************************/
void isrInit(){
    // Configure timer
    initTimer();
    clint_setSoftInterrupt(MSIP_ENABLE,0);
    irq_setTrapVector(trap_entry);
    irq_setType(IRQ_SOFTWARE|IRQ_TIMER);
    irq_enable();

}

/******************************************************************************
*
* @brief This main function initialize the system and waiting to be interrupted
*        by the core timer.
*
******************************************************************************/
void main() {
    // Initialize UART
    bsp_init();
    printf(ANSI_RESET "***Starting Clint Timer Interrupt Demo*** \n");

    // Initialize IRQ
    isrInit();
    while(1){
        bsp_uDelay(2000000); //2seconds
        clint_setSoftInterrupt(MSIP_ENABLE,0);

    };
}

