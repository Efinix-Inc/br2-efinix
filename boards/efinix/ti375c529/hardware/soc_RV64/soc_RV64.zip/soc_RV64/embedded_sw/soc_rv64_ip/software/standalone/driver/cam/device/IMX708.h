////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef IMX708_H
#define IMX708_H

/**
 * @file imx708.h
 * @author Efinix Inc
 * @brief imx708 Driver API definitions.
 * This file provides data structures and APIs for controlling
 * the imx708 camera device on the EfxSapphireSoC platform.
 * @note This is a device-specific driver implementation for the imx708 camera.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "cam/cam.h"
/**
 * @defgroup Supported_CAM Supported Devices
 * @ingroup CAM_DRV
 * @brief Supported Camera.
 * 
 * @note This module provides device-specific drivers for various camera hardware that currently supported by Efinix.
 * @note - User may add their custom camera device drivers based on this framework.
 * @{
 */

/**
 * @defgroup IMX708_Config IMX708 Camera Driver
 * @ingroup Supported_CAM
 * @brief IMX708 Camera driver definitions.
 * 
 * @note This is a device-specific driver implementation for the IMX708 camera.
 * @{
 */

#if __cplusplus
extern "C" {
#endif

/* ========================================================================== */
/* SUB-GROUP : REGISTER DEFINITIONS                                          */
/* ========================================================================== */

/**
 * @defgroup IMX708_Macros Register Definitions
 * @ingroup Supported_CAM
 * @brief Register bitmasks and offsets.
 * @{
 */
    /**
     * @brief I2C Address for IMX708 Camera device.
     */
    #define CAM_IMX708_ADDR              0x1A <<1     ///< IMX708 I2C Address */

/** @} */ // End of IMX708_Macros group

/* ========================================================================== */
/* SUB-GROUP : Driver Definition                                        */
/* ========================================================================== */

/**
 * @defgroup IMX708_DRV Driver Structure
 * @ingroup Supported_CAM
 * @brief This is the IMX708 driver structure.
 * @{
 */
    /**
     * @brief IMX708 Driver Instance.
     * Point your generic CAM pointer to this structure to use the IMX708 hardware.
     * @note Implements the following hooks from @ref cam_api_t:
     *      - **initCam:** Initialize all required camera sequence.
     *      - **startStreaming:** Start Stream video.
     *      - **stopStreaming:** Stop Stream Video.
     * @see cam_api_t
     * @code
     * // Example Usage:
	 * cam_instance_t camera;
	 * cam_api_t *drv = &IM708_DRIVER
     * drv->initCam(&camera); 
     * @endcode
     */
    extern const cam_api_t IMX708_DRIVER;

/** @} */ // End of IMX708_DRV group


/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup IMX708_Funcs API Functions
 * @ingroup Supported_CAM
 * @brief Function definitions for IMX708 driver.
 * @note This is the public API for the IMX708 CAM device.
 * @{
 */
     /**
     * @brief Apply I2C + CAM configuration.
     * @param cam Pointer to CAM instance.
     * @return Status code of the operation.
     */
    cam_status_t IMX708_applyConfig(cam_instance_t *cam);
     /**
     * @brief Enable error interrupt for IMX708 Camera.
     * @param cam Pointer to Camera instance.
     * @return Status code of the operation.
     */
    cam_status_t IMX708_enableErrorInterrupt(cam_instance_t *cam);
    /**
     * @brief Initialize Camera Sequence.
     * @param cam Pointer to Camera instance.
     */
    cam_status_t IMX708_initCam(cam_instance_t *cam);
    /**
     * @brief Start Stream Video.
     * @param cam Pointer to Camera instance.
     */
    cam_status_t IMX708_startStreaming(cam_instance_t *cam);
    /**
     * @brief Stop Stream Video.
     * @param cam Pointer to Camera instance.
     */
    cam_status_t IMX708_stopStreaming(cam_instance_t *cam);


    /**
     * @brief Apply Common Configuration.
     * @details Sets up PLLs, basic timing, and power management settings common to all modes.
     * @param cam Pointer to Camera instance.
     */
    void IMX708_ConfigCommon(cam_instance_t *cam);

    /**
     * @brief Configure Sensor Output Format.
     * @details Sets resolution, binning, and framerate based on the selected mode.
     * @param cam Pointer to Camera instance.
     * @param mode Index of the configuration (e.g., 0=Full Res, 1=Binning).
     */
    void IMX708_ConfigFormat(cam_instance_t *cam, u8 mode);

    /**
     * @brief Configure MIPI Link Frequency.
     * @details Sets the MIPI CSI-2 clock lane frequency (e.g., 450Mbps vs 900Mbps).
     * @param cam Pointer to Camera instance.
     */
    void IMX708_ConfigLinkFreq(cam_instance_t *cam);

    /* -------------------------------------------------------------------------- */
    /* EXPOSURE & GAIN CONTROL                                                    */
    /* -------------------------------------------------------------------------- */

    /**
     * @brief Set PDAF (Phase Detection Auto Focus) Gain.
     * @details Configures the gain specifically for the PDAF pixel rows.
     * @param cam Pointer to Camera instance.
     */
    void IMX708_SetPdafGain(cam_instance_t *cam);

    /**
     * @brief Set Exposure Time.
     * @details Controls the integration time (shutter speed) in line units.
     * @param cam Pointer to Camera instance.
     * @param val Exposure lines (0 to FrameLength).
     */
    void IMX708_SetExposure(cam_instance_t *cam, u16 val);

    /**
     * @brief Set Analog Gain.
     * @details Applies analog amplification to the pixel signal before ADC.
     * @param cam Pointer to Camera instance.
     * @param val Gain value (Specific to sensor gain table).
     */
    void IMX708_SetAnalogueGain(cam_instance_t *cam, u16 val);

    /**
     * @brief Set Digital Gain.
     * @details Applies digital multiplication after ADC conversion.
     * @param cam Pointer to Camera instance.
     * @param val Digital gain multiplier (e.g., 0x0100 = 1.0x).
     */
    void IMX708_SetDigitalGain(cam_instance_t *cam, u16 val);

    /* -------------------------------------------------------------------------- */
    /* LENS ACTUATOR CONTROL (VCM)                                                */
    /* -------------------------------------------------------------------------- */

    /**
     * @brief Enable Lens Actuator (VCM).
     * @details Powers up the Voice Coil Motor driver for focus control.
     * @param cam Pointer to Camera instance.
     */
    void IMX708_OnActuator(cam_instance_t *cam);

    /**
     * @brief Disable Lens Actuator (VCM).
     * @details Powers down the VCM to save power or park the lens.
     * @param cam Pointer to Camera instance.
     */
    void IMX708_OffActuator(cam_instance_t *cam);

    /**
     * @brief Set Focus Position (DAC Value).
     * @details Moves the lens to a specific position by setting the VCM DAC code.
     * @param cam Pointer to Camera instance.
     * @param focus_step DAC value (e.g., 0 = Infinity, Max = Macro).
     */
    void IMX708_SetFocusStep(cam_instance_t *cam, u32 focus_step);

/** @} */ // End of IMX708_Funcs group


#if __cplusplus
}
#endif


/** @} */ // End of MAIN IMX708 Group

#endif // SRC_IMX708_H 
