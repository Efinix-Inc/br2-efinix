#include "l2ctrl/l2ctrl.h"

#ifdef SYSTEM_L2_CACHE_CTRL
#define L2CTRL ((l2ctrl_hwreg_t *)SYSTEM_L2_CACHE_CTRL)
#else
#define L2CTRL ((l2ctrl_hwreg_t *)0)
#endif

void l2cache_waitFlush() {
    while((L2CTRL->COMPLETION & 0x1U) == 0);
    asm("fence");   // Ensure that futher reads start after the flush completion
}

void l2cache_flush(void* address, u64 size) {
    while((L2CTRL->START & 0x1U));
    L2CTRL->ADDRESS_FROM = (uintptr_t)address;
    L2CTRL->ADDRESS_TO = (uintptr_t)address+size-1;
    asm("fence");
    L2CTRL->START = 0x3U;
}

void l2cache_flushBlocking(void* address, u64 size) {
    l2cache_flush(address, size);
    l2cache_waitFlush();
}

void l2cache_setFlushInterrupt(u64 mask) {
    L2CTRL->INTERRUPTS=mask;
}
