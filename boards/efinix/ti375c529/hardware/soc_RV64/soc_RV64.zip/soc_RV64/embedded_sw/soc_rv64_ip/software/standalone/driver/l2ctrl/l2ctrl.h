////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef L2CTRL_H
#define L2CTRL_H


/**
 * @file l2ctrl.h
 * @author Efinix Inc
 * @brief L2 controller driver API definitions.
 *
 * This file provides data structures and APIs for controlling
 * the L2 controller to flush the data cache.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "type.h"
#include "soc.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup L2CTRL L2 Cache Controller Driver
 * @brief L2 Cache Controller (L2CTRL) driver.
 * @ingroup cache_group
 *
 * This module provides functions to configure and control
 * L2CTRL input/output and interrupt behavior.
 * 
 * @section Example_L2Cache Usage & Initialization.
 * This example shows how to flush L2 Cache using <b> Blocking Method </b>.
 * @code 
 * #include "l2ctrl/l2ctrl.h"
 * void main()
 * {
 * 	char buf[40];
 * 	u64 val;
 * 	u64 *dat = (u64 *)SYSTEM_AXI_B_CTRL;
 * 
 * 	// Write 4KB data to axiB block ram
 * 	for(int i=0; i < (4096/sizeof(uintptr_t)); i=i+1) {
 * 		*dat = (0x0101010101010101*i);
 * 		dat++;
 * 	}
 * 	dat--;
 * 	// Read 4KB data from axiB block ram
 * 	for(int i=0; i < (4096/sizeof(uintptr_t)); i=i+1) {
 * 		val=*dat;
 * 		dat--;
 * 	}
 * 	// Data is now only available in L2 cache
 * 	// Flush the data to axiB block ram using blocking method
 * 	l2cache_flushBlocking(dat, 4096);
 * 	printf("Flush done ..\n");
 * }
 * @endcode
 * 
 * This example shows how to flush L2 Cache using <b> Interrupt Method </b>.
 * @code 
 * #include "l2ctrl/l2ctrl.h"
 * #include "irq.h"
 * 
 * // Interrupt handler for L2 Cache Flush completion
 * int irq_m_l2Cache_handler (){
 * 	printf("isr: Flush done ..\n");
 * 	l2cache_setFlushInterrupt(0x0U);
 * 	asm("fence");
 * 	return 0;
 * }
 * 
 * 
 * void l2_isr_init() {
 * 	plic_instance_t l2_plic = {
 * 		.target 	= BSP_PLIC_CPU_0,
 * 		.gateway 	= SYSTEM_L2_CACHE_CTRL_INTERRUPT,
 * 		.priority 	= 0x1U,
 * 		.enable 	= 0X1U,
 * 		.threshold 	= 0x0U,
 * 	};
 * 
 * 	plic_applyConfig(&l2_plic);
 * 	irq_setTrapVector(trap_entry);
 * 	irq_setType(IRQ_EXTERNAL);
 * 	irq_enable();
 * 
 * }
 * 
 * void main()
 * {
 * 	char buf[40];
 * 	u64 val;
 * 	u64 *dat = (u64 *)SYSTEM_AXI_B_CTRL;
 * 
 *  dat++;
 *  // Write another 4KB data to axiB block ram
 *  for(int i=0; i < (4096/sizeof(uintptr_t)); i=i+1) {
 *  	*dat = (0x1010101010101010*i);
 *  	dat++;
 *  }
 *  dat--;
 *  // Read 4KB data from axiB block ram
 *  for(int i=0; i < (4096/sizeof(uintptr_t)); i=i+1) {
 *  	val=*dat;
 *  	dat--;
 *  }
 *  dat++;
 *  // Flush the data to axiB block ram using nonblocking method and interrupt
 *  l2cache_flush(dat, 4096);
 *  l2cache_setFlushInterrupt(0x1U);
 *  while(1){};
 * }
 * @endcode
 * 
 * @see @ref axiBDemo "Example AXI-B Demo with L2 Cache" - Learn how to use the driver with AXI-B Interface
 * 
 * 
 * @{
 */

/* ========================================================================== */
/* SUB-GROUP : DATA STRUCTS                                          			*/
/* ========================================================================== */
/**
 * @defgroup L2_Types Data Structures
 * @ingroup L2CTRL
 * @brief Structs and Enums used by the driver.
 * @note User are allowed to use L2CTRL API directly without instantiate L2CTRL by 
 * pointing it to @ref l2ctrl_hwreg_t.
 * @see l2ctrl.c
 * @{
 */

    /**
     * @brief L2CTRL hardware register map.
     */
    typedef volatile struct 
    {
        u64		COMPLETION;					///< Offset: 0x0000, flush completion status
        u64		START;						///< Offset; 0x0008, start and busy status
        u64		ADDRESS_FROM;				///< Offset: 0x0010, starting address
        u64		ADDRESS_TO;					///< Offset: 0x0018, end address
        u64		reserved0[(0x38-0x20)/8U];	///< Reserved Space (0x20 to 0x30) 
        u64		INTERRUPTS;					///< Offset: 0xBFF8, MTIME Low 

    } l2ctrl_hwreg_t;

/** @} */ // End of L2_Types group

/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup L2CTRL_Funcs API Functions
 * @ingroup L2CTRL
 * @brief Function definitions for L2CTRL driver.
 * @{
 */

    /**
     * @brief Wait until Flush is completed.
    */
    void l2cache_waitFlush();
    
    /**
     * @brief Use the L2 cache registers to flush a range of memory, using physical address
     *
     * @param address Physical Address of ram for flusing.
     * @param size Size of address to be flushed.
     * @note This will also flush the CPUs L1 data caches, as the L2 is inclusive.
     */

    void l2cache_flush(void* address, u64 size);

    /**
     * @brief Use the L2 cache registers to flush a range of memory, using physical address
     * 		  and wait until the flush is completed.
     * @param address Physical Address of ram for flusing.
     * @param size Size of address to be flushed.
     * @note This will also flush the CPUs L1 data caches, as the L2 is inclusive.
     */
    void l2cache_flushBlocking(void* address, u64 size);

    /**
     * @brief Set L2 Cache Flush Interrupt.
     * @param mask Set 0x1U to enable Flush Interrupt.
     */
    void l2cache_setFlushInterrupt(u64 mask);
    /** @} */

/** @} */ // End of L2CTRL_Funcs group

#ifdef __cplusplus
}
#endif

/** @} */ // End of MAIN L2CTRL Group

#endif // L2CTRL_H