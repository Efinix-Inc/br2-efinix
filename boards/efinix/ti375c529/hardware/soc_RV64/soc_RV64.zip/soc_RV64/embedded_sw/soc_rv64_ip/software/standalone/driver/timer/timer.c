////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/**
* @file timer.c
* @brief Timer driver implementation.
*
* Implements the functions defined in timer.h for controlling
* Timer input/output and interrupts on the EfxSapphireSoC platform.
* @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
* See the full @ref license_page for Efinix and SaxonSoc MIT terms.
*/

#include "timer/timer.h"

/*----------------------------------------------------------------------------*/
/* Function implementations                                                    */
/*----------------------------------------------------------------------------*/

/**
* @brief Get stored Timer Configuration.
*/
u32 timer_getConfig(timer_instance_t *inst)
{
    return inst->hwreg->TIMER_CONFIG;
}

/**
* @brief Set Timer Configuration.
*/
u32 timer_setConfig(timer_instance_t *inst, u32 value)
{
    inst->hwreg->TIMER_CONFIG = value;
}

/**
* @brief Get stored Timer Prescaler Value.
*/
u32 timer_getPrescalerValue(timer_instance_t *inst)
{
    return inst->hwreg->PRESCALER;
}

/**
* @brief Set Timer Prescaler Value.
*/
u32 timer_setPrescalerValue(timer_instance_t *inst, u32 value)
{
    inst->hwreg->PRESCALER = value;
}

/**
* @brief Get stored Timer Limit (Reload Value).
*/
u32 timer_getLimit(timer_instance_t *inst)
{
    return inst->hwreg->TIMER_LIMIT;
}

/**
* @brief Set Timer Limit (Reload Value).
*/
u32 timer_setLimit(timer_instance_t *inst, u32 value)
{
    inst->hwreg->TIMER_LIMIT = value;
}

/**
* @brief Get stored Timer Value.
*/
u32 timer_getValue(timer_instance_t *inst)
{
    return inst->hwreg->TIMER_VALUE;
}

/**
* @brief Get stored Timer Configuration.
*/
void timer_clearValue(timer_instance_t *inst)
{
    inst->hwreg->TIMER_VALUE=0;
}

/** 
* @brief Apply the software configuration to the hardware.
*
* Writes all  values stored in the timer_instance to the corresponding
* Timer hardware registers.
*
*/
void timer_applyConfig(timer_instance_t *inst)
{
    slen mask = 0;
    inst->hwreg->TIMER_LIMIT = inst->timer_limit;
    
    if (inst->self_restart == 1) mask |= TIMER_CONFIG_SELF_RESTART;
    if (inst->prescaler_enable == 1) {
        mask |=TIMER_CONFIG_WITH_PRESCALER;
        inst->hwreg->PRESCALER = inst->prescaler_value;
    }
    else
    mask |=TIMER_CONFIG_WITHOUT_PRESCALER;
    inst->hwreg->TIMER_CONFIG=mask;
}