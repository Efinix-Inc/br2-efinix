////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/**
* @file cam.c
* @brief cam driver implementation.
*
* Implements the functions defined in cam.h for controlling
* cam input/output and interrupts on the EfxSapphireSoC platform.
* @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
* See the full @ref license_page for Efinix and SaxonSoc MIT terms.
*/

#include "cam/cam.h"
#include "debug.h"

cam_status_t applyConfig(cam_instance_t *cam) {
    // Safety check! Ensure the pointer actually exists before calling it
    if (cam != NULL && cam->drv != NULL && cam->drv->applyConfig != NULL) {
        
        return cam->drv->applyConfig(cam);
    }
    
    return CAM_ERR; 
}
cam_status_t enableErrorInterrupt(cam_instance_t *cam) {

    if (cam != NULL && cam->drv != NULL && cam->drv->enableErrorInterrupt != NULL) {
        return cam->drv->enableErrorInterrupt(cam);
    }
    return CAM_ERR;
}

void cam_writeReg(cam_instance_t *cam, u16 reg, u8 data)
{
    i2c_instance_t *inst = cam->inst;

    i2c_startMasterBlocking(inst);

    i2c_sendTxByte(inst, cam->inst->slaveAddress);
    i2c_sendNackBlocking(inst);
    BSP_ASSERT(i2c_getRxAck(inst),"Failed to Assert!\n"); // Optional check

    i2c_sendTxByte(inst, (reg>>8) & 0xFF);
    i2c_sendNackBlocking(inst);
    BSP_ASSERT(i2c_getRxAck(inst),"Failed to Assert!\n"); // Optional check

    i2c_sendTxByte(inst, (reg) & 0xFF);
    i2c_sendNackBlocking(inst);
    BSP_ASSERT(i2c_getRxAck(inst),"Failed to Assert!\n"); // Optional check

    i2c_sendTxByte(inst, data & 0xFF);
    i2c_sendNackBlocking(inst);
    BSP_ASSERT(i2c_getRxAck(inst),"Failed to Assert!\n"); // Optional check

    i2c_stopMasterBlocking(inst);
}

u8 cam_readReg(cam_instance_t *cam, u16 reg)
{
    i2c_instance_t *inst = cam->inst;
    u8 outdata;

    i2c_startMasterBlocking(inst);

    i2c_sendTxByte(inst, cam->inst->slaveAddress);
    i2c_sendNackBlocking(inst);
    BSP_ASSERT(i2c_getRxAck(inst),"Failed to Assert!\n"); // Optional check

    i2c_sendTxByte(inst, (reg>>8) & 0xFF);
    i2c_sendNackBlocking(inst);
    BSP_ASSERT(i2c_getRxAck(inst),"Failed to Assert!\n"); // Optional check

    i2c_sendTxByte(inst, (reg) & 0xFF);
    i2c_sendNackBlocking(inst);
    BSP_ASSERT(i2c_getRxAck(inst),"Failed to Assert!\n"); // Optional check

    i2c_stopMasterBlocking(inst);
    i2c_startMasterBlocking(inst);

    i2c_sendTxByte(inst, cam->inst->slaveAddress | 0x01);
    i2c_sendNackBlocking(inst);
    BSP_ASSERT(i2c_getRxAck(inst),"Failed to Assert!\n"); // Optional check

    i2c_sendTxByte(inst, 0xFF);
    i2c_sendNackBlocking(inst);
    BSP_ASSERT(i2c_getRxNack(inst),"Failed to Assert!\n"); // Optional check
    outdata = i2c_getRxData(inst);

    i2c_stopMasterBlocking(inst);

    return outdata;
}