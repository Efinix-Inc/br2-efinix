////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef SRC_IMX219_H_
#define SRC_IMX219_H_

/**
 * @file imx219.h
 * @author Efinix Inc
 * @brief IMX219 Driver API definitions.
 * This file provides data structures and APIs for controlling
 * the IMX219 camera device on the EfxSapphireSoC platform.
 * @note This is a device-specific driver implementation for the IMX219 camera.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "cam/cam.h"
/**
 * @defgroup Supported_CAM Supported Devices
 * @ingroup CAM_DRV
 * @brief Supported Camera.
 * 
 * @note This module provides device-specific drivers for various camera hardware that currently supported by Efinix.
 * @note - User may add their custom camera device drivers based on this framework.
 * @{
 */

/**
 * @defgroup IMX219_Config IMX219 Camera Driver
 * @ingroup Supported_CAM
 * @brief IMX219 Camera driver definitions.
 * * @note This is a device-specific driver implementation for the IMX219 camera.
 * @{
 */

#if __cplusplus
extern "C" {
#endif

/* ========================================================================== */
/* SUB-GROUP : REGISTER DEFINITIONS                                           */
/* ========================================================================== */

/**
 * @defgroup IMX219_Macros Register Definitions
 * @ingroup Supported_CAM
 * @brief Register bitmasks and offsets.
 * @{
 */
    /**
     * @brief I2C Address for IMX219 Camera device.
     * @note Standard 7-bit address is 0x10. Shifted left for 8-bit write address.
     */
    #define CAM_IMX219_ADDR              0x10 << 1    ///< IMX219 I2C Address (IMX219PQH5-C)

/** @} */ // End of IMX219_Macros group

/* ========================================================================== */
/* SUB-GROUP : Driver Definition                                              */
/* ========================================================================== */

/**
 * @defgroup IMX219_DRV Driver Structure
 * @ingroup Supported_CAM
 * @brief This is the IMX219 driver structure.
 * @{
 */
    /**
     * @brief IMX219 Driver Instance.
     * Point your generic CAM pointer to this structure to use the IMX219 hardware.
     * @note Implements the following hooks from @ref cam_api_t:
     * - **initCam:** Initialize all required camera sequence.
     * - **startStreaming:** Start Stream video.
     * - **stopStreaming:** Stop Stream Video.
     * @see cam_api_t
     * @code
     * // Example Usage:
     * cam_instance_t camera;
     * cam.drv = &IMX219_DRIVER;
     * cam.drv->init(&camera); 
     * @endcode
     */
    extern const cam_api_t IMX219_DRIVER;

/** @} */ // End of IMX219_DRV group


/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                       */
/* ========================================================================== */

/**
 * @defgroup IMX219_Funcs API Functions
 * @ingroup Supported_CAM
 * @brief Function definitions for IMX219 driver.
 * @note This is the public API for the IMX219 Camera device.
 * @{
 */
     /**
     * @brief Apply I2C + CAM configuration.
     * @param cam Pointer to CAM instance.
     * @return Status code of the operation.
     */
    cam_status_t IMX219_applyConfig(cam_instance_t *cam);
     /**
     * @brief Enable error interrupt for IMX219 Camera.
     * @param cam Pointer to Camera instance.
     * @return Status code of the operation.
     */
    cam_status_t IMX219_enableErrorInterrupt(cam_instance_t *cam);

    /**
     * @brief Initialize Camera Sequence.
     * @details Configures I2C, verifies ID, and sets default parameters.
     * @param cam Pointer to Camera instance.
     * @return 0 on success, non-zero on failure.
     */
    cam_status_t IMX219_initCam(cam_instance_t *cam);

    /**
     * @brief Start Stream Video.
     * @details Enables CSI-2 output streaming.
     * @param cam Pointer to Camera instance.
     * @return 0 on success.
     */
    cam_status_t IMX219_startStreaming(cam_instance_t *cam);

    /**
     * @brief Stop Stream Video.
     * @details Disables CSI-2 output streaming (Standby).
     * @param cam Pointer to Camera instance.
     * @return 0 on success.
     */
    cam_status_t IMX219_stopStreaming(cam_instance_t *cam);

    /* -------------------------------------------------------------------------- */
    /* CONFIGURATION & CONTROL                                                    */
    /* -------------------------------------------------------------------------- */

    /**
     * @brief Set Active Pixel Range (X-Axis).
     * @details Configures the horizontal window of interest (ROI).
     * @param cam Pointer to Camera instance.
     * @param XStart Start column index.
     * @param XEnd End column index.
     */
    void IMX219_Output_activePixelX(cam_instance_t *cam, u16 XStart, u16 XEnd);

    /**
     * @brief Set Active Pixel Range (Y-Axis).
     * @details Configures the vertical window of interest (ROI).
     * @param cam Pointer to Camera instance.
     * @param YStart Start row index.
     * @param YEnd End row index.
     */
    void IMX219_Output_activePixelY(cam_instance_t *cam, u16 YStart, u16 YEnd);

    /**
     * @brief Configure Test Pattern Generator.
     * @details Enables internal test patterns for debugging CSI links.
     * @param cam Pointer to Camera instance.
     * @param Enable 1 = Enable Test Pattern, 0 = Disable.
     * @param mode Pattern Mode (e.g., Color Bar, Grey ramp).
     * @param X Pattern X dimension (if applicable).
     * @param Y Pattern Y dimension (if applicable).
     */
    void IMX219_TestPattern(cam_instance_t *cam, u8 Enable, u8 mode, u16 X, u16 Y);

/** @} */ // End of IMX219_Funcs group


#if __cplusplus
}
#endif

/** @} */ // End of IMX219_Config Group

#endif /* SRC_IMX219_H_ */