#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

// #if (ENABLE_SEMIHOSTING_PRINT == 1)
// 	#include "semihosting.h"
// #endif

static void _putchar_nano(char character){
    #if (ENABLE_SEMIHOSTING_PRINT == 1)
        sh_writec(character);
    #else
        bsp_putChar(character);
    #endif // (ENABLE_SEMIHOSTING_PRINT == 1)
}
    static char _getchar_nano(){
    #if (ENABLE_SEMIHOSTING_PRINT == 1)
        return sh_readc();
    #else
        return bsp_getChar();
    #endif // (ENABLE_SEMIHOSTING_PRINT == 1)
}

/* Linker must provide these (define in linker.ld) */
extern char _heap_start; /* start of heap area (set in linker script) */
extern char _heap_end;   /* optional end of heap area */

static char *heap_ptr = &_heap_start;
const char msg[] = "\033[31m\nERR: Heap Collision!\n\033[0m";

/* _sbrk: provide heap for malloc */
ssize_t _sbrk(int incr)
{
    char *prev_heap = heap_ptr;
    if ((heap_ptr + incr) > &_heap_end) {
        write(1,msg,sizeof(msg));
        errno = ENOMEM;
        // while(1); //Should we halt the program when hit this issue ?
        return (ssize_t)-1;
    }
    heap_ptr += incr;
    return (ssize_t)prev_heap;
}


/* _write: used by printf/vfprintf -> send to UART */
ssize_t _write(int fd, const void *buf, size_t count)
{
    (void)fd; /* ignore fd; 1/2 -> stdout/stderr */
    const char *p = buf;
    for (size_t i = 0; i < count; ++i) {
        char c = p[i];
        if (c == '\n') {
            _putchar_nano('\r');
        	//uart_write(&uart0, '\r');
        }
        _putchar_nano(c);
        //uart_write(&uart0, c);
    }
    return (ssize_t)count;
}

ssize_t _read(int fd, char *buf, size_t count)
{
    (void)fd;
    char *start = buf; 
    size_t i = 0;

    for (; i < count; ) { 
        
        char c = _getchar_nano(); // Read raw data

        // --- 1. Handle Enter (CR) ---
        if (c == '\r' || c == '\n') { // Semihosting sometimes sends \n instead of \r!
#if (ENABLE_SEMIHOSTING_PRINT == 0)
            _putchar_nano('\r'); 
            _putchar_nano('\n'); 
#endif
            *buf = '\n';       
            buf++;
            return (ssize_t)(i + 1); 
        }

        // --- 2. Handle Backspace (0x08 or 0x7F) ---
        if (c == 0x08 || c == 0x7F) {
            if (i > 0) {
                buf--; 
                i--;
                
#if (ENABLE_SEMIHOSTING_PRINT == 0)
                // Only do the VT100 visual erase if on physical UART
                _putchar_nano('\b'); 
                _putchar_nano(' ');  
                _putchar_nano('\b'); 
#endif
            }
            continue; // Skip the rest, get next char
        }

        // --- 3. Handle Normal Characters ---
        if (c >= ' ' && c <= '~') {
            *buf = c;
#if (ENABLE_SEMIHOSTING_PRINT == 0)
            _putchar_nano(c); // Only echo if on physical UART
#endif
            buf++;
            i++;
        }
    }
    
    return (ssize_t)i;
}

/* _close */
int _close(int fd)
{
    (void)fd;
    return -1;
}

/* _fstat: mark all fds as character special devices */
int _fstat(int fd, struct stat *st)
{
    (void)fd;
    st->st_mode = S_IFCHR;
    return 0;
}

/* _isatty */
int _isatty(int fd)
{
    (void)fd;
    return 1; /* treat as TTY */
}

/* _lseek */
off_t _lseek(int fd, off_t offset, int whence)
{
    (void)fd; (void)offset; (void)whence;
    return (off_t)-1;
}

/* _exit - terminate program: loop forever */
void _exit(int status)
{
    (void)status;
    while (1) { __asm__ volatile ("wfi"); }
}

/* _kill - required by newlib sometimes */
int _kill(int pid, int sig)
{
    (void)pid; (void)sig;
    errno = EINVAL;
    return -1;
}

/* _getpid */
int _getpid(void)
{
    return 1;
}

#ifdef __cplusplus
}
#endif // C_plusplus