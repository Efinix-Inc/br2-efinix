////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef TEMP_SENSOR_CONFIG_H
#define TEMP_SENSOR_CONFIG_H
/**
 * @file temp_sensor_config.h
 * @author Efinix Inc
 * @brief Temperature Sensor Configuration and Driver Selection.
 *
 * This file automatically selects the correct I2C address and 
 * driver structure based on the user-defined ACTIVE_TEMP_SENSOR_TYPE.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "userDef.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup TEMP_SENSOR_Config Driver Configuration
 * @ingroup TEMP_SENSOR
 * @brief Automatic hardware selection logic.
 * @{
 */

 /* ========================================================================== */
/* SUB-GROUP: DRIVER SELECTION LOGIC                                          */
/* ========================================================================== */

/** @name Automatic Driver Selection
 * Resolves the low-level driver implementation based on @ref ACTIVE_TEMP_SENSOR_TYPE.
 * This allows the user to switch Temperature Sensor devices by changing a single configuration value in userDef.h.
 * @note 
 * 		- User can switch between supported Temperature Sensor devices by changing
 * 		  the ACTIVE_TEMP_SENSOR_TYPE macro.
 * 			- Add #define ACTIVE_TEMP_SENSOR_TYPE SENSOR_TYPE_EMC1413 in userDef.h to use EMC1413 Temperature Sensor.
 * 		- For custom Temperature Sensor devices, include the custom driver header and define
 * 		  TEMP_SENSOR_CTRL and TEMP_SENSOR_DRIVER macros accordingly.
 * 			- Refer to userDef.h in tempSensorDemo of including a custom Temperature Sensor driver.
 * @{
 */
// --- Automatic Logic (Do not touch below) ---
#if (ACTIVE_TEMP_SENSOR_TYPE == SENSOR_TYPE_EMC1413)
    #include "sensor/device/EMC1413.h"
    /** @brief I2C Address for the currently selected RTC (PCF8523). 
     * @note User can switch to different RTC device by changing ACTIVE_RTC_TYPE macro in userDef.h.
    */
    #define TEMP_SENSOR_CTRL    TEMP_EMC1413_ADDR
    #define TEMP_SENSOR_DRIVER  EMC1413_DRIVER
#else
    #error "Invalid TEMP_SENSOR Configuration in app_config.h"
#endif

#ifdef __cplusplus
}
#endif // C_plusplus

#endif
