////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/******************************************************************************
*
* @file main.c: spiFlashDemo
*
* @brief This demo shows how to use spiFlash_probe to identify Flash and do some
*		 basic flash operation like read/write, it will shows error if missmatch occur.
*
******************************************************************************/
#include <stdio.h>
#include "bsp.h"
#include "userDef.h"

// Include driver
#include "spiFlash/spiFlash.h"

//#define CUSTOM_FLASH 1

/*
* SPI Freq = Fclk/((clkDivider +1)*2)
* where Fclk is the system clock (io_systemClk) to the SoC. If
* you enable the peripheral clock, then Fclk is driven by
* the peripheral clock (io_peripheralClk) instead.
*/
spiFlash_instance_t Flash = {
  .cs = 0,
  .inst = &(spi_instance_t){
              .hwreg      = SPI,
           .cpol       = LOW,
           .cpha       = DATA_SAMPLED_RISE_EDGE,
           .mode       = FULL_DUPLEX_SINGLE_LINE,
           .clkDivider = 15,
           .ssSetup    = 5,
           .ssHold     = 2,
           .ssDisable  = 7
},

};

#ifdef CUSTOM_FLASH
// Custom Flash - Example of how to configure a user-defined flash chip.
// Users are allowed to define the part_no, id, flags, and post-init function.
int custom_chip_setup(void *instance){
    Flash.cmd_wr_status =0x77;
    Flash.mask_qe= 0x40; //Just an example !
    printf("This is a user spiFlash function\n" );
    return 0;
}

// Users should declare a custom table and hook a custom function
// which will execute after initialization.
const spiFlash_info_t user_flash[] = {
    {
        .part_no = "FLASH_X",
        .jedec_id = 0x9D701A00,
        .flags = 0, // This chip is unique!
        .post_init_hook = custom_chip_setup,
    },
};

#endif

void spiFlash_read_write(){
    u8 wr_buf[TEST_LEN];
    u8 rd_buf[TEST_LEN];
    // Fill buffer with dummy data (0, 1, 2, ... 15)
    for(int i=0; i<TEST_LEN; i++) wr_buf[i] = i;

    // Write Operation
    printf("Writing block of %d bytes.\n", TEST_LEN);
    u8 status = spiFlash_write_single(&Flash,FLASH_START_ADDR,wr_buf,TEST_LEN);

    // Read Operation
    printf("Reading block of %d bytes.\n", TEST_LEN);
    spiFlash_read_single(&Flash,FLASH_START_ADDR,rd_buf,TEST_LEN);

    // Matching
    for (u32 i = 0; i < TEST_LEN; i++) {
        if (wr_buf[i] != rd_buf[i]) {
            printf(ANSI_RED"ERR: Index: %x, Address 0x%X not matched:= Wr[0x%X] vs Rd[0x%X] !\n" ANSI_RESET,i,
                    FLASH_START_ADDR+i,wr_buf[i],rd_buf[i]);
            while (1);
        } else
            printf("Addr 0x%x := Wr[0x%X] vs Rd[0x%X]\n", FLASH_START_ADDR + i,wr_buf[i], rd_buf[i]);
    }
}


void main() {
    bsp_init();
    printf(ANSI_RESET "***Starting SPI Flash Demo*** \n");
#ifdef CUSTOM_FLASH
    spiFlash_register(user_flash);
    spiFlash_probe(&Flash);
#else
    spiFlash_probe(&Flash);
#endif
    spiFlash_read_write();
    printf(ANSI_GREEN "OK: Demo ran successfully!\n"ANSI_RESET);
}

