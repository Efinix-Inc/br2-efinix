////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef SRC_RTC_H_
#define SRC_RTC_H_

/**
 * @file rtc.h
 * @author Efinix Inc
 * @brief RTC driver API definitions.
 *
 * This file provides data structures and APIs for controlling
 * the RTC peripheral on the EfxSapphireSoC platform.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "i2c/i2c.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup RTC Real Time Clock (RTC) Driver
 * @brief This module provides Generic Core functions of RTC to configure and control
 * RTC input/output and interrupt behavior.
 * @ingroup timer_group
 * @section Example_RTC Usage & Initialization.
 * This is an example show how to instantiate @ref RTC with @ref rtc_instance_t.
 * 
 * This implementation depends on @ref I2C.
 * 
 * @code 
 * #include "rtc/rtc.h"
 * 
 * // I2C instance configuration
 * #define I2C_FREQ       	100000
 * #define I2C_CTRL_HZ    	SYSTEM_CLINT_HZ
 * #define I2C_CTRL       	(i2c_hwreg_t *)SYSTEM_I2C_0_IO_CTRL
 * 
 * // RTC instance configuration
 * #define RTC_CTRL    	RTC_DS3231_ADDR
 * #define RTC_DRIVER  	ds3231_driver
 * 
 * rtc_instance_t RTC = {
 * 	.drv  = &RTC_DRIVER,
 * 	.inst = &(i2c_instance_t){
 * 		.hwreg      			= I2C_CTRL,
 * 		.slaveAddress			= RTC_CTRL,
 * 		.samplingClockDivider	= 3,
 * 		.timeout				= I2C_CTRL_HZ/1000,
 * 		.tsuDat					= I2C_CTRL_HZ/(I2C_FREQ*5),
 * 		.tLow					= I2C_CTRL_HZ/(I2C_FREQ*2),
 * 		.tHigh					= I2C_CTRL_HZ/(I2C_FREQ*2),
 * 		.tBuf					= I2C_CTRL_HZ/(I2C_FREQ),
 * },
 * };
 *  RTC.drv->applyConfig(&RTC);
 *  RTC.drv->enableErrorInterrupt(&RTC);
 *	RTC.drv->getTime(&RTC);
 *  printf("Current Time: %02d:%02d:%02d\n", RTC.current_time.hours, RTC.current_time.minutes, RTC.current_time.seconds);
 * 
 * @endcode
 * @see Supported_RTC - Learn about the supported Real Time Clock device list.
 * @see @ref rtcDemo "Example RTC Demo" - Learn how to use the driver for Real-Time Clock operations.
 * @{
 */


/* ========================================================================== */
/* SUB-GROUP : Data Types			                                         */
/* ========================================================================== */

/**
 * @defgroup RTC_ENUM Data Types
 * @ingroup RTC
 * @brief Enums used by the driver.
 * @{
 */

    /** @name Callback Enums
     * @brief Enums used for driver callback handling.
     * @note Used to indicate success or failure of RTC operations.
     * @{
     */

        
    /** @brief RTC Status List.
     *	@note Used to indicate the status of RTC operations.
     */
    typedef enum {
        RTC_OK       	= 0,	///< Successful Operation.
        RTC_ERR  		= 1,  	///< Failed to retrieve/write value.
        RTC_USER_ERR   	= 2,  	///< User provide wrong input.
        RTC_SKIP  		= 3, 	///< Skip the function.
    } rtc_status_t;
    /** @} */
/** @} */ // End of RTC_ENUM group


/* ========================================================================== */
/* SUB-GROUP : DATA STRUCTS                                          			*/
/* ========================================================================== */
/**
 * @defgroup RTC_Types Data Structures
 * @ingroup RTC
 * @brief Structs used by the driver.
 * @{
 */

    /** @brief Forward declaration of RTC instance */
    typedef struct rtc_instance rtc_instance_t;

     /**
     * @brief RTC time data structure.
     * @note This structure holds the individual components of time and date.
     */
    typedef struct {
        u8 seconds;			///< Seconds (0-59)
        u8 minutes;			///< Minutes (0-59)
        u8 hours;			///< Hours (0-23 or 1-12)
        u8 PM;				///< PM Indicator for 12-hour format (0 = AM, 1 = PM)
        u8 timesystem;		///< Time System (0 = 24-hour, 1 = 12-hour)
        u8 weekdays;		///< Day of the week (1-7)
        u8 days;			///< Day of the month (1-31)
        u8 months;			///< Month (1-12)
        u8 years;			///< Year (0-99)
    }rtc_data_t;

    /**
     * @brief RTC API structure.
     * @note This structure holds function pointers for RTC operations.
     */
    typedef struct {
        rtc_status_t (*applyConfig) (rtc_instance_t *rtc);				///< Apply i2c config , user can call via @ref rtc_applyConfig as well.
        rtc_status_t (*enableErrorInterrupt)(rtc_instance_t *rtc);		///< Enable error interrupt function pointer, user can call via @ref rtc_enableErrorInterrupt as well.
        rtc_status_t (*getTime)(rtc_instance_t *rtc);					///< Get time function pointer 
        rtc_status_t (*setTime)(rtc_instance_t *rtc);					///< Set time function pointer 
        rtc_status_t (*setTimeSystem)(rtc_instance_t *rtc, u8 mode);	///< Set time system function pointer 
    }rtc_api_t;

    /**
     * @brief RTC instance structure.
     * @note This structure holds the instance data, driver and i2c setting for 
     * 		 an RTC peripheral.
     * 			- inst: Pointer to I2C instance used for RTC communication.	
     * 			- drv:  Pointer to RTC API structure. Uses function pointers for RTC operations.
     * 			- current_time: Current time data structure.
     */
    struct rtc_instance {
        i2c_instance_t	*inst;			///< Pointer to I2C instance.
        const rtc_api_t *drv;			///< Pointer to RTC API structure.
        rtc_data_t		current_time;	///< Current time data.
    };

/** @} */ // End of RTC_Types group

/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup RTC_Funcs API Functions
 * @ingroup RTC
 * @brief Function definitions for RTC driver.
 * @warning Below function are helper function only.
 *  Refer to @ref rtc_api_t for the list of API functions.
 * @{
 */
    /**
     * @brief Wrapper: Apply I2C + RTC configuration.
     * @param rtc Pointer to RTC instance.
     * @return Status code of the operation.
     * @note This is a wrapper function for API function pointer. 
     * User also can call @ref rtc_api_t.applyConfig directly to apply the configuration.
     * Refer to @ref rtc_api_t for more details.
     */
    rtc_status_t rtc_applyConfig(rtc_instance_t *rtc);
    /**
     * @brief Wrapper: Enable RTC error interrupt.
     * @param rtc Pointer to RTC instance.
     * @return Status code of the operation.
     */
    rtc_status_t rtc_enableErrorInterrupt(rtc_instance_t *rtc);
    /**
     * @brief Convert hour register between 12-hour and 24-hour format.
     * @param old_reg_val Original hour register value.
     * @param to_12h Flag indicating conversion direction (1 for 12-hour, 0 for 24-hour).
     * @return Converted hour register value.
     */
    u8 convert_hour_register(u8 old_reg_val, u8 to_12h);
    /** @name RTC (Internal Functions)
     * Helper function.
     * @{
    */
        /**
         * @brief Convert BCD to Binary.
         * @param val BCD value to convert.
         * @return Converted binary value.
         * @note Private function for BCD to binary conversion.
         */
        static inline u8 bcd2bin(u8 val) { return (val & 0x0F) + ((val >> 4) * 10); }
        /**
         * @brief Convert Binary to BCD.
         * @param val Binary value to convert.
         * @return Converted BCD value.
         * @note Private function for binary to BCD conversion.
         */
        static inline u8 bin2bcd(u8 val) { return ((val / 10) << 4) + (val % 10); }
    /** @} */ // End of RTC Internal Functions group

    /** @name RTC (Public API - String Based Functions)
     * Helper function.
     * @{
    */
        /**
         * @brief Get ordinal suffix for a given day.
         * @note Array index 0 is "st", index 1 is "nd", etc..
         */
        extern const char* Day_ordinal [];
        /**
         * @brief Get string representations for Sunday,Monday ,etc..
         * @note Array index 0 is "Unknown", index 1 is "Sunday", etc..
         */
        extern const char* const DayStrings[];
        /**
         * @brief Get string representations for months.
         * @note Array index 0 is "Unknown", index 1 is "January", etc..
         */
        extern const char* const MonthStrings[];
        /**
         * @brief Get string representations for meridiem (AM/PM).
         * @note Array index 0 is "am", index 1 is "pm".
         */
        extern const char* const  meridiem[];
        /**
         * @brief Get ordinal suffix for a given day.
         * @param day Day of the month (1-31).
         * @return Ordinal suffix string ("st", "nd", "rd", "th").
         */
        extern const char* get_ordinal(u8 day);
    /** @} */ // End of RTC Public API - String Based Functions group

/** @} */ // End of RTC_Funcs group

/* ========================================================================== */
/* SUB-GROUP: RTC CONFIGURATION                                               */
/* ========================================================================== */

    /** RTC config **/
    #include "rtc/rtc_config.h"

#ifdef __cplusplus

}
#endif
/** @} */ // End of MAIN RTC Group

#endif /* SRC_RTC_H_ */
