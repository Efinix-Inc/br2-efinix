////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////
#ifndef START_H
#define START_H

#include <stdint.h> 

#ifdef __cplusplus
extern "C" {
#endif

extern void smp_unlock(void (*userMain)(uintptr_t, uintptr_t, uintptr_t));

// #if __riscv_xlen == 64
// extern void smp_unlock(void (*userMain)(u64, u64, u64));
// #elif __riscv_xlen == 32
// extern void smp_unlock(void (*userMain)(u32, u32, u32));
// #endif

#ifdef __cplusplus
}
#endif // C_plusplus

#endif // START_H