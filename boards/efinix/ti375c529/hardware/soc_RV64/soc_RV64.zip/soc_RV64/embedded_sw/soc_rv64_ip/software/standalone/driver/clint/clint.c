////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/**
* @file clint.c
* @brief CLINT driver implementation.
*
* Implements the functions defined in clint.h for controlling
* CLINT input/output and interrupts on the EfxSapphireSoC platform.
* @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
* See the full @ref license_page for Efinix and SaxonSoc MIT terms.
*/

#include "clint/clint.h"

/**
 * @brief Pointer to the CLINT hardware registers.
 */
#define CLINT ((clint_hwreg_t *)SYSTEM_CLINT_CTRL)

/*----------------------------------------------------------------------------*/
/* Function implementations                                                    */
/*----------------------------------------------------------------------------*/

u32 clint_getTimeLow()
{
    return CLINT->MTIME_LOW;
}


u32 clint_getTimeHigh()
{
    return CLINT->MTIME_HIGH;
}


u32 clint_getSoftInterrupt(u32 hart_id)
{
    return CLINT->MSIP[hart_id];
}


u64 clint_getTime()
{
    u32 lo, hi;
    do {
        hi = clint_getTimeHigh();
        lo = clint_getTimeLow();
    } while (clint_getTimeHigh() != hi);
    return (((u64)hi) << 32) | lo;
}


void clint_setCmp(u64 cmp, u32 hart_id)
{
    volatile clint_mtimecmp_hwreg_t *p = &CLINT->MTIMECMP[hart_id];
    p->MTIMECMP_HIGH = 0xFFFFFFFF;       // Set Upper 32-bits (Offset +4 bytes) to Max
    p->MTIMECMP_LOW  = (u32)cmp;         // Set Lower 32-bits (Offset +0 bytes)
    p->MTIMECMP_HIGH = (u32)(cmp >> 32); // Set Upper 32-bits (Offset +4 bytes)
}

void clint_uDelay(u32 usec, u32 hz)
{
    u32 mTimePerUsec = hz/1000000;
    u32 limit = clint_getTimeLow() + usec*mTimePerUsec;
    while((s32)(limit-(clint_getTimeLow())) >= 0);
}


void clint_setSoftInterrupt(clint_msip_t enable, u32 hart_id)
{
    CLINT->MSIP[hart_id] = enable;
}

double clint_getTimeDiff(u64 t0, u64 t1){
    return ((double)(t1-t0)/(double)SYSTEM_CLINT_HZ);
}







