////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/******************************************************************************
*
* @file main.c: uartEchoDemo
*
* @brief This demo shows how to use the UART to print messages on a terminal. 
*        The characters user type on a keyboard are echoed back to the terminal
*        from the SoC and printed on the terminal. 
*
******************************************************************************/
#include <stdio.h>
#include "bsp.h"

/******************************************************************************
*
* @brief This function capture the character that user asserted on keyboard and 
*        printed on the terminal. 
*
******************************************************************************/
void main() {
    char dat;
    bsp_init();
    printf(ANSI_RESET "***Starting Uart Echo Demo*** \n");
    printf("Start typing on terminal to send character... \n");
    while(1)
    {
        while(uart_getReadOccupancy(&uart0)){
            dat=uart_read(&uart0);
            printf("Echo character: %c \n", dat);
        }
    }

}
