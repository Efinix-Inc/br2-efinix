////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/**
* @file spi.c
* @brief SPI driver implementation.
*
* Implements the functions defined in spi.h for controlling
* SPI input/output and interrupts on the EfxSapphireSoC platform.
* @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
* See the full @ref license_page for Efinix and SaxonSoc MIT terms.
*/
#include "spi/spi.h"
#include "bsp.h"

/*----------------------------------------------------------------------------*/
/* Function implementations                                                    */
/*----------------------------------------------------------------------------*/

/**
 * @brief Set SPI Data Mode (Full/Half Duplex, Dual/Quad Line).
 */
void spi_setDataMode(spi_instance_t *inst, enum cfg_mode mode)
{
    inst->mode = mode;
    spi_applyConfig(inst);
}

/**
 * @brief Returns the availability of command buffer space in the SPI buffer
 */
u32 spi_getCmdAvailability(spi_instance_t *inst)
{
    return inst->hwreg->RSP & 0xFFFF;
}

/**
 * @brief Returns the occupancy of the response buffer in the SPI buffer
 */
u32 spi_getRspOccupancy(spi_instance_t *inst)
{
    return inst->hwreg->RSP >> 16;
}

/**
 * @brief Reads a 32-bit data value from the SPI read register.
 */
u32 spi_read32(spi_instance_t *inst)
{
    while(spi_getCmdAvailability(inst) == 0);
    inst->hwreg->CMD = SPI_CMD_RD;
    while(spi_getRspOccupancy(inst) == 0);
    return inst->hwreg->CMD_READLARGE;
}
/**
 * @brief Writes data to and reads data from the SPI data register.
 */
u32 spi_writeRead32(spi_instance_t *inst, u32 data)
{
    while(spi_getCmdAvailability(inst) == 0);
    inst->hwreg->CMD_READWRITELARGE = data;
    while(spi_getRspOccupancy(inst) == 0);
    return inst->hwreg->CMD_READLARGE;
}

/**
 * @brief Reads an 8-bit data value from the SPI read register.
 */
u8 spi_read(spi_instance_t *inst)
{
    while (spi_getCmdAvailability(inst)==0);
    inst->hwreg->CMD =SPI_CMD_RD;
    while(spi_getRspOccupancy(inst) == 0);
    return inst->hwreg->CMD;
}

/**
 * @brief Writes data to and reads data from the SPI data register.
 */
u8 spi_writeRead(spi_instance_t *inst, u8 data)
{
    while(spi_getCmdAvailability(inst) == 0);
    inst->hwreg->CMD = data | SPI_CMD_WR | SPI_CMD_RD;
    while(spi_getRspOccupancy(inst) == 0);
    return inst->hwreg->CMD;
}

/**
 * @brief Applies the current configuration settings stored in the spi_instance_t structure to the SPI hardware registers.
 */
void spi_applyConfig(spi_instance_t *inst)
{
    inst->hwreg->CONFIG			= (inst->cpol << 0) | (inst->cpha << 1) | (inst->mode <<4);
    inst->hwreg->CLOCKDIVIDER 	= inst->clkDivider;
    inst->hwreg->SSSETUP 		= inst->ssSetup;
    inst->hwreg->SSHOLD 		= inst->ssHold;
    inst->hwreg->SSDISABLE 		= inst->ssDisable;
}

/**
 * @brief Writes an 8-bit data value to the SPI data register.
 */
void spi_write(spi_instance_t *inst, u8 data)
{
    while (spi_getCmdAvailability(inst)==0);
    inst->hwreg->CMD = data |SPI_CMD_WR;
}

/**
 * @brief Writes a 32-bit data value to the SPI data register.
 */
void spi_write32(spi_instance_t *inst, u32 data)
{
    while(spi_getCmdAvailability(inst) == 0);
    inst->hwreg->CMD_WRITELARGE = data;
}

/**
 * @brief Selects the SPI slave by asserting the corresponding chip select (CS) line.
 */
void spi_select(spi_instance_t *inst, u32 cs)
{
    while (spi_getCmdAvailability(inst)==0);
    inst->hwreg->CMD = cs | 0x80  | SPI_CMD_SS;
}

/**
 * @brief Deselects the SPI slave by deasserting the corresponding chip select (CS) line.
 */
void spi_deselect(spi_instance_t *inst, u32 cs)
{
    while (spi_getCmdAvailability(inst)==0);
    inst->hwreg->CMD = cs | 0x00  | SPI_CMD_SS;
}

/**
 * @brief Check SPI if it has any command waiting to be executed in queue.
 */
u32 spi_isBusy(spi_instance_t *inst)
{
    return inst->hwreg->INTERRUPT & SPI_CMD_VALID;
}


/**
 * @brief Waits for SPI if it has any command waiting to be executed in queue.
 */
void spi_waitUntilIdle(spi_instance_t *inst){

    while (spi_isBusy(inst) != 0);
}
