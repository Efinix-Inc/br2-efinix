////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef SRC_USERDEF_H_
#define SRC_USERDEF_H_

#ifdef __cplusplus
extern "C" {
#endif

/* -----------------------------------------------------------------------------*/
/*  HARDWARE CONFIGURATION
/* -----------------------------------------------------------------------------*/
#define I2C_CTRL_HZ    						SYSTEM_CLINT_HZ
#define I2C_CTRL       						(i2c_hwreg_t *)SYSTEM_I2C_0_IO_CTRL
#define I2C_FREQ       						100000

/* -----------------------------------------------------------------------------*/
/*  USER CONFIGURATION
/* -----------------------------------------------------------------------------*/
#define EXTENDED_RANGE_ENABLED  	  		0 //If set to 0, means range of temp measurement from 0°C to +127°C (Default)
                                               //If set to 1, means range of temp measurement from -64°C to +191°C (Extended Range enabled)
#define HIGH_TEMPERATURE_LIMIT_VALUE_INT  	85 //High limit temp for internal temperature sensor in EMC1413 itself.
#define LOW_TEMPERATURE_LIMIT_VALUE_INT   	0 //Low  limit temp for temperature sensor 1 on Ti375C529.

#define HIGH_TEMPERATURE_LIMIT_VALUE_EXT1 	85 //High limit temp for internal temperature sensor in EMC1413 itself.
#define LOW_TEMPERATURE_LIMIT_VALUE_EXT1   	0  //Low  limit temp for temperature sensor 1 on Ti375C529.

#define HIGH_TEMPERATURE_LIMIT_VALUE_EXT2  	85 //High limit temp for internal temperature sensor in EMC1413 itself.
#define LOW_TEMPERATURE_LIMIT_VALUE_EXT2   	0  //Low  limit temp for temperature sensor 1 on Ti375C529.

/* -----------------------------------------------------------------------------*/
/*  SENSOR Selection
/* -----------------------------------------------------------------------------*/
// --- TEMP_SENSOR Selection ---
#define SENSOR_TYPE_EMC1413		1
#define SENSOR_TYPE_CUSTOM    	2 // User's Sensor

/* --- Add custom driver here or main.c -- */
//	#include "sensor/device/custom.h"
//	#define TEMP_SENSOR_CTRL  	TEMP_CUSTOM_ADDR
//	#define TEMP_SENSOR_DRIVER   custom_driver

// User Selects Here:
#define ACTIVE_TEMP_SENSOR_TYPE    SENSOR_TYPE_EMC1413

/* -----------------------------------------------------------------------------*/
/*  USER DEBUG CONFIGURATION
/* -----------------------------------------------------------------------------*/
// --- DEBUG_MODE --- 
    // 0 = Asserts OFF, Logs removed
    // 1 = Asserts ON, Logs filtered
#define DEBUG_MODE 1
// --- ACTIVE_DEBUG_MOD --- This is the list of available module to debug
    // DBG_MOD_SYS          // Enable Log for RISCV Extension
    // DBG_MOD_IRQ          // Enable Log for IRQ, mtrap
    // DBG_MOD_FAULT        // Enable Log for System Fault  
    // DBG_MOD_UART         // Enable Log for UART Driver
    // DBG_MOD_I2C          // Enable Log for I2C Driver   
    // DBG_MOD_SPI          // Enable Log for SPI Driver
    // DBG_MOD_SPI_FLASH    // Enable Log for SPI FLASH Driver
    // DBG_MOD_RTC          // Enable Log for RTC Driver
    // DBG_MOD_CAM          // Enable Log for CAM Driver
    // DBG_MOD_SENSOR       // Enable Log for Sensor (temp sensor)
    // DBG_MOD_MAIN         // Enable Log for main.c
    // DBG_MOD_ALL          // Enable all Logs
#define ACTIVE_DEBUG_MOD   DBG_MOD_MAIN | DBG_MOD_SYS | DBG_MOD_IRQ

// --- ACTIVE_MIN_LVL ---
    // DBG_LVL_ALL     0   // Show Info, Warn, Error
    // DBG_LVL_WARN    1   // Show Warn, Error
    // DBG_LVL_ERR     2   // Show Error only
    // DBG_LVL_NONE    3   // Silence
#define ACTIVE_MIN_LVL   DBG_LVL_ALL


#ifdef __cplusplus
}
#endif // C_plusplus

#endif /* SRC_USERDEF_H_ */
