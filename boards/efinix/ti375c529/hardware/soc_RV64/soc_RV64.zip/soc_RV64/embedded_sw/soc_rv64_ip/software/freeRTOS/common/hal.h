//*------------------------------------------------------------------------------------------
//  MIT License
//
//  Copyright (c) 2025 SaxonSoc contributors
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.
//*------------------------------------------------------------------------------------------
#ifndef HAL_H_
#define HAL_H_

#include "FreeRTOS.h"
#include "task.h"
#include "portmacro.h"
#include "bsp.h"
#include "plic.h"

/**
 * @brief Machine-mode external interrupt handler, called by the FreeRTOS
 *        RISC-V port via portasmHANDLE_INTERRUPT.
 *
 * Each hart has its own PLIC context.  The MEI (Machine External Interrupt)
 * context index for hart K is SYSTEM_PLIC_CPU_0_MEI + (K * 2), matching the
 * soc.h layout:
 *
 *   Hart 0 MEI → SYSTEM_PLIC_CPU_0_MEI (0)
 *   Hart 1 MEI → SYSTEM_PLIC_CPU_1_MEI (2)
 *   Hart 2 MEI → SYSTEM_PLIC_CPU_2_MEI (4)
 *   Hart 3 MEI → SYSTEM_PLIC_CPU_3_MEI (6)
 *
 * Using BSP_PLIC_CPU_0 unconditionally would cause harts 1-3 to claim and
 * release interrupts from hart 0's PLIC context, which is incorrect on a
 * multi-hart SoC.
 */
void external_interrupt_handler(void)
{
    /* Read the hardware thread ID from the mhartid CSR. */
    unsigned long hartId;
    __asm__ volatile ("csrr %0, mhartid" : "=r" (hartId));

    /*
     * Derive the PLIC claim/complete context for this hart.
     * SYSTEM_PLIC_CPU_x_MEI values in soc.h are 0, 2, 4, 6 for harts 0-3,
     * so each hart's MEI context = SYSTEM_PLIC_CPU_0_MEI + (hartId * 2).
     */
    uint32_t plicCtx = (uint32_t)(SYSTEM_PLIC_CPU_0_MEI + (hartId * 2u));

    uint32_t claim;
    while ((claim = plic_claim(BSP_PLIC, plicCtx)) != 0u) {
        switch (claim) {
            /* Add peripheral interrupt cases here, e.g.:
             * case SYSTEM_UART_0_IO_INTERRUPT:
             *     uart_irq_handler();
             *     break;
             */
            default:
                /* Unexpected interrupt source — release and continue. */
                break;
        }
        plic_release(BSP_PLIC, plicCtx, claim);
    }
}

#endif /* HAL_H_ */
