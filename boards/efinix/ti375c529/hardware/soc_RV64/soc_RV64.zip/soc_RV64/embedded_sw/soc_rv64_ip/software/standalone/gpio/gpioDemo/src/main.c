////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/******************************************************************************
*
* @file main.c: GpioDemo (onBoard LED Blinking Demo)
*
* @brief This demo performs onboard LED blinking through GPIO controller 
*        and allow external interrupt by user. 
*
******************************************************************************/
#include <stdio.h>
#include "bsp.h"
#include "userDef.h"
#include "irq.h"

// Include driver
#include "gpio/gpio.h"

extern void trap_entry();

//Store the count of interrupt happened
u32 count;


/******************************************************************************
*
* @brief This GPIO IRQ function will keep on counting once enter interrupt routine.
*
******************************************************************************/
int irq_m_gpio0_0_handler(){
    printf("Entering gpio interrupt routine .. \n");
    bsp_uDelay(100);
    count++;
    printf("Count:%d .. Done \n",count);
    return 0;
}

/******************************************************************************
*
* @brief This instance is used to configure GPIO setting.
*
******************************************************************************/
gpio_instance_t gpio_0 = {
    .hwreg		    = GPIO_0,
    .output         = 0x00, // Set GPIO Output pin Value
    .outputEnable   = 0x0E, // Set to Enable GPIO pin as OUTPUT.
};

/******************************************************************************
*
* @brief This instance is used to configure ISR for GPIO.
*
******************************************************************************/
void gpio_isr_init(){
    plic_instance_t gpio_plic = {
        // Set Target to handler external interrupt
        .target 	= BSP_PLIC_CPU_0,
        // Interrupt source ID
        .gateway 	= SYSTEM_GPIO_0_IO_INTERRUPTS_0,
        // Priority Level: 0=Disable, 1=Low, 3=Highest
        .priority   = 0x1U, 
        // Interrupt Enable Bit (1=Enable)
        .enable     = 0x1U, 
        // Threshold: CPU accepts any priority > 0
        .threshold  = 0x0U,
    };
    // Apply Config for PLIC & GPIO setting
    plic_applyConfig(&gpio_plic);
    gpio_setInterruptRiseEnable(&gpio_0, 0x1U);

    // Initialize IRQ Sequence
    irq_setTrapVector(trap_entry);
    irq_setType(IRQ_EXTERNAL);
    irq_enable();

}

/******************************************************************************
*
* @brief This main function initializes the board, configures GPIO 0 to control onboard
*        LEDs, and then sets up a loop to blink the LEDs. After that, it 
*        demonstrates GPIO 0 interrupt handling by instructing the user to press
*        and release various onboard buttons (sw4, sw6, sw7) corresponding to
*        different timer intervals.
*
******************************************************************************/

void main() {
    bsp_init();
    printf(ANSI_RESET "***Starting GPIO Demo*** \n");
    printf("Configure GPIOs to blink .. \n");
    // Set GPIO to output
    gpio_applyConfig(&gpio_0);
    for (int i=0; i<50; i=i+1) {
        gpio_setOutput(&gpio_0, gpio_getOutput(&gpio_0) ^ 0xe);
        bsp_uDelay(LOOP_UDELAY);
    }   
    printf("***Starting GPIO Interrupt Demo*** \n");
    printf("Press and release onboard button sw4 .. \n");
    gpio_isr_init();
    while(1); 
}


