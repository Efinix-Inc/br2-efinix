////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2025 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef TEMPERATURE_DRIVER_EMC1413_H_
#define TEMPERATURE_DRIVER_EMC1413_H_

/**
 * @file EMC1413.h
 * @author Efinix Inc
 * @brief EMC1413 Temperature Sensor Driver API definitions.
 * This file provides data structures and APIs for controlling
 * the EMC1413 Temperature Sensor device on the EfxSapphireSoC platform.
 * @note This is a device-specific driver implementation for the EMC1413 Temperature Sensor.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "sensor/temp_sensor/temp_sensor.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup Supported_TEMP_SENSOR Supported Devices
 * @ingroup TEMP_SENSOR
 * @brief Supported Temperature Sensor devices.
 * 
 * @note This module provides device-specific drivers for various Temperature Sensor hardware that currently supported by Efinix.
 *      - User may add their custom Temperature Sensor device drivers based on this framework.
 * @{
 */

/**
 * @defgroup EMC1413_Config EMC1413 Temperature Sensor Driver
 * @ingroup Supported_TEMP_SENSOR
 * @brief EMC1413 Temperature Sensor driver definitions.
 * 
 * @note This is a device-specific driver implementation for the EMC1413 Temperature Sensor.
 * @{
 */

/* ========================================================================== */
/* SUB-GROUP : REGISTER DEFINITIONS                                          */
/* ========================================================================== */

/**
 * @defgroup EMC1413_Macros Register Definitions
 * @ingroup EMC1413_Config
 * @brief Register bitmasks and offsets.
 * @{
 */
    /**
     * @brief I2C Address for I2C MUX.
     * @note Used to select the correct I2C channel for the EMC1413 device.
     */
    #define MUX_ADDR			0x71<<1
    /**
     * @brief I2C Address for EMC1413 Temperature Sensor device.
     */
    #define TEMP_EMC1413_ADDR	0x4C<<1

/** @} */ // End of EMC1413_Macros group

/* ========================================================================== */
/* SUB-GROUP : Driver Definition                                        */
/* ========================================================================== */

/**
 * @defgroup EMC1413_DRV Driver Structure
 * @ingroup Supported_TEMP_SENSOR
 * @brief This is the EMC1413 driver structure.
 * @{
 */
    /**
     * @brief EMC1413 Driver Instance.
     * Point your generic Temperature Sensor pointer to this structure to use the EMC1413.
     * @note Implements the following hooks from @ref temp_sensor_api_t:
     *          - **getTemp**: Reads temperature value from sensor, implemented by EMC1413_getTemp.  
     *          - **getTempLimit**: Reads temperature limit values from sensor, implemented by EMC1413_getTempLimit.  
     *          - **setTempRange**: Sets the temperature range mode, implemented by EMC1413_setTempRange.
     *          - **setTempLimit**: Sets the temperature limit values, implemented by EMC1413_setTempLimit.
     *          - **checkTempRange**: Checks if temperature is within range, implemented by EMC1413_checkTempRange.
     *          - **checkTempAlert**: Checks for temperature alerts, implemented by EMC1413_checkTempAlert.
     * @see temp_sensor_api_t
     * @code
     * // Example Usage:
     * temp_sensor_api_t *my_temp = &EMC1413_DRIVER;
     * my_temp->getTemp(&t);
     * @endcode
     */
    extern const temp_sensor_api_t EMC1413_DRIVER;

    /** @} */ // End of EMC1413_DRV group

/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup EMC1413_Funcs API Functions
 * @ingroup EMC1413_Config
 * @brief Function definitions for EMC1413 driver.
 * @note This is the public API for the EMC1413 Temperature Sensor device.
 * @{
 */
     /**
     * @brief Apply I2C + Temp Sensor configuration.
     * @param rtc Pointer to Temperature Sensor instance.
     * @return Status code of the operation.
     */
    temp_sensor_status_t EMC1413_applyConfig(temp_sensor_instance_t *temp);
     /**
     * @brief Enable error interrupt for EMC1413 Temperature Sensor.
     * @param rtc Pointer to Temperature Sensor instance.
     * @return Status code of the operation.
     */
    temp_sensor_status_t EMC1413_enableErrorInterrupt(temp_sensor_instance_t *temp);
    /**
     * @brief Get temperature from EMC1413 Temperature Sensor.
     * @param temp Pointer to Temperature Sensor instance.
     * @return Status code of the operation.
     */
    temp_sensor_status_t EMC1413_getTemp(temp_sensor_instance_t *temp);
    /** 
     * @brief Get temperature limits from EMC1413 Temperature Sensor.
     * @param temp Pointer to Temperature Sensor instance.
     * @return Status code of the operation.
     */
    temp_sensor_status_t EMC1413_getTempLimit(temp_sensor_instance_t *temp) ;
    /**
     * @brief Check if temperature is within range for EMC1413 Temperature Sensor.
     * @param temp Pointer to Temperature Sensor instance.
     * @return Status code of the operation.
     */
    u8 EMC1413_checkTempRange(temp_sensor_instance_t *temp);
    /**
     * @brief Check for temperature alerts from EMC1413 Temperature Sensor.
     * @param temp Pointer to Temperature Sensor instance.
     * @return Status code of the operation.
     */
    temp_sensor_status_t EMC1413_checkTempAlert(temp_sensor_instance_t *temp);
    /**
     * @brief Set temperature range for EMC1413 Temperature Sensor.
     * @param temp Pointer to Temperature Sensor instance.
     * @param enable_extended Flag to enable extended temperature range.
     * @return Status code of the operation.
     */
    temp_sensor_status_t EMC1413_setTempRange(temp_sensor_instance_t *temp, u8 enable_extended);
    /**
     * @brief Set temperature limits for EMC1413 Temperature Sensor.
     * @param temp Pointer to Temperature Sensor instance.
     * @return Status code of the operation.
     */
    temp_sensor_status_t EMC1413_setTempLimit(temp_sensor_instance_t *temp);

/** @} */ // End of EMC1413_Funcs group
#ifdef __cplusplus
}
#endif // C_plusplus

/** @} */ // End of MAIN EMC1413 Group

/** @} */ // End of MAIN Supported_TEMP_SENSOR Group
#endif // EMC1413_H_