////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef SPI_FLASH_H
#define SPI_FLASH_H

/**
 * @file spiFlash.h
 * @author Efinix Inc
 * @brief SPI Flash driver API definitions.
 *
 * This file provides data structures and APIs for controlling
 * the SPI Flash peripheral on the EfxSapphireSoC platform.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include <string.h>
#include "spi/spi.h"
#include "spiFlash/spiFlash_list.h"

#ifdef __cplusplus
extern "C" {
#endif

// ToDo:
// Add spiFlash_read that handle multi-read support (Single,Dual,Quad) based on user's struct. 
// Add spiFlash_write that handle multi-write support (Single,Dual,Quad) based on user's struct.
// Add a safe guard where it set to single line mode when configure flash such as write/read status reg.

/**
 * @defgroup SPI_FLASH SPI Flash Driver
 * @brief Serial Peripheral Interface (SPI) Flash driver.
 * @ingroup comm_group
 *
 * This module provides functions to configure and control
 * SPI Flash input/output and interrupt behavior.
 * @section Example_SPI_Flash Usage & Initialization
 *  This is an example show how to instantiate @ref SPI_FLASH with @ref spiFlash_instance_t.
 * 
 * @note <b> Instead of using @ref spiFlash_applyConfig, Efinix recommends users to call @ref spiFlash_probe which will do the following sequence: </b>
 * - Initialize the SPI driver with the user configuration (falls back to 
 * default settings if input is invalid).
 * - Release the flash from Deep Power-Down mode.
 * - Read the JEDEC ID.
 * - Identify the SPI Flash by cross-referencing the detected ID with 
 * 	 the User Flash Table and Known Flash Table.
 * - Load default commands for 4-byte exit, status read, and status write.
 * - Check for and apply hardware quirks for special handling.
 * - Ensure the device returns to 3-Byte Addressing Mode.
 * - Execute the user-provided custom setup function (post_init_hook).
 * 
 * @code 
 * #include "spiFlash/spiFlash.h"
 * 
 * spiFlash_instance_t Flash = {
 *   .cs = 0,
 *   .inst = &(spi_instance_t){
 * 	   	   .hwreg      = SPI,
 * 		   .cpol       = LOW,
 * 		   .cpha       = DATA_SAMPLED_RISE_EDGE,
 * 		   .mode       = FULL_DUPLEX_SINGLE_LINE,
 * 		   .clkDivider = 15,
 * 		   .ssSetup    = 5,
 * 		   .ssHold     = 2,
 * 		   .ssDisable  = 7
 * },
 * 
 * spiFlash_probe(&Flash);
 * 
 * @endcode
 * 
 * @see @ref spiFlashDemo "Example SPI Flash Demo" - Learn how to use the driver for interacting with Flash devices
 * @see @ref Example_Custom_Flash - Learn how to register a custom flash chip via @ref spiFlash_register.
 * @see SPI_FLASH_LIST - Learn about the known flash database and Capability flags.
 * @see  [<b> Known Flash Table </b>](spi_flash__list_8c_source.html#L20)  - Learn about the supported flash list.
 * @see @ref SPI_FLASH_Funcs - Learn about the available Flash API functions.
 * 
 * @{
 */

/* ========================================================================== */
/* SUB-GROUP : REGISTER DEFINITIONS                                           */
/* ========================================================================== */

/**
 * @defgroup SPI_FLASH_Macros Register Definitions
 * @ingroup SPI_FLASH
 * @brief Standard SPI Flash command definitions.
 * @{
 */

    /** @name ID & Discovery
     * @brief Standard SPI Flash Identification Commands.
     * @note Used during initialization to identify the connected SPI Flash device.
     * @{
     */
        #define CMD_READ_JEDEC_ID           0x9F  ///< Standard Read JEDEC ID (Manuf + Type + Cap).
        #define CMD_READ_DEVICE_ID          0xAB  ///< Standard Read device ID (legacy).
    /** @} */

    /** @name Status Register Commands
     * @brief Standard SPI Flash Status Register Commands.
     * @note Used to read and write status registers of the SPI Flash device.
     * @{
     */
        #define CMD_READ_STATUS_REG_1       0x05  ///< Standard Read Status Register 1 (WIP, WEL, BP). 
        #define CMD_READ_STATUS_REG_2       0x35  ///< Read Status Register 2 (*QE for Winbond). 
        #define CMD_READ_STATUS_REG_3       0x15  ///< Read Status Register 3 (*Winbond). 
        #define CMD_WRITE_STATUS_REG_1      0x01  ///< Standard Write SR1 (Macronix/ISSI/Standard). 
        #define CMD_WRITE_STATUS_REG_2      0x31  ///< Write SR2 (*Winbond Specific Quirk). 
        #define CMD_WRITE_STATUS_REG_3      0x11  ///< Write SR3.
    /** @} */

    /** @name Standard Write Commands
     * @brief Standard SPI Flash Standard Commands.
     * @note Used to perform standard write operations on the SPI Flash device.
     * @{
     */
        #define CMD_PAGE_PROGRAM            0x02  ///< Standard Write Page (256 Bytes). 
        #define CMD_QUAD_PAGE_PROGRAM       0x32  ///< Standard Write Page (256 Bytes). 
        #define CMD_WRITE_ENABLE            0x06  ///< Standard Set WEL Bit. 
        #define CMD_WRITE_DISABLE           0x04  ///< Standard Clear WEL Bit. 
    /** @} */

    /** @name Standard Read Commands
     * @brief Standard SPI Flash Read Commands.
     * @note Used to perform standard read operations on the SPI Flash device.
     * @{
     */
        #define CMD_READ_DATA               0x03 ///< Standard Read (up to 33MHz). 
        #define CMD_FAST_READ               0x0B ///< Standard Read at higher speed. 
        #define CMD_DUAL_OUTPUT_READ        0x3B ///< Standard Double throughput in read mode.
        #define CMD_QUAD_OUTPUT_READ        0x6B ///< Standard Quad throughput in read mode.
    /** @} */

    /** @name Standard Misc Commands
     * @brief Standard SPI Flash Standard Commands.
     * @note Used for miscellaneous operations on the SPI Flash device.
     * @{
     */
        #define CMD_RELEASE_DEEP_POWER_DOWN 0xAB  ///< Standard Release flash from deep power down. 
        #define CMD_ENABLE_RESET            0x66  ///< Standard Reset Enable. 
        #define CMD_RESET_DEVICE            0x99  ///< Standard Trigger Reset. 
        #define CMD_GLOBAL_LOCK             0x7E  ///< Standard Global Block Lock. 
        #define CMD_GLOBAL_UNLOCK           0x98  ///< Standard Global Block Unlock. 
        #define CMD_ENABLE_QPI          	0x38  ///< To enable Quad Mode, need to write to this register for (*GigaDevice Quirk). 
    /** @} */

    /** @name Standard 4-Byte Addressing Commands
     * @brief Standard SPI Flash 4-Byte Addressing Commands.
     * @note Used for 4-byte addressing operations on the SPI Flash device.
     * - Only applicable for devices larger than 16MB.
     * @{
     */
        #define CMD_ENTER_4B                0xB7  ///< Standard Enter 4-Byte Mode (Stateful).
        #define CMD_EXIT_4B                 0xE9  ///< Standard Exit 4-Byte Mode (Standard).
        #define CMD_EXIT_4B_ISSI            0x29  ///< Exit 4-Byte Mode (*ISSI Quirk).
        #define CMD_DUAL_OUTPUT_READ_4B     0x3C  ///< Standard Double throughput in read mode, 4-byte Mode.
        #define CMD_QUAD_OUTPUT_READ_4B     0x6C  ///< Standard Quad throughput in read mode, 4-byte Mode.
        #define CMD_READ_4B                 0x13  ///< Standard Read Data with 32-bit Address.
        #define CMD_PROGRAM_4B              0x12  ///< Standard Page Program with 32-bit Address.
        #define CMD_SECTOR_ERASE            0x20  ///< Standard Erase 4KB Sector.
        #define CMD_ERASE_4K_4B             0x21  ///< Standard Sector Erase with 32-bit Address.
        #define CMD_ERASE_64K_4B            0xDC  ///< Standard Block Erase with 32-bit Address.
    /** @} */

    /** @name Misc Macros
     * @brief Standard SPI Flash Miscellaneous Macros.
     * @{
     */
        #define QE_BIT6    0x40 ///< This Macro specifically for Macronix & ISIS Flash to enable Quad Mode.
        #define QE_BIT1    0x02 ///< This Macro specifically for Windbond Flash to enable Quad Mode.
        #define WEL_BIT    0x02 ///< Write Enable Latch Bit in Status Reg.
    /** @} */

/** @} */ // End of SPI_FLASH_Macros group


/* ========================================================================== */
/* SUB-GROUP : Data Types                                                     */
/* ========================================================================== */

/**
 * @defgroup SPI_FLASH_ENUM Data Types
 * @ingroup SPI_FLASH
 * @brief Enums used by the driver.
 * @{
 */
    /** @name Configuration Enums
     * @brief Enums used for driver initialization.
     * @{
     */
        /** @brief SPI Flash transfer mode configuration. 
        * @note Used to indicate the status of SPI Flash operations.
        */
        typedef enum {
            SPI_FLASH_OK        = 0,    ///< Successful Operation.
            SPI_FLASH_ERR       = 1,    ///< Unknown JEDEC ID, Electrical failure (0x00/0xFF).
            SPI_FLASH_SKIP      = 2,    ///< Skip the function.
        } spiFlash_status_t;
    /** @} */

/** @} */ // End of SPI_FLASH_ENUM group

/* ========================================================================== */
/* SUB-GROUP : DATA STRUCTS                                                   */
/* ========================================================================== */
/**
 * @defgroup SPI_FLASH_Types Data Structures
 * @ingroup SPI_FLASH
 * @{
 */
    /**
     * @brief SPI Flash instance structure.
     * @note This structure holds the instance data, driver and SPI setting for 
     * an SPI Flash peripheral.
     * - **inst**: Pointer to SPI instance used for SPI Flash communication.   
     * - **info**: Pointer to Flash Descriptor structure.
     * - **detected_id**: Detected JEDEC ID after probing.
     * - **cs**: Chip select line used for SPI Flash communication.
     * - **cmd_rd_status**: Command for reading status register.
     * - **cmd_wr_status**: Command for writing status register.
     * - **cmd_exit_4byte**: Command for exiting 4-byte addressing mode.
     * - **mask_qe**: Mask for Quad Enable bit in status register.
     * 
     * All the content such as @ref SPI_FLASH_JEDECS, part_no and post_init_hook will
      * be stored in @ref spiFlash_instance_t that user declared initially.
     */
    typedef struct{
        spi_instance_t          *inst;          ///< Pointer to shared SPI Master. 
        const spiFlash_info_t   *info;          ///< Flash Descriptor. 
        u32                     detected_id;    ///< JEDEC_ID = Manu_id, mem_type, capacity. 
        u8                      cs;             ///< Chip select. 

        // Command 
        u8 cmd_rd_status;   ///< CMD for Read Status 
        u8 cmd_wr_status;   ///< CMD for Write Status 
        u8 cmd_exit_4byte;  ///< CMD for exit 4 byte addressing 
        u8 mask_qe;         ///< CMD for Quad Enable Bit 

    } spiFlash_instance_t;

/** @} */ // End of SPI_FLASH_Types group

/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                       */
/* ========================================================================== */

/**
 * @defgroup SPI_FLASH_Funcs API Functions
 * @ingroup SPI_FLASH
 * @brief Function definitions for SPI Flash driver.
 * @{
 */

    /** @name SPI Flash (Public API -Initialization)
     * Used to initialize SPI Flash.
     * @{
     */
        /**
         * @brief Select spi and wake up SPI Flash.
         * @param flash Pointer to SPI Flash Instance.
         * @note Make sure to used it to ensure the device is in operation
         * state before start communicate with the device.
         */
        void spiFlash_wake(spiFlash_instance_t *flash);
        /**
         * @brief Apply stored SPI Flash configuration to hardware.
         * @param inst Pointer to SPI Flash instance.
         * @note Refer to @ref spi_applyConfig for more details.
         */
        void spiFlash_applyConfig(spiFlash_instance_t *flash);

        /** 
         * @brief High level Wrapper to register Custom Flash to the driver.
         * @param table Pointer to SPI Flash Info Instance.
         * @param count The number of entry in the table.
         * @warning User should use this macro to register flash, and it will call 
         * @ref spiFlash_registerFlash to store the pointer and count of user flash 
         * table.
         */
        #define spiFlash_register(table) \
            spiFlash_registerFlash((table), sizeof(table) / sizeof((table)[0]))
            
        /** 
         * @brief Register Custom Flash to the driver.
         * @param table Pointer to SPI Flash Info Instance.
         * @param count The number of entry in the table.
         * @warning User should use @ref spiFlash_register to register flash, 
         * and it will call @ref spiFlash_registerFlash to store the pointer 
         * and count of user flash table.
         */
        void spiFlash_registerFlash(const spiFlash_info_t *table, size_t count);

        /** 
         * @brief Initialize SPI setting.
         * @param flash Pointer to SPI Flash Instance.
         * @note It will check if user provide a correct value to SPI setting.
         * Else, default value is used.
         */
        void spiFlash_initController(spiFlash_instance_t *flash);

        /** 
         * @brief Main wrapper function to initialize the SPI Flash.
         * @param flash      Pointer to the SPI Flash instance.
         * @warning Efinix recommends that users use spiFlash_probe for 
         * initialization instead of calling spiFlash_applyConfig directly.
         * @note The initialization sequence is as follows:
         * - Initialize the SPI driver with the user configuration (falls back to 
         * default settings if input is invalid).
         * - Release the flash from Deep Power-Down mode.
         * - Read the JEDEC ID.
         * - Identify the SPI Flash by cross-referencing the detected ID with 
         * 	 the User Flash Table and Known Flash Table.
         * - Load default commands for 4-byte exit, status read, and status write.
         * - Check for and apply hardware quirks for special handling.
         * - Ensure the device returns to 3-Byte Addressing Mode.
         * - Execute the user-provided custom setup function (post_init_hook).
         * @return spiFlash_status_t Status of the initialization process.
         */
        spiFlash_status_t spiFlash_probe(spiFlash_instance_t * flash);
        
    /** @} */
    
    /** @name SPI Flash (Public API - Identification)
     * Used to identify SPI Flash.
     * @{
     */
        /**
         * @brief Select and Read Device ID from spiFlash.
         * @param flash Pointer to SPI Flash Instance.
         * @return SPI Flash status
         */
        u8 spiFlash_readId(spiFlash_instance_t *flash);
        
        /**
         * @brief Select and read JEDEC ID from spiFlash.
         * @param flash Pointer to SPI Flash Instance.
         * @return SPI Flash status
         */
        u32 spiFlash_readJedecId(spiFlash_instance_t *flash);

        /**
         * @brief Identify SPI Flash by looking up User Flash Table and known flash table.
         * @param detected_id Detected JEDEC ID.
         * @param table Pointer to SPI Flash Info Instance.
         * @return SPI Flash Info
         * @note The sequence of the function:
         * - Check User Flash Table, if exist, return SPI Flash Info.
         * - Fall Back to Known Flash Table if user Flash doesn't exist/match.
         * - If match, then return the table info.
         * - Else, return NULL.
         */
        const spiFlash_info_t * spiFlash_lookup(u32 detected_id);

        /**
        * @brief Verify spiFlash.
        * @param flash Pointer to SPI Flash Instance.
        * @return SPI Flash Status
        * @note The following are the sequence:
        *       1. Call @ref spiFlash_readJedecId to obtain jedec_id.
        *       2. Hardware Sanity Check.
        *       3. Call @ref spiFlash_lookup to ensure there is known flash.
        *       4. Return SPI Flash Status.
        */
        spiFlash_status_t spiFlash_verify(spiFlash_instance_t *flash);

        /** 
         * @brief Handle those spiFlash that have unique register/way.
         * @param flash Pointer to SPI Flash Instance.
         * @note This function apply for write protection, 4-byte exit cmd, quad enable
         */
        void spiFlash_applyQuirks(spiFlash_instance_t *flash);
    /** @} */

    /** @name SPI Flash (Public API - Read/Write Operation)
     * Used for read/write SPI Flash.
     * @{
     */
        /**
         * @brief Read Status Register
         * @param flash Pointer to SPI Flash Instance.
         * @return Value of status
         */
        u8 spiFlash_readStatusReg(spiFlash_instance_t *flash);
        
        /**
         * @brief Write Status Register
         * @param flash Pointer to SPI Flash Instance.
         * @param data 8-bit data.
         */
        void spiFlash_writeStatusReg(spiFlash_instance_t *flash,u8 data);
        
        /**
         * @brief Write N byte to Flash using standard write mode via single Data Line.
         * @param flash Pointer to SPI Flash Instance.
         * @param flashAddress The Flash address to read the data
         * @param src The source of data to be written.
         * @param len The length of data to be written.
         * @return SPI Flash Status.
         * @note Used to write 256 byte Only!
         */
        u8 spiFlash_write_single(spiFlash_instance_t *flash, u32 flashAddress, u8 *src, u32 len);
        
        /**
         * @brief Read N byte from Flash using standard read mode via single Data Line.
         * @param flash Pointer to SPI Flash Instance.
         * @param flashAddress The Flash address to read the data
         * @param buffer The variable that stored the data.
         * @param len The length of data to be read.
         */
        void spiFlash_read_single(spiFlash_instance_t *flash, u32 flashAddress, u8 *buffer, u32 len);
        
        /**
        * @brief This function read data from FlashAddress and copy to memoryAddress of 
        *        specific size with single data line.
        * @param spi SPI port base address
        * @param flashAddress The flash address to read the data
        * @param memoryAddress The RAM address to write the data
        * @param size The size of data to copy
        */
        void spiFlash_f2m_single(spiFlash_instance_t *flash, u32 flashAddress, uintptr_t memoryAddress, u32 size);

        /**
        * @brief This function read data from FlashAddress and copy to memoryAddress of 
        *        specific size with dual data line.
        * @param spi SPI port base address
        * @param flashAddress The flash address to read the data
        * @param memoryAddress The RAM address to write the data
        * @param size The size of data to copy
        * @note Make sure hardware need to connect both Data0 and Data1 port. Else, it would not work. 
        */
        void spiFlash_f2m_dual(spiFlash_instance_t *flash, u32 flashAddress, uintptr_t memoryAddress, u32 size);

        /**
        * @brief This function read data from FlashAddress and copy to memoryAddress of 
        *        specific size with quad data line.
        * @param spi SPI port base address
        * @param flashAddress The flash address to read the data
        * @param memoryAddress The RAM address to write the data
        * @param size The size of data to copy
        * @note Make sure hardware need to connect all data ports. Else, it would not work. 
        */
        void spiFlash_f2m_quad(spiFlash_instance_t *flash, u32 flashAddress, uintptr_t memoryAddress, u32 size);


    /** @} */

    /** @name SPI Flash (Public API - Configuration)
     * Used to configure SPI Flash setting.
     * @{
     */
        /**
         * @brief Wait for spiFlash to be free.
         * @param flash Pointer to SPI Flash Instance.
         * @return SPI Flash status, 1 -> timeout, 0-> Ok
         */
        spiFlash_status_t spiFlash_waitBusy(spiFlash_instance_t *flash);
        
        /**
         * @brief Exit 4-byte addressing.
         * @param flash Pointer to SPI Flash Instance.
         * @return SPI Flash status, 3-> skip
         */
        u8 spiFlash_exit4ByteAddr(spiFlash_instance_t *flash);
        
        /**
         * @brief Globally locks the SPI flash.
         * @param flash Pointer to SPI Flash Instance.
         */
        void spiFlash_lockGlobal(spiFlash_instance_t *flash);
        
        /**
         * @brief Set Write Enable Latch (WEL) to 1.
         * @param flash Pointer to SPI Flash Instance.
         */
        void spiFlash_enableWrite(spiFlash_instance_t *flash);
        
        /**
         * @brief Globally unlocks the SPI flash.
         * @param flash Pointer to SPI Flash Instance.
         */
        void spiFlash_unlockGlobal(spiFlash_instance_t *flash);
        
        /**
         * @brief Set Write Enable Latch and set Quad Enable bit to enable Quad Mode.
         * @param flash Pointer to SPI Flash Instance.
         */
        void spiFlash_enableQuadMode(spiFlash_instance_t *flash);

        /**
         * @brief Set Write Enable Latch and send CMD 0x38 to enable QPI Mode.
         * @param flash Pointer to SPI Flash Instance.
         */
        void spiFlash_enableQPI(spiFlash_instance_t *flash);
        
        /**
         * @brief Erases a sector of the SPI flash given an address.
         * @param flash Pointer to SPI Flash Instance.
         * @param flashAddress The flash address to read the data
         */
        void spiFlash_eraseSector(spiFlash_instance_t *flash, u32 flashAddress);
    /** @} */

/** @} */ // End of SPI_FLASHFunc


/* ========================================================================== */
/* SUB-GROUP: Internal FUNCTIONS                                              */
/* ========================================================================== */

    /**
     * @brief Wake up SPI Flash.
     * @param flash Pointer to SPI Flash Instance.
     * @note Make sure to used it to ensure the device is in operation
     * state before start communicate with the device.
     */
    static void spiFlash_wake_(spiFlash_instance_t *flash);

    /**
     * @brief  Read Device ID from spiFlash.
     * @param flash Pointer to SPI Flash Instance.
     * @return SPI Flash status
     */
    static u8 spiFlash_readId_(spiFlash_instance_t *flash);
    /**
     * @brief  Read JEDEC ID from spiFlash.
     * @param flash Pointer to SPI Flash Instance.
     * @return SPI Flash status
     */
    static u32 spiFlash_readJedecId_(spiFlash_instance_t *flash);

    /**
     * @brief  Write Operation
     * @note Refer to @ref spiFlash_f2m_single_, spiFlash_f2m_dual_ and spiFlash_f2m_quad_
     */
    static void spiFlash_f2m_single_(spiFlash_instance_t *flash, u32 flashAddress, uintptr_t memoryAddress, u32 size);
    static void spiFlash_f2m_dual_(spiFlash_instance_t *flash, u32 flashAddress, uintptr_t memoryAddress, u32 size);
    static void spiFlash_f2m_quad_(spiFlash_instance_t *flash, u32 flashAddress, uintptr_t memoryAddress, u32 size);


#ifdef __cplusplus
}
#endif

/** @} */ // End of MAIN SPI_FLASH Group

#endif // SPI_FLASH_H