#include "bsp.h"
#include "syscall.h"

uart_instance_t uart0;

void bsp_init() {
    // Init uart 0
    uart0.hwreg = UART0_BASE;
    uart0.dataLength = BITS_8;
    uart0.parity = NONE;
    uart0.stop = ONE;
    uart0.clockDivider = BSP_CLINT_HZ/(BSP_UART_BAUDRATE*BSP_UART_DATA_LEN)-1;
    uart_applyConfig(&uart0);
}

