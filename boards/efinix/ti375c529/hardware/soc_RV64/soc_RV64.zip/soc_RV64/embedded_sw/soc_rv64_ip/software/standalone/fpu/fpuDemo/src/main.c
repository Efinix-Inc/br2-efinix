////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2025 Efinix Inc. All rights reserved.              
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/******************************************************************************
*
* @file main.c: Floating-Point Unit Arithmetic Demo
*
* @brief This demo performs various floating-point arithmetic operations and 
*        measures the processing time for each operation. It also checks if 
*        the Floating Point Unit (FPU) is enabled and provides information 
*        accordingly.
*
******************************************************************************/

#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include "bsp.h"
#include <math.h>

/*******************************************************************************
*
* @brief This function print processing time between two timestamps
*
* @param ts1 First timestamp.
* @param ts2 Second timestamp.
* @param s Character  
*
******************************************************************************/
void printPTime(u64 ts1, u64 ts2, char *s) {
    u64 rts;
    rts=ts2-ts1;
    printf("%s %d \n\n",s, rts);
}

/******************************************************************************
*
* @brief This main function demonstrates various floating-point calculations using
*        the FPU (Floating Point Unit). Additionally, it measures the clock cycles
*        taken for each calculation and prints the results along with the 
*        processing times.
*
******************************************************************************/
void main() {
    double inp1,
           inp2,
           rSin,
           rCos,
           rTan,
           rSqrt,
           rDiv;    
    u64 timerCmp0, timerCmp1;
    bsp_init();
    printf("***Starting FPU Demo*** \n");
#if ( SYSTEM_RISCV_ISA_EXT_F == 0) // If FPU extension is disabled in SOC
    printf("FPU is disabled, more processing time required for following calculation \n");
    printf("FPU is disabled, please expect bigger size compiled binary \n");
#endif

    /* Calculation */
    inp1=-0.8414709848078965;   
    timerCmp0 = clint_getTime();   
    rSin=sin(inp1);
    timerCmp1 = clint_getTime();
    printPTime(timerCmp0,timerCmp1,"Sine processing clock cycles:");
    timerCmp0 = clint_getTime(); 
    rCos=cos(inp1);
    timerCmp1 = clint_getTime();
    printPTime(timerCmp0,timerCmp1,"Cosine processing clock cycles:");
    timerCmp0 = clint_getTime(); 
    rTan=tan(inp1);
    timerCmp1 = clint_getTime();
    printPTime(timerCmp0,timerCmp1,"Tangent processing clock cycles:");   

    
    inp2=0.4161468365471424;
    timerCmp0 = clint_getTime(); 
    rSqrt=sqrt(inp2);
    timerCmp1 = clint_getTime();
    printPTime(timerCmp0,timerCmp1,"Square root processing clock cycles:");
    timerCmp0 = clint_getTime();
    rDiv=inp2/3.6789;
    timerCmp1 = clint_getTime();
    printPTime(timerCmp0,timerCmp1,"Division processing clock cycles:");

    printf("\n");
    printf("Input 1 (in rad): %f \n", inp1);
    printf("Sine result: %f \n", rSin);
    printf("Cosine result: %f \n", rCos);
    printf("Tangent result: %f \n", rTan);
    printf("Input 2: %f \n", inp2);
    printf("Square root result: %f \n", rSqrt);
    printf("Divsion result: %f \n", rDiv);

    printf("***Succesfully Ran Demo*** \n");
}
