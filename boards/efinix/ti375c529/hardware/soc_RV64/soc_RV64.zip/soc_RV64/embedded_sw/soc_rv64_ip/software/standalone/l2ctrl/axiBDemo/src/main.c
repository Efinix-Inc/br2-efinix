////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/******************************************************************************
*
* @file main.c: l2ctrl
*
* @brief This demo shows how to use L2 controller to flush the cache data to
*        block RAM through axiB interface.
*
* @note In this example, user first setup the interrupt trap and routine to
*		serve interrupt from L2 controller. It writes then read a group of 4KB data.
*		and flush the data back to block RAM from L2. This demo showcase flushing in
*		blocking and nonblocking method. The L2 interrupt trigger when L2 flush is done.
******************************************************************************/
#include <stdio.h>
#include "bsp.h"
#include "irq.h"

// Include driver
#include "l2ctrl/l2ctrl.h"

extern void trap_entry();

#if defined(SYSTEM_AXI_B_CTRL) && defined(SYSTEM_L2_CACHE_CTRL)
/******************************************************************************
*
* @brief This IRQ function will inform user the flushing is done and mask off
* 		 the interrupt.
*
******************************************************************************/
int irq_m_l2Cache_handler (){
    printf("isr: Flush done ..\n");
    l2cache_setFlushInterrupt(0x0U);
    asm("fence");
    return 0;
}

/******************************************************************************
*
* @brief This instance is used to configure PLIC to accept interrupt from L2.
*
******************************************************************************/
void l2_isr_init() {
    plic_instance_t l2_plic = {
        .target 	= BSP_PLIC_CPU_0,
        .gateway 	= SYSTEM_L2_CACHE_CTRL_INTERRUPT,
        .priority 	= 0x1U,
        .enable 	= 0X1U,
        .threshold 	= 0x0U,
    };

    plic_applyConfig(&l2_plic);
    irq_setTrapVector(trap_entry);
    irq_setType(IRQ_EXTERNAL);
    irq_enable();

}

/******************************************************************************
*
* @brief This main function intialize the system and then write,read and flush
*        to block RAM via axiB.
*
******************************************************************************/

void main()
{
    char buf[40];
    u64 val;
    bsp_init();
    printf(ANSI_RESET "***Starting L2 flush and axiB Demo*** \n");
    u64 *dat = (u64 *)SYSTEM_AXI_B_CTRL;
    l2_isr_init();
    printf("Write 4KB data to axiB block ram ..\n");
    for(int i=0; i < (4096/sizeof(uintptr_t)); i=i+1) {
        *dat = (0x0101010101010101*i);
        dat++;
    }
    dat--;
    printf("Read 4KB data from axiB block ram ..\n");
    for(int i=0; i < (4096/sizeof(uintptr_t)); i=i+1) {
        val=*dat;
        dat--;
    }
    printf("Data is now only available in L2 cache ..\n");
    printf("Flush the data to axiB block ram using blocking method ..\n");
    l2cache_flushBlocking(dat, 4096);
    printf("Flush done ..\n");
    dat++;
    printf("Write another 4KB data to axiB block ram ..\n");
    for(int i=0; i < (4096/sizeof(uintptr_t)); i=i+1) {
        *dat = (0x1010101010101010*i);
        dat++;
    }
    dat--;
    printf("Read 4KB data from axiB block ram ..\n");
    for(int i=0; i < (4096/sizeof(uintptr_t)); i=i+1) {
        val=*dat;
        dat--;
    }
    dat++;
    printf("Flush the data to axiB block ram using nonblocking method and interrupt..\n");
    l2cache_flush(dat, 4096);
    l2cache_setFlushInterrupt(0x1U);
    while(1){};

}

#else

void main() {
    bsp_init();
    printf(ANSI_RED "\n[ERR] L2 or axiB is disabled, please enable them to run this app. \n"ANSI_RESET);
}
#endif


