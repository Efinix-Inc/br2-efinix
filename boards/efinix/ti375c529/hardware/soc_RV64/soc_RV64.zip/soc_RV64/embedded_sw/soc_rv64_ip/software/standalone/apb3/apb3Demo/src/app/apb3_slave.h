
////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef SRC_APB3_SLAVE_H_
#define SRC_APB3_SLAVE_H_

#include "type.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ========================================================================== */
/* SUB-GROUP : DATA STRUCTS                                                   */
/* ========================================================================== */
    /**
     * @brief APB3 Slave Demo hardware register map.
     */
    typedef volatile struct {
        u32 APB3_REG0_STATUS;        ///< Address Offset: 0x00 (Read Register)
        u32 APB3_REG1_CTRL;          ///< Address Offset: 0x04 (LFSR Stop Control)
        u32 APB3_REG2_RESERVED;      ///< Address Offset: 0x08 (Reserved)
        u32 APB3_REG3_OWRITE_CTRL;   ///< Address Offset: 0x0C (Memory Start & Length)
        u32 APB3_REG4_DATA;          ///< Address Offset: 0x10 (Configuration Data)
        u32 APB3_REG5_ADDR;          ///< Address Offset: 0x14 (Configuration Address)
    } apb3_hwreg_t;
    /**
     * @brief APB3 instance.
     * Holds the software configuration and hardware pointer.
     * - lfsr_stop: 1 to stop LFSR operation, 0 to run.
     * - mem_start: 1 to start memory operation.
     * - ilen:      8-bit operation length.
     * * @note To apply the changes, please call apb3_applyConfig() after modifying
     * the configuration fields.
     */
    typedef struct {
        apb3_hwreg_t    *hwreg;     ///< Pointer to Hardware Register Map
        u8              lfsr_stop;  ///< LFSR Stop Flag (1-bit)
        u8              mem_start;  ///< Memory Start Flag (1-bit)
        u8              ilen;       ///< Instruction/Data Length (8-bit)
    } apb3_instance_t;


/* ========================================================================== */
/* SUB-GROUP : API FUNCTIONS                                                  */
/* ========================================================================== */
    u32  apb3_read(apb3_instance_t *inst);
    void apb3_applyConfig(apb3_instance_t *inst);
    void apb3_write_data(apb3_instance_t *inst, u32 data);
    void apb3_write_addr(apb3_instance_t *inst, u32 addr);

#ifdef __cplusplus
}
#endif // C_plusplus

#endif /* SRC_APB3_SLAVE_H_ */
