////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////
#ifndef BSP_H
#define BSP_H

/**
 * @file bsp.h
 * @author Efinix Inc
 * @brief Board Support Package API definitions.
 *
 * This file provides default hardware mappings and initialization for the EfxSapphireSoC platform.
 * It includes configurations for the primary UART, CLINT timer, and PLIC interrupt controller.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

/* --- Board & Peripheral Drivers --- */
#include "boards/rv64_platform.h"
#include "clint/clint.h"
#include "uart/uart.h"
#include "debug.h"
#include "soc.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup BSP Board Support Package
 * @brief Board Support Package provide default hardware mappings and initialization for RV64.
 * @{
 */

/* ========================================================================== */
/* DEFAULT MAIN PERIPHERALS FOR SOC                                     */
/* ========================================================================== */

/**
 * @defgroup BSP_Peripherals Default SoC Peripherals
 * @brief Default Hardware mappings for the primary Interrupt Controller and Timer.
 * @details
 * These macros provide the base addresses and configurations for the PLIC, CLINT, and UART peripherals on the EfxSapphireSoC platform.
 * * The default UART is configured for 115200 baud, 8 data bits, no parity, and 1 stop bit. 
 * * The CLINT timer is configured based on the SYSTEM_CLINT_HZ macro.
 * * These mappings are used by the BSP initialization and API functions to interact with the hardware peripherals.
 * @{
 */ //
    #define BSP_PLIC                    SYSTEM_PLIC_CTRL        ///< Primary PLIC controller base address
    #define BSP_PLIC_CPU_0              SYSTEM_PLIC_CPU_0_MEI   ///< Primary PLIC CPU 0 External Interrupt base address
    #define BSP_CLINT                   SYSTEM_CLINT_CTRL       ///< Primary CLINT controller base address
    #define BSP_CLINT_HZ                SYSTEM_CLINT_HZ         ///< Primary CLINT controller clock frequency
    #define BSP_UART_BAUDRATE           115200                  ///< Default UART baudrate
    #define BSP_UART_DATA_LEN           8                       ///< Default UART data length (bits)
    #define ENABLE_SEMIHOSTING_PRINT    0                       ///< Enable printing with semihosting, Disabled by default.

    #if (SYSTEM_UART_0_IO_CTRL || defined(__DOXYGEN__))
        /* Hardware UART is enabled in Efinix Sapphire Soc */
        extern uart_instance_t uart0;       ///< Primary UART instance for standard I/O mapping
        #define BSP_UART_TERMINAL   SYSTEM_UART_0_IO_CTRL   ///< Physical UART base address for standard I/O mapping
    #else
    // No Hardware UART present. Provide safe dummy macros. 
        #define BSP_UART_TERMINAL   0 
    #endif

/** @} */ //

    /**
     * @defgroup BSP_Funcs API Functions
     * @ingroup BSP
     * @brief Board Support Package API functions.
     * @{
     */

        /**
         * @brief Initialize Board Support Package Peripherals
         */
        void bsp_init();

        /**
        * @brief Microsecond delay function using CLINT timer.
        */
        #define bsp_uDelay(usec)    clint_uDelay(usec, SYSTEM_CLINT_HZ)

        #if (SYSTEM_UART_0_IO_CTRL || defined(__DOXYGEN__))
            /* Hardware UART is enabled in Efinix Sapphire Soc */
            /**
            * @brief Map standard character output to the physical UART.
            * @note If hardware UART is present, these macros will use the uart_write functions to perform I/O through the physical UART.
            * If hardware UART is not present, these macros will be defined as safe dummy macros that do nothing (for putChar).
            * @note It is recommended to use standard printf for better functionality and compatibility with the C library, which are also mapped to the physical UART if it exists.
            * @ingroup BSP_Funcs
            */
            #define bsp_putChar(c)      uart_write(&uart0, c)
            /**
            * @brief Map standard character input to the physical UART.
            * @note If hardware UART is present, these macros will use the uart_read functions to perform I/O through the physical UART.
            * If hardware UART is not present, these macros will be defined as safe dummy macros that do nothing return 0 (for getChar).
            * @note It is recommended to use standard scanf for better functionality and compatibility with the C library, which are also mapped to the physical UART if it exists.
            * @ingroup BSP_Funcs
            */
            #define bsp_getChar()       uart_read(&uart0) 
        #else
            /* No Hardware UART present. Provide safe dummy macros. */
            #define bsp_putChar(c)      ((void)0) 
            #define bsp_getChar()       (0) 
        #endif
    /** @} */ //

/* ========================================================================== */
/* Internal Module Inclusion Logic (SemiHosting)              */
/* ========================================================================== */

    #if (ENABLE_SEMIHOSTING_PRINT == 1)
        #include "semihosting.h"
    #endif

/* ========================================================================== */
/* TINY PRINTF CONFIG (USELIB == 0, NEWLIB=NOSTD)               */
/* ========================================================================== */

#if(USELIB == 0)
/**
 * @defgroup BSP_SETTING Bsp_printf Config (Legacy)
 * @ingroup BSP
 * @brief Only applicable when using setting (NEWLIB=NOSTD) in makefile. Toggle between the Lite and Full printf implementations and enable specific format specifiers.
 * @note When <b>NEWLIB=NANO</b> in makefile, it uses <b> optimized printf </b> from the C library, and these settings will have no effect.
 * @note When <b>NEWLIB=NOSTD</b> in makefile, it overrides printf with the legacy @ref bsp_printf defined in this module, and these settings will configure the behavior of that custom printf.
 * @{
 */
    /**
     * @brief Custom Bare-Metal Printf override.
     * @note When NEWLIB=NANO in makefile, it uses optimized printf from the C library.
     * @note When NEWLIB=NOSTD in makefile, it overrides printf with this custom bsp_printf.
     * This bsp_Printf 
     * @ingroup BSP_Funcs
     */
    static int bsp_printf(const char *format, ...);
    
    /**
     * @brief Printf Wrapper Helper, ignore it.
     */
    /** @cond */ 
    #define printf(...) (bsp_printf(__VA_ARGS__))
    /** @endcond */
    
    /** @name Printf Module Selection
     * @ingroup BSP_SETTING
     * @brief Toggle between the Lite and Full printf implementations.
     * @{
     */
        /** @brief (Lite) Supports char, string, decimal, hex, floats. Moderate memory footprint. */
        #define ENABLE_BSP_PRINTF               1
        
        /** @brief (Full) Full support including flags and precisions. Larger memory footprint. */
        #define ENABLE_BSP_PRINTF_FULL          1
        
        /** @brief Enable function sharing between 'full' and 'lite' printing modules. */
        #define ENABLE_BRIDGE_FULL_TO_LITE      1
        
        /** @brief Print a warning message when a format specifier is not supported. */
        #define ENABLE_PRINTF_WARNING           1
    /** @} */

    /** @name Extended Format Specifier Support
     * @ingroup BSP_SETTING
     * @brief Enable specific data types (Costs extra memory).
     * @{
     */
        #define ENABLE_FLOATING_POINT_SUPPORT   0  ///< Support for %f (Printing only)
        #define ENABLE_FP_EXPONENTIAL_SUPPORT   0  ///< Support for %e / %E
        #define ENABLE_PTRDIFF_SUPPORT          0  ///< Support for %t (Pointer differences)
        #define ENABLE_LONG_LONG_SUPPORT        1  ///< Support for %lld / %llu
    /** @} */


    /* ========================================================================== */
    /* Internal Module Inclusion Logic (SemiHosting)              */
    /* ========================================================================== */
    /** @cond */
    #if (ENABLE_BSP_PRINTF)
        #include "print.h"
    #endif

    #if (ENABLE_BSP_PRINTF_FULL)
        
        #if (!ENABLE_FLOATING_POINT_SUPPORT)
            #define PRINTF_DISABLE_SUPPORT_FLOAT 1
        #endif 

        #if (!ENABLE_FP_EXPONENTIAL_SUPPORT)
            #define PRINTF_DISABLE_SUPPORT_EXPONENTIAL 1
        #endif 

        #if (!ENABLE_PTRDIFF_SUPPORT)
            #define PRINTF_DISABLE_SUPPORT_PTRDIFF_T 1
        #endif 

        #if (!ENABLE_LONG_LONG_SUPPORT)
            #define PRINTF_DISABLE_SUPPORT_LONG_LONG 1
        #endif 

        #if (ENABLE_BRIDGE_FULL_TO_LITE)
            #if (!ENABLE_BSP_PRINTF)
                #define bsp_printf bsp_printf_full
            #endif 
        #endif 

        #include "print_full.h"
    #endif 
    /** @endcond */
#endif // USELIB == 0

/** @} */ //
#ifdef __cplusplus
}
#endif

#endif // BSP_H