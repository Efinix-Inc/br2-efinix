////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/**
* @file watchdog.c
* @brief Watchdog driver implementation.
*
* Implements the functions defined in watchdog.h for controlling
* Watchdog input/output and interrupts on the EfxSapphireSoC platform.
* @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
* See the full @ref license_page for Efinix and SaxonSoc MIT terms.
*/
#include "watchdog/watchdog.h"


/*----------------------------------------------------------------------------*/
/* Function implementations                                                    */
/*----------------------------------------------------------------------------*/

u32 watchdog_getCounterValue(watchdog_instance_t *inst, u32 counterId)
{
    volatile u32 *p = (volatile u32 *)(uintptr_t)&inst->hwreg->WDG_COUNTER_VALUE_0;
    return p[counterId];
}

void watchdog_setPrescaler(watchdog_instance_t * inst, u32 value)
{
    inst->hwreg->WDG_PRESCALER = value;
}


void watchdog_setCounterLimit(watchdog_instance_t *inst, u32 counterId, u32 value)
{
    if (counterId >1) return;
    volatile u32 *p = (volatile u32 *)(uintptr_t)&inst->hwreg->WDG_COUNTER_LIMIT_0;
    p[counterId] = value;
}


void watchdog_setHeartBeat(watchdog_instance_t *inst, watchdog_heartbeat_t value)
{
    inst->hwreg->WDG_HEARTBEAT = value;
}

void watchdog_clear(watchdog_instance_t *inst)
{
    watchdog_setHeartBeat(inst,WDG_TIMER_CLEAR);
}


void watchdog_lock(watchdog_instance_t *inst)
{
    watchdog_setHeartBeat(inst,WDG_TIMER_LOCK);
}

void watchdog_unlock(watchdog_instance_t *inst)
{
    watchdog_setHeartBeat(inst,WDG_TIMER_UNLOCK);
}


void watchdog_enable(watchdog_instance_t *inst, u32 mask)
{
    inst->hwreg->WDG_ENABLE |= mask;
}

void watchdog_disable(watchdog_instance_t *inst, u32 mask)
{
    inst->hwreg->WDG_DISABLE &= ~mask;
}


u32 watchdog_getEnable(watchdog_instance_t *inst)
{
    return inst->hwreg->WDG_ENABLE;
}


void watchdog_applyConfig(watchdog_instance_t *inst)
{
    watchdog_setPrescaler(inst,inst->prescaler);
    watchdog_setCounterLimit(inst,0,inst->counterLimit[0]);
    watchdog_setCounterLimit(inst,1,inst->counterLimit[1]);

    // Safety Check for HeartBeat Config
    if ((inst->heartbeat == WDG_TIMER_CLEAR)  || 
        (inst->heartbeat == WDG_TIMER_UNLOCK) || 
        (inst->heartbeat == WDG_TIMER_LOCK)) 
    {
        watchdog_setHeartBeat(inst, inst->heartbeat);
    }

    // Counter 0 Handling
    if (inst->enable[0]) {
        watchdog_enable(inst, 0x1); // Enable Bit 0
    } else {
        watchdog_disable(inst, 0x1); // Disable Bit 0 (Must pass 1, not 0!)
    }

    // Counter 1 Handling
    if (inst->enable[1]) {
        watchdog_enable(inst, 0x2); // Enable Bit 1 (1 << 1)
    } else {
        watchdog_disable(inst, 0x2); // Disable Bit 1
    }
}

