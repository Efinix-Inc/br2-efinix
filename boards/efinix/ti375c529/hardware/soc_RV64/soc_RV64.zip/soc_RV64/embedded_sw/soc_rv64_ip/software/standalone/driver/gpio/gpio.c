////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/**
* @file gpio.c
* @brief GPIO driver implementation.
*
* Implements the functions defined in gpio.h for controlling
* GPIO input/output and interrupts on the EfxSapphireSoC platform.\
* @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
* See the full @ref license_page for Efinix and SaxonSoc MIT terms.
*/

#include "gpio/gpio.h"

/*----------------------------------------------------------------------------*/
/* Function implementations                                                    */
/*----------------------------------------------------------------------------*/

void gpio_setOutput(gpio_instance_t *inst, u32 value)
{
    inst->hwreg->OUTPUT = value;
}

void gpio_setOutputEnable(gpio_instance_t *inst, u32 value)
{
    inst->hwreg->OUTPUT_ENABLE = value;
}

void gpio_setInterruptRiseEnable(gpio_instance_t *inst, u32 value)
{
    inst->hwreg->INTERRUPT_RISE_ENABLE = value;
}

void gpio_setInterruptFallEnable(gpio_instance_t *inst, u32 value)
{
    inst->hwreg->INTERRUPT_FALL_ENABLE = value;
}

void gpio_setInterruptHighEnable(gpio_instance_t *inst, u32 value)
{
    inst->hwreg->INTERRUPT_HIGH_ENABLE = value;
}

void gpio_setInterruptLowEnable(gpio_instance_t *inst, u32 value)
{
    inst->hwreg->INTERRUPT_LOW_ENABLE = value;
}

u32 gpio_getInput(gpio_instance_t *inst)
{
    return inst->hwreg->INPUT;
}

u32 gpio_getOutput(gpio_instance_t *inst)
{
    return inst->hwreg->OUTPUT;
}

u32 gpio_getOutputEnable(gpio_instance_t *inst)
{
    return inst->hwreg->OUTPUT_ENABLE;
}

u32 gpio_getInterruptRiseEnable(gpio_instance_t *inst)
{
    return inst->hwreg->INTERRUPT_RISE_ENABLE;
}

u32 gpio_getInterruptFallEnable(gpio_instance_t *inst)
{
    return inst->hwreg->INTERRUPT_FALL_ENABLE;
}

u32 gpio_getInterruptHighEnable(gpio_instance_t *inst)
{
    return inst->hwreg->INTERRUPT_HIGH_ENABLE;
}

u32 gpio_getInterruptLowEnable(gpio_instance_t *inst)
{
    return inst->hwreg->INTERRUPT_LOW_ENABLE;
}

void gpio_applyConfig(gpio_instance_t *inst)
{
    gpio_setOutput(inst, inst->output);
    gpio_setOutputEnable(inst, inst->outputEnable);
    gpio_setInterruptRiseEnable(inst, inst->interruptRiseEnable);
    gpio_setInterruptFallEnable(inst, inst->interruptFallEnable);
    gpio_setInterruptHighEnable(inst, inst->interruptHighEnable);
    gpio_setInterruptLowEnable(inst, inst->interruptLowEnable);
}