///////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2025 SaxonSoc contributors
//  SPDX license identifier: MIT
//  Full license header bsp/efinix/EfxSapphireSoc/include/LICENSE.MD
//////////////////////////////////////////////////////////////////////////////////

/******************************************************************************
*
* @file main.c: axi4Demo
*
* @brief This demo performs a write and read test for the internal BRAM that is attached
*        to an AXI interface. First, the software writes to the internal BRAM through
*        the AXI interface. Next, it reads back the data and compares it to the expected
*        value. If the data is correct, the software writes "Passed" to a UART terminal
*
* @note Please ensure the AXI4 Slave is enabled in Sapphire Soc.
*
******************************************************************************/

#include <stdio.h>
#include "bsp.h"
#include "userDef.h"

#ifdef SYSTEM_AXI_A_CTRL

    #define AXI SYSTEM_AXI_A_CTRL
    #define AXI_SIZE 2048

#endif


/******************************************************************************
*
* @brief This function perform write/read test for the internal BRAM and
*        AXI4 master interrupt is triggered when the data written to AXI bus is
*        0xABCD.
*
******************************************************************************/
void main() {
    u32 data;
    bsp_init();
#ifdef SYSTEM_AXI_A_CTRL

    printf(ANSI_RESET"Welcome to AXI4 Slave demo ! \n");

    for (int i=0; i < AXI_SIZE ; i = i + 4 ){
        write_u32(i, AXI + i);
    }

    for (int i=0; i < AXI_SIZE ; i = i + 4 ){
        data = read_u32(AXI + i);
        if(i != data){
            printf("Failed at address 0x%x with value 0x%x \n", i, data);
            while (1) {}
        }
    }
    printf("Passed! \n");

#else

    printf(ANSI_RED "[ERR] AXI4 slave is disabled, please enable it to run this app. \n"ANSI_RESET);

#endif

}

