////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/**
* @file EMC1413.c
* @brief EMC1413 Temperature Sensor driver implementation.
*
* Implements the functions defined in EMC1413.h for controlling
* EMC1413 Temperature Sensor input/output and interrupts on the EfxSapphireSoC platform.
* @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
* See the full @ref license_page for Efinix and SaxonSoc MIT terms.
*/

#include "sensor/device/EMC1413.h"
#include <math.h>

/* -----------------------------------------------------------------------------*/
/*  Temperature Sensor - Hardware Register Map for EMC1413	              						
/* -----------------------------------------------------------------------------*/

/* --- Address: ID Register --- */
#define PRODUCT_ID			0xFD	//Should return h'21
#define MICROCHIP_ID		0xFE	//Should return h'5D

/* --- Address: Temperature Data Register --- */
#define INT_DIODE_HB		0x00
#define INT_DIODE_LB		0x29
#define EXT_DIODE1_HB		0x01
#define EXT_DIODE1_LB		0x10
#define EXT_DIODE2_HB		0x23
#define EXT_DIODE2_LB		0x24

/* --- Address: CSR Register --- */
#define STATUS_REG			0x02
#define CONFIG_REG			0x03	//Can accessed this at address of 0x09 as well
#define CONVERT_RATE_REG	0x04	//Can accessed this at address of 0x0A as well

/* --- Address: Limit Register --- */
#define HIGH_LIMIT_REG_INT_DIODE		0x05 //Can accessed this at address of 0x0B as well
#define LOW_LIMIT_REG_INT_DIODE			0x06 //Can accessed this at address of 0x0C as well
#define HIGH_LIMIT_REG_EXT_DIODE1_HB	0x07 //Can accessed this at address of 0x0D as well
#define LOW_LIMIT_REG_EXT_DIODE1_HB 	0x08 //Can accessed this at address of 0x0E as well
#define HIGH_LIMIT_REG_EXT_DIODE1_LB 	0x13 
#define LOW_LIMIT_REG_EXT_DIODE1_LB 	0x14
#define HIGH_LIMIT_REG_EXT_DIODE2_HB 	0x15 
#define LOW_LIMIT_REG_EXT_DIODE2_HB 	0x16
#define HIGH_LIMIT_REG_EXT_DIODE2_LB 	0x17 
#define LOW_LIMIT_REG_EXT_DIODE2_LB 	0x18

/* --- Address: EMC1414 - Ext_Diode 3 Register --- */
#define HIGH_LIMIT_REG_EXT_DIODE3_HB 	0x2C
#define HIGH_LIMIT_REG_EXT_DIODE3_LB 	0x2E
#define LOW_LIMIT_REG_EXT_DIODE3_HB 	0x2D
#define LOW_LIMIT_REG_EXT_DIODE3_LB 	0x2F

/* --- Address: Thermal Limit Register --- */
#define THERM_LIMIT          			0X37
#define THERM_LIMIT_EXT_DIODE1			0X19
#define THERM_LIMIT_EXT_DIODE2			0X1A
#define THERM_LIMIT_EXT_DIODE3			0X30
#define THERM_LIMIT_INT_DIODE 			0X20
#define THERM_LIMIT_HYSTERESIS 			0X21

/* --- Address: Limit Status Register --- */
#define HIGH_LIMIT_STATUS_REG			0x35
#define LOW_LIMIT_STATUS_REG			0x36
#define THERM_LIMIT_STATUS_REG			0x37

/* --- Address: Calibration --- */
#define BETA_CONFIG_EX1_REG				0x25 //Default: h'08
#define BETA_CONFIG_EX2_REG				0x26 //Default: h'08

/* --- Address: Other Register --- */
#define FILTER_CTRL_REG					0x40
#define EXT_DIODE_FAULT					0x1B
#define CONSECUTIVE_ALRT_REG			0x70
#define CHANNEL_MASK_REG				0x1F

/* --- Address: Limit Temperature Data Register --- */
#define DEFAULT_HIGH_LIMIT_VALUE		0x55
#define DEFAULT_LOW_LIMIT_VALUE			0x00


/* -----------------------------------------------------------------------------*/
/* Temperature Sensor: Plug & Play Driver                            	        	
/* -----------------------------------------------------------------------------*/
const temp_sensor_api_t EMC1413_DRIVER =
{
    .applyConfig			= EMC1413_applyConfig,
    .enableErrorInterrupt 	= EMC1413_enableErrorInterrupt,
    .getTemp        		= EMC1413_getTemp,     
    .getTempLimit   		= EMC1413_getTempLimit,     
    .setTempRange   		= EMC1413_setTempRange,
    .setTempLimit   		= EMC1413_setTempLimit,
    .checkTempRange 		= EMC1413_checkTempRange,
    .checkTempAlert 		= EMC1413_checkTempAlert,

};

/* -----------------------------------------------------------------------------*/
/* Temperature Sensor: Register Lookup Table of reg to set/retrieve limit value                           	        	
/* -----------------------------------------------------------------------------*/
static const u8 LIMIT_REGS[3][5] = {
    // [0] High_HB, [1] High_LB, [2] Low_HB, [3] Low_LB, [4] Therm
    { HIGH_LIMIT_REG_INT_DIODE, 0,  LOW_LIMIT_REG_INT_DIODE, 0, THERM_LIMIT_INT_DIODE },
    { HIGH_LIMIT_REG_EXT_DIODE1_HB, HIGH_LIMIT_REG_EXT_DIODE1_LB, LOW_LIMIT_REG_EXT_DIODE1_HB, LOW_LIMIT_REG_EXT_DIODE1_LB, THERM_LIMIT_EXT_DIODE1 },
    { HIGH_LIMIT_REG_EXT_DIODE2_HB, HIGH_LIMIT_REG_EXT_DIODE2_LB, LOW_LIMIT_REG_EXT_DIODE2_HB, LOW_LIMIT_REG_EXT_DIODE2_LB, THERM_LIMIT_EXT_DIODE2 }
};

/* -----------------------------------------------------------------------------*/
/* Temperature Sensor: Register Lookup Table of reg to retrieve Temp value                              	        	
/* -----------------------------------------------------------------------------*/
static const u8 REG_HB[] = { INT_DIODE_HB, EXT_DIODE1_HB, EXT_DIODE2_HB };
static const u8 REG_LB[] = { INT_DIODE_LB, EXT_DIODE1_LB, EXT_DIODE2_LB };

temp_sensor_status_t EMC1413_applyConfig(temp_sensor_instance_t *temp) {

    i2c_applyConfig(temp->inst);
    return TEMP_SENSOR_OK;
}

temp_sensor_status_t EMC1413_enableErrorInterrupt(temp_sensor_instance_t *temp) {

    // Will drop I2C Transcation if Timeout.
    i2c_enableInterrupt(temp->inst, I2C_INTERRUPT_DROP);
    return TEMP_SENSOR_OK;
}

temp_sensor_status_t EMC1413_getTemp(temp_sensor_instance_t *temp) {
    u8 is_extended = EMC1413_checkTempRange(temp);

    for (int i = 0; i < 3; i++) {
        u8 hb = tempSensor_readTempReg(temp, REG_HB[i]);
        u8 lb = tempSensor_readTempReg(temp, REG_LB[i]);

        // Calculate temperature in celsisus and store in struct.
        temp->temp_value.channels[i].current_temp = tempSensor_calTempCelsius(hb, lb, is_extended);
    }
    return TEMP_SENSOR_OK;
}

temp_sensor_status_t EMC1413_getTempLimit(temp_sensor_instance_t *temp) {
    
    // Check Range Mode (Extended vs Standard)
    u8 is_extended = EMC1413_checkTempRange(temp);
    float offset = (is_extended) ? 64.0 : 0.0;

    // Iterate through all 3 channels
    for (int i = 0; i < 3; i++) {
        temp_sensor_channelData_t *ch = &temp->temp_value.channels[i];
        // Get the Register Map for this channel from the Lookup Table
        const u8 *regs = LIMIT_REGS[i];

        // Read High Byte (Integer)
        u8 hb = (int8_t)tempSensor_readTempReg(temp, regs[0]);
        // Read Low Byte (Fractional) - Check if register exists (Internal diode has no LB)
        float fraction = 0.0;
        if (regs[1] != 0) {
            u8 raw_lb = tempSensor_readTempReg(temp, regs[1]);
            fraction = (raw_lb >> 5) * 0.125;
        }
        
        // Combine and Apply Offset
        ch->high_limit = ((float)hb + fraction) - offset;

        // Read High Byte
        hb = (int8_t)tempSensor_readTempReg(temp, regs[2]);
        
        // Read Low Byte
        fraction = 0.0;
        if (regs[3] != 0) {
            u8 raw_lb = tempSensor_readTempReg(temp, regs[3]);
            fraction = (raw_lb >> 5) * 0.125;
        }

        // Combine and Apply Offset
        ch->low_limit = ((float)hb + fraction) - offset;
    }
    return TEMP_SENSOR_OK;
}

temp_sensor_status_t EMC1413_setTempRange(temp_sensor_instance_t *temp, u8 enable_extended)
{
    u8 status = tempSensor_readTempReg(temp, CONFIG_REG);
    u8 current_bit = (status & 0x04) >> 2;

    if (current_bit != enable_extended) {
        if (enable_extended) status |= 0x04;
        else status &= ~0x04;
        tempSensor_writeTempReg(temp, CONFIG_REG, status);
        return TEMP_SENSOR_OK;
    }
    return TEMP_SENSOR_SKIP;
}


temp_sensor_status_t EMC1413_setTempLimit(temp_sensor_instance_t *temp)
{
    u8 is_extended = EMC1413_checkTempRange(temp);

    // Iterate through all 3 channels
    for (int i = 0; i < 3; i++) {
        u8 hb, lb;
        temp_sensor_channelData_t *ch = &temp->temp_value.channels[i];
        const u8 *regs = LIMIT_REGS[i];
        // Write High Limit
        tempSensor_encodeTempLimit(ch->high_limit, is_extended, &hb, &lb);
        tempSensor_writeTempReg(temp, regs[0], hb);
        if (regs[1] != 0)
            tempSensor_writeTempReg(temp, regs[1], lb);

        // Write Low Limit
        tempSensor_encodeTempLimit(ch->low_limit, is_extended, &hb, &lb);
        tempSensor_writeTempReg(temp, regs[2], hb);
        if (regs[3] != 0)
            tempSensor_writeTempReg(temp, regs[3], lb);
    
        // Update Thermal Limit (Using High Limit Integer)
        tempSensor_writeTempReg(temp, regs[4], hb);
        }
        return TEMP_SENSOR_OK;
}

temp_sensor_status_t EMC1413_checkTempAlert(temp_sensor_instance_t *temp) {
    u8 high_status = tempSensor_readTempReg(temp, HIGH_LIMIT_STATUS_REG) & 0x07;
    u8 low_status  = tempSensor_readTempReg(temp, LOW_LIMIT_STATUS_REG)  & 0x07;

    if (high_status > 0) return TEMP_SENSOR_HIGH_ALERT; // High Alert
    if (low_status > 0)  return TEMP_SENSOR_LOW_ALERT; // Low Alert
    return TEMP_SENSOR_OK; // OK
}


u8 EMC1413_checkTempRange(temp_sensor_instance_t *temp) {
    u8 status = tempSensor_readTempReg(temp, CONFIG_REG);
    return (status & 0x04) >> 2;
}
