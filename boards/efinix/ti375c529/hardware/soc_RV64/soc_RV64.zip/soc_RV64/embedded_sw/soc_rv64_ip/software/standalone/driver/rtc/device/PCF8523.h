////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef SRC_RTC_PCF8523_H_
#define SRC_RTC_PCF8523_H_

/**
 * @file pcf8523.h
 * @author Efinix Inc
 * @brief PCF8523 Driver API definitions.
 * This file provides data structures and APIs for controlling
 * the PCF8523 RTC device on the EfxSapphireSoC platform.
 * @note This is a device-specific driver implementation for the PCF8523 RTC.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "rtc/rtc.h"
/**
 * @defgroup Supported_RTC Supported RTC Devices
 * @ingroup RTC
 * 
 * @{
 */

/**
 * @defgroup PCF8523_Config PCF8523 RTC Driver
 * @ingroup Supported_RTC
 * @brief PCF8523 Real Time Clock driver definitions.
 * 
 * @note This is a device-specific driver implementation for the PCF8523 RTC.
 * @{
 */

#ifdef __cplusplus
extern "C" {
#endif

/* ========================================================================== */
/* SUB-GROUP : REGISTER DEFINITIONS                                          */
/* ========================================================================== */

/**
 * @defgroup PCF8523_Macros Register Definitions
 * @ingroup Supported_RTC
 * @brief Register bitmasks and offsets.
 * @{
 */
    /**
     * @brief I2C Address for Mux device.
     * @note Used to select the correct I2C channel for the PCF8523 device.
     */
    #define MUX_ADDR 			0x71<<1
    /**
     * @brief I2C Address for PCF8523 RTC device.
     */
    #define RTC_PCF8523_ADDR 	0x68<<1

/** @} */ // End of PCF8523_Macros group

/* ========================================================================== */
/* SUB-GROUP : Driver Definition                                        */
/* ========================================================================== */

/**
 * @defgroup PCF8523_DRV Driver Structure
 * @ingroup Supported_RTC
 * @brief This is the PCF8523 driver structure.
 * @{
 */
    /**
     * @brief PCF8523 Driver Instance.
     * Point your generic RTC pointer to this structure to use the PCF8523 hardware.
     * @note Implements the following hooks from @ref rtc_api_t:
     *          - **getTime**: Reads current time registers.
     *          - **setTime**: Writes current time registers.
     *          - **setTimeSystem**: Configures the 12/24H mode bit.
     * @see rtc_api_t
     * @code
     * // Example Usage:
     * rtc_api_t *my_rtc = &PCF8523_DRIVER;
     * * // The application code doesn't know this is a PCF8523
     * my_rtc->getTime(&t); 
     * @endcode
     */
    extern const rtc_api_t PCF8523_DRIVER;
/** @} */ // End of PCF8523_DRV group


/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup PCF8523_Funcs API Functions
 * @ingroup Supported_RTC
 * @brief Function definitions for PCF8523 driver.
 * @note This is the public API for the PCF8523 RTC device.
 * @{
 */
     /**
     * @brief Apply I2C + RTC configuration.
     * @param rtc Pointer to RTC instance.
     * @return Status code of the operation.
     */
    rtc_status_t PCF8523_applyConfig(rtc_instance_t *rtc);
     /**
     * @brief Enable error interrupt for PCF8523 RTC.
     * @param rtc Pointer to RTC instance.
     * @return Status code of the operation.
     */
    rtc_status_t PCF8523_enableErrorInterrupt(rtc_instance_t *rtc);
    /**
     * @brief Get control/status register from PCF8523 RTC.
     * @param rtc Pointer to RTC instance.
     * @return Status code of the operation.
     */
    rtc_status_t PCF8523_getCSR(rtc_instance_t *rtc);
    /**
     * @brief Get time from PCF8523 RTC.
     * @param rtc Pointer to RTC instance.
     * @return Status code of the operation.
     */
    rtc_status_t PCF8523_getTime(rtc_instance_t *rtc);
    /**
     * @brief Set time on PCF8523 RTC.
     * @param rtc Pointer to RTC instance.
     * @return Status code of the operation.
     */
    rtc_status_t PCF8523_setTime(rtc_instance_t *rtc);
    /**
     * @brief Set time system (12-hour or 24-hour) on PCF8523 RTC.
     * @param rtc Pointer to RTC instance.
     * @param use_12hour_mode Flag indicating whether to use 12-hour mode (1) or 24-hour mode (0).
     * @return Status code of the operation.
     */
    rtc_status_t PCF8523_setTimeSystem(rtc_instance_t *rtc, u8 use_12hour_mode) ;

/** @} */ // End of PCF8523_Funcs group
#ifdef __cplusplus
}
#endif // C_plusplus

/** @} */ // End of MAIN PCF8523 Group

/** @} */ // End of MAIN Supported_RTC Group
#endif // PCF8523_H_