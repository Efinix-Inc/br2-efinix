////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef TIMER_H
#define TIMER_H

/**
 * @file timer.h
 * @author Efinix Inc
 * @brief User Timer driver API definitions.
 *
 * This file provides data structures and APIs for controlling
 * the User Timer peripheral on the EfxSapphireSoC platform.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "type.h"
#include "io.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup UserTimer UserTimer Driver
 * @brief Timer driver API definitions.
 * @ingroup timer_group
 *
 * This module provides functions to configure and control
 * Timer input/output and interrupt behavior.
 * @section Example_TIMER Usage & Initialization.
 * This is an example show how to instantiate @ref TIMER with @ref timer_instance_t.
 * 
 * This implementation depends on @ref PLIC for interrupt configuration.
 * 
 * @code 
 * #include "timer/timer.h"
 * #include "irq.h"
 * 
 * #define TIMER_0 					((timer_hwreg_t *)SYSTEM_USER_TIMER_0_CTRL)
 * #define PRESCALER_VALUE			127
 * #define TIMER_LIMIT_VALUE			4095
 * 
 * // Interrupt handler for user timer 0
 * int irq_m_userTimer0_handler(void) {}
 * 
 * // User Timer instance configuration
 * timer_instance_t timer0 = {
 * 	.hwreg 				= TIMER_0,
 * 	.prescaler_value 	= PRESCALER_VALUE,
 * 	.prescaler_enable 	= 0x1U,
 * 	.self_restart 		= 0x1U,
 * 	.timer_limit 		= TIMER_LIMIT_VALUE,
 * };
 * 
 * // PLIC instance configuration for user timer 0
 * plic_instance_t timer0_plic = {
 * 	// Configure the interrupt source
 * 	.target    = BSP_PLIC_CPU_0,
 * 	.gateway   = SYSTEM_USER_TIMER_0_INTERRUPTS_0,
 * 	.priority  = 0x1U,
 * 	.enable    = 0x1U,
 * 	.threshold = 0x0U,
 * };
 * 
 * void isrInit(){
 *	timer_applyConfig(&timer0);
 *	plic_applyConfig(&timer0_plic);
 *	irq_setTrapVector(trap_entry);
 *	irq_setType(IRQ_EXTERNAL);
 *	irq_enable();
 *}
 * @endcode
 * @see @ref userTimerDemo "Example User Timer Demo" - Learn how to use the driver for timer operations
 * @{
 */

/* ========================================================================== */
/* SUB-GROUP : REGISTER DEFINITIONS                                          */
/* ========================================================================== */
/**
 * @defgroup TIMER_Macros Register Definitions
 * @ingroup UserTimer
 * @brief Register bitmasks and offsets.
 * @{
 */
    #define TIMER_CONFIG_WITH_PRESCALER     0x2 		///< Prescaler Enabled */
    #define TIMER_CONFIG_WITHOUT_PRESCALER  0x1			///< No Prescaler */
    #define TIMER_CONFIG_SELF_RESTART       0x10000		///< Self Restart */
/** @} */ // End of TIMER_Macros group

/* ========================================================================== */
/* SUB-GROUP : DATA STRUCTS                                          			*/
/* ========================================================================== */
/**
 * @defgroup TIMER_Types Data Structures
 * @ingroup UserTimer
 * @brief Structs used by the driver.
 * @note
 * <b> This is an example show how to instantiate User Timer with @ref timer_instance_t 
 * and @ref timer_hwreg_t.
 * 
 * @code 
 * #define timer_0 		((timer_hwreg_t *)SYSTEM_USER_TIMER_0_CTRL)
 * 
 * timer_instance_t timer0 = {
 * 	// Configure the interrupt source
 * 		.hwreg 				= timer_0,
 * 		.prescaler_value 	= 999,
 * 		.prescaler_enable 	= 0x1U,
 * 		.self_restart 		= 0x1U,
 * 		.timer_limit 		= 19999,
 * };
 *},
 * timer_applyConfig(&timer0);
 *
 * @endcode
 * @{
 */
    /**
     * @brief UserTimer hardware register map.
     * @note This is the main structure that maps directly onto the Timer peripheral
     *       memory-mapped register layout.
     */
    typedef volatile struct 
    {
        u32 PRESCALER;						///< Address Offset: 0x00 - Prescaler Register */
        u32 reserved0[(0x0040U-0x4U)/4U];	///< Reserved Space (0x04 to 0x3F) */
        u32 TIMER_CONFIG;					///< Address Offset: 0x40 - Timer Configuration Register */
        u32 TIMER_LIMIT;					///< Address Offset: 0x44 - Timer Limit Register */
        u32 TIMER_VALUE;					///< Address Offset: 0x48 - Timer Current Value Register */
    } timer_hwreg_t;

    /**
     * @brief UserTimer instance.
     * Holds the software registers and hardware pointer.
     * @note This structure holds configuration values to be applied to the hardware.
     *			- prescaler_value: Clock divider value.
     *			- prescaler_enable: Prescaler enable flag (1 = enabled, 0 = disabled).
     *			- self_restart: Self-restart enable flag (1 = enabled, 0 = disabled).
     *			- timer_limit: Timer limit (reload) value.
     *			- To apply the changes, please call timer_applyConfig() after modifying the configuration fields.
     * 
     */
    typedef struct
    {
        timer_hwreg_t  *hwreg;				///< Pointer to Hardware Register Map */
        u32             prescaler_value;	///< Prescaler value */
        u32             prescaler_enable;	///< Prescaler enable flag */
        u32             self_restart;		///< Self restart enable flag */
        u32             timer_limit;		///< Timer limit value */
    }timer_instance_t;
    
/** @} */ // End of TIMER_Types group

/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup TIMER_Funcs API Functions
 * @ingroup UserTimer
 * @brief Function definitions for Timer driver.
 * @{
 */
    /** 
     * @brief Apply the software configuration to the hardware.
     *
     * Writes all  values stored in the timer_instance to the corresponding
     * Timer hardware registers.
     *
     * @param inst Pointer to Timer instance.
     */
    void timer_applyConfig(timer_instance_t *inst);
    /**
     * @brief Clear Timer Value to zero.
     * @param inst Pointer to Timer instance.
     */
    void timer_clearValue(timer_instance_t *inst);

    /** @name UserTimer (Get Functions)
     * Read values from the Timer hardware registers.
     * @{
     */
        /**
        /* @brief Get stored Timer Configuration.
         * @param inst Pointer to Timer instance.
         * @return The current configuration bitmask (Enable, Auto-Reload, etc.).
         */
        u32 timer_getConfig(timer_instance_t *inst);
        /**
         * @brief Get stored Timer Limit (Reload Value).
         * @param inst Pointer to Timer instance.
         * @return The count limit value.
         */
        u32 timer_getLimit(timer_instance_t *inst);
        /**
         * @brief Get current Timer Value.
         * @param inst Pointer to Timer instance.
         * @return The current timer count value.
         */
        u32 timer_getValue(timer_instance_t *inst);
        /**
         * @brief Get stored Prescaler Value.
         * @param inst Pointer to Timer instance.
         * @return The current clock prescaler divider.
         */
        u32 timer_getPrescalerValue(timer_instance_t *inst);
    /** @} */

    /** @name UserTimer (Set Functions)
     * Write values to the Timer registers.
     * @note Call timer_applyConfig() to make these changes effective.
     * @{
     */
    
        /**
         /* @brief Set Timer Configuration.
         * @param inst  Pointer to Timer instance.
         * @param value Configuration bitmask (e.g., Enable | Interrupt).
         */
        u32 timer_setConfig(timer_instance_t *inst, u32 value);
        /**
         * @brief Set Prescaler Value.
         * @param inst  Pointer to Timer instance.
         * @param value Clock divider value.
         */
        u32 timer_setPrescalerValue(timer_instance_t *inst, u32 value);
        /**
         * @brief Get stored Timer Limit (Reload Value).
         * @param inst Pointer to Timer instance.
         * @return The count limit value.
         */
        u32 timer_setLimit(timer_instance_t *inst, u32 value);
    /** @} */

/** @} */ // End of TIMER_Funcs group

#ifdef __cplusplus
}
#endif

/** @} */ // End of MAIN UserTimer Group

#endif // TIMER_H