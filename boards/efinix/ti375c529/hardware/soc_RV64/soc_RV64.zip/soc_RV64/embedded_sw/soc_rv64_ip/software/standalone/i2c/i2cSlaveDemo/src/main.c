////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/******************************************************************************
*
* @file main.c: i2cSlaveDemo
*
* @brief This demo demonstrate how to configure Sapphire SoC as an I2C Slave device, emulating
*        the behavior of an I2C EEPROM device. You may use the I2CMasterDemo to act as the
*        master to control this slave device.
*
* @note  Please ensure you've configured the correct address and and number of byte of register
*        address.
*        Please also ensure your hardware and RTL connected the SDA and SCL with pull-up resistors.
*        You may run this demo on a Sapphire SoC while the I2CMasterDemo on another Sapphire SoC,
*        on the same or different board/ device.
*        It assume it is the single master on the bus, and send frame in a blocking manner.
*        Please enable printf_full for a cleaner UART printout.
*
******************************************************************************/

#include <stdio.h>
#include "bsp.h"
#include "userDef.h"
#include "irq.h"

// Include driver
#include "i2c/i2c.h"

unsigned char addr0 = 0x00;     // MSB
unsigned char addr1 = 0x00;     // LSB
u16 addr = 0x00;
unsigned char data0[MEM_SIZE];

#ifdef SYSTEM_I2C_0_IO_CTRL

extern void trap_entry();


//I2C interrupt state
enum {
    IDLE,
    Write_Addr_0,
    Write_Addr_1,
    Read_DATA_0,
    Write_DATA_0
} state = IDLE;

/******************************************************************************
*
* @brief This function configure PLIC setting and init i2c setting.
*
******************************************************************************/
i2c_instance_t I2C = {
    .hwreg      			= I2C_CTRL,
    .slaveAddress			= I2C_SLAVE_ADDR<<1,
    .samplingClockDivider	= 3,
    .timeout				= I2C_CTRL_HZ/1000, //Set to 0 to disable timeout
    .tsuDat					= I2C_CTRL_HZ/(I2C_FREQ*5),
    .tLow					= I2C_CTRL_HZ/(I2C_FREQ*2),
    .tHigh					= I2C_CTRL_HZ/(I2C_FREQ*2),
    .tBuf					= I2C_CTRL_HZ/(I2C_FREQ),
};

plic_instance_t i2c_plic = {
    .target 	= BSP_PLIC_CPU_0,
    .gateway 	= SYSTEM_I2C_0_IO_INTERRUPT,
    .priority 	= 0x1U,
    .enable 	= 0X1U,
    .threshold 	= 0x0U,
};

void i2c_init(){
    i2c_applyConfig(&I2C);
    i2c_setFilterConfig(&I2C, 0, I2C_SLAVE_ADDR | I2C_FILTER_7_BITS | I2C_FILTER_ENABLE);
    i2c_enableInterrupt(&I2C, I2C_INTERRUPT_FILTER);
    plic_applyConfig(&i2c_plic);
    irq_setTrapVector(trap_entry);
    irq_setType(IRQ_EXTERNAL);
    irq_enable();

}

/******************************************************************************
*
* @brief This custom IRQ Handler handles external interrupts for I2C communication.
*        It manages I2C read and write operations based on the received data.
*
******************************************************************************/
int irq_m_i2c0_handler()
{

    u32 irq_status = i2c_getInterruptFlag(&I2C);
    LOG_INFO(DBG_MOD_MAIN,"State: %x\n",state);
    LOG_INFO(DBG_MOD_MAIN,"IRQ Status: %x\n",irq_status);

    if (irq_status & I2C_INTERRUPT_FILTER) {
        i2c_disableInterrupt(&I2C, I2C_INTERRUPT_TX_DATA);
        state = IDLE;
    }

    switch(state){
    case IDLE:
        //I2C filter 0 hit => frame for us
        if(i2c_getFilteringHit(&I2C) == 1){
            //read
            if(i2c_getFilteringStatus(&I2C) == 1){
                LOG_INFO(DBG_MOD_MAIN,"Read operation requested by master\n");
                i2c_sendTxAck(&I2C);
                i2c_sendTxByte(&I2C, data0[addr0]); // Send First Read Value to Master
                state = Read_DATA_0;
            } else {
                LOG_INFO(DBG_MOD_MAIN,"Write operation requested by master\n");
                i2c_sendTxAck(&I2C);
                i2c_sendTxByte(&I2C, 0xFF);
                state = Write_Addr_0;
            }

            i2c_enableInterrupt(&I2C, I2C_INTERRUPT_TX_DATA); // Enable the TX Data interrupt
        }
        else
        {
            // Interrupt occurred but the interrupt is not due to correct address received.
            LOG_ERR(DBG_MOD_MAIN,"unknown condition\n"); 
            state = IDLE;
        }
        i2c_clearInterruptFlag(&I2C, I2C_INTERRUPT_FILTER);
        break;

#if ( WORD_REG_ADDR == 1) // 2-Byte Register Address Selected
        //Write frame 0 to us
        case Write_Addr_0:
            i2c_sendTxAck(&I2C);
            i2c_sendTxByte(&I2C, 0xFF);
            //Get First register address byte from Master
            addr0 = i2c_getRxData(&I2C);
            state = Write_Addr_1;
            break;

            //Write frame to us
        case Write_Addr_1:
            i2c_sendTxAck(&I2C);
            i2c_sendTxByte(&I2C, 0xFF);
            //Get second register address byte from Master
            addr1 = i2c_getRxData(&I2C);
            addr = (addr0 << 8) | addr1; // concatenate 2 bytes of register address into a 16-bit address.
            state = Write_DATA_0;
            break;

        case Write_DATA_0:
            i2c_sendTxAck(&I2C);
            i2c_sendTxByte(&I2C, 0xFF);
            //Get Value from Master
            data0[addr] = i2c_getRxData(&I2C);
            state = Write_DATA_0; // Continue remain at here if there is more write data received.
            addr++; // Increment the address to store the value.
            break;

        //Read frame to us
        case Read_DATA_0:
            addr++;
            i2c_sendTxNack(&I2C);
            // Send second Read Value to Master
            i2c_sendTxByte(&I2C, data0[addr]); // Write selected register data back to master
            state = Read_DATA_0;
            break;

#else // 1-Byte Register Address Selected
        //Write frame to us
        case Write_Addr_0:
            i2c_sendTxAck(&I2C);
            i2c_sendTxByte(&I2C, 0xFF);
            //Get register address from Master
            addr0 = i2c_getRxData(&I2C);
            LOG_INFO(DBG_MOD_MAIN,"Write Address received from master\n");
            state = Write_DATA_0;
            break;

        case Write_DATA_0:
            i2c_sendTxAck(&I2C);
            i2c_sendTxByte(&I2C, 0xFF);
            //Get Value from Master
            data0[addr0] = i2c_getRxData(&I2C);
            LOG_INFO(DBG_MOD_MAIN,"Write Data received from master, addr: %x\n", addr0);
            state = Write_DATA_0; // Continue here if more data receiving from master
            addr0++; // Increment the address to store the value.
            break;

        //Read frame to us
        case Read_DATA_0:
            addr0++;
            i2c_sendTxNack(&I2C);
            // Send second Read Value to Master
            i2c_sendTxByte(&I2C, data0[addr0]);
            LOG_INFO(DBG_MOD_MAIN,"Read Data sent to master, addr: %x\n", addr0);
            state = Read_DATA_0;
            break;
#endif


    }
        return 0;

}





/******************************************************************************
*
* @brief  This function displays the content of the memory. It prints the memory content
*         in a formatted manner, displaying 16 bytes per line with corresponding memory 
*         addresses.
*
******************************************************************************/

void display_memory_content()
{
    int i, j;
    int count = 0;

    printf("\n     0  1  2  3  4  5  6  7  8  9  a  b  c  d  e  f\n");
    for (i = 0; i < MEM_SIZE; i+=16) {
        printf("%2x: ", i);
        for (j = 0; j < 16; j++) {
            printf("%2x ", data0[count++]);
        }
        printf("\n");
    }

    printf("\n");
}


/******************************************************************************
*
* @brief This main function initializes the system, sets up the I2C slave configuration,
*       displays memory content, and waits for user input to display memory content.
*
******************************************************************************/
void main() {
    int n;
    u32 irq_status;
    char key;

    bsp_init();
    printf(ANSI_RESET"Welcome to I2C Slave Demo ! \n");
    for(n=0;n<MEM_SIZE;n++)
    {
        data0[n]=0xff;
    }

    i2c_init();
    printf("I2C 0 init done \n");
    printf("This device will act as I2C Slave with 8 bit x 256 memory\n");
    printf("Configurations: \nSlave Address = 0x%x \nTimeout setting = 0x%x\nTsu = %i \ntLow = %i\ntHigh = %i\ntBuf = %i\n", I2C_SLAVE_ADDR, I2C.timeout, I2C.tsuDat, I2C.tLow, I2C.tHigh, I2C.tBuf);


    display_memory_content();
    LOG_WARN(DBG_MOD_MAIN, "Debug Mode is enabled, please be sure to disable timeout (i2c), set to 0 to avoid partially printing logs. \n");
    while (1) {
        printf("Press i to show the memory content of I2C slave\n");
        printf(">> ");
        scanf("%s",&key);
        if (key == 'i') {
            display_memory_content();
        }
    }
}
#else
/******************************************************************************
*
* @brief This main function is executed when I2C functionality is disabled.
*        It initializes the BSP and prints a message indicating that
*        I2C 0 is disabled, and the user should enable it to run the app.
*
******************************************************************************/

void main() {
    int n;
    bsp_init();
    printf("i2c 0 is disabled, please enable it to run this app \n");
}
#endif

