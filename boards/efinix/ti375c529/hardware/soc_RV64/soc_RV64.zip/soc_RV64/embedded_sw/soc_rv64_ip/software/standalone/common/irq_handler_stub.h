////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef IRQ_HANDLER_STUB_H
#define IRQ_HANDLER_STUB_H

/**
 * @file irq_handler_stub.h
 * @author Efinix Inc
 * @brief Weak Vector Table Definitions.
 *
 * @warning **IMPLEMENTATION FILE**: This header contains function definitions 
 * and weak aliases. It must be included **exactly once** in the project 
 * (typically by `irq.c` or a dedicated `vector.c`), otherwise linker errors will occur.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include <stdio.h>
#include "type.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup ISR_Stub Default ISR Stubs
 * @ingroup Core_IRQ
 * @brief Weak aliases for all PLIC interrupt sources.
 * @warning **IMPLEMENTATION FILE**: This header contains function definitions 
 * and weak aliases. It must be included **exactly once** in the project 
 * (typically by `irq.c` or a dedicated `vector.c`), otherwise linker errors will occur.
 * 
 * @note These definitions allow the application to override a specific handler 
 * (e.g., `irq_m_user_timer_0_handler`) by simply defining it in `main.c`.
 * If not defined, they default to `irq_handleDefault`.
 * 
 * <b> Example of modifying default IRQ function with custom content<b/>
 * @code
 * 
 * // Assign a task to timer 0 interrupt handler, and override the default handler.
 * // When timer 0 interrupt fires, it will execute the user-defined function instead of the default one.
 * void irq_m_userTimer0_handler(){
 * 		printf("Entering timer 0 interrupt routine .. \n");
 * 		count++;
 * 		printf("Count:%d .. Done \n",count);
 *}
 *
 * @endcode
 * 
 * @{
 */

/* ========================================================================== */
/* DEFAULT HANDLER                                                            */
/* ========================================================================== */

    /**
     * @brief Default Fallback Interrupt Handler.
     * @details Invoked if an interrupt fires but no specific handler is defined.
     * @return 0
     */
    int irq_handleDefault(void);

    /* Note: Implementation inside header (See file warning) */
    int irq_handleDefault(void) {
        LOG_WARN(DBG_MOD_IRQ, "Default IRQ handler invoked (Unhandled Interrupt).");
        return 0;
    }

/* ========================================================================== */
/* WEAK ALIASES                                                               */
/* ========================================================================== */

    /**
     * @brief System Interrupts
     * @{
     */
    int irq_m_invalid_handler(void)       __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_system_axi_a_handler(void)  __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_watch_dog_handler(void)     __attribute__((weak, alias("irq_handleDefault")));
    /** @} */

    
/* ========================================================================== */
/* PERIPHERAL HANDLERS (Specific Hardware)                                    */
/* ========================================================================== */

    /** 
     * @brief UART (IDs 1-3) 
     * Meaning: Machine Mode UART 0 Handler 
     * */
    int irq_m_uart0_handler(void)  __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_uart1_handler(void)  __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_uart2_handler(void)  __attribute__((weak, alias("irq_handleDefault")));

    /**
     * @brief SPI (IDs 6-8) 
     * */
    int irq_m_spi0_handler(void)   __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_spi1_handler(void)   __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_spi2_handler(void)   __attribute__((weak, alias("irq_handleDefault")));

    /**  
     * @brief I2C (IDs 11-15) 
     * */
    int irq_m_i2c0_handler(void)   __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_i2c1_handler(void)   __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_i2c2_handler(void)   __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_i2c3_handler(void)   __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_i2c4_handler(void)   __attribute__((weak, alias("irq_handleDefault")));

    /**  
     * @brief GPIO (IDs 16-19) 
     * */
    int irq_m_gpio0_0_handler(void)   __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_gpio0_1_handler(void)   __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_gpio1_0_handler(void)   __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_gpio1_1_handler(void)   __attribute__((weak, alias("irq_handleDefault")));

    /**  
     * @brief User Timer (IDs 21-25) 
     * */
    int irq_m_userTimer0_handler(void)   __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_userTimer1_handler(void)   __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_userTimer2_handler(void)   __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_userTimer3_handler(void)   __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_userTimer4_handler(void)   __attribute__((weak, alias("irq_handleDefault")));

    /**  
     * @brief WatchDog Timer (IDs 26-27) 
     * */
    int irq_m_watchDog0_handler(void)   __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_watchDog1_handler(void)   __attribute__((weak, alias("irq_handleDefault")));

    /**  
     * @brief AXI A (ID 30)
     * */   
    int irq_m_axiA_handler(void)   __attribute__((weak, alias("irq_handleDefault")));

    /**  
     * @brief L2 Cache Control (ID 31)
     * */   
    int irq_m_l2Cache_handler(void)   __attribute__((weak, alias("irq_handleDefault")));
    
/* ========================================================================== */
/* FABRIC HANDLERS (Generic "User" Inputs)                                    */
/* ========================================================================== */

    /**
     * @brief User Interrupts (IDs 32-39) 
    /* */
    int irq_m_user_a_handler(void)    __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_user_b_handler(void)    __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_user_c_handler(void)    __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_user_d_handler(void)    __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_user_e_handler(void)    __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_user_f_handler(void)    __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_user_g_handler(void)    __attribute__((weak, alias("irq_handleDefault")));
    int irq_m_user_h_handler(void)    __attribute__((weak, alias("irq_handleDefault")));

/** @} */ // End of ISR_Stub

#ifdef __cplusplus
}
#endif

#endif // IRQ_HANDLER_STUB_H