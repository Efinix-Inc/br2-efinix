////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef TEMP_SENSOR_H_
#define TEMP_SENSOR_H_

/**
 * @file temp_sensor.h
 * @author Efinix Inc
 * @brief Temperature Sensor driver API definitions.
 *
 * This file provides data structures and APIs for controlling
 * the Temperature Sensor peripheral on the EfxSapphireSoC platform.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "i2c/i2c.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup TEMP_SENSOR Temperature Sensor Driver
 * @brief Temperature Sensor driver.
 * @ingroup sensor_group
 *
 * This module provides Generic functions to configure and control
 * Temperature Sensor input/output and interrupt behavior.
 * @section Example_TEMP_SENSOR Usage & Initialization.
 * This is an example show how to instantiate @ref TEMP_SENSOR with @ref temp_sensor_instance_t.
 * 
 * This implementation depends on @ref I2C.
 * 
 * @code  
 * #include "temp_sensor/temp_sensor.h"
 * 
 * #define I2C_CTRL_HZ    						SYSTEM_CLINT_HZ
 * #define I2C_CTRL       						(i2c_hwreg_t *)SYSTEM_I2C_0_IO_CTRL
 * #define I2C_FREQ       						100000
 * #define ACTIVE_TEMP_SENSOR_TYPE    			SENSOR_TYPE_EMC1413
 * 
 * temp_sensor_instance_t TEMP_SENSOR = {
 * 	.drv  = &TEMP_SENSOR_DRIVER,
 * 	.inst = &(i2c_instance_t){
 * 		.hwreg      			= I2C_CTRL,
 * 		.slaveAddress			= TEMP_SENSOR_CTRL,
 * 		.samplingClockDivider	= 3,
 * 		.timeout				= I2C_CTRL_HZ/1000,
 * 		.tsuDat					= I2C_CTRL_HZ/(I2C_FREQ*5),
 * 		.tLow					= I2C_CTRL_HZ/(I2C_FREQ*2),
 * 		.tHigh					= I2C_CTRL_HZ/(I2C_FREQ*2),
 * 		.tBuf					= I2C_CTRL_HZ/(I2C_FREQ),
 * },
 * };
 * 
 * TEMP_SENSOR.drv->applyConfig(&TEMP_SENSOR);
 * TEMP_SENSOR.drv->enableErrorInterrupt(&TEMP_SENSOR);
 * TEMP_SENSOR.drv->getTemp(&TEMP_SENSOR);
 * printf("Current Temperature: %.2f°C\n", TEMP_SENSOR.temp_value.channels[0].current_temp);
 * @endcode
 * @see Supported_TEMP_SENSOR - Learn about the supported Temperature Sensor list.
 * @see @ref temperatureSensorDemo "Example Temperature Sensor Demo" - Learn how to use the driver for Temperature Sensor operations
 * @{
 */

/* ========================================================================== */
/* SUB-GROUP : Data Types			                                         */
/* ========================================================================== */

/**
 * @defgroup TEMP_SENSOR_ENUM Data Types
 * @ingroup TEMP_SENSOR
 * @brief Enums used by the driver.
 * @{
 */

    /** @name Callback Enums
     * @brief Enums used for driver callback handling.
     * @note Used to indicate success or failure of Temperature Sensor operations.
     * @{
     */

        
    /** @brief Temperature Sensor Status List.
     *	@note Used to indicate the status of Temperature Sensor operations.
     */
    typedef enum {
        TEMP_SENSOR_OK       	= 0,	///< Successful Operation */
        TEMP_SENSOR_ERR  		= 1,  	///< Failed to retrieve/write value */
        TEMP_SENSOR_USER_ERR   	= 2,  	///< User provide wrong input */
        TEMP_SENSOR_SKIP  		= 3,  	///< Skip the function */
        TEMP_SENSOR_HIGH_ALERT  = 4, 	///< High Temperature Alert */
        TEMP_SENSOR_LOW_ALERT   = 5, 	///< Low Temperature Alert */
    } temp_sensor_status_t;

    /** @} */	
/** @} */ // End of TEMP_SENSOR_ENUM group

/* ========================================================================== */
/* SUB-GROUP : DATA STRUCTS                                          			*/
/* ========================================================================== */
/**
 * @defgroup TEMP_SENSOR_Types Data Structures
 * @ingroup TEMP_SENSOR
 * @brief Structs used by the driver.
 * @note
 * <b> This is an example show how to instantiate Temperature Sensor with 
 * @ref temp_sensor_instance_t, @ref temp_sensor_data_t, and @ref temp_sensor_api_t.
 * 
 * @code 
 * #define I2C_CTRL_HZ				SYSTEM_CLINT_HZ
 * #define I2C_CTR					(i2c_hwreg_t *)SYSTEM_I2C_0_IO_CTRL
 * #define I2C_FREQ					100000
 * #define TEMP_SENSOR_CTRL			TEMP_EMC1413_ADDR
 * #define TEMP_SENSOR_DRIVER		EMC1413_DRIVER
 * 
 * temp_sensor_instance_t TEMP_SENSOR = {
 * 	.drv  = &TEMP_SENSOR_DRIVER,
 * 	.inst = &(i2c_instance_t){
 * 		.hwreg      			= I2C_CTRL,
 * 		.slaveAddress			= TEMP_SENSOR_CTRL,
 * 		.samplingClockDivider	= 3,
 * 		.timeout				= I2C_CTRL_HZ/1000,
 * 		.tsuDat					= I2C_CTRL_HZ/(I2C_FREQ*5),
 * 		.tLow					= I2C_CTRL_HZ/(I2C_FREQ*2),
 * 		.tHigh					= I2C_CTRL_HZ/(I2C_FREQ*2),
 * 		.tBuf					= I2C_CTRL_HZ/(I2C_FREQ),
 * },
 * };
 * 
 * temp_sensor_init(&TEMP_SENSOR);
 * TEMP_SENSOR.drv->getTemp(&TEMP_SENSOR);
 * u8 alert = TEMP_SENSOR.drv->checkTempAlert(&TEMP_SENSOR);
 * @endcode
 * @{
 */
    /** @brief Forward declaration of Temperature Sensor instance */
    typedef struct temp_sensor_instance temp_sensor_instance_t;

     /**
     * @brief Hold temperature data for a single channel/diode.
     * @note This structure holds the individual components of temperature data.
     */
    typedef struct {
        float current_temp;		///< Current Temperature */
        float high_limit;		///< High Temperature Limit */
        float low_limit;		///< Low Temperature Limit */
    }temp_sensor_channelData_t;

    /**
     * @brief Temperature Sensor data structure.
     * @note This structure holds temperature data for multiple channels/diodes.
     */
    typedef struct {
        temp_sensor_channelData_t channels[3]; // Supports up to 3 diodes
    } temp_sensor_data_t;
    /**
     * @brief Temperature Sensor API structure.
     * @note This structure holds function pointers for Temperature Sensor operations.
     * 		- applyConfig: Function to apply I2C and temperature configuration.
     * 		- enableErrorInterrupt: Function to enable error interrupt.
     * 		- getTemp: Function to get current temperature.
     * 		- getTempLimit: Function to get temperature limits.
     * 		- setTempRange: Function to set temperature range (extended or normal).
     * 		- setTempLimit: Function to set temperature limits.
     * 		- checkTempRange: Function to check if temperature is within range.
     * 		- checkTempAlert: Function to check for temperature alerts.
     */
    typedef struct {
        temp_sensor_status_t (*applyConfig)(temp_sensor_instance_t *temp);
        temp_sensor_status_t (*enableErrorInterrupt)(temp_sensor_instance_t *temp);
        temp_sensor_status_t (*getTemp)(temp_sensor_instance_t *temp);
        temp_sensor_status_t (*getTempLimit)(temp_sensor_instance_t *temp);
        temp_sensor_status_t (*setTempRange)(temp_sensor_instance_t *temp, u8 enable_extended);
        temp_sensor_status_t (*setTempLimit)(temp_sensor_instance_t *temp);
        temp_sensor_status_t (*checkTempAlert)(temp_sensor_instance_t *temp);
        u8 (*checkTempRange)(temp_sensor_instance_t *temp);
    }temp_sensor_api_t;

    /**
     * @brief Temperature Sensor instance structure.
     * @note This structure holds the instance data, driver and i2c setting for
     * 			an Temperature Sensor peripheral.
     * 		- inst: Pointer to I2C instance used for Temperature Sensor communication.	
     * 		- drv:  Pointer to Temperature Sensor API structure. 
     * 				Uses function pointers for Temperature Sensor operations.
     * 		- temp_value: Temperature Sensor data structure holding temperature readings.
     */  			
    struct temp_sensor_instance{
        i2c_instance_t 			*inst;			///< Pointer to I2C instance */
        const temp_sensor_api_t *drv;			///< Pointer to Temperature Sensor API structure */
        temp_sensor_data_t		temp_value;		///< Temperature Sensor data */
    } ;

/** @} */ // End of TEMP_SENSOR_Types group


/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup TEMP_SENSOR_Funcs API Functions
 * @ingroup TEMP_SENSOR
 * @brief Common Function definitions for Temperature Sensor driver.
 * @{
 */
     /**
     * @brief Apply I2C + Temp Sensor configuration.
     * @param rtc Pointer to Temperature Sensor instance.
     * @return Status code of the operation.
     */
    temp_sensor_status_t tempSensor_applyConfig(temp_sensor_instance_t *temp);
     /**
     * @brief Enable error interrupt for the Temperature Sensor.
     * @param rtc Pointer to Temperature Sensor instance.
     * @return Status code of the operation.
     */
    temp_sensor_status_t tempSensor_enableErrorInterrupt(temp_sensor_instance_t *temp);
    /**
     * @brief Read a register from the Temperature Sensor.
     * @param temp Pointer to Temperature Sensor instance.
     * @param reg Register address to read from.
     * @return Value read from the register.
     */
    u8 tempSensor_readTempReg(temp_sensor_instance_t *temp, const u8 reg);
    /**
     * @brief Write a value to a register in the Temperature Sensor.
     * @param temp Pointer to Temperature Sensor instance.
     * @param reg Register address to write to.
     * @param data Value to write to the register.
     * @return Status code of the operation.
     */
    u8 tempSensor_writeTempReg(temp_sensor_instance_t *temp, const u8 reg, const u8 data);
    /**
     * @brief Encode temperature limit into high and low byte format.
     * @param val Temperature value to encode.
     * @param is_extended Flag indicating if extended range is used.
     * @param out_hb Pointer to store the output high byte.
     * @param out_lb Pointer to store the output low byte.
     * @return Status code of the operation.
     */
    u8 tempSensor_encodeTempLimit(float val, u8 is_extended, u8 *out_hb, u8 *out_lb);
    /**
     * @brief Calculate temperature in Celsius from high and low byte format.
     * @param hb High byte of the temperature value.
     * @param lb Low byte of the temperature value.
     * @param is_extended Flag indicating if extended range is used.
     * @return Calculated temperature in Celsius.
     */
    float tempSensor_calTempCelsius(u8 hb, u8 lb, u8 is_extended);
/** @} */ // End of TEMP_SENSOR_Funcs group



/* ========================================================================== */
/* SUB-GROUP: TEMP SENSOR CONFIGURATION                                       */
/* ========================================================================== */

/** Temperature Sensor Configuration */
#include "sensor/temp_sensor/temp_sensor_config.h"

#ifdef __cplusplus

}
#endif
/** @} */ //End of TEMP_SENSOR group

#endif /* TEMP_SENSOR_H_ */
