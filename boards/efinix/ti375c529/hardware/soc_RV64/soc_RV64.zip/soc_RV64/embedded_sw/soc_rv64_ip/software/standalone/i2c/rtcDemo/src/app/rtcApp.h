////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/*******************************************************************************
*
* @file RTC_APP.h
*
* @brief Header file contain high level API for RTC
*
******************************************************************************/

#ifndef SRC_APP_RTCAPP_H_
#define SRC_APP_RTCAPP_H_

#include "rtc/rtc.h"

/* -----------------------------------------------------------------------------*/
/*  RTC APP - Public API		              						
/* -----------------------------------------------------------------------------*/
u8 rtcApp_setTime(rtc_instance_t *rtc) ;
u8 rtcApp_setTimeSystem(rtc_instance_t *rtc);
void rtcApp_printTime(rtc_instance_t *rtc) ;
u32 rtcApp_getValidInt(const char* prompt, u32 min, u32 max) ;


/* -----------------------------------------------------------------------------*/
/*  Structure for RTCdemo		              						
/* -----------------------------------------------------------------------------*/
typedef enum {
    IDLE,
    READ_DATA,
    WRITE_DATA,
    CONFIG_TIMESYSTEM,
}  states;


//Main Menu Strings
#define  	RTC_MENU	"************Rtc Demo Main Menu***************  \n" \
                            "Please key in the selection and press enter: \n" \
                            "1: Check Time 2: Configure Time\n" \
                            "3: Change TimeSystem (12/24hrs)\n" \
                            "*****************************************  \n\n"


#ifdef __cplusplus

}
#endif
                            
#endif /* SRC_APP_RTCAPP_H_ */
