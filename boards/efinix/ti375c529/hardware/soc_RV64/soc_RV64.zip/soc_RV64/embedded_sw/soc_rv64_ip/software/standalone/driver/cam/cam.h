////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef SRC_CAM_H_
#define SRC_CAM_H_

/**
 * @file cam.h
 * @author Efinix Inc
 * @brief CAM driver API definitions.
 *
 * This file provides data structures and APIs for controlling
 * the CAM peripheral on the EfxSapphireSoC platform.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "i2c/i2c.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup CAM_DRV Camera Driver
 * @brief Camera driver.
 * @ingroup cam
 *
 * This module provides Generic functions to configure and control
 * CAM input/output and interrupt behavior.
 * 
 * @section Example_CAM Usage & Initialization.
 * This is an example show how to instantiate @ref CAM with @ref cam_instance_t.
 * 
 * This implementation depends on @ref I2C.
 * 
 * @code  
 * #include "cam/cam.h"
 * 
 * #define I2C_CTRL_HZ    						SYSTEM_CLINT_HZ
 * #define I2C_CTRL       						(i2c_hwreg_t *)SYSTEM_I2C_0_IO_CTRL
 * #define I2C_FREQ       						100000
 * cam_instance_t CAM = {
 * 	.drv  = &CAM_DRIVER,
 * 	.inst = &(i2c_instance_t){
 * 		.hwreg      			= I2C_CTRL,
 * 		.slaveAddress			= CAM_CTRL,
 * 		.samplingClockDivider	= 3,
 * 		.timeout				= I2C_CTRL_HZ/1000,
 * 		.tsuDat					= I2C_CTRL_HZ/(I2C_FREQ*5),
 * 		.tLow					= I2C_CTRL_HZ/(I2C_FREQ*2),
 * 		.tHigh					= I2C_CTRL_HZ/(I2C_FREQ*2),
 * 		.tBuf					= I2C_CTRL_HZ/(I2C_FREQ),
 * },
 * };
 * 
 * CAM.drv->applyConfig(&CAM);
 * CAM.drv->enableErrorInterrupt(&CAM);
 * CAM.drv->initCam(&CAM);
 * CAM.drv->startStreaming(&CAM);
 * @endcode
 * @see Supported_CAM - Learn about the supported Camera list.
 * @{
 */


/* ========================================================================== */
/* SUB-GROUP : Data Types			                                         */
/* ========================================================================== */

/**
 * @defgroup CAM_ENUM Data Types
 * @ingroup CAM_DRV
 * @brief Enums used by the driver.
 * @{
 */

    /** @name Callback Enums
     * @brief Enums used for driver callback handling.
     * @note Used to indicate success or failure of CAM operations.
     * @{
     */

        
    /** @brief CAM Status List.
     *	@note Used to indicate the status of CAM operations.
     */
    typedef enum {
        CAM_OK       	= 0,	///< Successful Operation */
        CAM_ERR  		= 1,  	///< Failed to retrieve/write value */
        CAM_USER_ERR   	= 2,  	///< User provide wrong input */
        CAM_SKIP  		= 3, 	///< Skip the function */
    } cam_status_t;
    /** @} */
/** @} */ // End of CAM_ENUM group


/* ========================================================================== */
/* SUB-GROUP : DATA STRUCTS                                          			*/
/* ========================================================================== */
/**
 * @defgroup CAM_Types Data Structures
 * @ingroup CAM_DRV
 * @brief Structs used by the driver.
 * @note
 * 
 * <b> This is an example show how to instantiate CAM with @ref cam_instance_t,
 * @ref cam_api_t.
 * 
 * @code 
 * #include "cam/cam.h"
 * #define I2C_CTRL_HZ    	SYSTEM_CLINT_HZ
 * #define I2C_CTRL       	(i2c_hwreg_t *)SYSTEM_I2C_0_IO_CTRL
 * #define I2C_FREQ       	100000
 * 
 * CAM_instance_t CAM = {
 * 	.drv  = &CAM_DRIVER,
 * 	.inst = &(i2c_instance_t){
 * 		.hwreg      			= I2C_CTRL,
 * 		.slaveAddress			= CAM_CTRL,
 * 		.samplingClockDivider	= 3,
 * 		.timeout				= I2C_CTRL_HZ/1000,
 * 		.tsuDat					= I2C_CTRL_HZ/(I2C_FREQ*5),
 * 		.tLow					= I2C_CTRL_HZ/(I2C_FREQ*2),
 * 		.tHigh					= I2C_CTRL_HZ/(I2C_FREQ*2),
 * 		.tBuf					= I2C_CTRL_HZ/(I2C_FREQ),
 * },
 * };
 * 
 * @endcode
 * @{
 */

    /** @brief Forward declaration of CAM instance */
    typedef struct cam_instance cam_instance_t;

    /**
     * @brief CAM API structure.
     * @note This structure holds function pointers for CAM operations.
     */
    typedef struct {
        cam_status_t (*applyConfig) (cam_instance_t *cam);			///< Apply i2c config
        cam_status_t (*enableErrorInterrupt)(cam_instance_t *cam);	///< Enable error interrupt function pointer
        cam_status_t (*initCam)(cam_instance_t *cam);				///< Initialize Camera function pointer 
        cam_status_t (*startStreaming)(cam_instance_t *cam);	///< Start Camera Streaming function pointer 
        cam_status_t (*stopStreaming)(cam_instance_t *cam);		///< Stop Camera Streaming function pointer 
    }cam_api_t;

    /**
     * @brief CAM instance structure.
     * @note This structure holds the instance data, driver and i2c setting for 
     * 		 an CAM peripheral.
     * 			- inst: Pointer to I2C instance used for CAM communication.	
     * 			- drv:  Pointer to CAM API structure. Uses function pointers for CAM operations.
     * 			- current_time: Current time data structure.
     */
    struct cam_instance {
        i2c_instance_t	*inst;			///< Pointer to I2C instance */
        const cam_api_t *drv;			///< Pointer to CAM API structure */
    };

/** @} */ // End of CAM_Types group

/* ========================================================================== */
/* SUB-GROUP: FUNCTIONS                                                     */
/* ========================================================================== */

/**
 * @defgroup CAM_Funcs API Functions
 * @ingroup CAM_DRV
 * @brief These are common API functions for CAM driver (Read/Write Register).
 * @note Refer to @ref cam_api_t to see the full list of function pointers for CAM operations.
 * 
 * @note Refer to @ref Supported_CAM for device-specific driver functions.
 * @{
 */
    /** @name Common Function (read/write register)
     * Helper function.
     * @{
    */
        /**
         * @brief Write Data to specific register in camera
         */
        void cam_writeReg(cam_instance_t *cam, u16 reg, u8 data);
        /**
         * @brief Read Data from specific register in camera
         */
        u8 cam_readReg(cam_instance_t *cam, u16 reg);
    /** @} */ // End of CAM Public API - String Based Functions group

/** @} */ // End of CAM_Funcs group

/* ========================================================================== */
/* SUB-GROUP: CAMERA CONFIGURATION                                               */
/* ========================================================================== */

    /** Camera config **/
    #include "cam/cam_config.h"


#ifdef __cplusplus
}
#endif
/** @} */ // End of MAIN CAM Group

#endif /* SRC_CAM_H_ */
