////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef RTC_CONFIG_H
#define RTC_CONFIG_H

/**
 * @file rtc_config.h
 * @author Efinix Inc
 * @brief RTC Configuration and Driver Selection.
 *
 * This file automatically selects the correct I2C address and 
 * driver structure based on the user-defined ACTIVE_RTC_TYPE.
 * @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
 * See the full @ref license_page for Efinix and SaxonSoc MIT terms.
 */

#include "userDef.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup RTC_Config Driver Configuration
 * @ingroup RTC
 * @brief Automatic hardware selection logic.
 * @{
 */

/* ========================================================================== */
/* SUB-GROUP: DRIVER SELECTION LOGIC                                          */
/* ========================================================================== */

/** @name Automatic Driver Selection
 * Resolves the low-level driver implementation based on @ref ACTIVE_RTC_TYPE.
 * This allows the user to switch RTC devices by changing a single configuration value in userDef.h.
 * @note 
 * 		- User can switch between supported RTC devices by changing
 * 		  the ACTIVE_RTC_TYPE macro.
 * 			- Add #define ACTIVE_RTC_TYPE RTC_TYPE_PCF8523 in userDef.h to use PCF8523 RTC.
 * 			- Add #define ACTIVE_RTC_TYPE RTC_TYPE_DS3231 in userDef.h to use DS3231 RTC.
 * 		- For custom RTC devices, include the custom driver header and define
 * 		  RTC_CTRL and RTC_DRIVER macros accordingly.
 * 			- Refer to userDef.h in rtcDemo of including a custom RTC driver.
 * @{
 */

#if (ACTIVE_RTC_TYPE == RTC_TYPE_PCF8523)
    #include "rtc/device/PCF8523.h"
    
    /** @brief I2C Address for the currently selected RTC (PCF8523). 
	 * @note User can switch to different RTC device by changing ACTIVE_RTC_TYPE macro in userDef.h.
	*/
    #define RTC_CTRL    RTC_PCF8523_ADDR 	///< RTC_CTRL used for Address of RTC controller */
    
    /** @brief Driver Interface Table for the currently selected RTC (PCF8523). 
	 * @note User can switch to different RTC device by changing ACTIVE_RTC_TYPE macro in userDef.h.
	 */
    #define RTC_DRIVER   PCF8523_DRIVER		///< RTC_DRIVER used for Driver API Table of RTC controller */

#elif (ACTIVE_RTC_TYPE == RTC_TYPE_DS3231)
    #include "rtc/device/DS3231.h"

    /** @brief I2C Address for the currently selected RTC (DS3231).
	 * @note User can switch to different RTC device by changing ACTIVE_RTC_TYPE macro in userDef.h.
	 */
    #define RTC_CTRL    RTC_DS3231_ADDR		///< RTC_CTRL used for Address of RTC controller */

    /** @brief Driver Interface Table for the currently selected RTC (DS3231).
	 * @note User can switch to different RTC device by changing ACTIVE_RTC_TYPE macro in userDef.h.
	 */
    #define RTC_DRIVER  DS3231_DRIVER		///< RTC_DRIVER used for Driver API Table of RTC controller */
#else
    #warning "Unsupported ACTIVE_RTC_TYPE"
    #warning "Make sure to include the custom driver !!"
#endif

/** @} */ // End of Automatic Driver Selection

/** @} */ // End of RTC_Config Group

#ifdef __cplusplus
}
#endif // C_plusplus

#endif // RTC_CONFIG_H