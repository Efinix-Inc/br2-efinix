////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

#ifndef VEX_RISCV_H_
#define VEX_RISCV_H_

#include "riscv.h"
#include "type.h"

#ifdef __cplusplus
extern "C" {
#endif

//Invalidate the whole instruction cache
#define instruction_cache_invalidate() asm("fence.i");

#if __riscv_xlen == 32
    //Invalidate the whole data cache
    #define data_cache_invalidate_all() asm(".word(0x500F)");

    //Invalidate all the data cache ways lines which could store the given address
    #define data_cache_invalidate_address(address)     \
    ({                                             \
        asm volatile(                              \
         ".word ((0x500F) | (regnum_%0 << 15));"   \
         :                                         \
         : "r" (address)                               \
        );                                         \
    })
#endif //RV32

#if __riscv_xlen == 64
    #ifdef __riscv_zicbom
        // Flush the caches using the Rvcbm flush instruction. This will also flush the L2 cache, work with virtual address
        // Note, to ensure all the flush are done, call the rvcbm_fence()
        #define rvcbm_flush_address(address)                       \
            ({                                   \
                register uintptr_t _tmp = (uintptr_t)(address); \
                __asm__ volatile (".word 0x20200F | (regnum_%0 << 15)" :: "r"(_tmp)); \
            })

        // Flush the caches using the Rvcbm flush instruction. This will also flush the L2 cache, work with virtual address
        // Note, to ensure all the flush are done, call the rvcbm_fence()
        static void rvcbm_flush(void* address, u64 size){
            u64 ptr = (((u64)address) >> 6) << 6;
            u64 end = (u64)address + size;
            while(ptr < end){
                rvcbm_flush_address(ptr);
                ptr += 64;
            }
        }

        // Ensure all the previously executed rvcbm flush are done
        #define rvcbm_fence() asm("fence")

    #endif // __riscv_zicbom

    // Software Prefetcher
    // Ask the L1 data cache to prefetch the memory at the given address, for future CPU read
    #define prefetch_r(address)                       \
        ({                                   \
            register uintptr_t _tmp = (uintptr_t)(address); \
            __asm__ volatile ("ori x0, %0, 1" :: "r"(_tmp)); \
        })

    // Ask the L1 data cache to prefetch the memory at given address, for future CPU read/write
    #define prefetch_rw(address)                       \
        ({                                   \
            register uintptr_t _tmp = (uintptr_t)(address); \
            __asm__ volatile ("ori x0, %0, 3" :: "r"(_tmp)); \
        })


    // Ask the L1 data cache to prefetch the memory at the given (address + offset * 64), for future CPU read
    #define prefetch_r_line(address, offset)                       \
        ({                                   \
            register uintptr_t _tmp = (uintptr_t)(address); \
            __asm__ volatile ("ori x0, %0, %c1" :: "r"(_tmp), "i"(1 + ((offset) * 64))); \
        })

    // Ask the L1 data cache to prefetch the memory at the given (address + offset * 64), for future CPU read/write
    #define prefetch_rw_line(address, offset)                       \
        ({                                   \
            register uintptr_t _tmp = (uintptr_t)(address); \
            __asm__ volatile ("ori x0, %0, %c1" :: "r"(_tmp), "i"(3 + ((offset) * 64))); \
        })
#endif //RV64

#ifdef __cplusplus
}
#endif // C_plusplus

#endif // VEX_RISCV_H_


