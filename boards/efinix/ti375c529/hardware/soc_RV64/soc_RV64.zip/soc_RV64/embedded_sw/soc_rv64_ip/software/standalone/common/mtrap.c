////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////


/**
* @file mtrap.c
* @brief Trap and Exception Handling Implementation.
*
* Implements the functions defined in mtrap.h for handling traps and exceptions
* on the EfxSapphireSoC platform.
* @copyright 2013-2026 Efinix Inc. All rights reserved. <br>
* See the full @ref license_page for Efinix and SaxonSoc MIT terms.
*/

#include <stddef.h> 
#include "bsp.h"
#include "mtrap.h"

/******************************************************************************
*
* @brief Default Fallback Interrupt Handler.
* @note Invoked if an interrupt fires but no specific handler is defined.
*
******************************************************************************/
int irq_handleDefault(void) {
    LOG_WARN(DBG_MOD_IRQ, "Default IRQ handler invoked (Unhandled Interrupt).");
    return 0;
}

/******************************************************************************
*
* @brief These are weak aliases for all PLIC interrupt sources.
* @note The user can override any of these by defining a function with the same name.
*
******************************************************************************/
int irq_m_invalid_handler(void)       	__attribute__((weak, alias("irq_handleDefault"))); // ID: 0
int irq_m_uart0_handler(void)  			__attribute__((weak, alias("irq_handleDefault"))); // ID: 1
int irq_m_uart1_handler(void)  			__attribute__((weak, alias("irq_handleDefault"))); // ID: 2
int irq_m_uart2_handler(void)  			__attribute__((weak, alias("irq_handleDefault"))); // ID: 3
int irq_m_spi0_handler(void)   			__attribute__((weak, alias("irq_handleDefault"))); // ID: 6
int irq_m_spi1_handler(void)   			__attribute__((weak, alias("irq_handleDefault"))); // ID: 7
int irq_m_spi2_handler(void)   			__attribute__((weak, alias("irq_handleDefault"))); // ID: 8
int irq_m_i2c0_handler(void)   			__attribute__((weak, alias("irq_handleDefault"))); // ID: 11
int irq_m_i2c1_handler(void)   			__attribute__((weak, alias("irq_handleDefault"))); // ID: 12
int irq_m_i2c2_handler(void)   			__attribute__((weak, alias("irq_handleDefault"))); // ID: 13
int irq_m_i2c3_handler(void)   			__attribute__((weak, alias("irq_handleDefault"))); // ID: 14
int irq_m_i2c4_handler(void)   			__attribute__((weak, alias("irq_handleDefault"))); // ID: 15
int irq_m_gpio0_0_handler(void)   		__attribute__((weak, alias("irq_handleDefault"))); // ID: 16
int irq_m_gpio0_1_handler(void)   		__attribute__((weak, alias("irq_handleDefault"))); // ID: 17
int irq_m_gpio1_0_handler(void)   		__attribute__((weak, alias("irq_handleDefault"))); // ID: 18
int irq_m_gpio1_1_handler(void)   		__attribute__((weak, alias("irq_handleDefault"))); // ID: 19
int irq_m_userTimer0_handler(void)   	__attribute__((weak, alias("irq_handleDefault"))); // ID: 21
int irq_m_userTimer1_handler(void)   	__attribute__((weak, alias("irq_handleDefault"))); // ID: 22
int irq_m_userTimer2_handler(void)   	__attribute__((weak, alias("irq_handleDefault"))); // ID: 23
int irq_m_watchDog0_handler(void)   	__attribute__((weak, alias("irq_handleDefault"))); // ID: 26
int irq_m_axiA_handler(void)   			__attribute__((weak, alias("irq_handleDefault"))); // ID: 30  
int irq_m_l2Cache_handler(void)   		__attribute__((weak, alias("irq_handleDefault"))); // ID: 31
int irq_m_user_a_handler(void)    		__attribute__((weak, alias("irq_handleDefault"))); // ID: 32
int irq_m_user_b_handler(void)    		__attribute__((weak, alias("irq_handleDefault"))); // ID: 33
int irq_m_user_c_handler(void)    		__attribute__((weak, alias("irq_handleDefault"))); // ID: 34
int irq_m_user_d_handler(void)    		__attribute__((weak, alias("irq_handleDefault"))); // ID: 35
int irq_m_user_e_handler(void)    		__attribute__((weak, alias("irq_handleDefault"))); // ID: 36
int irq_m_user_f_handler(void)    		__attribute__((weak, alias("irq_handleDefault"))); // ID: 37
int irq_m_user_g_handler(void)    		__attribute__((weak, alias("irq_handleDefault"))); // ID: 38
int irq_m_user_h_handler(void)    		__attribute__((weak, alias("irq_handleDefault"))); // ID: 39


/******************************************************************************
*
* @brief Vector Table for PLIC Interrupts.
*
******************************************************************************/
int (*interrupt_vector_table[64])(void) =
{
    irq_m_invalid_handler,	// 0
    irq_m_uart0_handler,	// 1
    irq_m_uart1_handler,	// 2
    irq_m_uart2_handler,	// 3
    0,						// 4
    0,						// 5
    irq_m_spi0_handler,   	// 6
    irq_m_spi1_handler,   	// 7
    irq_m_spi2_handler,   	// 8
    0,						// 9
    0,						// 10
    irq_m_i2c0_handler,   	// 11
    irq_m_i2c1_handler,   	// 12
    irq_m_i2c2_handler,   	// 13
    irq_m_i2c3_handler,   	// 14
    irq_m_i2c4_handler,   	// 15
    irq_m_gpio0_0_handler,	// 16
    irq_m_gpio0_1_handler,	// 17
    irq_m_gpio1_0_handler,	// 18
    irq_m_gpio1_1_handler,	// 19
    0,							// 20
    irq_m_userTimer0_handler,	// 21
    irq_m_userTimer1_handler,	// 22
    irq_m_userTimer2_handler,	// 23
    0,							// 24
    0,							// 25
    irq_m_watchDog0_handler,	// 26
    0,							// 27
    0,							// 28
    0,							// 29
    irq_m_axiA_handler,			// 30
    irq_m_l2Cache_handler,		// 31
    irq_m_user_a_handler,		// 32 
    irq_m_user_b_handler,		// 33 
    irq_m_user_c_handler,		// 34 
    irq_m_user_d_handler,		// 35 
    irq_m_user_e_handler,		// 36 
    irq_m_user_f_handler,		// 37 
    irq_m_user_g_handler,		// 38 
    irq_m_user_h_handler,		// 39 
};


/******************************************************************************
*
* @brief This function uses for setting up the trap entry point.
* @note Naked function to setup the stack and call the C trap handler.
* @note This trap entry should work for both RV32 and RV64, with or without FPU, 
* by adjusting the stack frame accordingly.
*
******************************************************************************/
__attribute__((naked, aligned(4))) 
void trap_entry (void) {

    asm volatile (
        "addi sp,sp, -(" STACK_SIZE ")\n"

        // --- SAVE GPRs ---
        STORE " x1,   0*"GPR_SIZE"(sp)\n"
        STORE " x5,   1*"GPR_SIZE"(sp)\n"
        STORE " x6,   2*"GPR_SIZE"(sp)\n"
        STORE " x7,   3*"GPR_SIZE"(sp)\n"
        STORE " x10,  4*"GPR_SIZE"(sp)\n"
        STORE " x11,  5*"GPR_SIZE"(sp)\n"
        STORE " x12,  6*"GPR_SIZE"(sp)\n"
        STORE " x13,  7*"GPR_SIZE"(sp)\n"
        STORE " x14,  8*"GPR_SIZE"(sp)\n"
        STORE " x15,  9*"GPR_SIZE"(sp)\n"
        STORE " x16, 10*"GPR_SIZE"(sp)\n"
        STORE " x17, 11*"GPR_SIZE"(sp)\n"
        STORE " x28, 12*"GPR_SIZE"(sp)\n"
        STORE " x29, 13*"GPR_SIZE"(sp)\n"
        STORE " x30, 14*"GPR_SIZE"(sp)\n"
        STORE " x31, 15*"GPR_SIZE"(sp)\n"

#ifdef __riscv_flen
        // --- SAVE FPRs ---
        FSTORE " f0,  (16*"GPR_SIZE" + 0*"FPR_SIZE")(sp)\n"
        FSTORE " f1,  (16*"GPR_SIZE" + 1*"FPR_SIZE")(sp)\n"
        FSTORE " f2,  (16*"GPR_SIZE" + 2*"FPR_SIZE")(sp)\n"
        FSTORE " f3,  (16*"GPR_SIZE" + 3*"FPR_SIZE")(sp)\n"
        FSTORE " f4,  (16*"GPR_SIZE" + 4*"FPR_SIZE")(sp)\n"
        FSTORE " f5,  (16*"GPR_SIZE" + 5*"FPR_SIZE")(sp)\n"
        FSTORE " f6,  (16*"GPR_SIZE" + 6*"FPR_SIZE")(sp)\n"
        FSTORE " f7,  (16*"GPR_SIZE" + 7*"FPR_SIZE")(sp)\n"
        FSTORE " f10, (16*"GPR_SIZE" + 8*"FPR_SIZE")(sp)\n"
        FSTORE " f11, (16*"GPR_SIZE" + 9*"FPR_SIZE")(sp)\n"
        FSTORE " f12, (16*"GPR_SIZE" + 10*"FPR_SIZE")(sp)\n"
        FSTORE " f13, (16*"GPR_SIZE" + 11*"FPR_SIZE")(sp)\n"
        FSTORE " f14, (16*"GPR_SIZE" + 12*"FPR_SIZE")(sp)\n"
        FSTORE " f15, (16*"GPR_SIZE" + 13*"FPR_SIZE")(sp)\n"
        FSTORE " f16, (16*"GPR_SIZE" + 14*"FPR_SIZE")(sp)\n"
        FSTORE " f17, (16*"GPR_SIZE" + 15*"FPR_SIZE")(sp)\n"
        FSTORE " f28, (16*"GPR_SIZE" + 16*"FPR_SIZE")(sp)\n"
        FSTORE " f29, (16*"GPR_SIZE" + 17*"FPR_SIZE")(sp)\n"
        FSTORE " f30, (16*"GPR_SIZE" + 18*"FPR_SIZE")(sp)\n"
        FSTORE " f31, (16*"GPR_SIZE" + 19*"FPR_SIZE")(sp)\n"
        
        // --- SAVE FCSR ---
        "csrr t0, fcsr\n"
        STORE " t0,   (16*"GPR_SIZE" + 20*"FPR_SIZE")(sp)\n"
#endif

        "call trap\n"

#ifdef __riscv_flen
        // --- RESTORE FCSR ---
        LOAD " t0,    (16*"GPR_SIZE" + 20*"FPR_SIZE")(sp)\n"
        "csrw fcsr, t0\n"

        // --- RESTORE FPRs ---
        FLOAD " f0,  (16*"GPR_SIZE" + 0*"FPR_SIZE")(sp)\n"
        FLOAD " f1,  (16*"GPR_SIZE" + 1*"FPR_SIZE")(sp)\n"
        FLOAD " f2,  (16*"GPR_SIZE" + 2*"FPR_SIZE")(sp)\n"
        FLOAD " f3,  (16*"GPR_SIZE" + 3*"FPR_SIZE")(sp)\n"
        FLOAD " f4,  (16*"GPR_SIZE" + 4*"FPR_SIZE")(sp)\n"
        FLOAD " f5,  (16*"GPR_SIZE" + 5*"FPR_SIZE")(sp)\n"
        FLOAD " f6,  (16*"GPR_SIZE" + 6*"FPR_SIZE")(sp)\n"
        FLOAD " f7,  (16*"GPR_SIZE" + 7*"FPR_SIZE")(sp)\n"
        FLOAD " f10, (16*"GPR_SIZE" + 8*"FPR_SIZE")(sp)\n"
        FLOAD " f11, (16*"GPR_SIZE" + 9*"FPR_SIZE")(sp)\n"
        FLOAD " f12, (16*"GPR_SIZE" + 10*"FPR_SIZE")(sp)\n"
        FLOAD " f13, (16*"GPR_SIZE" + 11*"FPR_SIZE")(sp)\n"
        FLOAD " f14, (16*"GPR_SIZE" + 12*"FPR_SIZE")(sp)\n"
        FLOAD " f15, (16*"GPR_SIZE" + 13*"FPR_SIZE")(sp)\n"
        FLOAD " f16, (16*"GPR_SIZE" + 14*"FPR_SIZE")(sp)\n"
        FLOAD " f17, (16*"GPR_SIZE" + 15*"FPR_SIZE")(sp)\n"
        FLOAD " f28, (16*"GPR_SIZE" + 16*"FPR_SIZE")(sp)\n"
        FLOAD " f29, (16*"GPR_SIZE" + 17*"FPR_SIZE")(sp)\n"
        FLOAD " f30, (16*"GPR_SIZE" + 18*"FPR_SIZE")(sp)\n"
        FLOAD " f31, (16*"GPR_SIZE" + 19*"FPR_SIZE")(sp)\n"
#endif

        // --- RESTORE GPRs ---
        LOAD " x1 ,  0*"GPR_SIZE"(sp)\n"
        LOAD " x5,   1*"GPR_SIZE"(sp)\n"
        LOAD " x6,   2*"GPR_SIZE"(sp)\n"
        LOAD " x7,   3*"GPR_SIZE"(sp)\n"
        LOAD " x10,  4*"GPR_SIZE"(sp)\n"
        LOAD " x11,  5*"GPR_SIZE"(sp)\n"
        LOAD " x12,  6*"GPR_SIZE"(sp)\n"
        LOAD " x13,  7*"GPR_SIZE"(sp)\n"
        LOAD " x14,  8*"GPR_SIZE"(sp)\n"
        LOAD " x15,  9*"GPR_SIZE"(sp)\n"
        LOAD " x16, 10*"GPR_SIZE"(sp)\n"
        LOAD " x17, 11*"GPR_SIZE"(sp)\n"
        LOAD " x28, 12*"GPR_SIZE"(sp)\n"
        LOAD " x29, 13*"GPR_SIZE"(sp)\n"
        LOAD " x30, 14*"GPR_SIZE"(sp)\n"
        LOAD " x31, 15*"GPR_SIZE"(sp)\n"

        "addi sp,sp, " STACK_SIZE "\n"
        "mret\n"
    );
}

/******************************************************************************
*
* @brief Claim pending interrupts for a hart and call their corresponding handlers.
*
* @param hart_id Hart ID
*
* @note Uses PLIC claim/release mechanism.
*
******************************************************************************/
void irq_handleExt()
{
    volatile uintptr_t id; 

    while ((id = plic_claimExtIRQ_m())) {

        // Call the external interrupt handler
        interrupt_vector_table[id]();

        plic_releaseExtIRQ_m(id);
    }
}

/******************************************************************************
*
* @brief This function handles to report exception counter and cause .
*
* @note Default exception handler to read and print mepc and mcause.
*		__attribute__((weak)) means the user can override this function.
*
******************************************************************************/
__attribute__((weak))
void irq_handleException()
{
    LOG_ERR(DBG_MOD_FAULT,"Exception occurred!\n");
    LOG_ERR(DBG_MOD_FAULT,"mepc: 0x%lx\n", csr_read(mepc));
    LOG_ERR(DBG_MOD_FAULT,"mcause: 0x%lx\n", csr_read(mcause));
    while(1) {
        __asm__ volatile ("wfi");
    }

}

/******************************************************************************
*
* @brief This function uses when unexpected cause happens.
*
* @note Default crash handler for any unhandled exceptions or interrupts.
*		__attribute__((weak)) means the user can override this function.
*
******************************************************************************/
__attribute__((weak))
void crash()
{
    LOG_ERR(DBG_MOD_FAULT,"\n*** Unsupported irq or exception ***\n");
    while(1) {
        __asm__ volatile ("wfi");
    }
}

/******************************************************************************
*
* @brief Default function handles both exceptions and interrupts.
*
* @note Called by trap_entry (from trap.S) on any trap event.
*		It reads mcause to determine the type of trap, and then
*		calls the corresponding handler function.
*		If unhandled, it calls crash().
* 		__attribute__((weak)) means the user can override this function.
*
******************************************************************************/
__attribute__((weak)) 
void trap(){
    // Read the current hart/core ID
    volatile uintptr_t mhartid = csr_read(mhartid);

    // Read the cause of the trap
    volatile intptr_t mcause = csr_read(mcause);

    // Determine if it is an interrupt (true) or exception (false)
    intptr_t interrupt = mcause < 0;
    intptr_t cause     = mcause & 0xF; // Lower bits indicate cause

    if(interrupt){ // Handle interrupts
        switch(cause){

        case CAUSE_MACHINE_SOFTWARE:
            // Needs a handler that clears the CLINT MSIP bit.
            irq_handleSoft(); 
            break;

        case CAUSE_MACHINE_TIMER:
            // Needs a handler that updates the CLINT mtimecmp register.
            irq_handleTimer(); 
            break;

        case CAUSE_MACHINE_EXTERNAL:
            // It handles the PLIC "Claim/Release" dance.
            irq_handleExt(); 
            break;
        default: 
            crash();                // Call crash if interrupt is unhandled
        }
    } else { // Handle exceptions
        switch (cause){
            case CAUSE_INSTRUCTION_ADDR_MISALIGNED: // Instruction address misaligned
            case CAUSE_ACCESS_FAULT:				// Memory access fault
            case CAUSE_ILLEGAL_INSTRUCTION:			// Illegal instruction executed
            case CAUSE_BREAKPOINT:					// Breakpoint trap
            case CAUSE_LOAD_ADDR_MISALIGNED:		// Load address misaligned
            case CAUSE_LOAD_ACCESS_FAULT:			// Load access fault
            case CAUSE_STORE_AMO_ADDR_MISALIGNED:	// Store/AMO address misaligned
            case CAUSE_STORE_AMO_ACCESS_FAULT:		// Store/AMO access fault
            case CAUSE_ENV_CALL_U_MODE:				// Environment call from U-mode
            case CAUSE_ENV_CALL_S_MODE:				// Environment call from S-mode
            case CAUSE_ENV_CALL_M_MODE:				// Environment call from M-mode
            case CAUSE_INSTRUCTION_PAGE_FAULT:		// Instruction page fault
            case CAUSE_LOAD_PAGE_FAULT:				// Load page fault
            case CAUSE_STORE_AMO_PAGE_FAULT:		// Store/AMO page fault
                irq_handleException();
                break;
            default: 							 	// Any other exception
                crash();
        }
    }
}
