////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/*******************************************************************************
*
* @file TEMP_SENSOR_APP.h
*
* @brief Header file contain high level API for Temperature Sensor
*
******************************************************************************/

#ifndef SRC_APP_TEMP_SENSORAPP_H_
#define SRC_APP_TEMP_SENSORAPP_H_

#include "sensor/temp_sensor/temp_sensor.h"
#include "../userDef.h"

#ifdef __cplusplus
extern "C" {
#endif


/* -----------------------------------------------------------------------------*/
/*  Temperature Sensor APP - Public API
/* -----------------------------------------------------------------------------*/
void tempSensorApp_configure(temp_sensor_instance_t *temp);


#ifdef __cplusplus

}
#endif
							
#endif /* SRC_APP_TEMP_SENSORAPP_H_ */
