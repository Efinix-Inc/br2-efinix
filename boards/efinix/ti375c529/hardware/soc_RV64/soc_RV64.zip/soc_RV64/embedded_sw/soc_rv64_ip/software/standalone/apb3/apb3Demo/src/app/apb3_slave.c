#include "apb3_slave.h"

/*******************************************************************************
* @brief Read a 32-bit value from the APB3 slave status register (APB3_REG0).
*
* @param inst Pointer to the APB3 instance.
* @return The value read from the APB3 slave register.
******************************************************************************/
u32 apb3_read(apb3_instance_t *inst)
{
    if (!inst || !inst->hwreg) return 0;
    
    // Direct memory read using the struct
    return inst->hwreg->APB3_REG0_STATUS;
}

/*******************************************************************************
* @brief Applies the software configuration to the hardware registers.
* * @note This handles the bit-packing for APB3_REG1 and APB3_REG3 automatically based
* on the values stored in the instance structure.
*
* @param inst Pointer to the APB3 instance.
******************************************************************************/   
void apb3_applyConfig(apb3_instance_t *inst)
{
    if (!inst || !inst->hwreg) return;

    // Pack and write APB3_REG1 (LFSR Stop: bit 0)
    inst->hwreg->APB3_REG1_CTRL = (inst->lfsr_stop & 0x01);

    // Pack and write APB3_REG3 (Mem Start: bit 0, iLen: bits 8-15)
    u32 reg3_val = 0;
    reg3_val |= (inst->mem_start & 0x01) << 0;
    reg3_val |= (inst->ilen & 0xFF) << 8;
    
    inst->hwreg->APB3_REG3_OWRITE_CTRL = reg3_val;
}

/*******************************************************************************
* @brief Write standard data to the APB3 slave (APB3_REG4).
*
* @param inst Pointer to the APB3 instance.
* @param data The 32-bit data to be written.
******************************************************************************/ 
void apb3_write_data(apb3_instance_t *inst, u32 data)
{
    if (!inst || !inst->hwreg) return;
    inst->hwreg->APB3_REG4_DATA = data;
}

/*******************************************************************************
* @brief Write an address to the APB3 slave (APB3_REG5).
*
* @param inst Pointer to the APB3 instance.
* @param addr Address to be written to the slave.
******************************************************************************/ 
void apb3_write_addr(apb3_instance_t *inst, u32 addr)
{
    if (!inst || !inst->hwreg) return;
    inst->hwreg->APB3_REG5_ADDR = addr;
}
