////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// Full license header bsp/efinix/EfxSapphireSocRV64/include/LICENSE.MD
////////////////////////////////////////////////////////////////////////////////

/******************************************************************************
*
* @file main.c: apb3Demo
*
* @brief This demo shows how to use an APB3 slave peripheral where APB3 slave is
*        attached to a pseudorandom number generator. When user run the application,
*        the Sapphire SoC programs the APB3 slave to stop generating a new random
*        number and reads the last random number generated. The test passes if the
*        returned data is a non-zero value.
*
* @note Please ensure APB3 is enabled in Sapphire Soc.
*
******************************************************************************/
#include <stdio.h>
#include "bsp.h"
#include "app/apb3_slave.h"
#include "userDef.h"

#ifdef IO_APB_SLAVE_0_CTRL

    #define APB0    IO_APB_SLAVE_0_CTRL

#endif


/*******************************************************************************
*
* @brief This main function initialize the system and stop APB3 from generating a
*        new random number and read the value from APB3 slave. The result is passed
*        if the return value is non-zero.
*
******************************************************************************/
void main(void) {
    u32 data = 0;
    bsp_init();

#ifdef APB0

    printf(ANSI_RESET"Welcome to APB3 Slave 0 Demo!\n");

    // Instantiate the APB3 device and link the hardware address
    apb3_instance_t APB3 = {
        .hwreg = (apb3_hwreg_t *)APB0, // Link the memory map
        .lfsr_stop = 0,
        .mem_start = 0,
        .ilen      = 0
    };

    // Modify the configuration and apply it
    APB3.lfsr_stop = 1;
    apb3_applyConfig(&APB3);

    // Read the data from APB3 slave and print it
    data = apb3_read(&APB3);
    printf("Random number: 0x%x \n", data);

    // Evaluate the result 
    if (data == 0x0) {
        printf("Failed! \n");
        while (1) {} // Trap the CPU on failure
    } else {
        printf("Passed! \n");
    }

#else

    printf(ANSI_RED "[ERR] APB3 Slave 0 is disabled, please enable it to run this app.\n" ANSI_RESET);

#endif

}

