module axi4_memTester #(
	parameter FREQ = 100,
	parameter DW = 128,
	parameter ID = 'hE,
	parameter NUM_PER_BURST = 1024,
	parameter START_ADDR = 37'h802000000
) (

	input				clk,
	input				rst,
	input				start,
	output reg			led_status,
	output reg			aw_valid,
	input				aw_ready,
	output reg [36:0]	aw_payload_addr,
	output reg [3:0]	aw_payload_id,
	output reg [3:0]	aw_payload_region,
	output reg [7:0]	aw_payload_len,
	output reg [2:0]	aw_payload_size,
	output reg [1:0]	aw_payload_burst,
	output reg			aw_payload_lock,
	output reg [3:0]	aw_payload_cache,
	output reg [3:0]	aw_payload_qos,
	output reg [2:0]	aw_payload_prot,
	output reg			aw_payload_allStrb,
	output reg			w_valid,
	input				w_ready,
	output reg [DW-1:0]	w_payload_data,
	output reg [DW/8-1:0] w_payload_strb,
	output reg			w_payload_last,
	input				b_valid,
	output reg			b_ready,
	input   [3:0]		b_payload_id,
	input   [1:0]		b_payload_resp,
	output reg			ar_valid,
	input				ar_ready,
	output reg [36:0]	ar_payload_addr,
	output reg [3:0]	ar_payload_id,
	output reg [3:0]	ar_payload_region,
	output reg [7:0]	ar_payload_len,
	output reg [2:0]	ar_payload_size,
	output reg [1:0]	ar_payload_burst,
	output reg			ar_payload_lock,
	output reg [3:0]	ar_payload_cache,
	output reg [3:0]	ar_payload_qos,
	output reg [2:0]	ar_payload_prot,
	input				r_valid,
	output reg			r_ready,
	input [DW-1:0]		r_payload_data,
	input [3:0]			r_payload_id,
	input [1:0]			r_payload_resp,
	input				r_payload_last
);
//////////////////////////////////////////////
localparam	SIZE =	(DW == 512)?	6 :
					(DW == 256)?	5 :
					(DW == 128)?	4 :
					(DW == 64)?		3 : 2;

localparam	ADDR_LSB =	(DW == 1024)?	7 :
						(DW == 512)?	6 :
						(DW == 256)?	5 :
						(DW == 128)?	4 :
						(DW == 64 )?	3 : 2;

localparam STATE_NUM = 16;
localparam [$clog2(STATE_NUM)-1:0]	IDLE = 8'd0,
	ARM = 8'd1,
	REQ_WRITE = 8'd2,
	REQ_READ = 8'd3,
	WRITE = 8'd4,
	WRITE_RSP = 8'd5,
	READ = 8'd6,
	CHANGE	= 8'd7,
	ERR = 8'd8,
	ERR_ID	= 8'd9,
	DONE = 8'd15;

reg [$clog2(STATE_NUM)-1:0]		
				tester_st, tester_next;
reg [$clog2(NUM_PER_BURST)-1:0]	
				transfer_cnt;
reg				transfer_last_flag;
reg [7:0]		burstlen_cnt;
reg [36:0]		address_cnt;
reg [31:0]		led_cnt;
wire			compareError;
wire			incrBurst;
wire			incr;
// write
reg [8:0]		w_cnt;
wire			w_en;
wire			w_valid_prbs;
reg				w_done;
wire			last_op;
// read
reg  			r_done;
// read check
wire [DW-1:0]	r_payload_data_check;
// delay
wire			aw_valid_d;
wire [36:0]		aw_payload_addr_d;
wire [3:0]		aw_payload_id_d;
wire [3:0]		aw_payload_region_d;
wire [7:0]		aw_payload_len_d;
wire [2:0]		aw_payload_size_d;
wire [1:0]		aw_payload_burst_d;
wire			aw_payload_lock_d;
wire [3:0]		aw_payload_cache_d;
wire [3:0]		aw_payload_qos_d;
wire [2:0]		aw_payload_prot_d;
wire			aw_payload_allStrb_d;
wire			w_valid_d;
wire [DW-1:0]	w_payload_data_d;
wire [DW/8-1:0] w_payload_strb_d;
wire			w_payload_last_d;
wire			b_ready_d;
wire			ar_valid_d;
wire [36:0]		ar_payload_addr_d;
wire [3:0]		ar_payload_id_d;
wire [3:0]		ar_payload_region_d;
wire [7:0]		ar_payload_len_d;
wire [2:0]		ar_payload_size_d;
wire [1:0]		ar_payload_burst_d;
wire			ar_payload_lock_d;
wire [3:0]		ar_payload_cache_d;
wire [3:0]		ar_payload_qos_d;
wire [2:0]		ar_payload_prot_d;
wire			r_ready_d;
//////////////////////////////////////////////
// tester logic

assign incr = (tester_st == ARM) && (transfer_cnt != 'd0);
assign incrBurst = (transfer_last_flag && ((b_valid && b_ready_d) || (r_payload_last && r_valid)));
assign last_op = (incr && burstlen_cnt == 'd0 && transfer_cnt == NUM_PER_BURST-1);
assign compareError = r_valid ? (r_payload_data != r_payload_data_check) :  1'b0;

always@(posedge clk or posedge rst)
begin
	if(rst)
		transfer_cnt <= 'd0;
	else
	begin
		if((aw_valid_d && aw_ready) || (ar_valid_d && ar_ready))
			if(transfer_cnt == NUM_PER_BURST-1)
				transfer_cnt <= 'd0;
			else
				transfer_cnt <= transfer_cnt + 1'b1;
	end
end

always@(posedge clk)
begin
	if((transfer_cnt == NUM_PER_BURST-1) && (tester_st == ARM))
		transfer_last_flag <= 1'b1;
	else if (b_valid && b_ready_d || (r_payload_last && r_valid))
		transfer_last_flag <= 1'b0;
	else	
		transfer_last_flag <= transfer_last_flag;
end

always@(posedge clk or posedge rst)
begin
	if(rst)
		burstlen_cnt <= 'd255;
	else
	begin
		if(tester_st == CHANGE)
		   burstlen_cnt <= 'd255;
		else if(incrBurst)
			burstlen_cnt <= burstlen_cnt >> 1'b1;
	end
end

always@(posedge clk or posedge rst)
begin
	if(rst)
		address_cnt <= START_ADDR;
	else
	begin
		if(tester_st == CHANGE)
		   address_cnt <= START_ADDR;
		else if(incr || incrBurst)
		//else if(incr)
			address_cnt <= address_cnt + ((burstlen_cnt + 1'b1) << ADDR_LSB);
		else
			address_cnt <= address_cnt;
	end
end

always@ (posedge clk or posedge rst)
begin
	if(rst)
	begin
		led_cnt <= 'd0;
		led_status <= 1'b0; 
	end
	else
	begin
		if(tester_st == ERR)
		begin
			if(led_cnt == ((FREQ<<1)*10000-1))
			begin
				led_cnt <= 'd0;
				led_status <= ~led_status;
			end
		else	
			begin
				led_cnt <= led_cnt + 1'b1;
				led_status <= led_status;
			end
		end 
		else if (tester_st == ERR_ID)
		begin
			if(led_cnt == ((FREQ<<3)*10000-1))
			begin
				led_cnt <= 'd0;
				led_status <= ~led_status;
			end
		else	
			begin
				led_cnt <= led_cnt + 1'b1;
				led_status <= led_status;
			end
		end 
		else if(tester_st == DONE)
		begin
			led_cnt <= 'd0;
			led_status <= 1'b1;
		end
	end
end
//////////////////////////////////////////////
always @(*) begin
	aw_valid <= aw_valid_d;
	aw_payload_addr <= aw_payload_addr_d;
	aw_payload_id <= aw_payload_id_d;
	aw_payload_region <= aw_payload_region_d;
	aw_payload_len <= aw_payload_len_d;
	aw_payload_size <= aw_payload_size_d;
	aw_payload_burst <= aw_payload_burst_d;
	aw_payload_lock <= aw_payload_lock_d;
	aw_payload_cache <= aw_payload_cache_d;
	aw_payload_qos <= aw_payload_qos_d;
	aw_payload_prot <= aw_payload_prot_d;
	aw_payload_allStrb <= aw_payload_allStrb_d;
	w_payload_last <= w_payload_last_d;
	w_payload_strb <= w_payload_strb_d;
	w_payload_data <= w_payload_data_d;
	w_valid <= w_valid_d;
	b_ready <= b_ready_d;
	ar_valid <= ar_valid_d;
	ar_payload_addr <= ar_payload_addr_d;
	ar_payload_id <= ar_payload_id_d;
	ar_payload_region <= ar_payload_region_d;
	ar_payload_len <= ar_payload_len_d;
	ar_payload_size <= ar_payload_size_d;
	ar_payload_burst <= ar_payload_burst_d;
	ar_payload_lock <= ar_payload_lock_d;
	ar_payload_cache <= ar_payload_cache_d;
	ar_payload_qos <= ar_payload_qos_d;
	ar_payload_prot <= ar_payload_prot_d;
	r_ready <= r_ready_d;
end


// AW
assign aw_valid_d = (tester_st == REQ_WRITE);
assign aw_payload_addr_d = address_cnt;
assign aw_payload_id_d= ID;
assign aw_payload_region_d = 'h0;
assign aw_payload_len_d = burstlen_cnt;
assign aw_payload_size_d = SIZE;
assign aw_payload_burst_d = 2'b01;
assign aw_payload_lock_d = 1'b0;
assign aw_payload_cache_d = 4'h0;
assign aw_payload_qos_d = 4'h0;
assign aw_payload_prot_d = 3'b000;
assign aw_payload_allStrb_d = 1'b0;

wire w_last;
// W
assign w_payload_last_d = (w_cnt == (burstlen_cnt));
assign w_payload_strb_d = {DW/8{1'b1}};

always@(posedge clk or posedge rst)
begin
	if(rst)
		w_done <= 1'b0;
	else
	begin
		if(last_op)
			w_done <= 1'b1;
	end
end

always@(posedge clk or posedge rst)
begin
	if(rst)
		w_cnt <= 1'b0;
	else
	begin
		if(tester_st == WRITE)
			if(w_ready)
				w_cnt <= w_cnt + 1'b1;
			else	
				w_cnt <= w_cnt;
		else
			w_cnt <= 'd0;
	end
end

assign w_en = (tester_st == WRITE) && w_ready;

prbs32b #(
	.DW(DW)
) prbs32b_winst (
	.clk (clk),
	.rst (rst),
	.ce (w_en),
	.prbs (w_payload_data_d),
	.valid (w_valid_prbs)
);

assign w_valid_d = w_valid_prbs;

// B
assign b_ready_d = (tester_st == WRITE_RSP);

// AR
assign ar_valid_d = (tester_st == REQ_READ);
assign ar_payload_addr_d = address_cnt;
assign ar_payload_id_d	= ID;
assign ar_payload_region_d = 'h0;
assign ar_payload_len_d = burstlen_cnt;
assign ar_payload_size_d = SIZE;
assign ar_payload_burst_d = 2'b01;
assign ar_payload_lock_d = 1'b0;
assign ar_payload_cache_d = 4'h0;
assign ar_payload_qos_d = 4'h0;
assign ar_payload_prot_d = 3'b000;

// R
assign r_ready_d = (tester_st == READ);

always@(posedge clk or posedge rst)
begin
	if(rst)
		r_done <= 1'b0;
	else
	begin
		if(last_op && w_done)
			r_done <= 1'b1;
	end
end

// read check
prbs32b #(
	.DW(DW)
) prbs32b_rinst (
	.clk (clk),
	.rst (rst),
	.ce (r_valid && r_ready_d),
	.prbs (r_payload_data_check),
	.valid ()
);

//////////////////////////////////////////////
always@(posedge clk or posedge rst)
begin
	if(rst)
		tester_st <= IDLE;
	else
		tester_st <= tester_next;
end

always@(*)
begin
	begin
	tester_next = tester_st;
	case(tester_st)
	IDLE:
	begin
		if(start)
			tester_next = ARM;
		else
			tester_next = IDLE;
	end 
	ARM:
	begin
		if(!w_done)
			tester_next = REQ_WRITE;
		else	
			tester_next = REQ_READ;
	end
	REQ_WRITE:
	begin
		if(aw_valid_d && aw_ready)
			tester_next = WRITE;
		else
			tester_next = REQ_WRITE;
	end
	REQ_READ:
	begin
		if (ar_valid_d && ar_ready)
			tester_next = READ;
		else
			tester_next = REQ_READ;
	end
	WRITE:
	begin
		if(w_ready && w_valid_d && w_payload_last_d)
			tester_next = WRITE_RSP;
		else
			tester_next = WRITE;
	end
	WRITE_RSP:
	begin
		if(b_valid && b_ready_d && !w_done)
		begin
			if(b_payload_id == aw_payload_id_d)
				tester_next = ARM;
			else
				tester_next = ERR_ID;   
		end
		else if (b_valid && b_ready_d && w_done)
		begin
			if(b_payload_id == aw_payload_id_d)
				tester_next = CHANGE;
			else
				tester_next = ERR_ID;
		end
		else
			tester_next = WRITE_RSP;
	end
	READ:
	begin
		if(compareError)
			tester_next = ERR;
		else if(r_ready_d && r_valid && r_payload_last && r_done)
		begin
			if(r_payload_id == ar_payload_id_d)
				tester_next = DONE;
			else
				tester_next = ERR_ID;
			end
		else if(r_ready_d && r_valid && r_payload_last && !r_done)
		begin
			if(r_payload_id == ar_payload_id_d)
				tester_next = ARM;
			else
				tester_next = ERR_ID;
			end
		else	
			tester_next = READ; 
	end
	CHANGE:
		tester_next = ARM;
	ERR:
	begin
		tester_next = ERR;
	end
	ERR_ID:
	begin
		tester_next = ERR_ID;
	end
	DONE:
	begin
		tester_next = DONE;
	end
	endcase
	end
end

//for sim only
initial
begin
	led_status = 1'b0;
	transfer_cnt = {$clog2(NUM_PER_BURST){1'b0}};
	transfer_last_flag = 1'b0;
	burstlen_cnt = 8'd0;
	address_cnt = 32'd0;
	led_cnt = 32'd0;
	w_cnt = 9'd0;
	w_done = 1'b0;
	r_done = 1'b0;
end

endmodule