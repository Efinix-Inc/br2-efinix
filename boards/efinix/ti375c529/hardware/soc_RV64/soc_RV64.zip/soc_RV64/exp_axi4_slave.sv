module axi_slave #(
	parameter D_WIDTH  = 128,
	parameter ID_WIDTH = 6,
	parameter D_DEPTH  = 19
) (
	axi4_if_mm.slave	mm
);
///////////////////////////////////////////////////////////////////////////////
localparam  ADDR_LSB = (D_WIDTH == 1024)? 7 :
	   (D_WIDTH == 512)?  6 :
	   (D_WIDTH == 256)?  5 :
	   (D_WIDTH == 128)?  4 :
	   (D_WIDTH == 64 )?  3 : 2; 

enum logic [1:0] {WIDLE, WPROC, WRITE, WRESP} wnow, wnext;
enum logic [1:0] {RIDLE, RPROC, READ, RRESP} rnow, rnext;

logic [31:0]			r_awaddr;
logic [ID_WIDTH-1:0]	r_awid;
logic [8:0]				r_awlen;
logic [2:0]				r_awsize;
logic [1:0]				r_awburst;
logic					r_awready;
logic					r_wready;
logic					r_bvalid;
logic [1:0]				r_bresp;
logic [ID_WIDTH-1:0]	r_bid;
logic [D_WIDTH/8-1:0]	r_wen;
logic [31:0]			r_araddr;
logic [ID_WIDTH-1:0]	r_arid;
logic [8:0]				r_arlen;
logic [2:0]				r_arsize;
logic [1:0]				r_arburst;
logic					r_arready;
logic					r_rvalid;
logic					r_rlast;
logic					r_rresp;
logic [D_WIDTH-1:0]	 	r_data_o;
logic [D_WIDTH-1:0]	 	r_data;
logic [ID_WIDTH-1:0]	r_rid;

///////////////////////////////////////////////////////////////////////////////

/*top-level port assignment*/
assign mm.awready = r_awready;
assign mm.wready = r_wready;
assign mm.bvalid = r_bvalid;
assign mm.bresp = r_bresp;
assign mm.bid = r_bid;
assign mm.arready = r_arready;
assign mm.rvalid = r_rvalid;
assign mm.rlast = r_rlast;
assign mm.rdata = r_data;
assign mm.rid = r_rid;
assign mm.rresp = r_rresp;

always_comb
begin
	r_awready <= (wnow == WIDLE);
	r_wready <= (wnow == WRITE);
	r_bvalid <= (wnow == WRESP);
	r_bresp <= 2'b00;
	r_bid <= r_awid;
	r_arready <= (rnow == RIDLE);
	r_rvalid <= (rnow == READ);
	r_rlast <= (r_arlen == 8'd1);
	r_data <= r_data_o;
	r_rid <= r_arid;
	r_rresp <= 2'b00;
end

///////////////////////////////////////////////////////////////////////////////

/***************************/

always_ff @(posedge mm.clk or posedge mm.rst)
begin
	if(mm.rst)
		wnow <= WIDLE;
	else
		wnow <= wnext;
end

always_comb 
begin
	wnext = wnow;
	case(wnow)
		WIDLE:if(mm.awvalid && mm.awready) wnext = WPROC; else wnext = WIDLE;
		WPROC: wnext = WRITE;
		WRITE:if(mm.wvalid && mm.wready && mm.wlast) wnext = WRESP; else wnext = WRITE;
		WRESP:if(mm.bvalid && mm.bready) wnext = WIDLE;
		default:wnext = WIDLE;
	endcase
end

always_ff@(posedge mm.clk or posedge mm.rst)
begin
	if(mm.rst)
	begin
		r_awaddr <= 32'd0;
		r_awid <= 6'd0;
		r_awlen <= 8'd0;
		r_awsize <= 3'd0;
		r_awburst <= 2'd0;
	end
	else
	begin
	if(mm.awvalid && mm.awready)
	begin
		r_awaddr <= mm.awaddr;
		r_awid <= mm.awid;
		r_awlen <= mm.awlen + 1'b1;
		r_awsize <= mm.awsize;
		r_awburst <= mm.awburst;
	end
	else
	begin
		if(wnow == WRITE && mm.wvalid)
		begin
			r_awaddr <= r_awaddr + (D_WIDTH/8);
		end
	end
	end
end

genvar i;
generate
begin
	for(i=0;i<D_WIDTH/8;i=i+1)
	begin
		assign r_wen[i] = mm.wready && mm.wvalid && mm.wstrb[i];
	end
end
endgenerate

always_ff @(posedge mm.clk or posedge mm.rst)
begin
	if(mm.rst)
		rnow <= RIDLE;
	else
		rnow <= rnext;
end

always_comb 
begin
	rnext = rnow;
	case(rnow)
		RIDLE:if(mm.arvalid && mm.arready) rnext = RPROC; else rnext = RIDLE;
		RPROC: rnext = READ;
		READ:if(mm.rvalid && mm.rready && mm.rlast) rnext = RRESP; else rnext = READ;
		RRESP: rnext = RIDLE;
		default:rnext = RIDLE;
	endcase
end

always_ff@(posedge mm.clk or posedge mm.rst)
begin
	if(mm.rst)
	begin
		r_araddr <= 32'd0;
		r_arid <= 6'd0;
		r_arlen <= 8'd0;
		r_arsize <= 3'd0;
		r_arburst <= 2'd0;
	end
	else begin
		if(mm.arvalid && mm.arready)
		begin
			r_araddr <= mm.araddr;
			r_arid <= mm.arid;
			r_arlen <= mm.arlen + 1'b1;
			r_arsize <= mm.arsize;
			r_arburst <= mm.arburst;
		end
		else
		begin
		if(rnow == READ && mm.rready)
		begin
			r_araddr <= r_araddr + (D_WIDTH/8);
			r_arlen <= r_arlen - 1'b1;
		end
		end
	end
end

bram #(
	.D_WIDTH (D_WIDTH),
	.D_DEPTH (D_DEPTH),
	.OUTPUT_REG	("FALSE")
) bram_inst (
	.wclk(mm.clk), 
	.we(r_wen),
	.waddr(r_awaddr>>ADDR_LSB), 
	.wdata(mm.wdata),
	.rclk(mm.clk),
	.re(r_rvalid && mm.rready), 
	.raddr(r_araddr>>ADDR_LSB),
	.rdata(r_data_o)
);

endmodule
