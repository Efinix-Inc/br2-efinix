/*
 * ext_interrupt.h
 *
 *  Created on: Oct 19, 2020
 *      Author: shchung
 */

#ifndef SRC_EXT_INTERRUPT_H_
#define SRC_EXT_INTERRUPT_H_

void uart_interrupt_init(void);

#endif /* SRC_EXT_INTERRUPT_H_ */
