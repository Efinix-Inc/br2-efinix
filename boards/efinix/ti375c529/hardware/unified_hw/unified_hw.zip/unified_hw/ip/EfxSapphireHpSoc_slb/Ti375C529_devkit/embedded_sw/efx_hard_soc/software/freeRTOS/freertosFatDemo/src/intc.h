#ifndef HEADER_INTC_H_
#define HEADER_INTC_H_

#include <stdint.h>
#include "bsp.h"
#include "plic.h"
#include "riscv.h"

void IntcInitialize();

#endif
