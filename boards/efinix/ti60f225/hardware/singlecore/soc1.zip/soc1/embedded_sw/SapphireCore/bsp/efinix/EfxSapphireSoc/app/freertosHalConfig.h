/*******************************************************************************
*
* @file freertosHalConfig.h
*
* @brief Header file define external interrupt for FreeRTOS.
*
******************************************************************************/


#pragma once

#define PLIC_MACHINE_TIMER_ID SYSTEM_PLIC_SYSTEM_CORES_0_EXTERNAL_INTERRUPT
