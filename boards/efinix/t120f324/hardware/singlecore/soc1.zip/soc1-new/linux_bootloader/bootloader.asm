
build/bootloader.elf:     file format elf32-littleriscv


Disassembly of section .init:

f9000000 <_start>:
f9000000:	00001197          	auipc	gp,0x1
f9000004:	bb818193          	addi	gp,gp,-1096 # f9000bb8 <__global_pointer$>
f9000008:	8201a023          	sw	zero,-2016(gp) # f90003d8 <smp_lottery_lock>

f900000c <smp_tyranny>:
f900000c:	f1402573          	csrr	a0,mhartid
f9000010:	c515                	beqz	a0,f900003c <init>

f9000012 <smp_slave>:
f9000012:	8201a503          	lw	a0,-2016(gp) # f90003d8 <smp_lottery_lock>
f9000016:	dd75                	beqz	a0,f9000012 <smp_slave>
f9000018:	0220000f          	fence	r,r
f900001c:	0000100f          	.word	0x0000100f
f9000020:	81c1a783          	lw	a5,-2020(gp) # f90003d4 <__bss_start>
f9000024:	4501                	li	a0,0
f9000026:	4581                	li	a1,0
f9000028:	4601                	li	a2,0
f900002a:	8782                	jr	a5

f900002c <smp_unlock>:
f900002c:	80a1ae23          	sw	a0,-2020(gp) # f90003d4 <__bss_start>
f9000030:	0110000f          	fence	w,w
f9000034:	4505                	li	a0,1
f9000036:	82a1a023          	sw	a0,-2016(gp) # f90003d8 <smp_lottery_lock>
f900003a:	8082                	ret

f900003c <init>:
f900003c:	00000117          	auipc	sp,0x0
f9000040:	4a410113          	addi	sp,sp,1188 # f90004e0 <_sp>
f9000044:	00000517          	auipc	a0,0x0
f9000048:	30450513          	addi	a0,a0,772 # f9000348 <_data>
f900004c:	00000597          	auipc	a1,0x0
f9000050:	2fc58593          	addi	a1,a1,764 # f9000348 <_data>
f9000054:	00000617          	auipc	a2,0x0
f9000058:	38060613          	addi	a2,a2,896 # f90003d4 <__bss_start>
f900005c:	00c5fa63          	bgeu	a1,a2,f9000070 <init+0x34>
f9000060:	00052283          	lw	t0,0(a0)
f9000064:	0055a023          	sw	t0,0(a1)
f9000068:	0511                	addi	a0,a0,4
f900006a:	0591                	addi	a1,a1,4
f900006c:	fec5eae3          	bltu	a1,a2,f9000060 <init+0x24>
f9000070:	00000517          	auipc	a0,0x0
f9000074:	36450513          	addi	a0,a0,868 # f90003d4 <__bss_start>
f9000078:	00000597          	auipc	a1,0x0
f900007c:	36858593          	addi	a1,a1,872 # f90003e0 <_end>
f9000080:	00b57763          	bgeu	a0,a1,f900008e <init+0x52>
f9000084:	00052023          	sw	zero,0(a0)
f9000088:	0511                	addi	a0,a0,4
f900008a:	feb56de3          	bltu	a0,a1,f9000084 <init+0x48>
f900008e:	24b9                	jal	f90002dc <__libc_init_array>
f9000090:	2019                	jal	f9000096 <main>

f9000092 <mainDone>:
f9000092:	a001                	j	f9000092 <mainDone>

f9000094 <_init>:
f9000094:	8082                	ret

Disassembly of section .text:

f9000096 <main>:
f9000096:	1141                	addi	sp,sp,-16
f9000098:	c606                	sw	ra,12(sp)
f900009a:	2a31                	jal	f90001b6 <configure_uart>
f900009c:	40b2                	lw	ra,12(sp)
f900009e:	0141                	addi	sp,sp,16
f90000a0:	a22d                	j	f90001ca <bspMain>

f90000a2 <spi_write.constprop.0>:
f90000a2:	f80146b7          	lui	a3,0xf8014
f90000a6:	6741                	lui	a4,0x10
f90000a8:	0691                	addi	a3,a3,4 # f8014004 <__stack_size+0xf8013f04>
f90000aa:	177d                	addi	a4,a4,-1 # ffff <__stack_size+0xfeff>
f90000ac:	429c                	lw	a5,0(a3)
f90000ae:	8ff9                	and	a5,a5,a4
f90000b0:	dff5                	beqz	a5,f90000ac <spi_write.constprop.0+0xa>
f90000b2:	10056513          	ori	a0,a0,256
f90000b6:	f80147b7          	lui	a5,0xf8014
f90000ba:	c388                	sw	a0,0(a5)
f90000bc:	8082                	ret

f90000be <_putchar_s>:
f90000be:	f80107b7          	lui	a5,0xf8010
f90000c2:	f80106b7          	lui	a3,0xf8010
f90000c6:	0791                	addi	a5,a5,4 # f8010004 <__stack_size+0xf800ff04>
f90000c8:	00054703          	lbu	a4,0(a0)
f90000cc:	e311                	bnez	a4,f90000d0 <_putchar_s+0x12>
f90000ce:	8082                	ret
f90000d0:	0505                	addi	a0,a0,1
f90000d2:	4390                	lw	a2,0(a5)
f90000d4:	01065593          	srli	a1,a2,0x10
f90000d8:	0ff5f593          	zext.b	a1,a1
f90000dc:	d9fd                	beqz	a1,f90000d2 <_putchar_s+0x14>
f90000de:	c298                	sw	a4,0(a3)
f90000e0:	b7e5                	j	f90000c8 <_putchar_s+0xa>

f90000e2 <spi_waitXferBusy.constprop.0>:
f90000e2:	f8b0c7b7          	lui	a5,0xf8b0c
f90000e6:	17e1                	addi	a5,a5,-8 # f8b0bff8 <__stack_size+0xf8b0bef8>
f90000e8:	4394                	lw	a3,0(a5)
f90000ea:	03268693          	addi	a3,a3,50 # f8010032 <__stack_size+0xf800ff32>
f90000ee:	4398                	lw	a4,0(a5)
f90000f0:	40e68733          	sub	a4,a3,a4
f90000f4:	fe075de3          	bgez	a4,f90000ee <spi_waitXferBusy.constprop.0+0xc>
f90000f8:	f80146b7          	lui	a3,0xf8014
f90000fc:	6741                	lui	a4,0x10
f90000fe:	0691                	addi	a3,a3,4 # f8014004 <__stack_size+0xf8013f04>
f9000100:	177d                	addi	a4,a4,-1 # ffff <__stack_size+0xfeff>
f9000102:	10000613          	li	a2,256
f9000106:	429c                	lw	a5,0(a3)
f9000108:	8ff9                	and	a5,a5,a4
f900010a:	fec79ee3          	bne	a5,a2,f9000106 <spi_waitXferBusy.constprop.0+0x24>
f900010e:	8082                	ret

f9000110 <spiFlash_f2m.constprop.0>:
f9000110:	1141                	addi	sp,sp,-16
f9000112:	f80146b7          	lui	a3,0xf8014
f9000116:	6741                	lui	a4,0x10
f9000118:	c422                	sw	s0,8(sp)
f900011a:	c226                	sw	s1,4(sp)
f900011c:	c04a                	sw	s2,0(sp)
f900011e:	c606                	sw	ra,12(sp)
f9000120:	892a                	mv	s2,a0
f9000122:	842e                	mv	s0,a1
f9000124:	84b2                	mv	s1,a2
f9000126:	0691                	addi	a3,a3,4 # f8014004 <__stack_size+0xf8013f04>
f9000128:	177d                	addi	a4,a4,-1 # ffff <__stack_size+0xfeff>
f900012a:	429c                	lw	a5,0(a3)
f900012c:	8ff9                	and	a5,a5,a4
f900012e:	dff5                	beqz	a5,f900012a <spiFlash_f2m.constprop.0+0x1a>
f9000130:	6785                	lui	a5,0x1
f9000132:	88078793          	addi	a5,a5,-1920 # 880 <__stack_size+0x780>
f9000136:	f8014737          	lui	a4,0xf8014
f900013a:	c31c                	sw	a5,0(a4)
f900013c:	452d                	li	a0,11
f900013e:	3795                	jal	f90000a2 <spi_write.constprop.0>
f9000140:	01095513          	srli	a0,s2,0x10
f9000144:	0ff57513          	zext.b	a0,a0
f9000148:	3fa9                	jal	f90000a2 <spi_write.constprop.0>
f900014a:	4501                	li	a0,0
f900014c:	3f99                	jal	f90000a2 <spi_write.constprop.0>
f900014e:	4501                	li	a0,0
f9000150:	3f89                	jal	f90000a2 <spi_write.constprop.0>
f9000152:	4501                	li	a0,0
f9000154:	37b9                	jal	f90000a2 <spi_write.constprop.0>
f9000156:	f80147b7          	lui	a5,0xf8014
f900015a:	6741                	lui	a4,0x10
f900015c:	85a2                	mv	a1,s0
f900015e:	94a2                	add	s1,s1,s0
f9000160:	f8014637          	lui	a2,0xf8014
f9000164:	0791                	addi	a5,a5,4 # f8014004 <__stack_size+0xf8013f04>
f9000166:	177d                	addi	a4,a4,-1 # ffff <__stack_size+0xfeff>
f9000168:	20000813          	li	a6,512
f900016c:	4394                	lw	a3,0(a5)
f900016e:	8ef9                	and	a3,a3,a4
f9000170:	def5                	beqz	a3,f900016c <spiFlash_f2m.constprop.0+0x5c>
f9000172:	01062023          	sw	a6,0(a2) # f8014000 <__stack_size+0xf8013f00>
f9000176:	4394                	lw	a3,0(a5)
f9000178:	82c1                	srli	a3,a3,0x10
f900017a:	def5                	beqz	a3,f9000176 <spiFlash_f2m.constprop.0+0x66>
f900017c:	4208                	lw	a0,0(a2)
f900017e:	00158693          	addi	a3,a1,1
f9000182:	00a58023          	sb	a0,0(a1)
f9000186:	02969663          	bne	a3,s1,f90001b2 <spiFlash_f2m.constprop.0+0xa2>
f900018a:	f80146b7          	lui	a3,0xf8014
f900018e:	6741                	lui	a4,0x10
f9000190:	0691                	addi	a3,a3,4 # f8014004 <__stack_size+0xf8013f04>
f9000192:	177d                	addi	a4,a4,-1 # ffff <__stack_size+0xfeff>
f9000194:	429c                	lw	a5,0(a3)
f9000196:	8ff9                	and	a5,a5,a4
f9000198:	dff5                	beqz	a5,f9000194 <spiFlash_f2m.constprop.0+0x84>
f900019a:	40b2                	lw	ra,12(sp)
f900019c:	4422                	lw	s0,8(sp)
f900019e:	6785                	lui	a5,0x1
f90001a0:	80078793          	addi	a5,a5,-2048 # 800 <__stack_size+0x700>
f90001a4:	f8014737          	lui	a4,0xf8014
f90001a8:	c31c                	sw	a5,0(a4)
f90001aa:	4492                	lw	s1,4(sp)
f90001ac:	4902                	lw	s2,0(sp)
f90001ae:	0141                	addi	sp,sp,16
f90001b0:	8082                	ret
f90001b2:	85b6                	mv	a1,a3
f90001b4:	bf65                	j	f900016c <spiFlash_f2m.constprop.0+0x5c>

f90001b6 <configure_uart>:
f90001b6:	f80107b7          	lui	a5,0xf8010
f90001ba:	03500713          	li	a4,53
f90001be:	c798                	sw	a4,8(a5)
f90001c0:	f80107b7          	lui	a5,0xf8010
f90001c4:	471d                	li	a4,7
f90001c6:	c7d8                	sw	a4,12(a5)
f90001c8:	8082                	ret

f90001ca <bspMain>:
f90001ca:	f9000537          	lui	a0,0xf9000
f90001ce:	1141                	addi	sp,sp,-16
f90001d0:	34850513          	addi	a0,a0,840 # f9000348 <_data>
f90001d4:	c606                	sw	ra,12(sp)
f90001d6:	35e5                	jal	f90000be <_putchar_s>
f90001d8:	3ff9                	jal	f90001b6 <configure_uart>
f90001da:	f9000537          	lui	a0,0xf9000
f90001de:	36c50513          	addi	a0,a0,876 # f900036c <_data+0x24>
f90001e2:	3df1                	jal	f90000be <_putchar_s>
f90001e4:	f80147b7          	lui	a5,0xf8014
f90001e8:	0007a423          	sw	zero,8(a5) # f8014008 <__stack_size+0xf8013f08>
f90001ec:	4709                	li	a4,2
f90001ee:	f80147b7          	lui	a5,0xf8014
f90001f2:	d398                	sw	a4,32(a5)
f90001f4:	4695                	li	a3,5
f90001f6:	f80147b7          	lui	a5,0xf8014
f90001fa:	d3d4                	sw	a3,36(a5)
f90001fc:	f80147b7          	lui	a5,0xf8014
f9000200:	d798                	sw	a4,40(a5)
f9000202:	471d                	li	a4,7
f9000204:	f80147b7          	lui	a5,0xf8014
f9000208:	d7d8                	sw	a4,44(a5)
f900020a:	3de1                	jal	f90000e2 <spi_waitXferBusy.constprop.0>
f900020c:	f80146b7          	lui	a3,0xf8014
f9000210:	6741                	lui	a4,0x10
f9000212:	0691                	addi	a3,a3,4 # f8014004 <__stack_size+0xf8013f04>
f9000214:	177d                	addi	a4,a4,-1 # ffff <__stack_size+0xfeff>
f9000216:	429c                	lw	a5,0(a3)
f9000218:	8ff9                	and	a5,a5,a4
f900021a:	dff5                	beqz	a5,f9000216 <bspMain+0x4c>
f900021c:	6785                	lui	a5,0x1
f900021e:	f8014737          	lui	a4,0xf8014
f9000222:	80078793          	addi	a5,a5,-2048 # 800 <__stack_size+0x700>
f9000226:	c31c                	sw	a5,0(a4)
f9000228:	f80146b7          	lui	a3,0xf8014
f900022c:	6741                	lui	a4,0x10
f900022e:	0691                	addi	a3,a3,4 # f8014004 <__stack_size+0xf8013f04>
f9000230:	177d                	addi	a4,a4,-1 # ffff <__stack_size+0xfeff>
f9000232:	429c                	lw	a5,0(a3)
f9000234:	8ff9                	and	a5,a5,a4
f9000236:	dff5                	beqz	a5,f9000232 <bspMain+0x68>
f9000238:	6785                	lui	a5,0x1
f900023a:	f8014737          	lui	a4,0xf8014
f900023e:	88078793          	addi	a5,a5,-1920 # 880 <__stack_size+0x780>
f9000242:	c31c                	sw	a5,0(a4)
f9000244:	0ab00513          	li	a0,171
f9000248:	3da9                	jal	f90000a2 <spi_write.constprop.0>
f900024a:	f80146b7          	lui	a3,0xf8014
f900024e:	6741                	lui	a4,0x10
f9000250:	0691                	addi	a3,a3,4 # f8014004 <__stack_size+0xf8013f04>
f9000252:	177d                	addi	a4,a4,-1 # ffff <__stack_size+0xfeff>
f9000254:	429c                	lw	a5,0(a3)
f9000256:	8ff9                	and	a5,a5,a4
f9000258:	dff5                	beqz	a5,f9000254 <bspMain+0x8a>
f900025a:	6785                	lui	a5,0x1
f900025c:	80078793          	addi	a5,a5,-2048 # 800 <__stack_size+0x700>
f9000260:	f8014737          	lui	a4,0xf8014
f9000264:	c31c                	sw	a5,0(a4)
f9000266:	3db5                	jal	f90000e2 <spi_waitXferBusy.constprop.0>
f9000268:	f8b0c7b7          	lui	a5,0xf8b0c
f900026c:	17e1                	addi	a5,a5,-8 # f8b0bff8 <__stack_size+0xf8b0bef8>
f900026e:	4394                	lw	a3,0(a5)
f9000270:	6705                	lui	a4,0x1
f9000272:	38870713          	addi	a4,a4,904 # 1388 <__stack_size+0x1288>
f9000276:	96ba                	add	a3,a3,a4
f9000278:	4398                	lw	a4,0(a5)
f900027a:	40e68733          	sub	a4,a3,a4
f900027e:	fe075de3          	bgez	a4,f9000278 <bspMain+0xae>
f9000282:	f9000537          	lui	a0,0xf9000
f9000286:	38050513          	addi	a0,a0,896 # f9000380 <_data+0x38>
f900028a:	3d15                	jal	f90000be <_putchar_s>
f900028c:	00040637          	lui	a2,0x40
f9000290:	020005b7          	lui	a1,0x2000
f9000294:	00600537          	lui	a0,0x600
f9000298:	3da5                	jal	f9000110 <spiFlash_f2m.constprop.0>
f900029a:	f9000537          	lui	a0,0xf9000
f900029e:	39050513          	addi	a0,a0,912 # f9000390 <_data+0x48>
f90002a2:	3d31                	jal	f90000be <_putchar_s>
f90002a4:	000c0637          	lui	a2,0xc0
f90002a8:	020405b7          	lui	a1,0x2040
f90002ac:	00680537          	lui	a0,0x680
f90002b0:	3585                	jal	f9000110 <spiFlash_f2m.constprop.0>
f90002b2:	f9000537          	lui	a0,0xf9000
f90002b6:	3a050513          	addi	a0,a0,928 # f90003a0 <_data+0x58>
f90002ba:	3511                	jal	f90000be <_putchar_s>
f90002bc:	02000537          	lui	a0,0x2000
f90002c0:	33b5                	jal	f900002c <smp_unlock>
f90002c2:	f9000537          	lui	a0,0xf9000
f90002c6:	3b050513          	addi	a0,a0,944 # f90003b0 <_data+0x68>
f90002ca:	3bd5                	jal	f90000be <_putchar_s>
f90002cc:	40b2                	lw	ra,12(sp)
f90002ce:	4601                	li	a2,0
f90002d0:	4581                	li	a1,0
f90002d2:	4501                	li	a0,0
f90002d4:	020007b7          	lui	a5,0x2000
f90002d8:	0141                	addi	sp,sp,16
f90002da:	8782                	jr	a5

f90002dc <__libc_init_array>:
f90002dc:	1141                	addi	sp,sp,-16
f90002de:	c422                	sw	s0,8(sp)
f90002e0:	c04a                	sw	s2,0(sp)
f90002e2:	00000797          	auipc	a5,0x0
f90002e6:	06478793          	addi	a5,a5,100 # f9000346 <__init_array_end>
f90002ea:	00000417          	auipc	s0,0x0
f90002ee:	05c40413          	addi	s0,s0,92 # f9000346 <__init_array_end>
f90002f2:	c606                	sw	ra,12(sp)
f90002f4:	c226                	sw	s1,4(sp)
f90002f6:	40878933          	sub	s2,a5,s0
f90002fa:	00878b63          	beq	a5,s0,f9000310 <__libc_init_array+0x34>
f90002fe:	40295913          	srai	s2,s2,0x2
f9000302:	4481                	li	s1,0
f9000304:	401c                	lw	a5,0(s0)
f9000306:	0485                	addi	s1,s1,1
f9000308:	0411                	addi	s0,s0,4
f900030a:	9782                	jalr	a5
f900030c:	ff24ece3          	bltu	s1,s2,f9000304 <__libc_init_array+0x28>
f9000310:	00000797          	auipc	a5,0x0
f9000314:	03678793          	addi	a5,a5,54 # f9000346 <__init_array_end>
f9000318:	00000417          	auipc	s0,0x0
f900031c:	02e40413          	addi	s0,s0,46 # f9000346 <__init_array_end>
f9000320:	40878933          	sub	s2,a5,s0
f9000324:	40295913          	srai	s2,s2,0x2
f9000328:	00878963          	beq	a5,s0,f900033a <__libc_init_array+0x5e>
f900032c:	4481                	li	s1,0
f900032e:	401c                	lw	a5,0(s0)
f9000330:	0485                	addi	s1,s1,1
f9000332:	0411                	addi	s0,s0,4
f9000334:	9782                	jalr	a5
f9000336:	ff24ece3          	bltu	s1,s2,f900032e <__libc_init_array+0x52>
f900033a:	40b2                	lw	ra,12(sp)
f900033c:	4422                	lw	s0,8(sp)
f900033e:	4492                	lw	s1,4(sp)
f9000340:	4902                	lw	s2,0(sp)
f9000342:	0141                	addi	sp,sp,16
f9000344:	8082                	ret
