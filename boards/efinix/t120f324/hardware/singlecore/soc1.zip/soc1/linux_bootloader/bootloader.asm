
build/bootloader.elf:     file format elf32-littleriscv


Disassembly of section .init:

f9000000 <_start>:

_start:
#ifdef USE_GP
.option push
.option norelax
	la gp, __global_pointer$
f9000000:	00001197          	auipc	gp,0x1
f9000004:	d2018193          	addi	gp,gp,-736 # f9000d20 <__global_pointer$>
.global smp_lottery_target
.global smp_lottery_lock
.global smp_slave


  sw x0, smp_lottery_lock, a1
f9000008:	8201a023          	sw	zero,-2016(gp) # f9000540 <smp_lottery_lock>

f900000c <smp_tyranny>:

smp_tyranny:
  csrr a0, mhartid
f900000c:	f1402573          	csrr	a0,mhartid
  beqz a0, init
f9000010:	c515                	beqz	a0,f900003c <init>

f9000012 <smp_slave>:

smp_slave:
	lw a0, smp_lottery_lock
f9000012:	8201a503          	lw	a0,-2016(gp) # f9000540 <smp_lottery_lock>
	beqz a0, smp_slave
f9000016:	dd75                	beqz	a0,f9000012 <smp_slave>

	fence r, r
f9000018:	0220000f          	fence	r,r
f900001c:	0000100f          	fence.i
	//li a1, -1
	//amoadd.w x0, a1,(a0)

	.word(0x100F) //i$ flush
	lw a5, smp_lottery_target
f9000020:	81c1a783          	lw	a5,-2020(gp) # f900053c <__bss_start>
	li a0, 0
f9000024:	4501                	li	a0,0
	li a1, 0
f9000026:	4581                	li	a1,0
	li a2, 0
f9000028:	4601                	li	a2,0
	jr a5
f900002a:	8782                	jr	a5

f900002c <smp_unlock>:

.global   smp_unlock
.type    smp_unlock,%function
smp_unlock:
	sw a0, smp_lottery_target, a1
f900002c:	80a1ae23          	sw	a0,-2020(gp) # f900053c <__bss_start>
	fence w, w
f9000030:	0110000f          	fence	w,w
	li a0, 1
f9000034:	4505                	li	a0,1
	sw a0, smp_lottery_lock, a1
f9000036:	82a1a023          	sw	a0,-2016(gp) # f9000540 <smp_lottery_lock>
    ret
f900003a:	8082                	ret

f900003c <init>:
#endif

init:
	la sp, _sp
f900003c:	93018113          	addi	sp,gp,-1744 # f9000650 <_sp>

	/* Load data section */
	la a0, _data_lma
f9000040:	00000517          	auipc	a0,0x0
f9000044:	48050513          	addi	a0,a0,1152 # f90004c0 <_data>
	la a1, _data
f9000048:	00000597          	auipc	a1,0x0
f900004c:	47858593          	addi	a1,a1,1144 # f90004c0 <_data>
	la a2, _edata
f9000050:	81c18613          	addi	a2,gp,-2020 # f900053c <__bss_start>
	bgeu a1, a2, 2f
f9000054:	00c5fa63          	bgeu	a1,a2,f9000068 <init+0x2c>
1:
	lw t0, (a0)
f9000058:	00052283          	lw	t0,0(a0)
	sw t0, (a1)
f900005c:	0055a023          	sw	t0,0(a1)
	addi a0, a0, 4
f9000060:	0511                	addi	a0,a0,4
	addi a1, a1, 4
f9000062:	0591                	addi	a1,a1,4
	bltu a1, a2, 1b
f9000064:	fec5eae3          	bltu	a1,a2,f9000058 <init+0x1c>
2:

	/* Clear bss section */
	la a0, __bss_start
f9000068:	81c18513          	addi	a0,gp,-2020 # f900053c <__bss_start>
	la a1, _end
f900006c:	82818593          	addi	a1,gp,-2008 # f9000548 <_end>
	bgeu a0, a1, 2f
f9000070:	00b57763          	bgeu	a0,a1,f900007e <init+0x42>
1:
	sw zero, (a0)
f9000074:	00052023          	sw	zero,0(a0)
	addi a0, a0, 4
f9000078:	0511                	addi	a0,a0,4
	bltu a0, a1, 1b
f900007a:	feb56de3          	bltu	a0,a1,f9000074 <init+0x38>
2:

#ifndef NO_LIBC_INIT_ARRAY
	call __libc_init_array
f900007e:	2ee1                	jal	f9000456 <__libc_init_array>
#endif

	call main
f9000080:	26e1                	jal	f9000448 <main>

f9000082 <mainDone>:
mainDone:
    j mainDone
f9000082:	a001                	j	f9000082 <mainDone>

f9000084 <_init>:


	.globl _init
_init:
    ret
f9000084:	8082                	ret

Disassembly of section .text:

f9000086 <uart_writeAvailability>:
#include "type.h"
#include "soc.h"


    static inline u32 read_u32(u32 address){
        return *((volatile u32*) address);
f9000086:	4148                	lw	a0,4(a0)
*          of available spaces for writing data from bits 23 to 16. It then
*          returns this value after masking with 0xFF.
*
******************************************************************************/
    static u32 uart_writeAvailability(u32 reg){
        return (read_u32(reg + UART_STATUS) >> 16) & 0xFF;
f9000088:	8141                	srli	a0,a0,0x10
    }
f900008a:	0ff57513          	andi	a0,a0,255
f900008e:	8082                	ret

f9000090 <uart_write>:
* @note    The function waits until there is available space in the UART buffer
*          for writing data. Once space is available, it writes the character
*          data to the UART data register.
*
******************************************************************************/
    static void uart_write(u32 reg, char data){
f9000090:	1141                	addi	sp,sp,-16
f9000092:	c606                	sw	ra,12(sp)
f9000094:	c422                	sw	s0,8(sp)
f9000096:	c226                	sw	s1,4(sp)
f9000098:	842a                	mv	s0,a0
f900009a:	84ae                	mv	s1,a1
        while(uart_writeAvailability(reg) == 0);
f900009c:	8522                	mv	a0,s0
f900009e:	37e5                	jal	f9000086 <uart_writeAvailability>
f90000a0:	dd75                	beqz	a0,f900009c <uart_write+0xc>
    }
    
    static inline void write_u32(u32 data, u32 address){
        *((volatile u32*) address) = data;
f90000a2:	c004                	sw	s1,0(s0)
        write_u32(data, reg + UART_DATA);
    }
f90000a4:	40b2                	lw	ra,12(sp)
f90000a6:	4422                	lw	s0,8(sp)
f90000a8:	4492                	lw	s1,4(sp)
f90000aa:	0141                	addi	sp,sp,16
f90000ac:	8082                	ret

f90000ae <uart_applyConfig>:
*          value using data length, parity, and stop bit settings from the configuration
*          structure, and writes this value to the UART frame configuration register.
*
******************************************************************************/
    static void uart_applyConfig(u32 reg, Uart_Config *config){
        write_u32(config->clockDivider, reg + UART_CLOCK_DIVIDER);
f90000ae:	45dc                	lw	a5,12(a1)
f90000b0:	c51c                	sw	a5,8(a0)
        write_u32(((config->dataLength-1) << 0) | (config->parity << 8) | (config->stop << 16), reg + UART_FRAME_CONFIG);
f90000b2:	419c                	lw	a5,0(a1)
f90000b4:	17fd                	addi	a5,a5,-1
f90000b6:	41d8                	lw	a4,4(a1)
f90000b8:	0722                	slli	a4,a4,0x8
f90000ba:	8fd9                	or	a5,a5,a4
f90000bc:	4598                	lw	a4,8(a1)
f90000be:	0742                	slli	a4,a4,0x10
f90000c0:	8fd9                	or	a5,a5,a4
f90000c2:	c55c                	sw	a5,12(a0)
    }
f90000c4:	8082                	ret

f90000c6 <clint_uDelay>:
*          and the time limit is non-negative, indicating that the delay has
*          not yet elapsed.
*
******************************************************************************/
    static void clint_uDelay(u32 usec, u32 hz, u32 reg){
        u32 mTimePerUsec = hz/1000000;
f90000c6:	000f47b7          	lui	a5,0xf4
f90000ca:	24078793          	addi	a5,a5,576 # f4240 <__stack_size+0xf4140>
f90000ce:	02f5d5b3          	divu	a1,a1,a5
    readReg_u32 (clint_getTimeLow , CLINT_TIME_ADDR)
f90000d2:	67b1                	lui	a5,0xc
f90000d4:	17e1                	addi	a5,a5,-8
f90000d6:	963e                	add	a2,a2,a5
        return *((volatile u32*) address);
f90000d8:	421c                	lw	a5,0(a2)
        u32 limit = clint_getTimeLow(reg) + usec*mTimePerUsec;
f90000da:	02a58533          	mul	a0,a1,a0
f90000de:	953e                	add	a0,a0,a5
f90000e0:	421c                	lw	a5,0(a2)
        while((int32_t)(limit-(clint_getTimeLow(reg))) >= 0);
f90000e2:	40f507b3          	sub	a5,a0,a5
f90000e6:	fe07dde3          	bgez	a5,f90000e0 <clint_uDelay+0x1a>
f90000ea:	8082                	ret

f90000ec <_putchar>:
#include <math.h>
#include <string.h>
#include "bsp.h"

#if (ENABLE_BSP_PRINTF)
    static void _putchar(char character){
f90000ec:	1141                	addi	sp,sp,-16
f90000ee:	c606                	sw	ra,12(sp)
        #if (ENABLE_SEMIHOSTING_PRINT == 1)
            sh_writec(character);
        #else
            bsp_putChar(character);
f90000f0:	85aa                	mv	a1,a0
f90000f2:	f8010537          	lui	a0,0xf8010
f90000f6:	3f69                	jal	f9000090 <uart_write>
        #endif // (ENABLE_SEMIHOSTING_PRINT == 1)
    }
f90000f8:	40b2                	lw	ra,12(sp)
f90000fa:	0141                	addi	sp,sp,16
f90000fc:	8082                	ret

f90000fe <_putchar_s>:

    static void _putchar_s(char *p)
    {
f90000fe:	1141                	addi	sp,sp,-16
f9000100:	c606                	sw	ra,12(sp)
f9000102:	c422                	sw	s0,8(sp)
f9000104:	842a                	mv	s0,a0
    #if (ENABLE_SEMIHOSTING_PRINT == 1)
        sh_write0(p);
    #else
        while (*p)
f9000106:	00044503          	lbu	a0,0(s0)
f900010a:	c501                	beqz	a0,f9000112 <_putchar_s+0x14>
            _putchar(*(p++));
f900010c:	0405                	addi	s0,s0,1
f900010e:	3ff9                	jal	f90000ec <_putchar>
f9000110:	bfdd                	j	f9000106 <_putchar_s+0x8>
    #endif // (ENABLE_SEMIHOSTING_PRINT == 1)
    }
f9000112:	40b2                	lw	ra,12(sp)
f9000114:	4422                	lw	s0,8(sp)
f9000116:	0141                	addi	sp,sp,16
f9000118:	8082                	ret

f900011a <bsp_printf_s>:
*
* @param s: A pointer to the null-terminated string to be output.
*
*******************************************************************************/
    static void bsp_printf_s(char *p)
    {
f900011a:	1141                	addi	sp,sp,-16
f900011c:	c606                	sw	ra,12(sp)
        _putchar_s(p);
f900011e:	37c5                	jal	f90000fe <_putchar_s>
    }
f9000120:	40b2                	lw	ra,12(sp)
f9000122:	0141                	addi	sp,sp,16
f9000124:	8082                	ret

f9000126 <bsp_init>:
    *   1. UART baudrate
    *   2. 
    */
////////////////////////////////////////////////////////////////////////////////
    static void bsp_init()
    {
f9000126:	1101                	addi	sp,sp,-32
f9000128:	ce06                	sw	ra,28(sp)
        Uart_Config uartConfig;
        uartConfig.dataLength   = BITS_8;
f900012a:	47a1                	li	a5,8
f900012c:	c03e                	sw	a5,0(sp)
        uartConfig.parity       = NONE;
f900012e:	c202                	sw	zero,4(sp)
        uartConfig.stop         = ONE;
f9000130:	c402                	sw	zero,8(sp)
        uartConfig.clockDivider = BSP_CLINT_HZ/(BSP_UART_BAUDRATE*BSP_UART_DATA_LEN)-1;
f9000132:	03500793          	li	a5,53
f9000136:	c63e                	sw	a5,12(sp)
        uart_applyConfig(BSP_UART_TERMINAL, &uartConfig);    
f9000138:	858a                	mv	a1,sp
f900013a:	f8010537          	lui	a0,0xf8010
f900013e:	3f85                	jal	f90000ae <uart_applyConfig>
    }
f9000140:	40f2                	lw	ra,28(sp)
f9000142:	6105                	addi	sp,sp,32
f9000144:	8082                	ret

f9000146 <spi_cmdAvailability>:
f9000146:	4148                	lw	a0,4(a0)
 * @return The availability of command buffer space (lower 16 bits of SPI buffer)
 *
 ******************************************************************************/
    static u32 spi_cmdAvailability(u32 reg){
        return read_u32(reg + SPI_BUFFER) & 0xFFFF;
    }
f9000148:	0542                	slli	a0,a0,0x10
f900014a:	8141                	srli	a0,a0,0x10
f900014c:	8082                	ret

f900014e <spi_rspOccupancy>:
f900014e:	4148                	lw	a0,4(a0)
 * @return The occupancy of response buffer space (upper 16 bits of SPI buffer)
 *
 ******************************************************************************/
    static u32 spi_rspOccupancy(u32 reg){
        return read_u32(reg + SPI_BUFFER) >> 16;
    }
f9000150:	8141                	srli	a0,a0,0x10
f9000152:	8082                	ret

f9000154 <spi_write>:
 * @param reg The base address of the SPI register
 *
 * @param data The data to be written
 *
 ******************************************************************************/
    static void spi_write(u32 reg, u8 data){
f9000154:	1141                	addi	sp,sp,-16
f9000156:	c606                	sw	ra,12(sp)
f9000158:	c422                	sw	s0,8(sp)
f900015a:	c226                	sw	s1,4(sp)
f900015c:	842a                	mv	s0,a0
f900015e:	84ae                	mv	s1,a1
        while(spi_cmdAvailability(reg) == 0);
f9000160:	8522                	mv	a0,s0
f9000162:	37d5                	jal	f9000146 <spi_cmdAvailability>
f9000164:	dd75                	beqz	a0,f9000160 <spi_write+0xc>
        write_u32(data | SPI_CMD_WRITE, reg + SPI_DATA);
f9000166:	1004e493          	ori	s1,s1,256
        *((volatile u32*) address) = data;
f900016a:	c004                	sw	s1,0(s0)
    }
f900016c:	40b2                	lw	ra,12(sp)
f900016e:	4422                	lw	s0,8(sp)
f9000170:	4492                	lw	s1,4(sp)
f9000172:	0141                	addi	sp,sp,16
f9000174:	8082                	ret

f9000176 <spi_read>:
 * @param reg The base address of the SPI register
 *
 * @return The data read from the SPI data register
 *
 ******************************************************************************/   
    static u8 spi_read(u32 reg){
f9000176:	1141                	addi	sp,sp,-16
f9000178:	c606                	sw	ra,12(sp)
f900017a:	c422                	sw	s0,8(sp)
f900017c:	842a                	mv	s0,a0
        while(spi_cmdAvailability(reg) == 0);
f900017e:	8522                	mv	a0,s0
f9000180:	37d9                	jal	f9000146 <spi_cmdAvailability>
f9000182:	dd75                	beqz	a0,f900017e <spi_read+0x8>
f9000184:	20000793          	li	a5,512
f9000188:	c01c                	sw	a5,0(s0)
        write_u32(SPI_CMD_READ, reg + SPI_DATA);
        while(spi_rspOccupancy(reg) == 0);
f900018a:	8522                	mv	a0,s0
f900018c:	37c9                	jal	f900014e <spi_rspOccupancy>
f900018e:	dd75                	beqz	a0,f900018a <spi_read+0x14>
        return *((volatile u32*) address);
f9000190:	4008                	lw	a0,0(s0)
        return read_u32(reg + SPI_DATA);
    }
f9000192:	0ff57513          	andi	a0,a0,255
f9000196:	40b2                	lw	ra,12(sp)
f9000198:	4422                	lw	s0,8(sp)
f900019a:	0141                	addi	sp,sp,16
f900019c:	8082                	ret

f900019e <spi_select>:
 *
 * @param reg The base address of the SPI register
 * @param slaveId The ID of the slave device to select
 *
 ******************************************************************************/
    static void spi_select(u32 reg, u32 slaveId){
f900019e:	1141                	addi	sp,sp,-16
f90001a0:	c606                	sw	ra,12(sp)
f90001a2:	c422                	sw	s0,8(sp)
f90001a4:	c226                	sw	s1,4(sp)
f90001a6:	842a                	mv	s0,a0
f90001a8:	84ae                	mv	s1,a1
        while(spi_cmdAvailability(reg) == 0);
f90001aa:	8522                	mv	a0,s0
f90001ac:	3f69                	jal	f9000146 <spi_cmdAvailability>
f90001ae:	dd75                	beqz	a0,f90001aa <spi_select+0xc>
        write_u32(slaveId | 0x80 | SPI_CMD_SS, reg + SPI_DATA);
f90001b0:	6785                	lui	a5,0x1
f90001b2:	88078793          	addi	a5,a5,-1920 # 880 <__stack_size+0x780>
f90001b6:	8cdd                	or	s1,s1,a5
        *((volatile u32*) address) = data;
f90001b8:	c004                	sw	s1,0(s0)
    }
f90001ba:	40b2                	lw	ra,12(sp)
f90001bc:	4422                	lw	s0,8(sp)
f90001be:	4492                	lw	s1,4(sp)
f90001c0:	0141                	addi	sp,sp,16
f90001c2:	8082                	ret

f90001c4 <spi_diselect>:
 *
 * @param reg The base address of the SPI register
 * @param slaveId The ID of the slave device to deselect
 *
 ******************************************************************************/  
    static void spi_diselect(u32 reg, u32 slaveId){
f90001c4:	1141                	addi	sp,sp,-16
f90001c6:	c606                	sw	ra,12(sp)
f90001c8:	c422                	sw	s0,8(sp)
f90001ca:	c226                	sw	s1,4(sp)
f90001cc:	842a                	mv	s0,a0
f90001ce:	84ae                	mv	s1,a1
        while(spi_cmdAvailability(reg) == 0);
f90001d0:	8522                	mv	a0,s0
f90001d2:	3f95                	jal	f9000146 <spi_cmdAvailability>
f90001d4:	dd75                	beqz	a0,f90001d0 <spi_diselect+0xc>
        write_u32(slaveId | 0x00 | SPI_CMD_SS, reg + SPI_DATA);
f90001d6:	6785                	lui	a5,0x1
f90001d8:	80078793          	addi	a5,a5,-2048 # 800 <__stack_size+0x700>
f90001dc:	8cdd                	or	s1,s1,a5
f90001de:	c004                	sw	s1,0(s0)
    }
f90001e0:	40b2                	lw	ra,12(sp)
f90001e2:	4422                	lw	s0,8(sp)
f90001e4:	4492                	lw	s1,4(sp)
f90001e6:	0141                	addi	sp,sp,16
f90001e8:	8082                	ret

f90001ea <spi_applyConfig>:
 * @param reg The base address of the SPI register
 * @param config Pointer to a Spi_Config structure containing the configuration settings
 *
 ******************************************************************************/
    static void spi_applyConfig(u32 reg, Spi_Config *config){
        write_u32((config->cpol << 0) | (config->cpha << 1) | (config->mode << 4), reg + SPI_CONFIG);
f90001ea:	419c                	lw	a5,0(a1)
f90001ec:	41d8                	lw	a4,4(a1)
f90001ee:	0706                	slli	a4,a4,0x1
f90001f0:	8fd9                	or	a5,a5,a4
f90001f2:	4598                	lw	a4,8(a1)
f90001f4:	0712                	slli	a4,a4,0x4
f90001f6:	8fd9                	or	a5,a5,a4
f90001f8:	c51c                	sw	a5,8(a0)
        write_u32(config->clkDivider, reg + SPI_CLK_DIVIDER);
f90001fa:	45dc                	lw	a5,12(a1)
f90001fc:	d11c                	sw	a5,32(a0)
        write_u32(config->ssSetup, reg + SPI_SS_SETUP);
f90001fe:	499c                	lw	a5,16(a1)
f9000200:	d15c                	sw	a5,36(a0)
        write_u32(config->ssHold, reg + SPI_SS_HOLD);
f9000202:	49dc                	lw	a5,20(a1)
f9000204:	d51c                	sw	a5,40(a0)
        write_u32(config->ssDisable, reg + SPI_SS_DISABLE);
f9000206:	4d9c                	lw	a5,24(a1)
f9000208:	d55c                	sw	a5,44(a0)
    }
f900020a:	8082                	ret

f900020c <spi_waitXferBusy>:
* @brief This function wait for SPI Transfer to complete.
    * 
    * @param reg SPI base address 
*
******************************************************************************/
    static void spi_waitXferBusy(u32 reg){
f900020c:	1141                	addi	sp,sp,-16
f900020e:	c606                	sw	ra,12(sp)
f9000210:	c422                	sw	s0,8(sp)
f9000212:	842a                	mv	s0,a0

#ifdef SYSTEM_SPI_2_IO_CTRL
    	if(reg == SYSTEM_SPI_2_IO_CTRL) cmdFifo_depth = SYSTEM_SPI_2_IO_PARAMETER_CMD_FIFO_DEPTH;
#endif

    	bsp_uDelay(1);
f9000214:	f8b00637          	lui	a2,0xf8b00
f9000218:	02faf5b7          	lui	a1,0x2faf
f900021c:	08058593          	addi	a1,a1,128 # 2faf080 <__stack_size+0x2faef80>
f9000220:	4505                	li	a0,1
f9000222:	3555                	jal	f90000c6 <clint_uDelay>
    	while(spi_cmdAvailability(reg) != cmdFifo_depth);
f9000224:	8522                	mv	a0,s0
f9000226:	3705                	jal	f9000146 <spi_cmdAvailability>
f9000228:	10000793          	li	a5,256
f900022c:	fef51ce3          	bne	a0,a5,f9000224 <spi_waitXferBusy+0x18>
    }
f9000230:	40b2                	lw	ra,12(sp)
f9000232:	4422                	lw	s0,8(sp)
f9000234:	0141                	addi	sp,sp,16
f9000236:	8082                	ret

f9000238 <spiFlash_select>:
    * @param spi SPI port base address 
    * @param cs 32-bit bitwise setting. Set 1 to enable particular bit. 
*
******************************************************************************/

    static void spiFlash_select(u32 spi, u32 cs){
f9000238:	1141                	addi	sp,sp,-16
f900023a:	c606                	sw	ra,12(sp)
        spi_select(spi, cs);
f900023c:	378d                	jal	f900019e <spi_select>
    }
f900023e:	40b2                	lw	ra,12(sp)
f9000240:	0141                	addi	sp,sp,16
f9000242:	8082                	ret

f9000244 <spiFlash_diselect>:
    * 
    * @param spi SPI port base address 
    * @param cs 32-bit bitwise setting. Set 1 to disable particular bit. 
*
******************************************************************************/
    static void spiFlash_diselect(u32 spi, u32 cs){
f9000244:	1141                	addi	sp,sp,-16
f9000246:	c606                	sw	ra,12(sp)
        spi_diselect(spi, cs);
f9000248:	3fb5                	jal	f90001c4 <spi_diselect>
    }
f900024a:	40b2                	lw	ra,12(sp)
f900024c:	0141                	addi	sp,sp,16
f900024e:	8082                	ret

f9000250 <spiFlash_init_>:
* @brief This function initialize SPI port with default settings
    * 
    * @param spi SPI port base address
*
******************************************************************************/
    static void spiFlash_init_(u32 spi){
f9000250:	7179                	addi	sp,sp,-48
f9000252:	d606                	sw	ra,44(sp)
f9000254:	d422                	sw	s0,40(sp)
f9000256:	842a                	mv	s0,a0
        Spi_Config spiCfg;
        spiCfg.cpol = 0;
f9000258:	c202                	sw	zero,4(sp)
        spiCfg.cpha = 0;
f900025a:	c402                	sw	zero,8(sp)
        spiCfg.mode = 0;
f900025c:	c602                	sw	zero,12(sp)
        spiCfg.clkDivider = 2;
f900025e:	4789                	li	a5,2
f9000260:	c83e                	sw	a5,16(sp)
        spiCfg.ssSetup = 5;
f9000262:	4715                	li	a4,5
f9000264:	ca3a                	sw	a4,20(sp)
        spiCfg.ssHold = 2;
f9000266:	cc3e                	sw	a5,24(sp)
        spiCfg.ssDisable = 7;
f9000268:	479d                	li	a5,7
f900026a:	ce3e                	sw	a5,28(sp)
        spi_applyConfig(spi, &spiCfg);
f900026c:	004c                	addi	a1,sp,4
f900026e:	3fb5                	jal	f90001ea <spi_applyConfig>
        spi_waitXferBusy(spi); 
f9000270:	8522                	mv	a0,s0
f9000272:	3f69                	jal	f900020c <spi_waitXferBusy>
    }
f9000274:	50b2                	lw	ra,44(sp)
f9000276:	5422                	lw	s0,40(sp)
f9000278:	6145                	addi	sp,sp,48
f900027a:	8082                	ret

f900027c <spiFlash_init>:
    * @param spi SPI port base address
    * @param gpio GPIO port base address 
    * @param cs 32-bit bitwise chip select setting.
*
******************************************************************************/
    static void spiFlash_init(u32 spi, u32 cs){
f900027c:	1141                	addi	sp,sp,-16
f900027e:	c606                	sw	ra,12(sp)
f9000280:	c422                	sw	s0,8(sp)
f9000282:	c226                	sw	s1,4(sp)
f9000284:	842a                	mv	s0,a0
f9000286:	84ae                	mv	s1,a1
        spiFlash_init_(spi);
f9000288:	37e1                	jal	f9000250 <spiFlash_init_>
        spiFlash_diselect(spi, cs);
f900028a:	85a6                	mv	a1,s1
f900028c:	8522                	mv	a0,s0
f900028e:	3f5d                	jal	f9000244 <spiFlash_diselect>
    }
f9000290:	40b2                	lw	ra,12(sp)
f9000292:	4422                	lw	s0,8(sp)
f9000294:	4492                	lw	s1,4(sp)
f9000296:	0141                	addi	sp,sp,16
f9000298:	8082                	ret

f900029a <spiFlash_wake_>:
*        start communicating with the device.
    * 
    * @param spi SPI port base address
*
******************************************************************************/
    static void spiFlash_wake_(u32 spi){
f900029a:	1141                	addi	sp,sp,-16
f900029c:	c606                	sw	ra,12(sp)
        spi_write(spi, 0xAB);        
f900029e:	0ab00593          	li	a1,171
f90002a2:	3d4d                	jal	f9000154 <spi_write>
    }
f90002a4:	40b2                	lw	ra,12(sp)
f90002a6:	0141                	addi	sp,sp,16
f90002a8:	8082                	ret

f90002aa <spiFlash_wake>:
*
* @param spi SPI port base address
* @param cs 32-bit bitwise chip select setting.
*
******************************************************************************/
    static void spiFlash_wake(u32 spi, u32 cs){
f90002aa:	1141                	addi	sp,sp,-16
f90002ac:	c606                	sw	ra,12(sp)
f90002ae:	c422                	sw	s0,8(sp)
f90002b0:	c226                	sw	s1,4(sp)
f90002b2:	842a                	mv	s0,a0
f90002b4:	84ae                	mv	s1,a1
        spiFlash_select(spi,cs);
f90002b6:	3749                	jal	f9000238 <spiFlash_select>
        spiFlash_wake_(spi);
f90002b8:	8522                	mv	a0,s0
f90002ba:	37c5                	jal	f900029a <spiFlash_wake_>
        spiFlash_diselect(spi,cs);
f90002bc:	85a6                	mv	a1,s1
f90002be:	8522                	mv	a0,s0
f90002c0:	3751                	jal	f9000244 <spiFlash_diselect>
        spi_waitXferBusy(spi);
f90002c2:	8522                	mv	a0,s0
f90002c4:	37a1                	jal	f900020c <spi_waitXferBusy>
        bsp_uDelay(100); // make sure the Flash fully awake
f90002c6:	f8b00637          	lui	a2,0xf8b00
f90002ca:	02faf5b7          	lui	a1,0x2faf
f90002ce:	08058593          	addi	a1,a1,128 # 2faf080 <__stack_size+0x2faef80>
f90002d2:	06400513          	li	a0,100
f90002d6:	3bc5                	jal	f90000c6 <clint_uDelay>
    }
f90002d8:	40b2                	lw	ra,12(sp)
f90002da:	4422                	lw	s0,8(sp)
f90002dc:	4492                	lw	s1,4(sp)
f90002de:	0141                	addi	sp,sp,16
f90002e0:	8082                	ret

f90002e2 <spiFlash_f2m_>:
    * @param flashAddress The flash address to read the data
    * @param memoryAddress The RAM address to write the data
    * @param size The size of data to copy
*
******************************************************************************/
    static void spiFlash_f2m_(u32 spi, u32 flashAddress, u32 memoryAddress, u32 size){
f90002e2:	1101                	addi	sp,sp,-32
f90002e4:	ce06                	sw	ra,28(sp)
f90002e6:	cc22                	sw	s0,24(sp)
f90002e8:	ca26                	sw	s1,20(sp)
f90002ea:	c84a                	sw	s2,16(sp)
f90002ec:	c64e                	sw	s3,12(sp)
f90002ee:	892a                	mv	s2,a0
f90002f0:	84ae                	mv	s1,a1
f90002f2:	8432                	mv	s0,a2
f90002f4:	89b6                	mv	s3,a3
        spi_write(spi, 0x0B);
f90002f6:	45ad                	li	a1,11
f90002f8:	3db1                	jal	f9000154 <spi_write>
        spi_write(spi, flashAddress >> 16);
f90002fa:	0104d593          	srli	a1,s1,0x10
f90002fe:	0ff5f593          	andi	a1,a1,255
f9000302:	854a                	mv	a0,s2
f9000304:	3d81                	jal	f9000154 <spi_write>
        spi_write(spi, flashAddress >>  8);
f9000306:	0084d593          	srli	a1,s1,0x8
f900030a:	0ff5f593          	andi	a1,a1,255
f900030e:	854a                	mv	a0,s2
f9000310:	3591                	jal	f9000154 <spi_write>
        spi_write(spi, flashAddress >>  0);
f9000312:	0ff4f593          	andi	a1,s1,255
f9000316:	854a                	mv	a0,s2
f9000318:	3d35                	jal	f9000154 <spi_write>
        spi_write(spi, 0);
f900031a:	4581                	li	a1,0
f900031c:	854a                	mv	a0,s2
f900031e:	3d1d                	jal	f9000154 <spi_write>
        uint8_t *ram = (uint8_t *) memoryAddress;
        for(u32 idx = 0;idx < size;idx++){
f9000320:	4481                	li	s1,0
f9000322:	0134f963          	bgeu	s1,s3,f9000334 <spiFlash_f2m_+0x52>
            u8 value = spi_read(spi);
f9000326:	854a                	mv	a0,s2
f9000328:	35b9                	jal	f9000176 <spi_read>
            *ram++ = value;
f900032a:	00a40023          	sb	a0,0(s0)
        for(u32 idx = 0;idx < size;idx++){
f900032e:	0485                	addi	s1,s1,1
            *ram++ = value;
f9000330:	0405                	addi	s0,s0,1
f9000332:	bfc5                	j	f9000322 <spiFlash_f2m_+0x40>
        }
    }
f9000334:	40f2                	lw	ra,28(sp)
f9000336:	4462                	lw	s0,24(sp)
f9000338:	44d2                	lw	s1,20(sp)
f900033a:	4942                	lw	s2,16(sp)
f900033c:	49b2                	lw	s3,12(sp)
f900033e:	6105                	addi	sp,sp,32
f9000340:	8082                	ret

f9000342 <spiFlash_f2m>:
* @param flashAddress The flash address to read the data
* @param memoryAddress The RAM address to write the data
* @param size The size of data to copy
*
******************************************************************************/
    static void spiFlash_f2m(u32 spi, u32 cs, u32 flashAddress, u32 memoryAddress, u32 size){
f9000342:	1101                	addi	sp,sp,-32
f9000344:	ce06                	sw	ra,28(sp)
f9000346:	cc22                	sw	s0,24(sp)
f9000348:	ca26                	sw	s1,20(sp)
f900034a:	c84a                	sw	s2,16(sp)
f900034c:	c64e                	sw	s3,12(sp)
f900034e:	c452                	sw	s4,8(sp)
f9000350:	842a                	mv	s0,a0
f9000352:	84ae                	mv	s1,a1
f9000354:	8932                	mv	s2,a2
f9000356:	89b6                	mv	s3,a3
f9000358:	8a3a                	mv	s4,a4
        spiFlash_select(spi,cs);
f900035a:	3df9                	jal	f9000238 <spiFlash_select>
        spiFlash_f2m_(spi, flashAddress, memoryAddress, size);
f900035c:	86d2                	mv	a3,s4
f900035e:	864e                	mv	a2,s3
f9000360:	85ca                	mv	a1,s2
f9000362:	8522                	mv	a0,s0
f9000364:	3fbd                	jal	f90002e2 <spiFlash_f2m_>
        spiFlash_diselect(spi,cs);
f9000366:	85a6                	mv	a1,s1
f9000368:	8522                	mv	a0,s0
f900036a:	3de9                	jal	f9000244 <spiFlash_diselect>
    }
f900036c:	40f2                	lw	ra,28(sp)
f900036e:	4462                	lw	s0,24(sp)
f9000370:	44d2                	lw	s1,20(sp)
f9000372:	4942                	lw	s2,16(sp)
f9000374:	49b2                	lw	s3,12(sp)
f9000376:	4a22                	lw	s4,8(sp)
f9000378:	6105                	addi	sp,sp,32
f900037a:	8082                	ret

f900037c <configure_uart>:

#define UART_0_SAMPLE_PER_BAUD  8
#define UART_0_BAUD_RATE        115200

void configure_uart()
{
f900037c:	1101                	addi	sp,sp,-32
f900037e:	ce06                	sw	ra,28(sp)
    Uart_Config uart0;
    uart0.dataLength = BITS_8;
f9000380:	47a1                	li	a5,8
f9000382:	c03e                	sw	a5,0(sp)
    uart0.parity = NONE;
f9000384:	c202                	sw	zero,4(sp)
    uart0.stop = ONE;
f9000386:	c402                	sw	zero,8(sp)
    uart0.clockDivider = BSP_CLINT_HZ/(UART_0_BAUD_RATE * UART_0_SAMPLE_PER_BAUD) - 1;
f9000388:	03500793          	li	a5,53
f900038c:	c63e                	sw	a5,12(sp)
    uart_applyConfig(BSP_UART_TERMINAL, &uart0);
f900038e:	858a                	mv	a1,sp
f9000390:	f8010537          	lui	a0,0xf8010
f9000394:	3b29                	jal	f90000ae <uart_applyConfig>
}
f9000396:	40f2                	lw	ra,28(sp)
f9000398:	6105                	addi	sp,sp,32
f900039a:	8082                	ret

f900039c <bspMain>:


void bspMain()
{
f900039c:	1141                	addi	sp,sp,-16
f900039e:	c606                	sw	ra,12(sp)
    configure_uart();
f90003a0:	3ff1                	jal	f900037c <configure_uart>

#ifdef __riscv_xlen
#if __riscv_xlen == 64
    bsp_printf_s("RISC-V: 64 bit\r\n");
#elif __riscv_xlen == 32
    bsp_printf_s("RISC-V: 32 bit\r\n");
f90003a2:	f9000537          	lui	a0,0xf9000
f90003a6:	4c050513          	addi	a0,a0,1216 # f90004c0 <__global_pointer$+0xfffff7a0>
f90003aa:	3b85                	jal	f900011a <bsp_printf_s>
#endif
#endif

    bsp_printf_s("Compiled: ");
f90003ac:	f9000537          	lui	a0,0xf9000
f90003b0:	4d450513          	addi	a0,a0,1236 # f90004d4 <__global_pointer$+0xfffff7b4>
f90003b4:	339d                	jal	f900011a <bsp_printf_s>
    bsp_printf_s(__DATE__);
f90003b6:	f9000537          	lui	a0,0xf9000
f90003ba:	4e050513          	addi	a0,a0,1248 # f90004e0 <__global_pointer$+0xfffff7c0>
f90003be:	3bb1                	jal	f900011a <bsp_printf_s>
    bsp_printf_s(" ");
f90003c0:	f9000537          	lui	a0,0xf9000
f90003c4:	4ec50513          	addi	a0,a0,1260 # f90004ec <__global_pointer$+0xfffff7cc>
f90003c8:	3b89                	jal	f900011a <bsp_printf_s>
    bsp_printf_s(__TIME__);
f90003ca:	f9000537          	lui	a0,0xf9000
f90003ce:	4f050513          	addi	a0,a0,1264 # f90004f0 <__global_pointer$+0xfffff7d0>
f90003d2:	33a1                	jal	f900011a <bsp_printf_s>
    bsp_printf_s("\r\n");
f90003d4:	80818513          	addi	a0,gp,-2040 # f9000528 <_data+0x68>
f90003d8:	3389                	jal	f900011a <bsp_printf_s>

    spiFlash_init(SPI, SPI_CS);
f90003da:	4581                	li	a1,0
f90003dc:	f8014537          	lui	a0,0xf8014
f90003e0:	3d71                	jal	f900027c <spiFlash_init>
    spiFlash_wake(SPI, SPI_CS);
f90003e2:	4581                	li	a1,0
f90003e4:	f8014537          	lui	a0,0xf8014
f90003e8:	35c9                	jal	f90002aa <spiFlash_wake>
    bsp_printf_s("OpenSBI copy\r\n");
f90003ea:	f9000537          	lui	a0,0xf9000
f90003ee:	4fc50513          	addi	a0,a0,1276 # f90004fc <__global_pointer$+0xfffff7dc>
f90003f2:	3325                	jal	f900011a <bsp_printf_s>
    spiFlash_f2m(SPI, SPI_CS, OPENSBI_FLASH, OPENSBI_MEMORY, OPENSBI_SIZE);
f90003f4:	00040737          	lui	a4,0x40
f90003f8:	020006b7          	lui	a3,0x2000
f90003fc:	00600637          	lui	a2,0x600
f9000400:	4581                	li	a1,0
f9000402:	f8014537          	lui	a0,0xf8014
f9000406:	3f35                	jal	f9000342 <spiFlash_f2m>
    bsp_printf_s("U-Boot copy\r\n");
f9000408:	f9000537          	lui	a0,0xf9000
f900040c:	50c50513          	addi	a0,a0,1292 # f900050c <__global_pointer$+0xfffff7ec>
f9000410:	3329                	jal	f900011a <bsp_printf_s>
    spiFlash_f2m(SPI, SPI_CS, UBOOT_SBI_FLASH, UBOOT_MEMORY, UBOOT_SIZE);
f9000412:	000c0737          	lui	a4,0xc0
f9000416:	020406b7          	lui	a3,0x2040
f900041a:	00680637          	lui	a2,0x680
f900041e:	4581                	li	a1,0
f9000420:	f8014537          	lui	a0,0xf8014
f9000424:	3f39                	jal	f9000342 <spiFlash_f2m>

    bsp_printf_s("Payload boot\r\n");
f9000426:	f9000537          	lui	a0,0xf9000
f900042a:	51c50513          	addi	a0,a0,1308 # f900051c <__global_pointer$+0xfffff7fc>
f900042e:	31f5                	jal	f900011a <bsp_printf_s>
#elif __riscv_xlen == 32
    void (*userMain)(u32, u32, u32) = (void (*)(u32, u32, u32))OPENSBI_MEMORY;
#endif

#ifdef SMP
    smp_unlock(userMain);
f9000430:	02000537          	lui	a0,0x2000
f9000434:	3ee5                	jal	f900002c <smp_unlock>
#endif
    userMain(0, 0, 0);
f9000436:	4601                	li	a2,0
f9000438:	4581                	li	a1,0
f900043a:	4501                	li	a0,0
f900043c:	020007b7          	lui	a5,0x2000
f9000440:	9782                	jalr	a5
}
f9000442:	40b2                	lw	ra,12(sp)
f9000444:	0141                	addi	sp,sp,16
f9000446:	8082                	ret

f9000448 <main>:
******************************************************************************/
#include "type.h"
#include "bsp.h"
#include "bootloaderConfig.h"

void main() {
f9000448:	1141                	addi	sp,sp,-16
f900044a:	c606                	sw	ra,12(sp)
    bsp_init();
f900044c:	39e9                	jal	f9000126 <bsp_init>
    bspMain();
f900044e:	37b9                	jal	f900039c <bspMain>
}
f9000450:	40b2                	lw	ra,12(sp)
f9000452:	0141                	addi	sp,sp,16
f9000454:	8082                	ret

f9000456 <__libc_init_array>:
f9000456:	1141                	addi	sp,sp,-16
f9000458:	c422                	sw	s0,8(sp)
f900045a:	c04a                	sw	s2,0(sp)
f900045c:	00000417          	auipc	s0,0x0
f9000460:	06440413          	addi	s0,s0,100 # f90004c0 <_data>
f9000464:	00000917          	auipc	s2,0x0
f9000468:	05c90913          	addi	s2,s2,92 # f90004c0 <_data>
f900046c:	40890933          	sub	s2,s2,s0
f9000470:	c606                	sw	ra,12(sp)
f9000472:	c226                	sw	s1,4(sp)
f9000474:	40295913          	srai	s2,s2,0x2
f9000478:	00090963          	beqz	s2,f900048a <__libc_init_array+0x34>
f900047c:	4481                	li	s1,0
f900047e:	401c                	lw	a5,0(s0)
f9000480:	0485                	addi	s1,s1,1
f9000482:	0411                	addi	s0,s0,4
f9000484:	9782                	jalr	a5
f9000486:	fe991ce3          	bne	s2,s1,f900047e <__libc_init_array+0x28>
f900048a:	00000417          	auipc	s0,0x0
f900048e:	03640413          	addi	s0,s0,54 # f90004c0 <_data>
f9000492:	00000917          	auipc	s2,0x0
f9000496:	02e90913          	addi	s2,s2,46 # f90004c0 <_data>
f900049a:	40890933          	sub	s2,s2,s0
f900049e:	40295913          	srai	s2,s2,0x2
f90004a2:	00090963          	beqz	s2,f90004b4 <__libc_init_array+0x5e>
f90004a6:	4481                	li	s1,0
f90004a8:	401c                	lw	a5,0(s0)
f90004aa:	0485                	addi	s1,s1,1
f90004ac:	0411                	addi	s0,s0,4
f90004ae:	9782                	jalr	a5
f90004b0:	fe991ce3          	bne	s2,s1,f90004a8 <__libc_init_array+0x52>
f90004b4:	40b2                	lw	ra,12(sp)
f90004b6:	4422                	lw	s0,8(sp)
f90004b8:	4492                	lw	s1,4(sp)
f90004ba:	4902                	lw	s2,0(sp)
f90004bc:	0141                	addi	sp,sp,16
f90004be:	8082                	ret
