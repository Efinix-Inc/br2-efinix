#pragma once

extern void smp_unlock(void (*userMain)(u32, u32, u32) );