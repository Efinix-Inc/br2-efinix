#pragma once

#define SPI SYSTEM_SPI_0_IO_APB